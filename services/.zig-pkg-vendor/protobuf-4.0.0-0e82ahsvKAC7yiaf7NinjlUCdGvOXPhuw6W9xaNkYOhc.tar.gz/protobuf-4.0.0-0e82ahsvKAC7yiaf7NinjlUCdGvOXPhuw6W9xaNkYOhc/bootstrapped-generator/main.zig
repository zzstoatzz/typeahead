const warn = @import("std").debug.warn;
const std = @import("std");
const pb = @import("protobuf");
const plugin = @import("google/protobuf/compiler.pb.zig");
const descriptor = @import("google/protobuf.pb.zig");
const mem = std.mem;
const FullName = @import("./FullName.zig").FullName;

pub const std_options: std.Options = .{ .log_scope_levels = &[_]std.log.ScopeLevel{.{ .level = .warn, .scope = .zig_protobuf }} };

pub fn main() !void {
    var stdin_buf: [4096]u8 = undefined;
    var stdin = std.fs.File.stdin().reader(&stdin_buf);

    const allocator = std.heap.smp_allocator;

    const request: plugin.CodeGeneratorRequest = try .decode(
        &stdin.interface,
        allocator,
    );

    var ctx: GenerationContext = try .init(allocator, request);

    try ctx.processRequest(allocator);

    var stdout_buf: [4096]u8 = undefined;
    var stdout = std.fs.File.stdout().writer(&stdout_buf);
    try ctx.res.encode(&stdout.interface, allocator);
    try stdout.interface.flush();
}

const GenerationContext = struct {
    req: plugin.CodeGeneratorRequest,
    res: plugin.CodeGeneratorResponse,

    /// map of known packages
    known_packages: std.StringHashMap(FullName),

    /// map of "package.fully.qualified.names" to output string lines
    fqn_lines: std.StringHashMap(std.ArrayList([]const u8)),

    /// map of message names to their dependencies
    message_deps: std.StringHashMap(std.ArrayList([]const u8)),

    /// Helper struct for working with SourceCodeInfo
    const SourceCodeInfo = struct {
        /// Appends a comment as doc-comment lines (///) to the output
        fn appendComment(allocator: std.mem.Allocator, lines: *std.ArrayList([]const u8), raw_comment: []const u8) !void {
            // Trim trailing newlines from the comment first
            var trimmed = raw_comment;
            while (trimmed.len > 0 and trimmed[trimmed.len - 1] == '\n') {
                trimmed = trimmed[0 .. trimmed.len - 1];
            }

            var comment_lines = std.mem.splitScalar(u8, trimmed, '\n');

            while (comment_lines.next()) |comment_line| {
                // Strip leading forward slashes that protobuf includes from the source
                var line = comment_line;
                while (line.len > 0 and (line[0] == '/' or line[0] == ' ')) {
                    line = line[1..];
                }

                // Use /// for doc comments as per issue discussion
                try lines.append(allocator, try std.fmt.allocPrint(
                    allocator,
                    "/// {s}\n",
                    .{line},
                ));
            }
        }

        /// Get source code location for an item in a repeated field
        fn getRepeatedFieldLocation(
            file: descriptor.FileDescriptorProto,
            root_path: []const i32,
            field_number: i32,
            index: usize,
        ) ?descriptor.SourceCodeInfo.Location {
            const sci = file.source_code_info orelse return null;

            for (sci.location.items) |location| {
                const path = location.path.items;

                if (path.len != root_path.len + 2) continue;
                if (!std.mem.eql(i32, root_path, path[0..root_path.len]))
                    continue;

                const rem_path = path[root_path.len..];

                if (rem_path[0] != field_number) continue;
                if (rem_path[1] != @as(i32, @intCast(index))) continue;

                return location;
            }

            return null;
        }
    };

    pub fn init(allocator: std.mem.Allocator, request: plugin.CodeGeneratorRequest) !GenerationContext {
        return .{
            .req = request,
            .res = .{},
            .known_packages = .init(allocator),
            .fqn_lines = .init(allocator),
            .message_deps = .init(allocator),
        };
    }

    pub fn processRequest(self: *GenerationContext, allocator: std.mem.Allocator) !void {
        defer {
            // Clean up message dependencies
            var it = self.message_deps.iterator();
            while (it.next()) |entry| {
                entry.value_ptr.deinit(allocator);
            }
            self.message_deps.deinit();
        }

        for (self.req.proto_file.items) |file| {
            const t: descriptor.FileDescriptorProto = file;

            if (t.package) |package| {
                try self.known_packages.put(package, FullName{ .buf = package });
            } else {
                self.res.@"error" = try std.fmt.allocPrint(
                    allocator,
                    "ERROR Package directive missing in {s}\n",
                    .{file.name.?},
                );
                return;
            }
        }

        for (self.req.proto_file.items) |file| {
            const t: descriptor.FileDescriptorProto = file;

            const name = FullName{ .buf = t.package.? };

            try self.printFileDeclarations(allocator, name, file);
        }

        var it = self.fqn_lines.iterator();
        while (it.next()) |entry| {
            var ret: plugin.CodeGeneratorResponse.File = .{};
            var name_buf: [std.fs.max_path_bytes]u8 = undefined;

            ret.name = try allocator.dupe(u8, packageToFileName(entry.key_ptr.*, &name_buf));
            ret.content = try std.mem.concat(allocator, u8, entry.value_ptr.*.items);

            try self.res.file.append(allocator, ret);
        }

        self.res.supported_features = @intFromEnum(plugin.CodeGeneratorResponse.Feature.FEATURE_PROTO3_OPTIONAL);
    }

    fn getOutputLines(self: *GenerationContext, allocator: std.mem.Allocator, name: FullName) !*std.ArrayList([]const u8) {
        const entry = try self.fqn_lines.getOrPut(name.buf);

        if (!entry.found_existing) {
            var lines: std.ArrayList([]const u8) = .empty;

            try lines.append(allocator, try std.fmt.allocPrint(allocator,
                \\// Code generated by protoc-gen-zig
                \\ ///! package {s}
                \\const std = @import("std");
                \\
                \\const protobuf = @import("protobuf");
                \\const fd = protobuf.fd;
                \\
            , .{name.buf}));

            // collect all imports from all files sharing the same package
            var importedPackages: std.StringHashMap(bool) = .init(allocator);

            for (self.req.proto_file.items) |file| {
                if (name.eqlString(file.package.?)) {
                    for (file.dependency.items) |dep| {
                        for (self.req.proto_file.items, 0..) |item, index| {
                            if (std.mem.eql(u8, dep, item.name.?)) {
                                var is_public_dep: bool = false;

                                // find whether an import is marked as public
                                for (file.public_dependency.items) |public_dep| {
                                    if (public_dep == index) {
                                        is_public_dep = true;
                                    }
                                }

                                try importedPackages.put(item.package.?, is_public_dep);
                            }
                        }
                    }
                }
            }

            var it = importedPackages.iterator();
            while (it.next()) |package| {
                if (!std.mem.eql(u8, package.key_ptr.*, name.buf)) {
                    try lines.append(
                        allocator,
                        try std.fmt.allocPrint(
                            allocator,
                            "/// import package {s}\n",
                            .{package.key_ptr.*},
                        ),
                    );

                    const optional_pub_directive: []const u8 = if (package.value_ptr.*) "pub const" else "const";

                    try lines.append(allocator, try std.fmt.allocPrint(
                        allocator,
                        "{s} {!s} = @import(\"{!s}\");\n",
                        .{
                            optional_pub_directive,
                            escapeFqn(allocator, package.key_ptr.*),
                            self.resolvePath(allocator, name.buf, package.key_ptr.*),
                        },
                    ));
                }
            }

            entry.value_ptr.* = lines;
        }

        return entry.value_ptr;
    }

    /// resolves an import path from the file A relative to B
    fn resolvePath(_: *GenerationContext, allocator: std.mem.Allocator, a: []const u8, b: []const u8) ![]const u8 {
        var a_path_buf: [std.fs.max_path_bytes]u8 = undefined;
        var b_path_buf: [std.fs.max_path_bytes]u8 = undefined;

        const aPath = std.fs.path.dirname(packageToFileName(a, &a_path_buf)) orelse "";
        const bPath = packageToFileName(b, &b_path_buf);

        // to resolve some escaping oddities, the windows path separator is canonicalized to /
        const resolvedRelativePath = try std.fs.path.relative(allocator, aPath, bPath);
        return std.mem.replaceOwned(u8, allocator, resolvedRelativePath, "\\", "/");
    }

    pub fn printFileDeclarations(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
    ) !void {
        const lines = try self.getOutputLines(allocator, fqn);

        // For file-level elements, root_path is empty
        const file_root_path: []const i32 = &.{};
        // Field number 5 for enum_type in FileDescriptorProto
        try self.generateEnums(allocator, lines, fqn, file, file.enum_type, file_root_path, 5);
        // Field number 4 for message_type in FileDescriptorProto
        try self.generateMessages(allocator, lines, fqn, file, file.message_type, file_root_path, 4);
    }

    fn generateEnums(
        ctx: *GenerationContext,
        allocator: std.mem.Allocator,
        lines: *std.ArrayList([]const u8),
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
        enums: std.ArrayListUnmanaged(descriptor.EnumDescriptorProto),
        root_path: []const i32,
        enum_field_number: i32,
    ) !void {
        _ = ctx;
        _ = fqn;

        for (enums.items, 0..) |theEnum, enum_i| {
            const e: descriptor.EnumDescriptorProto = theEnum;

            try lines.append(allocator, "\n");

            // Add leading comment if available
            if (SourceCodeInfo.getRepeatedFieldLocation(
                file,
                root_path,
                enum_field_number,
                enum_i,
            )) |loc| {
                if (loc.leading_comments) |leading_comments| {
                    try SourceCodeInfo.appendComment(allocator, lines, leading_comments);
                }
            }

            try lines.append(
                allocator,
                try std.fmt.allocPrint(allocator, "pub const {s} = enum(i32) {{\n", .{e.name.?}),
            );

            for (e.value.items) |elem| {
                try lines.append(
                    allocator,
                    try std.fmt.allocPrint(allocator, "   {s} = {},\n", .{ elem.name.?, elem.number orelse 0 }),
                );
            }

            try lines.append(allocator, "    _,\n};\n\n");
        }
    }

    fn escapeName(allocator: std.mem.Allocator, name: []const u8) ![]const u8 {
        if (std.zig.Token.keywords.get(name)) |_|
            return try std.fmt.allocPrint(allocator, "@\"{s}\"", .{name})
        else
            return name;
    }

    fn fieldTypeFqn(
        ctx: *GenerationContext,
        allocator: std.mem.Allocator,
        parentFqn: FullName,
        file: descriptor.FileDescriptorProto,
        field: descriptor.FieldDescriptorProto,
    ) ![]const u8 {
        if (field.type_name) |typeName| {
            const fullTypeName = FullName{ .buf = typeName[1..] };
            if (fullTypeName.parent()) |parent| {
                if (parent.eql(parentFqn)) {
                    const diff_idx = std.mem.indexOfDiff(
                        u8,
                        fullTypeName.buf,
                        file.package.?,
                    ).?;
                    return fullTypeName.buf[diff_idx + 1 ..];
                }
                if (parent.eql(FullName{ .buf = file.package.? })) {
                    return fullTypeName.name().buf;
                }
            }

            var parent: ?FullName = fullTypeName.parent();
            const filePackage = FullName{ .buf = file.package.? };

            // iterate parents until we find a parent that matches the known_packages
            while (parent != null) {
                var it = ctx.known_packages.valueIterator();

                while (it.next()) |value| {

                    // it is in current package, return full name
                    if (filePackage.eql(parent.?)) {
                        const name = fullTypeName.buf[parent.?.buf.len + 1 ..];
                        return name;
                    }

                    // it is in different package. return fully qualified name including accessor
                    if (value.eql(parent.?)) {
                        const prop = try escapeFqn(allocator, parent.?.buf);
                        const name = fullTypeName.buf[prop.len + 1 ..];
                        return try std.fmt.allocPrint(allocator, "{s}.{s}", .{ prop, name });
                    }
                }

                parent = parent.?.parent();
            }

            std.debug.print("Unknown type: {s} from {s} in {s}\n", .{ fullTypeName.buf, parentFqn.buf, file.package.? });

            return try escapeFqn(allocator, field.type_name.?);
        }
        @panic("field has no type");
    }

    fn getFieldType(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
        field: descriptor.FieldDescriptorProto,
        is_union: bool,
    ) ![]const u8 {
        var prefix: []const u8 = "";
        var postfix: []const u8 = "";
        const repeated = isRepeated(field);
        const t = field.type.?;

        if (!repeated) {
            if (!is_union) {
                // look for optional types
                switch (t) {
                    .TYPE_MESSAGE => {
                        // Check if the field type is self-referential
                        if (field.type_name) |type_name| {
                            const raw_type = type_name;
                            const dep_name = raw_type[1..]; // Remove leading dot
                            const last_dot = std.mem.lastIndexOf(u8, dep_name, ".");
                            const simple_name = if (last_dot) |idx| dep_name[idx + 1 ..] else dep_name;

                            // Get the current message name from fqn
                            const current_msg = fqn.name().buf;

                            if (std.mem.eql(u8, simple_name, current_msg)) {
                                prefix = "?*";
                            } else {
                                prefix = "?";
                            }
                        } else {
                            prefix = "?";
                        }
                    },
                    else => if (isOptional(file, field)) {
                        prefix = "?";
                    },
                }
            }
        } else {
            prefix = "std.ArrayListUnmanaged(";
            postfix = ")";
        }

        const infix: []const u8 = switch (t) {
            .TYPE_SINT32, .TYPE_SFIXED32, .TYPE_INT32 => "i32",
            .TYPE_UINT32, .TYPE_FIXED32 => "u32",
            .TYPE_INT64, .TYPE_SINT64, .TYPE_SFIXED64 => "i64",
            .TYPE_UINT64, .TYPE_FIXED64 => "u64",
            .TYPE_BOOL => "bool",
            .TYPE_DOUBLE => "f64",
            .TYPE_FLOAT => "f32",
            .TYPE_STRING, .TYPE_BYTES => "[]const u8",
            .TYPE_ENUM, .TYPE_MESSAGE => try self.fieldTypeFqn(allocator, fqn, file, field),
            else => {
                std.debug.print("Unrecognized type {}\n", .{t});
                @panic("Unrecognized type");
            },
        };

        return try std.mem.concat(allocator, u8, &.{ prefix, infix, postfix });
    }

    fn getFieldDefault(
        _: *GenerationContext,
        allocator: std.mem.Allocator,
        field: descriptor.FieldDescriptorProto,
        file: descriptor.FileDescriptorProto,
        nullable: bool,
    ) !?[]const u8 {
        const is_proto3 = is_proto3_file(file);

        // All repeated fields, across proto2/proto3/editions, have a default
        // of empty. Repeated fields cannot be marked required (or optional)
        // in proto2.
        const repeated = isRepeated(field);
        if (repeated) {
            if (field.default_value) |default| {
                return default;
            } else return ".empty";
        }

        if (nullable and field.default_value == null) {
            return "null";
        }

        // proto3 does not support explicit default values, the default scalar values are used instead.
        if (is_proto3) {
            return switch (field.type.?) {
                .TYPE_SINT32,
                .TYPE_SFIXED32,
                .TYPE_INT32,
                .TYPE_UINT32,
                .TYPE_FIXED32,
                .TYPE_INT64,
                .TYPE_SINT64,
                .TYPE_SFIXED64,
                .TYPE_UINT64,
                .TYPE_FIXED64,
                .TYPE_FLOAT,
                .TYPE_DOUBLE,
                => "0",
                .TYPE_BOOL => "false",
                .TYPE_STRING, .TYPE_BYTES => "&.{}",
                .TYPE_ENUM => "@enumFromInt(0)",
                else => null,
            };
        }

        if (field.default_value == null) {
            return null;
        }

        return switch (field.type.?) {
            .TYPE_SINT32,
            .TYPE_SFIXED32,
            .TYPE_INT32,
            .TYPE_UINT32,
            .TYPE_FIXED32,
            .TYPE_INT64,
            .TYPE_SINT64,
            .TYPE_SFIXED64,
            .TYPE_UINT64,
            .TYPE_FIXED64,
            .TYPE_BOOL,
            => field.default_value.?,
            .TYPE_FLOAT => if (std.mem.eql(u8, field.default_value.?, "inf"))
                "std.math.inf(f32)"
            else if (std.mem.eql(u8, field.default_value.?, "-inf"))
                "-std.math.inf(f32)"
            else if (std.mem.eql(u8, field.default_value.?, "nan"))
                "std.math.nan(f32)"
            else
                field.default_value.?,
            .TYPE_DOUBLE => if (std.mem.eql(u8, field.default_value.?, "inf"))
                "std.math.inf(f64)"
            else if (std.mem.eql(u8, field.default_value.?, "-inf"))
                "-std.math.inf(f64)"
            else if (std.mem.eql(u8, field.default_value.?, "nan"))
                "std.math.nan(f64)"
            else
                field.default_value.?,
            .TYPE_STRING, .TYPE_BYTES => if (field.default_value.?.len == 0)
                "&.{}"
            else
                try formatSliceEscapeImpl(allocator, field.default_value.?),
            .TYPE_ENUM => try std.mem.concat(allocator, u8, &.{ ".", field.default_value.? }),
            else => null,
        };
    }

    fn getFieldTypeDescriptor(
        _: *GenerationContext,
        allocator: std.mem.Allocator,
        _: FullName,
        file: descriptor.FileDescriptorProto,
        field: descriptor.FieldDescriptorProto,
        is_union: bool,
    ) ![]const u8 {
        _ = is_union;
        var prefix: []const u8 = "";

        var postfix: []const u8 = "";

        if (isRepeated(field)) {
            if (isPacked(file, field)) {
                prefix = ".{ .packed_repeated = ";
            } else {
                prefix = ".{ .repeated = ";
            }
            postfix = "}";
        }

        const infix: []const u8 = switch (field.type.?) {
            .TYPE_FLOAT => ".{ .scalar = .float }",
            .TYPE_DOUBLE => ".{ .scalar = .double }",
            .TYPE_FIXED32 => ".{ .scalar = .fixed32 }",
            .TYPE_SFIXED32 => ".{ .scalar = .sfixed32 }",
            .TYPE_FIXED64 => ".{ .scalar = .fixed64 }",
            .TYPE_SFIXED64 => ".{ .scalar = .sfixed64 }",
            .TYPE_ENUM => ".@\"enum\"",
            .TYPE_UINT32 => ".{ .scalar = .uint32 }",
            .TYPE_UINT64 => ".{ .scalar = .uint64 }",
            .TYPE_BOOL => ".{ .scalar = .bool }",
            .TYPE_INT32 => ".{ .scalar = .int32 }",
            .TYPE_INT64 => ".{ .scalar = .int64 }",
            .TYPE_SINT32 => ".{ .scalar = .sint32 }",
            .TYPE_SINT64 => ".{ .scalar = .sint64}",
            .TYPE_STRING => ".{ .scalar = .string }",
            .TYPE_BYTES => ".{ .scalar = .bytes }",
            .TYPE_MESSAGE => ".submessage",
            else => {
                std.debug.print("Unrecognized type {}\n", .{field.type.?});
                @panic("Unrecognized type");
            },
        };

        return try std.mem.concat(allocator, u8, &.{ prefix, infix, postfix });
    }

    fn generateFieldDescriptor(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        lines: *std.ArrayList([]const u8),
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
        message: descriptor.DescriptorProto,
        field: descriptor.FieldDescriptorProto,
        is_union: bool,
    ) !void {
        _ = message;
        const name = try escapeName(allocator, field.name.?);
        const descStr = try self.getFieldTypeDescriptor(allocator, fqn, file, field, is_union);
        const format = "        .{s} = fd({?d}, {s}),\n";
        try lines.append(
            allocator,
            try std.fmt.allocPrint(allocator, format, .{ name, field.number, descStr }),
        );
    }

    fn generateFieldDeclaration(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        lines: *std.ArrayList([]const u8),
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
        message: descriptor.DescriptorProto,
        field: descriptor.FieldDescriptorProto,
        is_union: bool,
    ) !void {
        _ = message;

        const type_str = try self.getFieldType(allocator, fqn, file, field, is_union);
        const field_name = try escapeName(allocator, field.name.?);
        const nullable = type_str[0] == '?';

        if (try self.getFieldDefault(allocator, field, file, nullable)) |default_value| {
            try lines.append(
                allocator,
                try std.fmt.allocPrint(allocator, "    {s}: {s} = {s},\n", .{ field_name, type_str, default_value }),
            );
        } else {
            try lines.append(
                allocator,
                try std.fmt.allocPrint(allocator, "    {s}: {s},\n", .{ field_name, type_str }),
            );
        }
    }

    /// this function returns the amount of options available for a given "oneof" declaration
    ///
    /// since protobuf 3.14, optional values in proto3 are wrapped in a single-element
    /// oneof to enable optional behavior in most languages. since we have optional types
    /// in zig, we can not use it for a better end-user experience and for readability
    fn amountOfElementsInOneofUnion(_: *GenerationContext, message: descriptor.DescriptorProto, oneof_index: ?i32) u32 {
        if (oneof_index == null) return 0;

        var count: u32 = 0;
        for (message.field.items) |f| {
            if (oneof_index == f.oneof_index)
                count += 1;
        }

        return count;
    }

    fn generateMessages(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        lines: *std.ArrayList([]const u8),
        fqn: FullName,
        file: descriptor.FileDescriptorProto,
        messages: std.ArrayListUnmanaged(descriptor.DescriptorProto),
        root_path: []const i32,
        message_field_number: i32,
    ) !void {
        for (messages.items, 0..) |message, message_i| {
            const m: descriptor.DescriptorProto = message;
            const messageFqn = try fqn.append(allocator, m.name.?);

            // Build the path for this message: root_path + [message_field_number, message_i]
            var message_path: std.ArrayList(i32) = .empty;
            defer message_path.deinit(allocator);
            try message_path.appendSlice(allocator, root_path);
            try message_path.append(allocator, message_field_number);
            try message_path.append(allocator, @intCast(message_i));

            try lines.append(allocator, "\n");

            // Add leading comment if available
            if (SourceCodeInfo.getRepeatedFieldLocation(
                file,
                root_path,
                message_field_number,
                message_i,
            )) |loc| {
                if (loc.leading_comments) |leading_comments| {
                    try SourceCodeInfo.appendComment(allocator, lines, leading_comments);
                }
            }

            try lines.append(
                allocator,
                try std.fmt.allocPrint(allocator, "pub const {s} = struct {{\n", .{m.name.?}),
            );

            // append all fields that are not part of a oneof
            for (m.field.items) |f| {
                if (f.oneof_index == null or self.amountOfElementsInOneofUnion(m, f.oneof_index) == 1) {
                    try self.generateFieldDeclaration(allocator, lines, messageFqn, file, m, f, false);
                }
            }

            // print all oneof fields
            for (m.oneof_decl.items, 0..) |oneof, i| {
                const union_element_count = self.amountOfElementsInOneofUnion(m, @as(i32, @intCast(i)));
                if (union_element_count > 1) {
                    const oneof_name = oneof.name.?;
                    try lines.append(allocator, try std.fmt.allocPrint(
                        allocator,
                        // Oneof fields across proto2, proto3, and editions
                        // are "not set" by default, which is represented as
                        // the null value here.
                        "    {s}: ?{s}_union = null,\n",
                        .{ try escapeName(allocator, oneof_name), oneof_name },
                    ));
                }
            }

            // then print the oneof declarations
            for (m.oneof_decl.items, 0..) |oneof, i| {
                // only emit unions that have more than one element
                const union_element_count = self.amountOfElementsInOneofUnion(m, @as(i32, @intCast(i)));
                if (union_element_count > 1) {
                    const oneof_name = oneof.name.?;

                    try lines.append(allocator, try std.fmt.allocPrint(allocator,
                        \\
                        \\    pub const _{s}_case = enum {{
                        \\
                    , .{oneof_name}));

                    for (m.field.items) |field| {
                        const f: descriptor.FieldDescriptorProto = field;
                        if (f.oneof_index orelse -1 == @as(i32, @intCast(i))) {
                            const name = try escapeName(allocator, f.name.?);
                            try lines.append(allocator, try std.fmt.allocPrint(allocator, "      {s},\n", .{name}));
                        }
                    }

                    try lines.append(allocator, try std.fmt.allocPrint(allocator,
                        \\    }};
                        \\    pub const {s}_union = union(_{s}_case) {{
                        \\
                    , .{ oneof_name, oneof_name }));

                    for (m.field.items) |field| {
                        const f: descriptor.FieldDescriptorProto = field;
                        if (f.oneof_index orelse -1 == @as(i32, @intCast(i))) {
                            const name = try escapeName(allocator, f.name.?);
                            const typeStr = try self.getFieldType(allocator, messageFqn, file, f, true);
                            try lines.append(allocator, try std.fmt.allocPrint(
                                allocator,
                                "      {s}: {s},\n",
                                .{ name, typeStr },
                            ));
                        }
                    }

                    try lines.append(allocator,
                        \\    pub const _desc_table  = .{
                        \\
                    );

                    for (m.field.items) |field| {
                        const f: descriptor.FieldDescriptorProto = field;
                        if (f.oneof_index orelse -1 == @as(i32, @intCast(i))) {
                            try self.generateFieldDescriptor(allocator, lines, messageFqn, file, m, f, true);
                        }
                    }

                    try lines.append(allocator,
                        \\      };
                        \\    };
                        \\
                    );
                }
            }

            // field descriptors
            try lines.append(allocator,
                \\
                \\    pub const _desc_table = .{
                \\
            );

            // first print fields
            for (m.field.items) |f| {
                if (f.oneof_index == null or self.amountOfElementsInOneofUnion(m, f.oneof_index) == 1) {
                    try self.generateFieldDescriptor(allocator, lines, messageFqn, file, m, f, false);
                }
            }

            // print all oneof fields
            for (m.oneof_decl.items, 0..) |oneof, i| {
                // only emit unions that have more than one element
                const union_element_count = self.amountOfElementsInOneofUnion(m, @as(i32, @intCast(i)));
                if (union_element_count > 1) {
                    const oneof_name = oneof.name.?;
                    try lines.append(
                        allocator,
                        try std.fmt.allocPrint(
                            allocator,
                            "    .{s} = fd(null, .{{ .oneof  = {s}_union }}),\n",
                            .{ try escapeName(allocator, oneof_name), oneof_name },
                        ),
                    );
                }
            }

            try lines.append(allocator,
                \\    };
                \\
            );

            // For nested enums, root_path is the message's path and field number is 4 (enum_type in DescriptorProto)
            try self.generateEnums(allocator, lines, messageFqn, file, m.enum_type, message_path.items, 4);
            // For nested messages, root_path is the message's path and field number is 3 (nested_type in DescriptorProto)
            try self.generateMessages(allocator, lines, messageFqn, file, m.nested_type, message_path.items, 3);

            try lines.append(allocator, try std.fmt.allocPrint(allocator,
                \\
                \\    /// Encodes the message to the writer
                \\    /// The allocator is used to generate submessages internally.
                \\    /// Hence, an ArenaAllocator is a preferred choice if allocations are a bottleneck.
                \\    pub fn encode(
                \\        self: @This(),
                \\        writer: *std.Io.Writer,
                \\        allocator: std.mem.Allocator,
                \\    ) (std.Io.Writer.Error || std.mem.Allocator.Error)!void {{
                \\        return protobuf.encode(writer, allocator, self);
                \\    }}
                \\
                \\    /// Decodes the message from the bytes read from the reader.
                \\    pub fn decode(
                \\        reader: *std.Io.Reader,
                \\        allocator: std.mem.Allocator,
                \\    ) (protobuf.DecodingError || std.Io.Reader.Error || std.mem.Allocator.Error)!@This() {{
                \\        return protobuf.decode(@This(), reader, allocator);
                \\    }}
                \\    
                \\    /// Deinitializes and frees the memory associated with the message.
                \\    pub fn deinit(self: *@This(), allocator: std.mem.Allocator) void {{
                \\        return protobuf.deinit(allocator, self);
                \\    }}
                \\
                \\    /// Duplicates the message.
                \\    pub fn dupe(self: @This(), allocator: std.mem.Allocator) std.mem.Allocator.Error!@This() {{
                \\        return protobuf.dupe(@This(), self, allocator);
                \\    }}
                \\
                \\    /// Decodes the message from the JSON string.
                \\    pub fn jsonDecode(
                \\        input: []const u8,
                \\        options: std.json.ParseOptions,
                \\        allocator: std.mem.Allocator,
                \\    ) !std.json.Parsed(@This()) {{
                \\        return protobuf.json.decode(@This(), input, options, allocator);
                \\    }}
                \\  
                \\    /// Encodes the message to a JSON string.
                \\    pub fn jsonEncode(
                \\        self: @This(),
                \\        options: std.json.Stringify.Options,
                \\        pb_options: protobuf.json.Options,
                \\        allocator: std.mem.Allocator,
                \\    ) ![]const u8 {{
                \\        return protobuf.json.encode(self, options, pb_options, allocator);
                \\    }}
                \\
                \\    /// This method is used by std.json
                \\    /// internally for deserialization. DO NOT RENAME!
                \\    pub fn jsonParse(
                \\        allocator: std.mem.Allocator,
                \\        source: anytype,
                \\        options: std.json.ParseOptions,
                \\    ) !@This() {{
                \\        return protobuf.json.parse(@This(), allocator, source, options);
                \\    }}
                \\
                \\}};
                \\
            , .{}));
        }
    }

    /// Analyzes message dependencies to detect self-referential messages
    fn analyzeMessageDependencies(
        self: *GenerationContext,
        allocator: std.mem.Allocator,
        fqn: FullName,
        message: descriptor.DescriptorProto,
    ) !bool {
        const message_name = message.name.?;
        const full_message_name = fqn.buf; // Use package name directly
        var deps: std.ArrayList([]const u8) = .empty;

        // Check fields for message types
        for (message.field.items) |field| {
            if (field.type) |t| {
                if (t == .TYPE_MESSAGE) {
                    if (field.type_name) |type_name| {
                        const raw_type = type_name;
                        const dep_name = raw_type[1..]; // Remove leading dot
                        try deps.append(allocator, dep_name);

                        // Check for direct self-reference by comparing the last part of the type name
                        const last_dot = std.mem.lastIndexOf(u8, dep_name, ".");
                        const simple_name = if (last_dot) |idx| dep_name[idx + 1 ..] else dep_name;

                        if (std.mem.eql(u8, simple_name, message_name)) {
                            return true;
                        }
                    }
                }
            }
        }

        // Store dependencies for this message
        try self.message_deps.put(full_message_name, deps);

        // Check if this message is self-referential (directly or indirectly)
        var visited: std.StringHashMap(bool) = .init(allocator);
        defer visited.deinit();
        return self.isMessageSelfReferential(full_message_name, &visited);
    }

    /// Recursively checks if a message is self-referential
    fn isMessageSelfReferential(
        self: *GenerationContext,
        message_name: []const u8,
        visited: *std.StringHashMap(bool),
    ) bool {
        if (visited.get(message_name)) |_| {
            return true; // Found a cycle
        }

        if (self.message_deps.get(message_name)) |deps| {
            visited.put(message_name, true) catch return false;
            defer _ = visited.remove(message_name);

            for (deps.items) |dep| {
                const last_dot = std.mem.lastIndexOf(u8, dep, ".");
                const simple_name = if (last_dot) |idx| dep[idx + 1 ..] else dep;
                const last_dot_msg = std.mem.lastIndexOf(u8, message_name, ".");
                const msg_simple_name = if (last_dot_msg) |idx| message_name[idx + 1 ..] else message_name;

                // Check for self-reference by comparing simple names
                if (std.mem.eql(u8, simple_name, msg_simple_name)) {
                    return true;
                }
                // Also check for indirect cycles
                if (self.isMessageSelfReferential(dep, visited)) {
                    return true;
                }
            }
        }

        return false;
    }
};

fn packageToFileName(package: []const u8, output: []u8) []const u8 {
    const result_len = package.len + ".pb.zig".len;
    std.debug.assert(output.len >= result_len);
    for (package, output[0..package.len]) |c, *dest_c| {
        dest_c.* = if (c == '.' or c == '\\') '/' else c;
    }
    @memcpy(output[package.len..result_len], ".pb.zig");
    return output[0..result_len];
}

fn escapeFqn(allocator: std.mem.Allocator, n: []const u8) ![]const u8 {
    var r: []u8 = try allocator.alloc(u8, n.len);
    for (n, 0..) |byte, i| {
        r[i] = switch (byte) {
            '.', '/', '\\' => '_',
            else => byte,
        };
    }
    return r;
}

fn isRepeated(field: descriptor.FieldDescriptorProto) bool {
    return (field.label orelse return false) == .LABEL_REPEATED;
}

fn isScalarNumeric(t: descriptor.FieldDescriptorProto.Type) bool {
    return switch (t) {
        .TYPE_DOUBLE,
        .TYPE_FLOAT,
        .TYPE_INT32,
        .TYPE_INT64,
        .TYPE_UINT32,
        .TYPE_UINT64,
        .TYPE_SINT32,
        .TYPE_SINT64,
        .TYPE_FIXED32,
        .TYPE_FIXED64,
        .TYPE_SFIXED32,
        .TYPE_SFIXED64,
        .TYPE_BOOL,
        => true,
        else => false,
    };
}

fn isPacked(file: descriptor.FileDescriptorProto, field: descriptor.FieldDescriptorProto) bool {
    const default = if (is_proto3_file(file))
        isScalarNumeric(field.type orelse return false)
    else
        false;

    if (field.options) |o| {
        if (o.@"packed") |p| {
            return p;
        }
    }
    return default;
}

fn isOptional(file: descriptor.FileDescriptorProto, field: descriptor.FieldDescriptorProto) bool {
    if (is_proto3_file(file)) {
        return field.proto3_optional orelse false;
    }

    return (field.label orelse return false) == .LABEL_OPTIONAL;
}

fn is_proto3_file(file: descriptor.FileDescriptorProto) bool {
    return std.mem.eql(
        u8,
        "proto3",
        file.syntax orelse return false,
    );
}

pub fn formatSliceEscapeImpl(allocator: std.mem.Allocator, str: []const u8) ![]const u8 {
    var writer: std.Io.Writer.Allocating = .init(allocator);
    try writer.writer.print("\"{f}\"", .{std.zig.fmtString(str)});

    return try writer.toOwnedSlice();
}

test "self referential" {
    _ = &GenerationContext.isMessageSelfReferential;
    _ = &GenerationContext.analyzeMessageDependencies;
}

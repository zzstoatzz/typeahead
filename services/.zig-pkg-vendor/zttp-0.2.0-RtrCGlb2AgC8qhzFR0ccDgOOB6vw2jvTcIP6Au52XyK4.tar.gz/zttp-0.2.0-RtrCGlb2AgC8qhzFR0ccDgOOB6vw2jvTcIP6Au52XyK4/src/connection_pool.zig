const std = @import("std");
const Connection = std.http.Client.Connection;
const Pool = std.http.Client.ConnectionPool;

pub fn release(io: std.Io, pool: *Pool, connection: *Connection) ?*Connection {
    pool.mutex.lockUncancelable(io);
    defer pool.mutex.unlock(io);
    pool.used.remove(&connection.pool_node);
    if (connection.closing or pool.free_size == 0) return connection;
    var retired: ?*Connection = null;
    if (pool.free_len >= pool.free_size) {
        retired = @alignCast(@fieldParentPtr("pool_node", pool.free.popFirst().?));
        pool.free_len -= 1;
    }
    if (connection.proxied) {
        pool.free.prepend(&connection.pool_node);
    } else {
        pool.free.append(&connection.pool_node);
    }
    pool.free_len += 1;
    return retired;
}

pub fn pop(io: std.Io, pool: *Pool) ?*Connection {
    pool.mutex.lockUncancelable(io);
    defer pool.mutex.unlock(io);
    const node = pool.free.popFirst() orelse return null;
    pool.free_len -= 1;
    return @alignCast(@fieldParentPtr("pool_node", node));
}

pub fn hasTls(io: std.Io, pool: *Pool) bool {
    pool.mutex.lockUncancelable(io);
    defer pool.mutex.unlock(io);
    var next = pool.free.first;
    while (next) |node| : (next = node.next) {
        const connection: *Connection = @alignCast(@fieldParentPtr("pool_node", node));
        if (connection.protocol == .tls) return true;
    }
    return false;
}

const std = @import("std");
const Io = std.Io;

pub const Shedding = enum {
    /// Keep queued work, reject the submitted item.
    drop_newest,
    /// Evict the oldest queued item, then accept the submitted item.
    drop_oldest,
};

pub const PushStatus = enum {
    accepted,
    dropped_newest,
    dropped_oldest,
};

pub fn PushResult(comptime Item: type) type {
    return struct {
        status: PushStatus,
        dropped: ?Item = null,

        pub fn accepted(self: @This()) bool {
            return self.status != .dropped_newest;
        }
    };
}

pub fn BoundedQueue(comptime Item: type) type {
    return struct {
        const Self = @This();

        buffer: []Item,
        head: usize = 0,
        len: usize = 0,
        closed: bool = false,
        mutex: Io.Mutex = .init,
        not_empty: Io.Condition = .init,
        not_full: Io.Condition = .init,

        pub fn init(buffer: []Item) Self {
            std.debug.assert(buffer.len > 0);
            return .{ .buffer = buffer };
        }

        pub fn close(self: *Self, io: Io) void {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);
            self.closed = true;
            self.not_empty.broadcast(io);
            self.not_full.broadcast(io);
        }

        pub fn put(self: *Self, io: Io, item: Item) (error{Closed} || Io.Cancelable)!void {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);

            if (self.closed) return error.Closed;
            while (self.len == self.buffer.len and !self.closed) {
                try self.not_full.wait(io, &self.mutex);
            }
            if (self.closed) return error.Closed;

            self.pushLocked(item);
            self.not_empty.signal(io);
        }

        pub fn offer(self: *Self, io: Io, item: Item, shedding: Shedding) error{Closed}!PushResult(Item) {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);

            if (self.closed) return error.Closed;
            if (self.buffer.len == 0) return .{ .status = .dropped_newest, .dropped = item };
            if (self.len == self.buffer.len) {
                switch (shedding) {
                    .drop_newest => return .{ .status = .dropped_newest, .dropped = item },
                    .drop_oldest => {
                        const dropped = self.popLocked();
                        self.pushLocked(item);
                        self.not_empty.signal(io);
                        return .{ .status = .dropped_oldest, .dropped = dropped };
                    },
                }
            }
            self.pushLocked(item);
            self.not_empty.signal(io);
            return .{ .status = .accepted };
        }

        pub fn pop(self: *Self, io: Io) (error{Closed} || Io.Cancelable)!Item {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);

            while (self.len == 0 and !self.closed) {
                try self.not_empty.wait(io, &self.mutex);
            }
            if (self.len == 0) return error.Closed;

            const item = self.popLocked();
            self.not_full.signal(io);
            return item;
        }

        pub fn drain(self: *Self, io: Io, comptime onItem: fn (Item) void) void {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);

            while (self.len > 0) {
                onItem(self.popLocked());
            }
        }

        pub fn count(self: *Self, io: Io) usize {
            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);
            return self.len;
        }

        pub fn capacity(self: *const Self) usize {
            return self.buffer.len;
        }

        fn pushLocked(self: *Self, item: Item) void {
            const idx = (self.head + self.len) % self.buffer.len;
            self.buffer[idx] = item;
            self.len += 1;
        }

        fn popLocked(self: *Self) Item {
            std.debug.assert(self.len > 0);
            const item = self.buffer[self.head];
            self.head = (self.head + 1) % self.buffer.len;
            self.len -= 1;
            return item;
        }
    };
}

test "drop_newest rejects full queue" {
    const testing = std.testing;
    const io = testing.io;
    var buffer: [2]u32 = undefined;
    var q = BoundedQueue(u32).init(&buffer);

    try testing.expect((try q.offer(io, 1, .drop_newest)).accepted());
    try testing.expect((try q.offer(io, 2, .drop_newest)).accepted());

    const r = try q.offer(io, 3, .drop_newest);
    try testing.expectEqual(PushStatus.dropped_newest, r.status);
    try testing.expectEqual(@as(?u32, 3), r.dropped);

    try testing.expectEqual(@as(u32, 1), try q.pop(io));
    try testing.expectEqual(@as(u32, 2), try q.pop(io));
}

test "drop_oldest evicts full queue head" {
    const testing = std.testing;
    const io = testing.io;
    var buffer: [2]u32 = undefined;
    var q = BoundedQueue(u32).init(&buffer);

    _ = try q.offer(io, 1, .drop_oldest);
    _ = try q.offer(io, 2, .drop_oldest);

    const r = try q.offer(io, 3, .drop_oldest);
    try testing.expectEqual(PushStatus.dropped_oldest, r.status);
    try testing.expectEqual(@as(?u32, 1), r.dropped);

    try testing.expectEqual(@as(u32, 2), try q.pop(io));
    try testing.expectEqual(@as(u32, 3), try q.pop(io));
}

test "put blocks until capacity and preserves order" {
    const testing = std.testing;
    const io = testing.io;
    var buffer: [2]u32 = undefined;
    var q = BoundedQueue(u32).init(&buffer);

    try q.put(io, 1);
    try q.put(io, 2);

    try testing.expectEqual(@as(u32, 1), try q.pop(io));
    try testing.expectEqual(@as(u32, 2), try q.pop(io));
}

test "blocked put observes cancellation" {
    const testing = std.testing;
    const io = testing.io;
    var buffer: [1]u32 = undefined;
    var q = BoundedQueue(u32).init(&buffer);

    try q.put(io, 1);

    const Helper = struct {
        fn putFull(queue: *BoundedQueue(u32), task_io: Io) (error{Closed} || Io.Cancelable)!void {
            try queue.put(task_io, 2);
        }
    };

    var future = io.async(Helper.putFull, .{ &q, io });
    try testing.expectError(error.Canceled, future.cancel(io));
    try testing.expectEqual(@as(u32, 1), try q.pop(io));
}

test "blocked pop observes cancellation" {
    const testing = std.testing;
    const io = testing.io;
    var buffer: [1]u32 = undefined;
    var q = BoundedQueue(u32).init(&buffer);

    const Helper = struct {
        fn popEmpty(queue: *BoundedQueue(u32), task_io: Io) (error{Closed} || Io.Cancelable)!u32 {
            return try queue.pop(task_io);
        }
    };

    var future = io.async(Helper.popEmpty, .{ &q, io });
    try testing.expectError(error.Canceled, future.cancel(io));
}

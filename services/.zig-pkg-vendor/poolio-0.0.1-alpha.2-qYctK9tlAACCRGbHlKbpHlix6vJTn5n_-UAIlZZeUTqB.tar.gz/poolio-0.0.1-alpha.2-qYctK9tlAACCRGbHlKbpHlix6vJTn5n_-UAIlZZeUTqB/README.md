# poolio

Worker pools for Zig 0.17 `std.Io`: bounded queues, `Io.Group.concurrent` workers, backpressure with `put`, and best-effort shedding with `offer`.

```zig
const std = @import("std");
const poolio = @import("poolio");

const Io = std.Io;

const Ctx = struct {
    fn process(_: *@This(), _: Io, item: u64) void {
        std.debug.print("work: {d}\n", .{item});
    }
};

pub fn main() !void {
    const allocator = std.heap.smp_allocator;
    var threaded = Io.Threaded.init(allocator, .{});
    const io = threaded.io();

    var ctx: Ctx = .{};
    var pool = try poolio.Pool(u64, Ctx).init(allocator, .{
        .queue_capacity = 1024,
        .workers = 4,
        .ctx = &ctx,
        .process = Ctx.process,
        .shedding = .drop_oldest,
    });
    defer pool.deinit();

    try pool.start(io);
    try pool.put(io, 1); // backpressure
    _ = pool.offer(io, 2); // non-blocking, uses shedding policy
    pool.shutdown(io);
}
```

Used in production by [typeahead](https://tangled.org/zzstoatzz.io/typeahead) for best-effort identity resolution (`.drop_newest`) and [pub-search](https://tangled.org/zzstoatzz.io/pub-search) for firehose ingest processing (`.drop_oldest`).

## Context

poolio is a bounded worker pool, in the same broad family as channel-backed worker patterns in Go and Rust. It is not an actor runtime: it does not provide process identity, routing, supervision, or restart policy. The Zig part is explicit ownership and lifetime: callers choose the allocator, `Io`, item type, processing callback, and optional drop callback.

## Io requirement

Workers are started with `std.Io.Group.concurrent`, so `start` requires an `Io` implementation that can provide correctness-relevant concurrency and may return `error.ConcurrencyUnavailable`. Use `std.Io.Threaded` or another `Io` implementation that supports `concurrent`; poolio uses `std.Io` synchronization primitives and does not spawn `std.Thread`s directly.

Blocking `put` calls observe `std.Io` cancellation and can return `error.Canceled`. `offer` remains immediate and non-blocking.

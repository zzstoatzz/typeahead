const std = @import("std");

/// the hegel-rust revision `hegel.h` is translated from: hegeltest-c 0.45.1
const hegel_rust_rev = "33d94c659e441127ce7b5a0f046ec4aa9315d794";

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const given_include = b.option(std.Build.LazyPath, "hegel-include", "directory containing hegel.h (default: built by scripts/libhegel.sh)");
    const given_lib = b.option(std.Build.LazyPath, "hegel-lib", "path to libhegel_c.a (default: built by scripts/libhegel.sh)");

    const include, const lib = if (given_include != null and given_lib != null)
        .{ given_include.?, given_lib.? }
    else built: {
        // cached by zig on the script and the revision; the script keeps its
        // own cargo build under ~/.cache/hegel-zig, so a wiped zig cache is a copy
        const cargo = b.addSystemCommand(&.{"sh"});
        cargo.setName("build libhegel");
        cargo.addFileArg(b.path("scripts/libhegel.sh"));
        cargo.addArg(hegel_rust_rev);
        const out_lib = cargo.addOutputFileArg("libhegel_c.a");
        const out_include = cargo.addOutputDirectoryArg("include");
        _ = cargo.captureStdOut(.{});
        break :built .{ out_include, out_lib };
    };

    const translate = b.addTranslateC(.{
        .root_source_file = include.path(b, "hegel.h"),
        .target = target,
        .optimize = optimize,
    });

    const mod = b.addModule("hegel", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{.{ .name = "c", .module = translate.createModule() }},
    });
    mod.addObjectFile(lib);
    if (target.result.os.tag.isDarwin()) {
        mod.linkFramework("CoreFoundation", .{});
        mod.linkFramework("Security", .{});
    }

    b.addNamedLazyPath("with-redis", b.path("scripts/with-redis.sh"));

    const stale_cache = b.addExecutable(.{
        .name = "stale-cache",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/stale_cache.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_stale_cache = b.addRunArtifact(stale_cache);
    run_stale_cache.addPassthruArgs();
    const example_step = b.step("example-stale-cache", "find and shrink a planted stale-cache bug in a toy map");
    example_step.dependOn(&run_stale_cache.step);

    // a blob printed by an earlier run of the example. libhegel is pinned, so
    // the blob stays valid until the pin moves
    const replay = b.addRunArtifact(stale_cache);
    replay.setEnvironmentVariable("HEGEL_ZIG_REPLAY", "AXicdYoxCgAACAK7ta3/fzYbhAhyUNGrkJJxcPFyDuXHsJgGGGMAhA==");
    replay.addCheck(.{ .expect_stderr_match = "minimal history:\nput(k0, 0)\nsum()\nput(k0, 1)\nsum()\n" });
    replay.addCheck(.{ .expect_stderr_match = "\n1 cases" });
    const replay_step = b.step("example-replay", "replay a recorded failure of the example");
    replay_step.dependOn(&replay.step);

    const stale_handle = b.addExecutable(.{
        .name = "stale-handle",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/stale_handle.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_stale_handle = b.addRunArtifact(stale_handle);
    run_stale_handle.addPassthruArgs();
    const handle_step = b.step("example-stale-handle", "find and shrink a planted stale-handle bug in a slot allocator");
    handle_step.dependOn(&run_stale_handle.step);

    const mutants_tool = b.addExecutable(.{
        .name = "hegel-mutants",
        .root_module = b.createModule(.{
            .root_source_file = b.path("tools/mutants.zig"),
            .target = b.graph.host,
        }),
    });
    b.installArtifact(mutants_tool);

    const sum_cache = b.addExecutable(.{
        .name = "sum-cache",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/mutants/sum_cache.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_sum_cache = b.addRunArtifact(sum_cache);
    b.step("example-sum-cache", "the fixed map, whose harness must pass").dependOn(&run_sum_cache.step);

    // the command rebuilds the example, since each mutant edits its source
    const run_mutants = b.addRunArtifact(mutants_tool);
    run_mutants.setCwd(b.path("."));
    run_mutants.addArgs(&.{ "examples/mutants/mutants.zon", "--seeds", "3", "--", b.graph.zig_exe, "build", "example-sum-cache" });
    run_mutants.has_side_effects = true;
    const mutants_step = b.step("example-mutants", "plant each mutant in the fixed map; every one must be caught");
    mutants_step.dependOn(&run_mutants.step);

    const test_step = b.step("test", "run the examples: each planted bug must be found, and one replayed");
    test_step.dependOn(example_step);
    test_step.dependOn(replay_step);
    test_step.dependOn(handle_step);
    test_step.dependOn(mutants_step);
}

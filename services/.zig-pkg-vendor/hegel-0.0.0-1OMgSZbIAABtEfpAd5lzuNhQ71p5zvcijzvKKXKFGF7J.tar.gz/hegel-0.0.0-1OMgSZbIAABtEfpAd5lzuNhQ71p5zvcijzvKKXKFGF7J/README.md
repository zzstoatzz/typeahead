# hegel-zig

a zig 0.17 driver for [libhegel](https://github.com/hegeldev/hegel-rust), the property-testing engine behind [Hegel](https://hegel.dev) (MIT, by Antithesis; hegel-rust describes itself as based on Hypothesis). libhegel generates test cases, shrinks failures and replays them. this repo wraps its C API in the loop a zig property needs, and carries the harness parts that [zat](https://tangled.org/zat.dev/zat), [burner-redis](https://tangled.org/zzstoatzz.io/burner-redis) and [docket](https://tangled.org/zzstoatzz.io/docket) each wrote once: the libhegel build, an operation tally, an echo mode for crashes, a throwaway redis-server to diff against, and a runner that plants mutants and counts the seeds that catch them.

## install

needs zig 0.17, and `cargo` and `git` the first time a build needs libhegel.

```bash
zig fetch --save=hegel https://tangled.org/zzstoatzz.io/hegel-zig/archive/<commit>.tar.gz
```

mark the dependency `.lazy = true` and gate it behind an option, so nothing but the property test pays for it:

```zig
if (b.option(bool, "hegel", "build the property tests (builds libhegel once)") orelse false) {
    if (b.lazyDependency("hegel", .{ .target = target, .optimize = optimize })) |hegel| {
        const pbt = b.addExecutable(.{
            .name = "pbt",
            .root_module = b.createModule(.{
                .root_source_file = b.path("pbt/machine.zig"),
                .target = target,
                .optimize = optimize,
                .imports = &.{.{ .name = "hegel", .module = hegel.module("hegel") }},
            }),
        });
        const run = b.addRunArtifact(pbt);
        run.addPassthruArgs();
        b.step("pbt", "run the state machine property test").dependOn(&run.step);
    }
}
```

`zig build pbt -Dhegel` then builds libhegel if it has not been built, and runs the harness.

## use

```zig
const hegel = @import("hegel");

const Rule = enum { put, sum };
var tally: hegel.Tally(Rule) = .{};

fn property(_: void, case: *hegel.TestCase) !void {
    var toy: Toy = .{};
    tally.case();
    var machine = try case.machine(Rule, &.{ 2, 1 }, 20);
    defer machine.deinit();
    while (try machine.next()) |rule| {
        tally.step(rule);
        switch (rule) {
            .put => {
                const key = try case.index(4);
                const value = try case.int(u8, 0, 255);
                case.note("put(k{d}, {d})", .{ key, value });
                toy.put(key, value);
            },
            .sum => {
                case.note("sum()", .{});
                if (toy.sum() != toy.recompute()) return case.fail("sum() disagrees with a recompute");
            },
        }
    }
    tally.finish(toy.count());
}

pub fn main() !void {
    const outcome = hegel.run(.{}, {}, property);
    tally.print();
    try outcome;
}
```

the whole program is [examples/stale_cache.zig](examples/stale_cache.zig). a failure prints the shrunk history and a blob that replays it:

```
FAILED: sum() disagrees with a recompute
minimal history:
put(k0, 0)
sum()
put(k0, 1)
sum()
reproduce: HEGEL_ZIG_REPLAY=AXicdYoxCgAACAK7ta3/fzYbhAhyUNGrkJJxcPFyDuXHsJgGGGMAhA==
```

<details>
<summary><b>handles, and rules that cannot apply</b></summary>

```zig
var live = try case.pool();
defer live.deinit();
...
.free => {
    const id = try live.take() orelse {
        machine.reject();
        tally.reject(rule);
        continue;
    };
    ...
},
```

a pool holds ids for things the case created, for rules that act on one of them: `add` when one is made, `pick` to use one, `take` to destroy one. an id keeps naming the same thing while the shrinker deletes the steps around it; an index into a list would shift. `machine.reject()` tells the engine a rule could not apply, so it does not spend a step. [examples/stale_handle.zig](examples/stale_handle.zig) keeps freed handles in a second pool and reads through them after their slot is reused.

</details>

<details>
<summary><b>coverage events</b></summary>

```zig
if (overwritten) case.event("sum after an overwrite of a summed map");
```

the tally counts rules; an event names the interaction a bug needs. the run prints the fraction of cases in which each one happened:

```
Statistics (over 500 test cases):
  * sum after an overwrite of a summed map: 33.8% of test cases
```

a fraction near zero means the generator rarely builds that history, and more cases will not fix it. on by default; `HEGEL_STATISTICS=0` turns it off.

</details>

<details>
<summary><b>mutants</b></summary>

```zon
.{
    .{
        .name = "an overwrite keeps the cached sum",
        .file = "src/toy.zig",
        .old = "self.cached = null;",
        .new = "if (self.values[key] == null) self.cached = null;",
    },
}
```

```zig
const mutants = b.addRunArtifact(hegel.artifact("hegel-mutants"));
mutants.setCwd(b.path("."));
mutants.addArgs(&.{ "pbt/mutants.zon", "--", b.graph.zig_exe, "build", "pbt", "-Dhegel" });
mutants.has_side_effects = true;
b.step("mutants", "plant each mutant and count the seeds that catch it").dependOn(&mutants.step);
```

plants each bug in turn, runs the harness under ten seeds (`--seeds n`), and restores the file:

```
baseline: passes 10/10
an overwrite keeps the cached sum: caught 10/10
```

the unmodified code must pass every seed first. a mutant no seed catches fails the step. when a finding is fixed, its mutant is the change that undoes the fix, so the harness is shown to find it again. `HEGEL_MUTANTS_ONLY=<text>` runs the mutants whose name contains it.

</details>

<details>
<summary><b>a throwaway redis-server</b></summary>

```zig
const with_redis = b.addSystemCommand(&.{"sh"});
with_redis.addFileArg(hegel.namedLazyPath("with-redis"));
with_redis.addArtifactArg(pbt);
with_redis.addPassthruArgs();
```

starts a redis-server with no persistence in a temporary directory, runs the harness with `HEGEL_REDIS_SOCKET` set, and removes both when it exits. `-p <port>` before the command also listens on TCP and sets `HEGEL_REDIS_URL`. for differential tests against the real thing.

</details>

<details>
<summary><b>replaying a failure</b></summary>

```bash
HEGEL_ZIG_REPLAY=<blob> zig build pbt -Dhegel
```

runs the one recorded case instead of exploring, and prints its history again. with `HEGEL_ZIG_ECHO=1` it prints every note along the way. a replay that passes means the failure is gone. the blob is tied to the libhegel revision this repo pins.

`HEGEL_DATABASE=.hegel` keeps every failure across runs instead, and the next run tries them first. each `run` call stores under its own key, `run-0`, `run-1` in call order, or `Settings.key`.

</details>

<details>
<summary><b>a crash</b></summary>

```bash
HEGEL_ZIG_ECHO=1 zig build pbt -Dhegel
```

prints every case's notes as they are made. a panic in the code under test kills the process before libhegel can shrink, so the history has to be read off the end of the output.

</details>

## design

- **the engine stays libhegel** — generation, shrinking and replay are the hard part and already exist. this is the loop, the draws and the report.
- **libhegel is built by the build** — `scripts/libhegel.sh` builds one pinned hegel-rust revision under `~/.cache/hegel-zig` and zig caches the result. the pin moves together with the wrapper, because `hegel.h` is translated at build time and the C API is still changing. rust is needed once.
- **opt-in in every consumer** — a lazy dependency behind `-Dhegel`, so `zig build test` in a project that uses this needs neither rust nor this repo.
- **the tally is part of the result** — a run that found nothing prints what it exercised. a quiet run over an empty state space is otherwise indistinguishable from a quiet run over a real one.
- **only as wide as its harnesses** — the API grows when one of the projects above needs a draw, not before.

## develop

```bash
zig build test                    # each example must find its planted bug; one replays from a blob, one kills its mutants
sh scripts/libhegel.sh <rev>      # build libhegel for a hegel-rust revision, print the checkout
```

`-Dhegel-include=<dir> -Dhegel-lib=<libhegel_c.a>` use a libhegel built elsewhere.

## docs

[docs/](docs/) holds the method: how a harness is built, checked and turned into reviewable fixes, written from the three campaigns that produced this repo.

## used by

- [zat](https://tangled.org/zat.dev/zat) — the MST against a key-value model, including partially loaded trees
- [burner-redis](https://tangled.org/zzstoatzz.io/burner-redis) — the store against redis-server, command by command
- [docket](https://tangled.org/zzstoatzz.io/docket) — the worker loop under a virtual clock, and its memory backend against redis-server

## license

[MIT](LICENSE). libhegel is MIT, by Antithesis.

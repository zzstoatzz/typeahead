const std = @import("std");
const Io = std.Io;
const net = Io.net;

pub fn read(io: Io, handle: net.Socket.Handle, data: [][]u8) !usize {
    const result = try io.operate(.{ .net_read = .{ .socket_handle = handle, .data = data } });
    return (try result.net_read).data_len;
}

pub fn write(io: Io, handle: net.Socket.Handle, bytes: []const u8) !usize {
    const result = try io.operate(.{ .net_write = .{
        .socket_handle = handle,
        .header = bytes,
        .data = &.{""},
        .splat = 0,
    } });
    return result.net_write;
}

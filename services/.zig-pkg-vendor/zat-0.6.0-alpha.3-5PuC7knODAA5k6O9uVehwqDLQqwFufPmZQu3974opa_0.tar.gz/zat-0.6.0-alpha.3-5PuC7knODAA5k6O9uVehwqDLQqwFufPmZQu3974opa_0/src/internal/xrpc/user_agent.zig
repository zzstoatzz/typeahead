const build_options = @import("build_options");

/// zat names itself in requests unless the application overrides it.
pub const default_user_agent = "zat/" ++ build_options.version ++ " (+https://tangled.org/zat.dev/zat)";

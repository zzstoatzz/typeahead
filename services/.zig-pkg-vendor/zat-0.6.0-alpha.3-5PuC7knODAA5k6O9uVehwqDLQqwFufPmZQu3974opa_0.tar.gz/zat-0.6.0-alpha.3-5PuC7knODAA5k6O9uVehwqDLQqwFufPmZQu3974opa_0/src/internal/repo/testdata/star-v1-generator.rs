use star_lite::mst::{BuilderOptions, MstStack, VerifyBackend};
use std::io::Write;
fn varint(out: &mut Vec<u8>, mut n: u64) {
    while n >= 128 { out.push((n as u8 & 127) | 128); n >>= 7; }
    out.push(n as u8);
}
fn main() {
    let records: Vec<_> = (256..556u16).map(|n| (
        format!("app.bsky.feed.post/{n:06}").into_bytes(),
        vec![0xa1, 0x61, b'n', 0x19, (n >> 8) as u8, n as u8],
    )).collect();
    let mut stack = MstStack::new(VerifyBackend, BuilderOptions::default());
    for (key, record) in &records { stack.insert(key, record).unwrap(); }
    let (root, _) = stack.finish().unwrap();
    let mut meta = b"\xa2\x64data\xd8\x2a\x58\x25\x00".to_vec();
    meta.extend(root.to_bytes());
    meta.extend(b"\x65$type\x78");
    let profile = b"atproto-public-repo-subtree";
    meta.push(profile.len() as u8);
    meta.extend(profile);
    let mut out = b"*l\x01\x00".to_vec();
    varint(&mut out, meta.len() as u64);
    out.extend(meta);
    for (key, record) in &records {
        varint(&mut out, key.len() as u64); out.extend(key);
        varint(&mut out, record.len() as u64); out.extend(record);
    }
    std::fs::File::create(std::env::args().nth(1).unwrap()).unwrap().write_all(&out).unwrap();
}

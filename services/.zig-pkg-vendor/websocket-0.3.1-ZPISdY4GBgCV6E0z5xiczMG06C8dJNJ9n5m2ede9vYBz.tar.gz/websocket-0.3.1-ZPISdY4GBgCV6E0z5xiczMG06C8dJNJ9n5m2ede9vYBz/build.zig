const std = @import("std");

pub fn build(b: *std.Build) !void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const use_zlib = b.option(bool, "zlib", "use C zlib for permessage-deflate instead of pmdeflate (compiles zlib, links libc)") orelse false;
    const pmdeflate = b.dependency("pmdeflate", .{ .target = target, .optimize = optimize }).module("pmdeflate");

    const websocket_module = b.addModule("websocket", .{
        .target = target,
        .optimize = optimize,
        .root_source_file = b.path("src/websocket.zig"),
        .imports = &.{.{ .name = "pmdeflate", .module = pmdeflate }},
    });
    {
        const options = b.addOptions();
        options.addOption(bool, "websocket_blocking", false);
        options.addOption(bool, "zlib", use_zlib);
        websocket_module.addOptions("build", options);
    }
    if (use_zlib) linkZlib(b, websocket_module, target, optimize);

    // run the suite with each codec, so the reference stays tested too. only
    // this repository's own build sets up the zlib variant: as a dependency,
    // asking for it would make every consumer fetch zlib.
    const force_blocking = b.option(bool, "force_blocking", "Force blocking mode") orelse false;
    const test_step = b.step("test", "Run tests");
    const codecs: []const bool = if (b.isRoot()) &.{ false, true } else &.{false};
    for (codecs) |with_zlib| {
        const options = b.addOptions();
        options.addOption(bool, "websocket_blocking", force_blocking);
        options.addOption(bool, "zlib", with_zlib);

        const test_module = b.createModule(.{
            .root_source_file = b.path("src/websocket.zig"),
            .target = target,
            .optimize = optimize,
            // the suite runs the server, which calls libc directly
            .link_libc = true,
            .imports = &.{.{ .name = "pmdeflate", .module = pmdeflate }},
        });
        test_module.addOptions("build", options);
        if (with_zlib) linkZlib(b, test_module, target, optimize);

        const tests = b.addTest(.{
            .name = if (with_zlib) "test-zlib" else "test",
            .root_module = test_module,
            .test_runner = .{ .path = b.path("test_runner.zig"), .mode = .simple },
        });
        test_step.dependOn(&b.addRunArtifact(tests).step);
    }

    const echo = b.addExecutable(.{
        .name = "echo",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/echo.zig"),
            .target = target,
            .optimize = optimize,
            // a server links libc: its socket handling calls libc directly
            .link_libc = true,
            .imports = &.{.{ .name = "websocket", .module = websocket_module }},
        }),
    });
    b.step("echo", "Run the echo server from the readme").dependOn(&b.addRunArtifact(echo).step);
    // the readme's example must keep compiling
    test_step.dependOn(&echo.step);

    const trust_probe = b.addExecutable(.{
        .name = "trust-probe",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/trust_probe.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "websocket", .module = websocket_module }},
        }),
    });
    const run_trust_probe = b.addRunArtifact(trust_probe);
    b.step("trust-probe", "Reject incident TLS hosts and accept a valid control").dependOn(&run_trust_probe.step);
}

fn linkZlib(b: *std.Build, module: *std.Build.Module, target: std.Build.ResolvedTarget, optimize: std.builtin.OptimizeMode) void {
    const zlib_dep = b.lazyDependency("zlib", .{}) orelse return;
    const zlib_mod = b.createModule(.{
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    zlib_mod.addIncludePath(zlib_dep.path("."));
    zlib_mod.addCSourceFiles(.{
        .root = zlib_dep.path("."),
        .files = &.{
            "adler32.c",
            "crc32.c",
            "deflate.c",
            "inffast.c",
            "inflate.c",
            "inftrees.c",
            "trees.c",
            "zutil.c",
        },
        .flags = &.{},
    });
    module.link_libc = true;
    module.addIncludePath(zlib_dep.path("."));
    module.linkLibrary(b.addLibrary(.{ .name = "websocket-zlib", .root_module = zlib_mod }));
}

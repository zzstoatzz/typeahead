# websocket.zig

a WebSocket server and client for Zig 0.17, forked from Karl Seguin's
[karlseguin/websocket.zig](https://github.com/karlseguin/websocket.zig). the
fork threads `std.Io` through the server, serves plain HTTP on the WebSocket
listener, bounds server and client shutdown, and compresses with
[pmdeflate](https://github.com/zzstoatzz/pmdeflate), so permessage-deflate needs
no C or libc. all credit for the library is Karl's.

## install

```sh
zig fetch --save=websocket https://tangled.org/zzstoatzz.io/websocket.zig/archive/v0.3.1.tar.gz
```

```zig
exe.root_module.addImport("websocket", b.dependency("websocket", .{}).module("websocket"));
```

Zig 0.16 users take a v0.1.x tag.

## use

```zig
const std = @import("std");
const ws = @import("websocket");

const Handler = struct {
    conn: *ws.Conn,

    pub fn init(_: *const ws.Handshake, conn: *ws.Conn, _: void) !Handler {
        return .{ .conn = conn };
    }

    pub fn clientMessage(self: *Handler, data: []const u8) !void {
        try self.conn.write(data);
    }
};

pub fn main(init: std.process.Init) !void {
    var threaded: std.Io.Threaded = .init(init.gpa, .{});
    defer threaded.deinit();

    var server = try ws.Server(Handler).init(init.gpa, threaded.io(), .{
        .port = 9224,
        .address = "127.0.0.1",
        .compression = .{},
    });
    defer server.deinit();
    try server.listen({});
}
```

this is [examples/echo.zig](examples/echo.zig), which `zig build test`
compiles. the server calls libc directly, so a server consumer links libc; a
client needs none.

## develop

```sh
zig build test                     # the suite with pmdeflate, then with zlib
zig build echo                     # run the echo server above
support/autobahn/server/run.sh     # Autobahn TestSuite against three endpoints (docker)
just conformance                   # real-socket shutdown qualification (docker)
zig build trust-probe              # TLS trust checks against live hosts
```

## docs

[docs/](docs/) holds upstream's server and client guides and what this fork
changes.

## license

[MIT](LICENSE), copyright Karl Seguin.

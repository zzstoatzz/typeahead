//! permessage-deflate through pmdeflate: pure Zig on std.compress.flate, so
//! compression needs no C library and no libc

const std = @import("std");
const pmdeflate = @import("pmdeflate");

const Allocator = std.mem.Allocator;

pub const Error = error{
    CompressionInitFailed,
    CompressionFailed,
    CompressionResetFailed,
    DecompressionInitFailed,
    DecompressionFailed,
    DecompressionResetFailed,
    InvalidCompressionTail,
    MessageTooLarge,
};

pub const Compressor = struct {
    deflater: *pmdeflate.Deflater,

    pub fn init(self: *Compressor, allocator: Allocator) Error!void {
        self.deflater = pmdeflate.Deflater.create(allocator, .{}) catch return error.CompressionInitFailed;
    }

    pub fn deinit(self: *Compressor) void {
        self.deflater.destroy();
    }

    pub fn reset(self: *Compressor) Error!void {
        self.deflater.reset() catch return error.CompressionResetFailed;
    }

    /// give back an output buffer a large message grew; the window is kept
    pub fn releaseOutput(self: *Compressor) void {
        self.deflater.trim() catch {};
    }

    /// the payload lives in the deflater until the next call; `output` is
    /// left for codecs that write into the caller's buffer
    pub fn compress(self: *Compressor, _: Allocator, input: []const u8, _: *std.ArrayList(u8)) (Allocator.Error || Error)![]const u8 {
        return self.deflater.compress(input);
    }
};

pub const Decompressor = struct {
    inflater: *pmdeflate.Inflater,

    pub fn init(self: *Decompressor, allocator: Allocator) Error!void {
        self.inflater = pmdeflate.Inflater.create(allocator, .{}) catch return error.DecompressionInitFailed;
    }

    pub fn deinit(self: *Decompressor) void {
        self.inflater.destroy();
    }

    pub fn reset(self: *Decompressor) Error!void {
        self.inflater.reset();
    }

    pub fn decompress(self: *Decompressor, payload: []const u8, output: *std.Io.Writer, max_len: usize) Error!usize {
        return self.inflater.decompress(payload, output, max_len) catch |err| switch (err) {
            error.MessageTooLarge => error.MessageTooLarge,
            else => error.DecompressionFailed,
        };
    }
};

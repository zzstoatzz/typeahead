//! permessage-deflate codec. pmdeflate, pure Zig, is the default.
//! `-Dzlib=true` selects C zlib instead, which compiles zlib and links libc;
//! it is kept as a reference for conformance runs and benchmarks.
const build = @import("build");

pub const uses_zlib = @hasDecl(build, "zlib") and build.zlib;
const impl = if (uses_zlib) @import("deflate_zlib.zig") else @import("deflate_pm.zig");

pub const Error = impl.Error;
pub const Compressor = impl.Compressor;
pub const Decompressor = impl.Decompressor;

//! a WebSocket echo server on 127.0.0.1:9224
const std = @import("std");
const ws = @import("websocket");

const Handler = struct {
    conn: *ws.Conn,

    pub fn init(_: *const ws.Handshake, conn: *ws.Conn, _: void) !Handler {
        return .{ .conn = conn };
    }

    pub fn clientMessage(self: *Handler, data: []const u8) !void {
        try self.conn.write(data);
    }
};

pub fn main(init: std.process.Init) !void {
    var threaded: std.Io.Threaded = .init(init.gpa, .{});
    defer threaded.deinit();

    var server = try ws.Server(Handler).init(init.gpa, threaded.io(), .{
        .port = 9224,
        .address = "127.0.0.1",
        // permessage-deflate through pmdeflate, if the client offers it
        .compression = .{},
    });
    defer server.deinit();
    try server.listen({});
}

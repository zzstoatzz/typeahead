//! zttp: a hardened HTTP client for zig 0.16, over std.http.Client.

const client = @import("client.zig");

pub const distrustCompromisedKeys = @import("trust.zig").distrust;

pub const Client = client.Client;
pub const Error = client.Error;
pub const Progress = client.Progress;
pub const default_user_agent = client.default_user_agent;

test {
    _ = client;
}

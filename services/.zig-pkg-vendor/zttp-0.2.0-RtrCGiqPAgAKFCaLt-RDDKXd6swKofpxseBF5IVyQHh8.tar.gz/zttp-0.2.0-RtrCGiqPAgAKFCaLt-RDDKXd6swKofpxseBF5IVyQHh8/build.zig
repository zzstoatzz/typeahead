const std = @import("std");

const version = @import("build.zig.zon").version;

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const build_options = b.addOptions();
    build_options.addOption([]const u8, "version", version);

    const mod = b.addModule("zttp", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{
            .{ .name = "build_options", .module = build_options.createModule() },
        },
    });

    const tests = b.addTest(.{ .root_module = mod });
    const run_tests = b.addRunArtifact(tests);
    run_tests.skip_foreign_checks = true;
    const test_step = b.step("test", "run unit tests");
    test_step.dependOn(&run_tests.step);

    const smoke = b.addExecutable(.{
        .name = "smoke",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/smoke.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{
                .{ .name = "zttp", .module = mod },
            },
        }),
    });
    b.installArtifact(smoke);
    const run_smoke = b.addRunArtifact(smoke);
    run_smoke.addPassthruArgs();
    const smoke_step = b.step("smoke", "live smoke: real origins over tls, gzip, redirects, and a blackholed peer");
    smoke_step.dependOn(&run_smoke.step);
    const trust_probe = b.addExecutable(.{
        .name = "trust-probe",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/trust_probe.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "zttp", .module = mod }},
        }),
    });
    const run_trust_probe = b.addRunArtifact(trust_probe);
    b.step("trust-probe", "Reject incident TLS hosts and accept a valid control").dependOn(&run_trust_probe.step);
}

const std = @import("std");
const Client = @import("zttp").Client;

pub fn main(init: std.process.Init) !void {
    var client = Client.init(init.io, init.gpa);
    defer client.deinit();
    client.keep_alive = false;
    client.dead_connection_attempts = 0;
    for (hosts) |host| {
        const url = try std.fmt.allocPrint(init.arena.allocator(), "https://{s}/", .{host});
        if (client.fetch(.{ .url = url })) |result| {
            var unexpected = result;
            unexpected.deinit(init.gpa);
            return error.CompromisedChainAccepted;
        } else |err| {
            if (err != error.TlsInitializationFailed) return err;
            std.debug.print("rejected {s}: {s}\n", .{ host, @errorName(err) });
        }
    }
    var control = try client.fetch(.{ .url = "https://atproto.com/" });
    defer control.deinit(init.gpa);
    if (control.status != .ok) return error.ControlFailed;
    std.debug.print("control atproto.com: 200\n", .{});
}
const hosts = [_][]const u8{ "dv-g3b-emudhra.we-have-a-problem.com", "dv-g3b-aaa-emudhra.we-have-a-problem.com", "emudhra.divy.zone" };

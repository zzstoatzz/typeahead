const std = @import("std");
const log = @import("log.zig");

const segment_magic: u32 = 0x7a6b6e6c;
const head_magic: u32 = 0x7a6b6e68;
const header_len = 13;
const frame_header = 2 + 8 + 4;
const frame_trailer = 8;

pub const prefix = "node/";
pub const head_key = "node/head";
const checkpoint_key = "node/replay-index";
const checkpoint_magic: u32 = 0x7a6b6e69;

pub const Key = [prefix.len + 20]u8;

pub fn key(buf: *Key, ordinal: u64) []const u8 {
    return std.fmt.bufPrint(buf, prefix ++ "{d:0>20}", .{ordinal}) catch unreachable;
}

pub fn parseKey(name: []const u8) ?u64 {
    if (name.len != @sizeOf(Key) or !std.mem.startsWith(u8, name, prefix)) return null;
    return std.fmt.parseInt(u64, name[prefix.len..], 10) catch null;
}

pub const Frame = struct {
    db: []const u8,
    epoch: u64,
    body: []const u8,
};

fn frameSum(f: Frame) u64 {
    var h: std.hash.Wyhash = .init(0x66726d);
    h.update(f.db);
    h.update(std.mem.asBytes(&f.epoch));
    h.update(f.body);
    return h.final();
}

pub const Segment = struct {
    epoch: u64,
    fence: bool,
    frames: []const u8,

    pub fn decode(bytes: []const u8) error{Corrupt}!Segment {
        if (bytes.len < header_len + 4) return error.Corrupt;
        if (std.mem.readInt(u32, bytes[bytes.len - 4 ..][0..4], .little) != std.hash.Crc32.hash(bytes[0 .. bytes.len - 4])) return error.Corrupt;
        if (std.mem.readInt(u32, bytes[0..4], .little) != segment_magic or bytes[12] > 1) return error.Corrupt;
        return .{ .epoch = std.mem.readInt(u64, bytes[4..12], .little), .fence = bytes[12] == 1, .frames = bytes[header_len .. bytes.len - 4] };
    }

    pub fn iterator(self: Segment) Frames {
        return .{ .bytes = self.frames };
    }
};

pub const Frames = struct {
    bytes: []const u8,
    at: usize = 0,

    pub fn next(self: *Frames) error{Corrupt}!?Frame {
        if (self.at == self.bytes.len) return null;
        const rest = self.bytes[self.at..];
        if (rest.len < frame_header + frame_trailer) return error.Corrupt;
        const db_len = std.mem.readInt(u16, rest[0..2], .little);
        const epoch = std.mem.readInt(u64, rest[2..10], .little);
        const body_len = std.mem.readInt(u32, rest[10..14], .little);
        if (rest.len - frame_header - frame_trailer < @as(u64, db_len) + body_len) return error.Corrupt;
        const f: Frame = .{ .db = rest[frame_header..][0..db_len], .epoch = epoch, .body = rest[frame_header + db_len ..][0..body_len] };
        const sum_at = frame_header + db_len + body_len;
        if (std.mem.readInt(u64, rest[sum_at..][0..8], .little) != frameSum(f)) return error.Corrupt;
        self.at += sum_at + frame_trailer;
        return f;
    }
};

fn appendFrame(gpa: std.mem.Allocator, out: *std.ArrayList(u8), f: Frame) !void {
    const head = try out.addManyAsSlice(gpa, frame_header);
    std.mem.writeInt(u16, head[0..2], @intCast(f.db.len), .little);
    std.mem.writeInt(u64, head[2..10], f.epoch, .little);
    std.mem.writeInt(u32, head[10..14], @intCast(f.body.len), .little);
    try out.appendSlice(gpa, f.db);
    try out.appendSlice(gpa, f.body);
    std.mem.writeInt(u64, try out.addManyAsArray(gpa, 8), frameSum(f), .little);
}

pub const Options = struct {
    window_bytes: usize = 1 << 20,
    group_bytes: usize = 64 << 10,
    attempts: u32 = 16,
    floor: u64 = 0,
    /// re-read the head after each window lands, so a newer epoch fails the
    /// window at once. a writer whose own lease stops it acking once another
    /// may have opened the log can skip that read: a zombie's next window
    /// still collides with the newer epoch's fence segment, and only a
    /// fence already collected away would let it land unseen.
    verify_head: bool = true,
    replay_cache_bytes: usize = 0,
    checkpoint_replay_index: bool = false,
};

pub fn NodeLog(comptime Store: type) type {
    return struct {
        const Self = @This();

        gpa: std.mem.Allocator,
        store: *Store,
        options: Options,
        epoch: u64,
        etag: u64,
        floor: u64,
        swept: u64 = 0,
        next_ordinal: u64 = 0,
        dbs: std.StringHashMapUnmanaged(Db) = .empty,
        queue: std.ArrayList(*Ticket) = .empty,
        inflight: ?Inflight = null,
        broken: bool = false,
        replay_windows: std.AutoArrayHashMapUnmanaged(u64, []u8) = .empty,
        replay_bytes: usize = 0,
        index_records: std.ArrayList(u8) = .empty,
        index_etag: ?u64 = null,
        indexed_through: u64 = 0,
        index_failed: bool = false,

        const checkpoint_interval = 32;

        const max_replay_windows = 2048;

        const Db = struct {
            epoch: u64 = 0,
            registered: bool = false,
            applied: u64 = 0,
            frames: std.ArrayList(u64) = .empty,
        };

        const Inflight = struct {
            bytes: []u8,
            tickets: []*Ticket,
            attempts: u32 = 0,
        };

        pub const Ticket = struct {
            db: []const u8,
            group: []const u8,
            epoch: u64,
            body: []u8,
            ordinal: ?u64 = null,
            failure: ?anyerror = null,
            refs: u8 = 2,
        };

        pub fn open(gpa: std.mem.Allocator, store: *Store, options: Options) !*Self {
            const claimed = try claim(gpa, store, options.floor);
            const self = try gpa.create(Self);
            errdefer gpa.destroy(self);
            self.* = .{ .gpa = gpa, .store = store, .options = options, .epoch = claimed.epoch, .etag = claimed.etag, .floor = claimed.floor };
            errdefer self.deinitState();
            const checkpoint = if (options.checkpoint_replay_index) try store.get(gpa, checkpoint_key) else null;
            defer if (checkpoint) |object| gpa.free(object.bytes);
            const start = if (checkpoint) |object| try self.restoreIndex(object.bytes) else self.floor;
            try self.probe(start);
            self.index_etag = if (checkpoint) |object| object.etag else null;
            self.indexed_through = start;
            if (options.checkpoint_replay_index and start != self.next_ordinal - 2) {
                self.saveIndex(self.next_ordinal - 2) catch {};
            }
            return self;
        }

        const Head = struct { epoch: u64, floor: u64 };

        fn encodeHead(buf: *[20]u8, h: Head) []const u8 {
            std.mem.writeInt(u32, buf[0..4], head_magic, .little);
            std.mem.writeInt(u64, buf[4..12], h.epoch, .little);
            std.mem.writeInt(u64, buf[12..20], h.floor, .little);
            return buf;
        }

        fn decodeHead(bytes: []const u8) error{Corrupt}!Head {
            if (bytes.len != 20 or std.mem.readInt(u32, bytes[0..4], .little) != head_magic) return error.Corrupt;
            return .{ .epoch = std.mem.readInt(u64, bytes[4..12], .little), .floor = std.mem.readInt(u64, bytes[12..20], .little) };
        }

        fn claim(gpa: std.mem.Allocator, store: *Store, floor: u64) !struct { epoch: u64, etag: u64, floor: u64 } {
            var buf: [20]u8 = undefined;
            while (true) {
                const current = try store.get(gpa, head_key) orelse {
                    const etag = try store.putIfAbsent(head_key, encodeHead(&buf, .{ .epoch = 1, .floor = floor })) orelse continue;
                    return .{ .epoch = 1, .etag = etag, .floor = floor };
                };
                defer gpa.free(current.bytes);
                const h = try decodeHead(current.bytes);
                const etag = try store.cas(head_key, encodeHead(&buf, .{ .epoch = h.epoch + 1, .floor = h.floor }), current.etag) orelse continue;
                return .{ .epoch = h.epoch + 1, .etag = etag, .floor = h.floor };
            }
        }

        /// a window that does not decode and has no successor is the torn
        /// tail of a writer that died before its sync returned, never
        /// acknowledged, so dropped. one with a successor is corruption.
        fn tornTail(self: *Self, ordinal: u64) !bool {
            var buf: Key = undefined;
            if (try self.store.get(self.gpa, key(&buf, ordinal + 1))) |next_found| {
                self.gpa.free(next_found.bytes);
                return false;
            }
            try self.store.delete(key(&buf, ordinal));
            return true;
        }

        fn probe(self: *Self, indexed_through: u64) !void {
            const gpa = self.gpa;
            var buf: Key = undefined;
            var fence: std.ArrayList(u8) = .empty;
            defer fence.deinit(gpa);
            try encodeSegment(gpa, &fence, self.epoch, true, "");
            var ordinal = indexed_through + 1;
            while (true) : (ordinal += 1) {
                const found = try self.store.get(gpa, key(&buf, ordinal)) orelse found: {
                    if (try self.store.putIfAbsent(key(&buf, ordinal), fence.items)) |_| break;
                    break :found try self.store.get(gpa, key(&buf, ordinal)) orelse {
                        ordinal -= 1;
                        continue;
                    };
                };
                var retained = false;
                defer if (!retained) gpa.free(found.bytes);
                const segment = Segment.decode(found.bytes) catch |err| {
                    if (try self.tornTail(ordinal)) {
                        ordinal -= 1;
                        continue;
                    }
                    return err;
                };
                if (segment.epoch > self.epoch) return error.Fenced;
                if (segment.epoch == self.epoch) {
                    if (!segment.fence) return error.Corrupt;
                    break;
                }
                var frames = segment.iterator();
                while (try frames.next()) |f| {
                    if (try self.noteFrame(f.db, ordinal) and self.options.checkpoint_replay_index) {
                        try self.appendIndexRecord(f.db, ordinal);
                    }
                }
                if (!segment.fence) retained = self.retainWindow(ordinal, found.bytes);
            }
            self.next_ordinal = ordinal + 1;
        }

        fn restoreIndex(self: *Self, bytes: []const u8) !u64 {
            if (bytes.len < 24 or std.mem.readInt(u32, bytes[0..4], .little) != checkpoint_magic) return error.Corrupt;
            const payload = bytes[0 .. bytes.len - 4];
            if (std.mem.readInt(u32, bytes[payload.len..][0..4], .little) != std.hash.Crc32.hash(payload)) return error.Corrupt;
            const epoch = std.mem.readInt(u64, bytes[4..12], .little);
            const through = std.mem.readInt(u64, bytes[12..20], .little);
            if (epoch >= self.epoch) return error.Fenced;
            if (through <= self.floor) return self.floor;
            var records = payload[20..];
            while (records.len > 0) {
                if (records.len < 10) return error.Corrupt;
                const len = std.mem.readInt(u16, records[0..2], .little);
                const ordinal = std.mem.readInt(u64, records[2..10], .little);
                records = records[10..];
                if (len > records.len or ordinal > through) return error.Corrupt;
                if (ordinal > self.floor and try self.noteFrame(records[0..len], ordinal)) {
                    try self.appendIndexRecord(records[0..len], ordinal);
                }
                records = records[len..];
            }
            return through;
        }

        fn appendIndexRecord(self: *Self, db: []const u8, ordinal: u64) !void {
            const record = try self.index_records.addManyAsSlice(self.gpa, 10 + db.len);
            std.mem.writeInt(u16, record[0..2], @intCast(db.len), .little);
            std.mem.writeInt(u64, record[2..10], ordinal, .little);
            @memcpy(record[10..], db);
        }

        fn pruneIndex(self: *Self) void {
            const records = self.index_records.items;
            var read: usize = 0;
            var write: usize = 0;
            while (read < records.len) {
                const len = 10 + @as(usize, std.mem.readInt(u16, records[read..][0..2], .little));
                const ordinal = std.mem.readInt(u64, records[read..][2..10], .little);
                if (ordinal > self.floor) {
                    std.mem.copyForwards(u8, records[write..][0..len], records[read..][0..len]);
                    write += len;
                }
                read += len;
            }
            self.index_records.shrinkRetainingCapacity(write);
        }

        fn saveIndex(self: *Self, through: u64) !void {
            const gpa = self.gpa;
            self.pruneIndex();
            var bytes: std.ArrayList(u8) = .empty;
            defer bytes.deinit(gpa);
            const header = try bytes.addManyAsArray(gpa, 20);
            std.mem.writeInt(u32, header[0..4], checkpoint_magic, .little);
            std.mem.writeInt(u64, header[4..12], self.epoch, .little);
            std.mem.writeInt(u64, header[12..20], through, .little);
            try bytes.appendSlice(gpa, self.index_records.items);
            try endSegment(gpa, &bytes);
            self.index_etag = (if (self.index_etag) |etag|
                try self.store.cas(checkpoint_key, bytes.items, etag)
            else
                try self.store.putIfAbsent(checkpoint_key, bytes.items)) orelse {
                self.index_failed = true;
                return;
            };
            self.indexed_through = through;
        }

        fn retainWindow(self: *Self, ordinal: u64, bytes: []u8) bool {
            const limit = self.options.replay_cache_bytes;
            if (limit == 0 or bytes.len > limit) return false;
            self.replay_windows.ensureUnusedCapacity(self.gpa, 1) catch return false;
            while (self.replay_windows.count() == max_replay_windows or self.replay_bytes > limit - bytes.len) {
                const old = self.replay_windows.values()[0];
                self.replay_bytes -= old.len;
                self.gpa.free(old);
                self.replay_windows.orderedRemoveAt(0);
            }
            self.replay_windows.putAssumeCapacity(ordinal, bytes);
            self.replay_bytes += bytes.len;
            return true;
        }

        fn noteFrame(self: *Self, db: []const u8, ordinal: u64) !bool {
            const gpa = self.gpa;
            const slot = try self.dbs.getOrPut(gpa, db);
            if (!slot.found_existing) {
                slot.key_ptr.* = try gpa.dupe(u8, db);
                slot.value_ptr.* = .{};
            }
            const frames = &slot.value_ptr.frames;
            if (frames.items.len > 0 and frames.items[frames.items.len - 1] == ordinal) return false;
            try frames.append(gpa, ordinal);
            return true;
        }

        fn deinitState(self: *Self) void {
            const gpa = self.gpa;
            for (self.replay_windows.values()) |bytes| gpa.free(bytes);
            self.replay_windows.deinit(gpa);
            self.index_records.deinit(gpa);
            var it = self.dbs.iterator();
            while (it.next()) |kv| {
                gpa.free(kv.key_ptr.*);
                kv.value_ptr.frames.deinit(gpa);
            }
            self.dbs.deinit(gpa);
            for (self.queue.items) |t| {
                self.fail(t, error.Closed);
                self.release(t);
            }
            self.queue.deinit(gpa);
            if (self.inflight) |in| {
                for (in.tickets) |t| {
                    self.fail(t, error.Closed);
                    self.release(t);
                }
                gpa.free(in.tickets);
                gpa.free(in.bytes);
            }
        }

        fn fail(self: *Self, t: *Ticket, err: anyerror) void {
            if (t.ordinal == null and t.failure == null) t.failure = err;
            _ = self;
        }

        pub fn close(self: *Self) void {
            self.deinitState();
            self.gpa.destroy(self);
        }

        fn usable(self: *const Self) !void {
            if (self.broken) return error.Broken;
        }

        pub fn register(self: *Self, db: []const u8, epoch: u64, applied: u64, sink: anytype) !void {
            return self.registerFrom(db, epoch, applied, applied, sink);
        }

        /// `applied` is the durable table watermark. `after` is the last
        /// complete window already delivered to a paged replay caller.
        pub fn registerFrom(self: *Self, db: []const u8, epoch: u64, applied: u64, after: u64, sink: anytype) !void {
            try self.usable();
            const gpa = self.gpa;
            const slot = try self.dbs.getOrPut(gpa, db);
            if (!slot.found_existing) {
                slot.key_ptr.* = try gpa.dupe(u8, db);
                slot.value_ptr.* = .{};
            }
            const state = slot.value_ptr;
            if (epoch < state.epoch) return error.Fenced;
            state.epoch = epoch;
            state.registered = true;
            state.applied = applied;
            var buf: Key = undefined;
            const start = std.sort.upperBound(u64, state.frames.items, @max(applied, after), compareOrdinal);
            for (state.frames.items[start..]) |ordinal| {
                if (self.replay_windows.get(ordinal)) |bytes| {
                    try replayWindow(bytes, db, epoch, ordinal, sink);
                } else {
                    const found = try self.store.get(gpa, key(&buf, ordinal)) orelse return error.Missing;
                    defer gpa.free(found.bytes);
                    try replayWindow(found.bytes, db, epoch, ordinal, sink);
                }
            }
            try sink.reached(self.next_ordinal - 1);
            self.trim(state);
        }

        fn replayWindow(bytes: []const u8, db: []const u8, epoch: u64, ordinal: u64, sink: anytype) !void {
            const segment = try Segment.decode(bytes);
            var frames = segment.iterator();
            while (try frames.next()) |f| {
                if (!std.mem.eql(u8, f.db, db)) continue;
                if (f.epoch > epoch) return error.Fenced;
                try sink.landed(ordinal, log.Iterator{ .body = f.body });
            }
        }

        fn compareOrdinal(a: u64, b: u64) std.math.Order {
            return std.math.order(a, b);
        }

        pub fn forget(self: *Self, db: []const u8) void {
            const kv = self.dbs.fetchRemove(db) orelse return;
            self.gpa.free(kv.key);
            var frames = kv.value.frames;
            frames.deinit(self.gpa);
        }

        fn trim(self: *Self, state: *Db) void {
            _ = self;
            var drop: usize = 0;
            while (drop < state.frames.items.len and state.frames.items[drop] <= state.applied) drop += 1;
            state.frames.replaceRangeAssumeCapacity(0, drop, &.{});
        }

        pub fn submit(self: *Self, db: []const u8, group: []const u8, epoch: u64, body: []const u8) !*Ticket {
            try self.usable();
            const state = self.dbs.getPtr(db) orelse return error.Unregistered;
            if (!state.registered or epoch != state.epoch) return error.Fenced;
            const gpa = self.gpa;
            try self.queue.ensureUnusedCapacity(gpa, 1);
            const t = try gpa.create(Ticket);
            errdefer gpa.destroy(t);
            t.* = .{ .db = self.dbs.getKey(db).?, .group = group, .epoch = epoch, .body = try gpa.dupe(u8, body) };
            self.queue.appendAssumeCapacity(t);
            return t;
        }

        pub fn release(self: *Self, t: *Ticket) void {
            t.refs -= 1;
            if (t.refs > 0) return;
            self.gpa.free(t.body);
            self.gpa.destroy(t);
        }

        pub fn wait(self: *Self, t: *Ticket) !u64 {
            while (true) {
                if (t.ordinal) |o| return o;
                if (t.failure) |err| return err;
                try self.flush();
            }
        }

        pub fn flush(self: *Self) !void {
            try self.usable();
            if (self.inflight == null) try self.freeze();
            const in = &(self.inflight orelse return);
            const gpa = self.gpa;
            var buf: Key = undefined;
            while (true) {
                const landed = self.attempt(in, &buf) catch |err| switch (err) {
                    error.Fenced => return self.breakWith(err),
                    else => {
                        in.attempts += 1;
                        if (in.attempts >= self.options.attempts) return self.breakWith(err);
                        return err;
                    },
                };
                if (landed) break;
            }
            const ordinal = self.next_ordinal;
            self.next_ordinal += 1;
            if (self.options.checkpoint_replay_index and !self.index_failed) {
                for (in.tickets) |t| self.appendIndexRecord(t.db, ordinal) catch {
                    self.index_failed = true;
                    break;
                };
                if (!self.index_failed and ordinal - self.indexed_through >= checkpoint_interval) {
                    self.saveIndex(ordinal) catch {};
                }
            }
            for (in.tickets) |t| {
                t.ordinal = ordinal;
                if (self.dbs.getPtr(t.db)) |state| try self.noteFrameIn(state, ordinal);
                self.release(t);
            }
            gpa.free(in.tickets);
            gpa.free(in.bytes);
            self.inflight = null;
        }

        fn noteFrameIn(self: *Self, state: *Db, ordinal: u64) !void {
            const frames = &state.frames;
            if (frames.items.len > 0 and frames.items[frames.items.len - 1] == ordinal) return;
            try frames.append(self.gpa, ordinal);
        }

        fn attempt(self: *Self, in: *Inflight, buf: *Key) !bool {
            const gpa = self.gpa;
            if (try self.store.putIfAbsent(key(buf, self.next_ordinal), in.bytes) == null) {
                const found = try self.store.get(gpa, key(buf, self.next_ordinal)) orelse return false;
                defer gpa.free(found.bytes);
                if (!std.mem.eql(u8, found.bytes, in.bytes)) return error.Fenced;
            }
            if (!self.options.verify_head) return true;
            const head = try self.store.get(gpa, head_key) orelse return error.Fenced;
            defer gpa.free(head.bytes);
            if ((try decodeHead(head.bytes)).epoch != self.epoch) return error.Fenced;
            return true;
        }

        fn breakWith(self: *Self, err: anyerror) anyerror {
            self.broken = true;
            if (self.inflight) |in| for (in.tickets) |t| self.fail(t, err);
            for (self.queue.items) |t| self.fail(t, err);
            return err;
        }

        fn freeze(self: *Self) !void {
            if (self.queue.items.len == 0) return;
            const gpa = self.gpa;
            var bytes: std.ArrayList(u8) = .empty;
            errdefer bytes.deinit(gpa);
            try beginSegment(gpa, &bytes, self.epoch, false);
            var taken: std.ArrayList(*Ticket) = .empty;
            errdefer taken.deinit(gpa);
            var kept: usize = 0;
            var groups: std.StringHashMapUnmanaged(usize) = .empty;
            defer groups.deinit(gpa);
            for (self.queue.items) |t| {
                const used = try groups.getOrPut(gpa, t.group);
                if (!used.found_existing) used.value_ptr.* = 0;
                const cost = frame_header + t.db.len + t.body.len + frame_trailer;
                const over_group = used.value_ptr.* > 0 and used.value_ptr.* + cost > self.options.group_bytes;
                const over_window = taken.items.len > 0 and bytes.items.len + cost > self.options.window_bytes;
                if (over_group or over_window) {
                    self.queue.items[kept] = t;
                    kept += 1;
                    continue;
                }
                used.value_ptr.* += cost;
                try appendFrame(gpa, &bytes, .{ .db = t.db, .epoch = t.epoch, .body = t.body });
                try taken.append(gpa, t);
            }
            self.queue.shrinkRetainingCapacity(kept);
            try endSegment(gpa, &bytes);
            self.inflight = .{ .bytes = try bytes.toOwnedSlice(gpa), .tickets = try taken.toOwnedSlice(gpa) };
        }

        pub fn flushed(self: *Self, db: []const u8, ordinal: u64) void {
            const state = self.dbs.getPtr(db) orelse return;
            state.applied = @max(state.applied, ordinal);
            self.trim(state);
        }

        pub fn next(self: *const Self) u64 {
            return self.next_ordinal;
        }

        /// raises the floor past the windows no db needs, then deletes them.
        pub fn collect(self: *Self) !void {
            const floor = try self.raiseFloor();
            if (self.swept == floor) return;
            try sweep(self.gpa, self.store, floor);
            self.swept = floor;
        }

        /// raises the durable floor past every window no db still needs and
        /// returns it. the windows at or below it stay in the store for `sweep`.
        pub fn raiseFloor(self: *Self) !u64 {
            try self.usable();
            var watermark = self.next_ordinal - 1;
            var it = self.dbs.valueIterator();
            while (it.next()) |state| {
                if (state.frames.items.len > 0) watermark = @min(watermark, state.frames.items[0] - 1);
            }
            if (watermark > self.floor) {
                var buf: [20]u8 = undefined;
                self.etag = try self.store.cas(head_key, encodeHead(&buf, .{ .epoch = self.epoch, .floor = watermark }), self.etag) orelse return self.breakWith(error.Fenced);
                self.floor = watermark;
            }
            return self.floor;
        }
    };
}

/// deletes the node log's windows at or below `floor`, one store call each.
/// it reads nothing of a node's, so it can run beside the node's own calls
/// when the store takes concurrent calls; replay never reads below the floor.
pub fn sweep(gpa: std.mem.Allocator, store: anytype, floor: u64) !void {
    const names = try store.list(gpa, prefix);
    defer @import("store.zig").freeNames(gpa, names);
    for (names) |name| {
        const ordinal = parseKey(name) orelse continue;
        if (ordinal <= floor) try store.delete(name);
    }
}

fn beginSegment(gpa: std.mem.Allocator, out: *std.ArrayList(u8), epoch: u64, fence: bool) !void {
    out.clearRetainingCapacity();
    const head = try out.addManyAsSlice(gpa, header_len);
    std.mem.writeInt(u32, head[0..4], segment_magic, .little);
    std.mem.writeInt(u64, head[4..12], epoch, .little);
    head[12] = @intFromBool(fence);
}

fn endSegment(gpa: std.mem.Allocator, out: *std.ArrayList(u8)) !void {
    const crc = std.hash.Crc32.hash(out.items);
    std.mem.writeInt(u32, try out.addManyAsArray(gpa, 4), crc, .little);
}

fn encodeSegment(gpa: std.mem.Allocator, out: *std.ArrayList(u8), epoch: u64, fence: bool, frames: []const u8) !void {
    try beginSegment(gpa, out, epoch, fence);
    try out.appendSlice(gpa, frames);
    try endSegment(gpa, out);
}

pub fn NodeClient(comptime Node: type) type {
    return struct {
        const Self = @This();

        pub const Context = struct { node: *Node, db: []const u8, group: []const u8 };
        pub const Ticket = *Node.Ticket;

        gpa: std.mem.Allocator,
        context: Context,
        epoch: u64 = 0,
        abandoned: std.ArrayList(*Node.Ticket) = .empty,

        pub fn init(gpa: std.mem.Allocator, _: anytype, context: Context) Self {
            return .{ .gpa = gpa, .context = context };
        }

        pub fn deinit(self: *Self) void {
            for (self.abandoned.items) |t| self.context.node.release(t);
            self.abandoned.deinit(self.gpa);
        }

        pub fn state(_: *const Self) []const u64 {
            return &.{};
        }

        pub fn next(self: *const Self) u64 {
            return self.context.node.next();
        }

        pub fn recover(self: *Self, epoch: u64, applied: u64, _: []const u64, sink: anytype) !void {
            self.epoch = epoch;
            try self.context.node.register(self.context.db, epoch, applied, sink);
        }

        pub fn begin(self: *Self, body: []const u8) !Ticket {
            try self.abandoned.ensureUnusedCapacity(self.gpa, 1);
            return self.context.node.submit(self.context.db, self.context.group, self.epoch, body);
        }

        pub fn drop(self: *Self, ticket: Ticket) void {
            self.context.node.release(ticket);
        }

        pub fn finish(self: *Self, ticket: Ticket, sink: anytype) !u64 {
            const ordinal = self.context.node.wait(ticket) catch |err| {
                self.abandoned.appendAssumeCapacity(ticket);
                return err;
            };
            self.context.node.release(ticket);
            try self.settle(sink);
            return ordinal;
        }

        pub fn settle(self: *Self, sink: anytype) !void {
            var i: usize = 0;
            while (i < self.abandoned.items.len) {
                const t = self.abandoned.items[i];
                if (t.ordinal) |ordinal| {
                    try sink.landed(ordinal, log.Iterator{ .body = t.body });
                } else if (t.failure == null) {
                    i += 1;
                    continue;
                }
                _ = self.abandoned.swapRemove(i);
                self.context.node.release(t);
            }
        }

        pub fn collect(self: *Self, applied: u64) !void {
            self.context.node.flushed(self.context.db, applied);
            try self.context.node.collect();
        }
    };
}

const Sink = struct {
    pub fn landed(_: *Sink, _: u64, _: log.Iterator) !void {}
    pub fn reached(_: *Sink, _: u64) !void {}
};

test "without the head check, a zombie's next window still meets the newer fence" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);
    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    var sink: Sink = .{};
    for ([_]bool{ true, false }) |verify_head| {
        const old = try Node.open(gpa, &store, .{ .verify_head = verify_head });
        defer old.close();
        try old.register("a", 1, 0, &sink);
        const landed = try old.submit("a", "g", 1, "before");
        try std.testing.expect((try old.wait(landed)) > 0);
        old.release(landed);
        const fresh = try Node.open(gpa, &store, .{ .verify_head = verify_head });
        defer fresh.close();
        const late = try old.submit("a", "g", 1, "after");
        try std.testing.expectError(error.Fenced, old.wait(late));
        old.release(late);
        try std.testing.expect(old.broken);
    }
}

const Page = struct {
    ordinals: [3]u64 = undefined,
    count: usize = 0,
    limit: usize = 3,

    pub fn landed(p: *@This(), ordinal: u64, _: log.Iterator) !void {
        if (p.count == p.limit) return error.PageFull;
        p.ordinals[p.count] = ordinal;
        p.count += 1;
    }

    pub fn reached(_: *@This(), _: u64) !void {}
};

test "a replay page never advances the durable watermark" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);

    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    const writer = try Node.open(gpa, &store, .{});
    defer writer.close();
    var sink: Sink = .{};
    try writer.register("poll", 1, 0, &sink);
    var acknowledged: [3]u64 = undefined;
    for (&acknowledged) |*ordinal| {
        const ticket = try writer.submit("poll", "tenant", 1, "vote");
        defer writer.release(ticket);
        ordinal.* = try writer.wait(ticket);
    }

    var first: Page = .{ .limit = 1 };
    try std.testing.expectError(error.PageFull, writer.registerFrom("poll", 2, 0, 0, &first));
    try std.testing.expectEqualSlices(u64, acknowledged[0..1], first.ordinals[0..first.count]);

    var rest: Page = .{};
    try writer.registerFrom("poll", 2, 0, first.ordinals[0], &rest);
    try std.testing.expectEqualSlices(u64, acknowledged[1..], rest.ordinals[0..rest.count]);
    try writer.collect();

    const replacement = try Node.open(gpa, &store, .{});
    defer replacement.close();
    var replay: Page = .{};
    try replacement.register("poll", 3, 0, &replay);
    try std.testing.expectEqualSlices(u64, &acknowledged, replay.ordinals[0..replay.count]);
}

test "recovery still reads acknowledged windows that exceed the cache budget" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);
    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    {
        const writer = try Node.open(gpa, &store, .{});
        defer writer.close();
        var sink: Sink = .{};
        try writer.register("poll", 1, 0, &sink);
        for ([_][]const u8{ "a", "b", "c" }) |body| {
            const ticket = try writer.submit("poll", "tenant", 1, body);
            defer writer.release(ticket);
            _ = try writer.wait(ticket);
        }
    }

    const replacement = try Node.open(gpa, &store, .{ .replay_cache_bytes = 64 });
    defer replacement.close();
    try std.testing.expectEqual(@as(usize, 1), replacement.replay_windows.count());
    const Replay = struct {
        bytes: std.ArrayList(u8) = .empty,
        pub fn landed(r: *@This(), _: u64, frame: log.Iterator) !void {
            try r.bytes.appendSlice(std.testing.allocator, frame.body);
        }
        pub fn reached(_: *@This(), _: u64) !void {}
    };
    var replay: Replay = .{};
    defer replay.bytes.deinit(gpa);
    try replacement.register("poll", 2, 0, &replay);
    try std.testing.expectEqualStrings("abc", replay.bytes.items);
}

test "recovery drops a torn tail window and rejects corruption before a landed one" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);
    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    var whole: std.ArrayList(u8) = .empty;
    defer whole.deinit(gpa);
    try encodeSegment(gpa, &whole, 0, false, "");
    var buf: Key = undefined;
    try store.put(key(&buf, 1), whole.items);
    try store.put(key(&buf, 2), whole.items[0 .. whole.items.len / 2]);
    {
        const node = try Node.open(gpa, &store, .{});
        defer node.close();
        try std.testing.expectEqual(@as(u64, 3), node.next_ordinal);
        const fence = (try store.get(gpa, key(&buf, 2))).?;
        defer gpa.free(fence.bytes);
        try std.testing.expect((try Segment.decode(fence.bytes)).fence);
    }
    try store.put(key(&buf, 2), whole.items[0 .. whole.items.len / 2]);
    try store.put(key(&buf, 3), whole.items);
    try std.testing.expectError(error.Corrupt, Node.open(gpa, &store, .{}));
}

test "checkpoint restores the indexed prefix and probes a later writer tail" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);
    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    const options: Options = .{ .checkpoint_replay_index = true, .replay_cache_bytes = 4096 };
    var sink: Sink = .{};
    const first = try Node.open(gpa, &store, .{});
    defer first.close();
    try first.register("poll", 1, 0, &sink);
    const a = try first.submit("poll", "tenant", 1, "a");
    defer first.release(a);
    const a_ordinal = try first.wait(a);

    const second = try Node.open(gpa, &store, options);
    defer second.close();
    try second.register("poll", 2, 0, &sink);
    const b = try second.submit("poll", "tenant", 2, "b");
    defer second.release(b);
    const b_ordinal = try second.wait(b);

    const replacement = try Node.open(gpa, &store, options);
    defer replacement.close();
    try std.testing.expect(!replacement.replay_windows.contains(a_ordinal));
    try std.testing.expect(replacement.replay_windows.contains(b_ordinal));
    var page: Page = .{ .limit = 2 };
    try replacement.register("poll", 3, 0, &page);
    try std.testing.expectEqualSlices(u64, &.{ a_ordinal, b_ordinal }, page.ordinals[0..page.count]);

    const stale = try second.submit("poll", "tenant", 2, "stale");
    defer second.release(stale);
    try std.testing.expectError(error.Fenced, second.wait(stale));
}

test "steady-state checkpoint bounds the tail and survives forgetting a database" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);
    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    const options: Options = .{ .checkpoint_replay_index = true, .replay_cache_bytes = 4096 };
    var sink: Sink = .{};
    const writer = try Node.open(gpa, &store, options);
    defer writer.close();
    try writer.register("poll", 1, 0, &sink);
    const first = try writer.submit("poll", "tenant", 1, "first");
    defer writer.release(first);
    const ordinal = try writer.wait(first);
    writer.forget("poll");

    try writer.register("other", 1, 0, &sink);
    for (0..2 * Node.checkpoint_interval) |_| {
        const ticket = try writer.submit("other", "tenant", 1, "tail");
        defer writer.release(ticket);
        _ = try writer.wait(ticket);
    }

    const replacement = try Node.open(gpa, &store, options);
    defer replacement.close();
    try std.testing.expect(replacement.replay_windows.count() < Node.checkpoint_interval);
    var page: Page = .{};
    try replacement.register("poll", 2, 0, &page);
    try std.testing.expectEqualSlices(u64, &.{ordinal}, page.ordinals[0..page.count]);
}

test "a raised floor keeps its windows until a separate sweep deletes them" {
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const Node = NodeLog(MemoryStore);

    var store: MemoryStore = .init(gpa);
    defer store.deinit();
    const writer = try Node.open(gpa, &store, .{});
    defer writer.close();
    var sink: Sink = .{};
    try writer.register("poll", 1, 0, &sink);
    try writer.register("other", 1, 0, &sink);
    var last: u64 = 0;
    for (0..3) |_| {
        const ticket = try writer.submit("poll", "tenant", 1, "vote");
        defer writer.release(ticket);
        last = try writer.wait(ticket);
    }
    const kept = try writer.submit("other", "tenant", 1, "pending");
    defer writer.release(kept);
    const pending = try writer.wait(kept);
    writer.flushed("poll", last);

    const floor = try writer.raiseFloor();
    try std.testing.expectEqual(pending - 1, floor);
    const before = try windowsAtOrBelow(gpa, &store, floor);
    try std.testing.expect(before > 0);

    try sweep(gpa, &store, floor);
    try std.testing.expectEqual(0, try windowsAtOrBelow(gpa, &store, floor));
    var buf: Key = undefined;
    const survivor = (try store.get(gpa, key(&buf, pending))).?;
    gpa.free(survivor.bytes);

    const replacement = try Node.open(gpa, &store, .{});
    defer replacement.close();
    var replay: Page = .{};
    try replacement.register("other", 2, 0, &replay);
    try std.testing.expectEqualSlices(u64, &.{pending}, replay.ordinals[0..replay.count]);
}

fn windowsAtOrBelow(gpa: std.mem.Allocator, store: anytype, floor: u64) !usize {
    const names = try store.list(gpa, prefix);
    defer @import("store.zig").freeNames(gpa, names);
    var n: usize = 0;
    for (names) |name| if (parseKey(name)) |ordinal| {
        if (ordinal <= floor) n += 1;
    };
    return n;
}

const std = @import("std");

const magic: u32 = 0x7a6b766e;

pub const key = "manifest";
pub const levels = 7;

pub const table_prefix = "sst/";

pub const TableKey = [table_prefix.len + 16]u8;

pub fn tableKey(buf: *TableKey, id: u64) []const u8 {
    return std.fmt.bufPrint(buf, table_prefix ++ "{x:0>16}", .{id}) catch unreachable;
}

pub fn parseTableKey(name: []const u8) ?u64 {
    if (name.len != @sizeOf(TableKey) or !std.mem.startsWith(u8, name, table_prefix)) return null;
    return std.fmt.parseInt(u64, name[table_prefix.len..], 16) catch null;
}

pub const Ref = struct {
    id: u64,
    size: u64,
    meta_at: u64,
    hash: u64,
};

pub fn hash(bytes: []const u8) u64 {
    return std.hash.Wyhash.hash(0x7a6b, bytes);
}

pub const Manifest = struct {
    epoch: u64,
    applied: u64,
    fences: []const u64,
    tables: [levels][]const Ref,
};

pub fn encode(gpa: std.mem.Allocator, out: *std.ArrayList(u8), m: Manifest) !void {
    out.clearRetainingCapacity();
    try writeInt(gpa, out, u32, magic);
    try writeInt(gpa, out, u64, m.epoch);
    try writeInt(gpa, out, u64, m.applied);
    try writeIds(gpa, out, m.fences);
    for (m.tables) |refs| {
        try writeInt(gpa, out, u32, @intCast(refs.len));
        for (refs) |ref| inline for (.{ "id", "size", "meta_at", "hash" }) |field| try writeInt(gpa, out, u64, @field(ref, field));
    }
    try writeInt(gpa, out, u32, std.hash.Crc32.hash(out.items));
}

fn writeInt(gpa: std.mem.Allocator, out: *std.ArrayList(u8), comptime T: type, value: T) !void {
    std.mem.writeInt(T, try out.addManyAsArray(gpa, @sizeOf(T)), value, .little);
}

fn writeIds(gpa: std.mem.Allocator, out: *std.ArrayList(u8), ids: []const u64) !void {
    try writeInt(gpa, out, u32, @intCast(ids.len));
    for (ids) |id| try writeInt(gpa, out, u64, id);
}

pub const Decoded = struct {
    manifest: Manifest,
    ids: []const u64,
    refs: []const Ref,

    pub fn deinit(self: Decoded, gpa: std.mem.Allocator) void {
        gpa.free(self.ids);
        gpa.free(self.refs);
    }
};

pub fn decode(gpa: std.mem.Allocator, bytes: []const u8) !Decoded {
    if (bytes.len < 24 + 4 * (levels + 1)) return error.Corrupt;
    const body = bytes[0 .. bytes.len - 4];
    if (std.mem.readInt(u32, bytes[body.len..][0..4], .little) != std.hash.Crc32.hash(body)) return error.Corrupt;
    var reader: Reader = .{ .bytes = body };
    if (try reader.int(u32) != magic) return error.Corrupt;
    const epoch = try reader.int(u64);
    const applied = try reader.int(u64);
    const ids = try gpa.alloc(u64, (body.len - 24) / 8);
    errdefer gpa.free(ids);
    var used: usize = 0;
    const fences = try reader.ids(ids, &used);
    const refs = try gpa.alloc(Ref, (body.len - 24) / 32);
    errdefer gpa.free(refs);
    var placed: usize = 0;
    var tables: [levels][]const Ref = undefined;
    for (&tables) |*level| {
        const count = try reader.int(u32);
        if (refs.len - placed < count) return error.Corrupt;
        const out = refs[placed..][0..count];
        for (out) |*ref| ref.* = .{ .id = try reader.int(u64), .size = try reader.int(u64), .meta_at = try reader.int(u64), .hash = try reader.int(u64) };
        placed += count;
        level.* = out;
    }
    if (reader.at != body.len) return error.Corrupt;
    return .{ .manifest = .{ .epoch = epoch, .applied = applied, .fences = fences, .tables = tables }, .ids = ids, .refs = refs };
}

const Reader = struct {
    bytes: []const u8,
    at: usize = 0,

    fn int(self: *Reader, comptime T: type) error{Corrupt}!T {
        if (self.bytes.len - self.at < @sizeOf(T)) return error.Corrupt;
        defer self.at += @sizeOf(T);
        return std.mem.readInt(T, self.bytes[self.at..][0..@sizeOf(T)], .little);
    }

    fn ids(self: *Reader, into: []u64, used: *usize) error{Corrupt}![]const u64 {
        const count = try self.int(u32);
        if (into.len - used.* < count) return error.Corrupt;
        const out = into[used.*..][0..count];
        for (out) |*id| id.* = try self.int(u64);
        used.* += count;
        return out;
    }
};

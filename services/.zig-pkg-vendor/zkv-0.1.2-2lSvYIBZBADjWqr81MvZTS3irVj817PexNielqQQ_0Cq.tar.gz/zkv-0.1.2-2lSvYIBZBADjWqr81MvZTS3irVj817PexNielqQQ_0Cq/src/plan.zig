const Version = @import("version.zig").Version;
const levels = @import("manifest.zig").levels;

pub const Shape = struct {
    l0_tables: usize,
    level_bytes: u64,
    growth: u64,
};

pub fn plan(version: *const Version, shape: Shape) ?usize {
    if (version.tables[0].len >= shape.l0_tables) return 0;
    var target = shape.level_bytes;
    for (1..levels - 1) |level| {
        if (version.levelBytes(level) > target) return level;
        target *|= shape.growth;
    }
    return null;
}

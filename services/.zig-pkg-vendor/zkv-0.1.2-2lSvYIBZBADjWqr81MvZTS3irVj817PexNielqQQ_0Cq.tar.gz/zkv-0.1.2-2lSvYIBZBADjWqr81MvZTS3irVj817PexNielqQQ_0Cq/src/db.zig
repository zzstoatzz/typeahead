const std = @import("std");
const entry = @import("entry.zig");
const bloom = @import("bloom.zig");
const log = @import("log.zig");
const manifest = @import("manifest.zig");
const sst = @import("sst.zig");
const merge = @import("merge.zig");
const plan = @import("plan.zig");
const memtable = @import("memtable.zig");
const Memtable = memtable.Memtable;
const Table = @import("version.zig").Table;
const Version = @import("version.zig").Version;
const Cache = @import("cache.zig").Cache;
const Cached = @import("cache.zig").Cached;
const SegmentLog = @import("seglog.zig").SegmentLog;

const levels = manifest.levels;
const unbounded = std.math.maxInt(u64);
/// the most log segments a reader asks for in one round
const tail_window_max = 32;

pub const Options = struct {
    block_bytes: usize = 4096,
    table_bytes: usize = 8 << 20,
    bits_per_key: u32 = 10,
    table_encoding: sst.Encoding = .legacy,
    memtable_bytes: usize = 32 << 20,
    l0_tables: usize = 4,
    level_bytes: u64 = 64 << 20,
    growth: u64 = 10,
    /// Soft decoded-block cache charge, including entry structs. The newest
    /// block may exceed it. Evicted pins, map capacity and allocator overhead
    /// are excluded; this is not a bound on process or database memory.
    cache_bytes: usize = 1 << 20,
    /// Fence keys kept resident per table. 1 pins every table's whole
    /// metadata tail (fence index, bloom filter, min key) for the Db's
    /// lifetime. N keeps one fence in N and the bloom and min key, and
    /// fetches the fence entries between samples through the block cache,
    /// one range read of about N fence entries per cold partition; data block
    /// reads then need the partition too. Every table's tail is still read
    /// whole on open to check its hash. `residentMetadataBytes` reports the
    /// result.
    fence_stride: u32 = 1,
};

pub const Entry = struct {
    key: []const u8,
    value: []const u8,
};

pub const ScanOptions = struct {
    start: ?[]const u8 = null,
    end: ?[]const u8 = null,
    reverse: bool = false,
    limit: usize = std.math.maxInt(usize),
};

pub const CompactionProgress = enum { idle, progress, waiting };
pub const CompactionPhase = enum { idle, merge, verify, write, writing, publish };

pub fn Db(comptime Store: type) type {
    return DbWith(Store, SegmentLog(Store));
}

pub fn DbWith(comptime Store: type, comptime Log: type) type {
    return struct {
        const Self = @This();

        gpa: std.mem.Allocator,
        store: *Store,
        options: Options,
        epoch: u64,
        etag: u64,
        version: *Version,
        log: Log,
        memtable: *Memtable,
        batch: *Memtable,
        seq: u64 = 0,
        next_table: u32 = 0,
        attempt: ?Attempt = null,
        obsolete: std.ArrayList(u64) = .empty,
        retired: std.ArrayList(*Table) = .empty,
        scratch: std.ArrayList(u8) = .empty,
        fenced: bool = false,
        broken: bool = false,
        reader: bool = false,
        cache: Cache,
        held: ?*Cached = null,
        committing: ?Log.Ticket = null,
        compaction: ?*Compaction(true) = null,

        const Attempt = struct {
            bytes: []u8,
            version: *Version,
            created: []u64,
        };

        pub fn open(gpa: std.mem.Allocator, store: *Store, options: Options) !*Self {
            return openWith(gpa, store, {}, options);
        }

        pub fn openWith(gpa: std.mem.Allocator, store: *Store, context: Log.Context, options: Options) !*Self {
            var scratch: std.ArrayList(u8) = .empty;
            errdefer scratch.deinit(gpa);
            const claimed = try claim(gpa, store, &scratch);
            defer claimed.decoded.deinit(gpa);
            const m = claimed.decoded.manifest;

            const version = try loadVersion(gpa, store, m, null, options.fence_stride);
            errdefer version.release(gpa);

            const mem = try Memtable.create(gpa, m.applied);
            errdefer mem.release(gpa);
            const batch = try Memtable.create(gpa, 0);
            errdefer batch.release(gpa);

            const self = try gpa.create(Self);
            errdefer gpa.destroy(self);
            self.* = .{
                .gpa = gpa,
                .store = store,
                .options = options,
                .epoch = claimed.epoch,
                .etag = claimed.etag,
                .version = version,
                .memtable = mem,
                .batch = batch,
                .scratch = scratch,
                .cache = .{ .gpa = gpa, .budget = options.cache_bytes },
                .log = .init(gpa, store, context),
            };
            errdefer self.log.deinit();
            var sink: Sink = .{ .db = self };
            try self.log.recover(claimed.epoch, m.applied, m.fences, &sink);
            return self;
        }

        /// open a reader: it loads the manifest without claiming it, so it
        /// fences nobody and never writes. it holds its own copy of the
        /// unflushed log tail, and `refresh` brings it up to the newest
        /// durable commit. writes, `flush`, `compact` and `collect` on a
        /// reader fail with `error.ReadOnly`.
        pub fn openReader(gpa: std.mem.Allocator, store: *Store, options: Options) !*Self {
            comptime if (Log != SegmentLog(Store)) @compileError("a reader tails a database's own segment log");
            var stale: ?u64 = null;
            const version, const epoch, const etag = while (true) {
                const current = try store.get(gpa, manifest.key) orelse return error.Missing;
                defer gpa.free(current.bytes);
                const decoded = try manifest.decode(gpa, current.bytes);
                defer decoded.deinit(gpa);
                // a table collected between reading the manifest and loading
                // it means a newer manifest replaced it
                const version = loadVersion(gpa, store, decoded.manifest, null, options.fence_stride) catch |err| {
                    if (err != error.Missing or stale == current.etag) return err;
                    stale = current.etag;
                    continue;
                };
                break .{ version, decoded.manifest.epoch, current.etag };
            };
            const self = built: {
                errdefer version.release(gpa);
                const mem = try Memtable.create(gpa, version.applied);
                errdefer mem.release(gpa);
                const batch = try Memtable.create(gpa, 0);
                errdefer batch.release(gpa);
                const self = try gpa.create(Self);
                self.* = .{
                    .gpa = gpa,
                    .store = store,
                    .options = options,
                    .epoch = epoch,
                    .etag = etag,
                    .version = version,
                    .memtable = mem,
                    .batch = batch,
                    .reader = true,
                    .cache = .{ .gpa = gpa, .budget = options.cache_bytes },
                    .log = .init(gpa, store, {}),
                };
                break :built self;
            };
            // from here on `close` owns everything: refresh may replace the
            // version and memtable built above
            // a reader opening may be many commits behind: ask for a full
            // window of segments from the start
            self.refreshFrom(tail_window_max) catch |err| {
                self.close();
                return err;
            };
            return self;
        }

        /// bring a reader up to the newest durable commit: apply each log
        /// segment past the one it has, then check the manifest. a manifest
        /// that changed (a flush, a compaction, a new writer) is adopted: its
        /// tables replace the reader's, and the log is applied again from
        /// its `applied`. a reader that fell behind `collect` lands here too,
        /// since a collected segment is one the manifest has already
        /// covered. on error the reader keeps the last state it reached,
        /// which is always a whole number of commits.
        pub fn refresh(self: *Self) !void {
            return self.refreshFrom(1);
        }

        fn refreshFrom(self: *Self, first_window: usize) !void {
            if (!self.reader) return error.NotReader;
            if (self.broken) return error.Broken;
            var stale: ?u64 = null;
            while (true) {
                try self.tail(first_window);
                const current = try self.store.get(self.gpa, manifest.key) orelse return error.Missing;
                defer self.gpa.free(current.bytes);
                if (current.etag == self.etag) return;
                self.adopt(current) catch |err| {
                    // a table missing from the manifest that names it twice
                    // running is gone for good, not replaced
                    if (err != error.Missing or stale == current.etag) return err;
                    stale = current.etag;
                };
            }
        }

        /// apply every segment after the memtable's last ordinal, stopping at
        /// the first that is not there. a segment is decoded whole before
        /// any of it is applied, so a reader never shows part of a commit.
        /// segments are fetched in windows that double while every segment
        /// in them is there, so an idle reader asks for one and a reader far
        /// behind catches up in a few round trips, on a store that fetches
        /// at once. every probe finishes before `refresh` reads the manifest.
        fn tail(self: *Self, first_window: usize) !void {
            const gpa = self.gpa;
            var keys_buf: [tail_window_max]log.Key = undefined;
            var keys: [tail_window_max][]const u8 = undefined;
            var found: [tail_window_max]?@import("store.zig").Object = undefined;
            var window: usize = @min(first_window, tail_window_max);
            while (true) {
                const first = self.memtable.last_ordinal + 1;
                const n = window;
                for (0..n) |i| keys[i] = log.key(&keys_buf[i], first + i);
                const fetched = try @import("store.zig").getUntilMissing(self.store, gpa, keys[0..n], found[0..n]);
                defer for (found[0..fetched]) |f| if (f) |obj| gpa.free(obj.bytes);
                for (found[0..fetched], 0..) |f, i| {
                    const obj = f orelse return;
                    const segment = log.Segment.decode(obj.bytes) catch |err| {
                        // a torn tail is the writer's to drop on its next
                        // open; the reader waits for it. one with a
                        // successor is corruption.
                        if (i + 1 < fetched and found[i + 1] != null) return err;
                        return;
                    };
                    var it = segment.iterator();
                    while (it.next()) |e| try self.apply(e.key, e.value, e.kind);
                    self.memtable.last_ordinal = first + i;
                }
                window = @min(window * 2, tail_window_max);
            }
        }

        /// replace the reader's tables and memtable with those of a newer
        /// manifest. tables it already holds are kept, not fetched again. a
        /// table the manifest names but the store no longer has fails with
        /// `error.Missing`: usually a newer manifest replaced it.
        fn adopt(self: *Self, current: @import("store.zig").Object) !void {
            const gpa = self.gpa;
            const decoded = try manifest.decode(gpa, current.bytes);
            defer decoded.deinit(gpa);
            const version = try loadVersion(gpa, self.store, decoded.manifest, self.version, self.options.fence_stride);
            errdefer version.release(gpa);
            const fresh = try Memtable.create(gpa, decoded.manifest.applied);
            self.version.release(gpa);
            self.version = version;
            self.swap(fresh);
            self.etag = current.etag;
            self.epoch = decoded.manifest.epoch;
        }

        fn loadVersion(gpa: std.mem.Allocator, store: *Store, m: manifest.Manifest, have: ?*const Version, fence_stride: u32) !*Version {
            var loaded: [levels]std.ArrayList(*Table) = @splat(.empty);
            defer for (&loaded) |*level| {
                for (level.items) |table| table.release(gpa);
                level.deinit(gpa);
            };
            // fetch the metadata of every table not already held at once
            var wanted: std.ArrayList(manifest.Ref) = .empty;
            defer wanted.deinit(gpa);
            for (m.tables) |refs| for (refs) |ref| {
                if (have) |v| if (v.find(ref.id) != null) continue;
                if (ref.meta_at > ref.size) return error.Corrupt;
                try wanted.append(gpa, ref);
            };
            const keys = try gpa.alloc(manifest.TableKey, wanted.items.len);
            defer gpa.free(keys);
            const ranges = try gpa.alloc(@import("store.zig").Range, wanted.items.len);
            defer gpa.free(ranges);
            for (wanted.items, keys, ranges) |ref, *key, *range| range.* = .{
                .key = manifest.tableKey(key, ref.id),
                .offset = ref.meta_at,
                .len = ref.size - ref.meta_at,
            };
            const metas = try gpa.alloc(?[]u8, wanted.items.len);
            defer gpa.free(metas);
            try @import("store.zig").getRangeMany(store, gpa, ranges, metas);
            var next_meta: usize = 0;
            defer for (metas[next_meta..]) |meta| if (meta) |bytes| gpa.free(bytes);
            for (m.tables, &loaded) |refs, *level| {
                try level.ensureTotalCapacity(gpa, refs.len);
                for (refs) |ref| level.appendAssumeCapacity(held: {
                    if (have) |v| if (v.find(ref.id)) |table| break :held table.retain();
                    const meta = metas[next_meta] orelse return error.Missing;
                    metas[next_meta] = null;
                    next_meta += 1;
                    errdefer gpa.free(meta);
                    if (manifest.hash(meta) != ref.hash) return error.Corrupt;
                    break :held try Table.create(gpa, ref.id, ref.size, meta, fence_stride);
                });
            }
            var tables: [levels][]const *Table = undefined;
            for (&tables, loaded) |*slot, level| slot.* = level.items;
            return Version.create(gpa, m.applied, m.fences, tables);
        }

        const Claimed = struct { epoch: u64, etag: u64, decoded: manifest.Decoded };

        fn claim(gpa: std.mem.Allocator, store: *Store, scratch: *std.ArrayList(u8)) !Claimed {
            while (true) {
                const current = try store.get(gpa, manifest.key) orelse {
                    const empty: manifest.Manifest = .{ .epoch = 1, .applied = 0, .fences = &.{}, .tables = @splat(&.{}) };
                    try manifest.encode(gpa, scratch, empty);
                    const etag = try store.putIfAbsent(manifest.key, scratch.items) orelse continue;
                    return .{ .epoch = 1, .etag = etag, .decoded = .{ .manifest = empty, .ids = &.{}, .refs = &.{} } };
                };
                defer gpa.free(current.bytes);
                const decoded = try manifest.decode(gpa, current.bytes);
                errdefer decoded.deinit(gpa);
                var next = decoded.manifest;
                next.epoch += 1;
                try manifest.encode(gpa, scratch, next);
                const etag = try store.cas(manifest.key, scratch.items, current.etag) orelse {
                    decoded.deinit(gpa);
                    continue;
                };
                return .{ .epoch = next.epoch, .etag = etag, .decoded = decoded };
            }
        }

        fn loader(self: *Self) sst.Loader {
            return .{ .ctx = self, .load = loadBlock, .unpin = unpinBlock, .locate = locateBlock };
        }

        fn locateBlock(ctx: *anyopaque, table_ptr: *anyopaque, key: []const u8) anyerror!?u32 {
            const self: *Self = @ptrCast(@alignCast(ctx));
            return self.locate(@ptrCast(@alignCast(table_ptr)), key);
        }

        /// The first block whose fence is at or above `key`, null past the
        /// table's last key. Sparse fences cost a partition fetch on a miss.
        fn locate(self: *Self, table: *const Table, key: []const u8) !?u32 {
            switch (table.meta.fences) {
                .resident => return table.meta.locate(key),
                .sparse => |sp| {
                    const j = sp.lowerBound(key);
                    if (j == sp.partitions()) return null;
                    const c = try self.fetchFences(table, sp, j);
                    defer self.cache.release(c);
                    const within = c.block.lowerBound(key);
                    std.debug.assert(within < c.block.count);
                    return j * sp.stride + within;
                },
            }
        }

        fn handleOf(self: *Self, table: *const Table, i: u32) !sst.Handle {
            switch (table.meta.fences) {
                .resident => return table.meta.handle(i),
                .sparse => |sp| {
                    const c = try self.fetchFences(table, sp, i / sp.stride);
                    defer self.cache.release(c);
                    return sst.handleFrom(c.block.at(i % sp.stride).value);
                },
            }
        }

        /// Partition `j` of a sparse table's fence index, pinned in the
        /// block cache alongside data blocks.
        fn fetchFences(self: *Self, table: *const Table, sp: sst.Sparse, j: u32) !*Cached {
            const k = Cache.fenceKey(table.id, j);
            if (self.cache.lookup(k)) |c| return c;
            const r = sp.range(j);
            var key: manifest.TableKey = undefined;
            const bytes = try self.store.getRange(self.cache.gpa, manifest.tableKey(&key, table.id), table.meta.data_len + r.at, r.len) orelse return error.Missing;
            const decoded = try sst.decodeFences(self.cache.gpa, bytes, sp.blocksIn(j), sp.keyAt(j));
            errdefer self.cache.gpa.free(decoded.bytes);
            return self.cache.insert(k, decoded.bytes, decoded.block);
        }

        fn loadBlock(ctx: *anyopaque, table_ptr: *anyopaque, i: u32) anyerror!sst.Pin {
            const self: *Self = @ptrCast(@alignCast(ctx));
            const c = try self.fetch(@ptrCast(@alignCast(table_ptr)), i);
            return .{ .block = c.block, .token = c };
        }

        fn unpinBlock(ctx: *anyopaque, token: ?*anyopaque) void {
            const self: *Self = @ptrCast(@alignCast(ctx));
            self.cache.release(@ptrCast(@alignCast(token.?)));
        }

        fn fetch(self: *Self, table: *const Table, i: u32) !*Cached {
            const k = Cache.key(table.id, i);
            if (self.cache.lookup(k)) |c| return c;
            const h = try self.handleOf(table, i);
            var key: manifest.TableKey = undefined;
            if (comptime @hasDecl(Store, "getRangeInto")) {
                if (table.meta.encoding == .grouped and h.len <= 4096) {
                    const bytes = try self.fetchGrouped(manifest.tableKey(&key, table.id), h);
                    errdefer self.cache.gpa.free(bytes);
                    return self.cache.insert(k, bytes, @import("block.zig").Block.init(bytes));
                }
            }
            var bytes = try self.store.getRange(self.cache.gpa, manifest.tableKey(&key, table.id), h.at, h.len) orelse return error.Missing;
            errdefer self.cache.gpa.free(bytes);
            try sst.checkBytes(bytes, h);
            if (table.meta.encoding == .grouped) {
                const decoded = try @import("grouped.zig").decode(self.cache.gpa, bytes);
                self.cache.gpa.free(bytes);
                bytes = decoded;
            }
            const b = @import("block.zig").Block.init(bytes);
            return self.cache.insert(k, bytes, b);
        }

        noinline fn fetchGrouped(self: *Self, name: []const u8, h: sst.Handle) ![]u8 {
            var buffer: [4096]u8 = undefined;
            const encoded = buffer[0..h.len];
            if (!try self.store.getRangeInto(self.cache.gpa, name, h.at, encoded)) return error.Missing;
            try sst.checkBytes(encoded, h);
            return @import("grouped.zig").decode(self.cache.gpa, encoded);
        }

        const Sink = struct {
            db: *Self,

            pub fn landed(self: *Sink, ordinal: u64, entries: log.Iterator) !void {
                var it = entries;
                while (it.next()) |e| try self.db.apply(e.key, e.value, e.kind);
                self.db.memtable.last_ordinal = ordinal;
            }

            pub fn reached(self: *Sink, ordinal: u64) !void {
                self.db.memtable.last_ordinal = @max(self.db.memtable.last_ordinal, ordinal);
            }
        };

        /// Destroy all scans before closing this handle.
        pub fn close(self: *Self) void {
            const gpa = self.gpa;
            self.unhold();
            if (self.compaction) |job| {
                job.deinit();
                gpa.destroy(job);
            }
            self.cache.deinit();
            if (self.attempt) |attempt| self.dropAttempt(attempt);
            if (self.committing) |ticket| self.log.drop(ticket);
            self.version.release(gpa);
            self.memtable.release(gpa);
            self.batch.release(gpa);
            self.log.deinit();
            self.obsolete.deinit(gpa);
            for (self.retired.items) |table| table.release(gpa);
            self.retired.deinit(gpa);
            self.scratch.deinit(gpa);
            gpa.destroy(self);
        }

        fn dropAttempt(self: *Self, attempt: Attempt) void {
            attempt.version.release(self.gpa);
            self.gpa.free(attempt.bytes);
            self.gpa.free(attempt.created);
        }

        pub fn put(self: *Self, key: []const u8, value: []const u8) !void {
            if (self.reader) return error.ReadOnly;
            if (self.committing != null) return error.Committing;
            self.seq += 1;
            try self.batch.insert(key, value, self.seq, .put);
        }

        pub fn del(self: *Self, key: []const u8) !void {
            if (self.reader) return error.ReadOnly;
            if (self.committing != null) return error.Committing;
            self.seq += 1;
            try self.batch.insert(key, "", self.seq, .del);
        }

        /// Borrowed result: copy before the next operation on this Db or close.
        /// Do not free it. This conservative lifetime applies to every backing.
        /// on a reader, a table the writer has since collected is not an
        /// error: the reader adopts the manifest that replaced it and reads
        /// again.
        pub fn get(self: *Self, key: []const u8) !?[]const u8 {
            return self.getOnce(key) catch |err| {
                if (err != error.Missing or !self.reader) return err;
                try self.refresh();
                return self.getOnce(key);
            };
        }

        fn getOnce(self: *Self, key: []const u8) !?[]const u8 {
            self.unhold();
            if (self.batch.get(key, unbounded)) |node| return visible(node.kind, node.value);
            if (self.memtable.get(key, unbounded)) |node| return visible(node.kind, node.value);
            const h = bloom.hash(key);
            for (self.version.tables[0]) |table| {
                if (try self.lookup(table, key, h)) |e| return visible(e.kind, e.value);
            }
            for (self.version.tables[1..]) |run| {
                var lo: usize = 0;
                var hi = run.len;
                while (lo < hi) {
                    const mid = lo + (hi - lo) / 2;
                    if (std.mem.order(u8, run[mid].meta.max, key) == .lt) lo = mid + 1 else hi = mid;
                }
                if (lo == run.len or std.mem.order(u8, run[lo].meta.min, key) == .gt) continue;
                if (try self.lookup(run[lo], key, h)) |e| return visible(e.kind, e.value);
            }
            return null;
        }

        fn lookup(self: *Self, table: *const Table, key: []const u8, h: u64) !?entry.Entry {
            if (!table.meta.mayContain(h)) return null;
            const i = try self.locate(table, key) orelse return null;
            const c = try self.fetch(table, i);
            const e = sst.find(c.block, key) orelse {
                self.cache.release(c);
                return null;
            };
            self.held = c;
            return e;
        }

        fn unhold(self: *Self) void {
            const c = self.held orelse return;
            self.held = null;
            self.cache.release(c);
        }

        fn visible(kind: entry.Kind, value: []const u8) ?[]const u8 {
            return if (kind == .put) value else null;
        }

        /// Explicit ownership audit for tests/diagnostics, not external data validation.
        /// Does not read storage or allocate; never called implicitly on the hot path.
        pub fn assertIntegrity(self: *const Self) void {
            self.cache.assertIntegrity();
            std.debug.assert(self.version.refs > 0);
            std.debug.assert(self.memtable.refs > 0 and self.batch.refs > 0);
            if (self.held) |held| std.debug.assert(held.refs > @as(u32, @intFromBool(held.held)));
            for (self.version.tables) |level| for (level) |table| std.debug.assert(table.refs > 0);
        }

        /// Decoded-block buffer and entry charges, not RSS or allocator overhead.
        pub fn cacheStats(self: *const Self) @import("cache.zig").Stats {
            return self.cache.stats();
        }

        pub fn memtableBytes(self: *const Self) usize {
            return self.memtable.bytes;
        }

        /// Heap bytes pinned by the open tables' metadata: whole tails at
        /// `fence_stride` 1, filters and fence samples above it. Cached fence
        /// partitions are in `cacheStats` instead.
        pub fn residentMetadataBytes(self: *const Self) usize {
            var total: usize = 0;
            for (self.version.tables) |level| for (level) |table| {
                total += table.residentBytes();
            };
            return total;
        }

        pub fn unflushedSegments(self: *const Self) u64 {
            return self.log.next() - 1 - self.version.applied;
        }

        pub fn commit(self: *Self) !void {
            try self.commitBegin();
            try self.commitEnd();
        }

        pub fn commitBegin(self: *Self) !void {
            try self.usable();
            if (self.committing != null) return error.Committing;
            if (self.batch.count == 0) return;
            const gpa = self.gpa;
            self.scratch.clearRetainingCapacity();
            var staged = memtable.newest(self.batch);
            while (staged.next()) |node| try entry.append(gpa, &self.scratch, .{ .key = node.key, .value = node.value, .kind = node.kind });
            self.committing = try self.log.begin(self.scratch.items);
        }

        pub fn commitEnd(self: *Self) !void {
            try self.usable();
            var sink: Sink = .{ .db = self };
            const ticket = self.committing orelse return self.log.settle(&sink) catch |err| self.failed(err);
            self.committing = null;
            const ordinal = self.log.finish(ticket, &sink) catch |err| return self.failed(err);
            var staged = memtable.newest(self.batch);
            while (staged.next()) |node| try self.apply(node.key, node.value, node.kind);
            self.memtable.last_ordinal = ordinal;
            try self.discard();
        }

        fn failed(self: *Self, err: anyerror) anyerror {
            if (err == error.Fenced) self.fenced = true;
            return err;
        }

        fn apply(self: *Self, key: []const u8, value: []const u8, kind: entry.Kind) !void {
            self.seq += 1;
            self.memtable.insert(key, value, self.seq, kind) catch |err| {
                self.broken = true;
                return err;
            };
        }

        pub fn discard(self: *Self) !void {
            if (self.batch.refs == 1) return self.batch.clear();
            const fresh = try Memtable.create(self.gpa, 0);
            self.batch.release(self.gpa);
            self.batch = fresh;
        }

        pub fn stagedBytes(self: *const Self) usize {
            return self.batch.bytes;
        }

        pub fn flush(self: *Self) !void {
            try self.usable();
            try self.resolve();
            const gpa = self.gpa;
            const mem = self.memtable;
            const fresh = try Memtable.create(gpa, mem.last_ordinal);
            errdefer fresh.release(gpa);
            if (mem.last_ordinal == self.version.applied) {
                if (mem.count == 0) return fresh.release(gpa);
                return self.swap(fresh);
            }

            var created: std.ArrayList(u64) = .empty;
            defer created.deinit(gpa);
            errdefer self.obsolete.appendSliceAssumeCapacity(created.items);
            var level0: std.ArrayList(*Table) = .empty;
            // read now: the swap at the end releases `mem`, maybe freeing it
            // before this defer runs
            const emitting = mem.count > 0;
            defer {
                if (emitting and level0.items.len > 0) level0.items[0].release(gpa);
                level0.deinit(gpa);
            }
            if (mem.count > 0) {
                var builder: sst.Builder = .{ .gpa = gpa, .block_bytes = self.options.block_bytes, .bits_per_key = self.options.bits_per_key, .encoding = self.options.table_encoding };
                defer builder.deinit();
                var it = memtable.newest(mem);
                while (it.next()) |node| try builder.add(.{ .key = node.key, .value = node.value, .kind = node.kind });
                try level0.ensureUnusedCapacity(gpa, 1 + self.version.tables[0].len);
                level0.appendAssumeCapacity(try self.emit(&builder, &created));
            }
            try level0.appendSlice(gpa, self.version.tables[0]);
            var tables: [levels][]const *Table = undefined;
            for (&tables, self.version.tables) |*slot, level| slot.* = level;
            tables[0] = level0.items;
            try self.publish(mem.last_ordinal, tables, &created);
            self.swap(fresh);
        }

        fn swap(self: *Self, fresh: *Memtable) void {
            self.memtable.release(self.gpa);
            self.memtable = fresh;
        }

        fn emit(self: *Self, builder: *sst.Builder, created: *std.ArrayList(u64)) !*Table {
            const gpa = self.gpa;
            const expected = builder.digest.final();
            const bytes = try builder.finish();
            defer gpa.free(bytes);
            if (try sst.digest(gpa, bytes) != expected) return error.Corrupt;
            return self.writeTable(bytes, created);
        }

        fn writeTable(self: *Self, bytes: []const u8, created: *std.ArrayList(u64)) !*Table {
            const table = try self.prepareTable(bytes, created);
            errdefer table.release(self.gpa);
            var key: manifest.TableKey = undefined;
            try self.store.put(manifest.tableKey(&key, table.id), bytes);
            return table;
        }

        fn prepareTable(self: *Self, bytes: []const u8, created: *std.ArrayList(u64)) !*Table {
            const gpa = self.gpa;
            try created.ensureUnusedCapacity(gpa, 1);
            try self.obsolete.ensureUnusedCapacity(gpa, created.items.len + 1);
            const meta = try gpa.dupe(u8, bytes[try sst.metaAt(bytes)..]);
            const id = (self.epoch << 32) | self.next_table;
            self.next_table += 1;
            const table = Table.create(gpa, id, bytes.len, meta, self.options.fence_stride) catch |err| {
                gpa.free(meta);
                return err;
            };
            created.appendAssumeCapacity(id);
            return table;
        }

        pub fn compact(self: *Self) !bool {
            try self.usable();
            try self.resolve();
            if (self.compaction != null) {
                while (self.compaction != null) _ = try self.compactStep(std.math.maxInt(usize));
                return true;
            }
            var job = try Compaction(false).init(self) orelse return false;
            defer job.deinit();
            errdefer self.obsolete.appendSliceAssumeCapacity(job.created.items);
            _ = try job.step(std.math.maxInt(usize), false);
            return true;
        }

        /// Execute a merge/validation budget or one finalization phase.
        /// Encoding, writing, initialization and publication remain whole operations.
        /// Calls must be serialized with all other operations on this Db.
        pub fn compactStep(self: *Self, bytes: usize) !bool {
            while (true) switch (try self.compactAdvance(bytes, false)) {
                .idle => return false,
                .progress => return true,
                .waiting => if (comptime @hasDecl(Store, "putPoll")) self.store.waitPut() else unreachable,
            };
        }

        /// Non-waiting only for a backend with putPoll. Initialization, resolution,
        /// encoding and publication remain whole operations; bytes is not a deadline.
        /// Without putPoll, table writes are synchronous. Serialize with all Db calls.
        pub fn compactPoll(self: *Self, bytes: usize) !CompactionProgress {
            return self.compactAdvance(bytes, true);
        }

        /// Current resumable phase; writing means submitted, not necessarily unfinished.
        pub fn compactionPhase(self: *const Self) CompactionPhase {
            const job = self.compaction orelse return .idle;
            return switch (job.state.phase) {
                .merge => .merge,
                .verify => .verify,
                .write => .write,
                .writing => .writing,
                .publish => .publish,
            };
        }

        fn compactAdvance(self: *Self, bytes: usize, comptime asynchronous: bool) !CompactionProgress {
            if (bytes == 0) return error.InvalidBudget;
            try self.usable();
            try self.resolve();
            if (self.compaction) |job| if (job.failed) try self.cancelCompaction();
            if (self.compaction == null) {
                var state = try Compaction(true).init(self) orelse return .idle;
                const job = self.gpa.create(Compaction(true)) catch |err| {
                    state.deinit();
                    return err;
                };
                job.* = state;
                self.compaction = job;
            }
            const job = self.compaction.?;
            const done = job.step(bytes, asynchronous) catch |err| {
                job.failed = true;
                self.cancelCompaction() catch {};
                return err;
            };
            if (done) {
                self.compaction = null;
                job.deinit();
                self.gpa.destroy(job);
            } else if (job.state.waiting) return .waiting;
            return .progress;
        }

        pub fn cancelCompaction(self: *Self) !void {
            const job = self.compaction orelse return;
            try self.obsolete.appendSlice(self.gpa, job.created.items);
            self.compaction = null;
            job.deinit();
            self.gpa.destroy(job);
        }

        fn Compaction(comptime resumable: bool) type {
            return struct {
                const Job = @This();
                const Phase = enum { merge, verify, write, writing, publish };
                const Pending = struct {
                    bytes: []u8,
                    verifier: sst.Verifier,
                    expected: u64,
                    after: Phase,
                    table: if (@hasDecl(Store, "putPoll")) ?*Table else void = if (@hasDecl(Store, "putPoll")) null else {},
                };
                const State = struct { phase: Phase = .merge, pending: ?Pending = null, waiting: bool = false };
                db: *Self,
                version: *Version,
                from: usize,
                first: usize,
                end: usize,
                sources: std.ArrayList(merge.Source) = .empty,
                merged: ?merge.Merge = null,
                created: std.ArrayList(u64) = .empty,
                outputs: std.ArrayList(*Table) = .empty,
                builder: sst.Builder,
                failed: bool = false,
                state: if (resumable) State else void = if (resumable) .{} else {},

                fn init(db: *Self) !?Job {
                    const from = plan.plan(db.version, .{
                        .l0_tables = db.options.l0_tables,
                        .level_bytes = db.options.level_bytes,
                        .growth = db.options.growth,
                    }) orelse return null;
                    const selected = db.version.tables[from];
                    var min = selected[0].meta.min;
                    var max = selected[0].meta.max;
                    for (selected[1..]) |table| {
                        if (std.mem.order(u8, table.meta.min, min) == .lt) min = table.meta.min;
                        if (std.mem.order(u8, table.meta.max, max) == .gt) max = table.meta.max;
                    }
                    const destination = db.version.tables[from + 1];
                    var first: usize = 0;
                    while (first < destination.len and std.mem.order(u8, destination[first].meta.max, min) == .lt) : (first += 1) {}
                    var end = first;
                    while (end < destination.len and std.mem.order(u8, destination[end].meta.min, max) != .gt) : (end += 1) {}
                    var job: Job = .{
                        .db = db,
                        .version = db.version.retain(),
                        .from = from,
                        .first = first,
                        .end = end,
                        .builder = .{ .gpa = db.gpa, .block_bytes = db.options.block_bytes, .bits_per_key = db.options.bits_per_key, .encoding = db.options.table_encoding },
                    };
                    errdefer job.deinit();
                    if (from == 0) {
                        for (selected) |*table| try job.sources.append(db.gpa, .tables(table[0..1], db.loader()));
                    } else {
                        try job.sources.append(db.gpa, .tables(selected, db.loader()));
                    }
                    try job.sources.append(db.gpa, .tables(destination[first..end], db.loader()));
                    var bottom = true;
                    for (db.version.tables[from + 2 ..]) |level| bottom = bottom and level.len == 0;
                    job.merged = try .init(job.sources.items, .{}, !bottom);
                    return job;
                }

                fn deinit(job: *Job) void {
                    const gpa = job.db.gpa;
                    if (job.merged) |*merged| merged.deinit();
                    job.sources.deinit(gpa);
                    job.builder.deinit();
                    if (resumable) if (job.state.pending) |pending| {
                        if (comptime @hasDecl(Store, "putPoll")) if (pending.table) |table| {
                            job.db.store.cancelPut();
                            table.release(gpa);
                        };
                        gpa.free(pending.bytes);
                    };
                    for (job.outputs.items) |table| table.release(gpa);
                    job.outputs.deinit(gpa);
                    job.created.deinit(gpa);
                    job.version.release(gpa);
                }

                fn emit(job: *Job) !void {
                    const db = job.db;
                    try job.outputs.ensureUnusedCapacity(db.gpa, 1);
                    job.outputs.appendAssumeCapacity(try db.emit(&job.builder, &job.created));
                    job.builder.deinit();
                    job.builder = .{ .gpa = db.gpa, .block_bytes = db.options.block_bytes, .bits_per_key = db.options.bits_per_key, .encoding = db.options.table_encoding };
                }

                fn step(job: *Job, bytes: usize, comptime asynchronous: bool) !bool {
                    const db = job.db;
                    if (resumable) job.state.waiting = false;
                    if (resumable) switch (job.state.phase) {
                        .verify => {
                            const pending = &job.state.pending.?;
                            if (try pending.verifier.step(db.gpa, bytes)) {
                                if (pending.verifier.final() != pending.expected) return error.Corrupt;
                                job.state.phase = .write;
                            }
                            return false;
                        },
                        .write => {
                            if (asynchronous and @hasDecl(Store, "putPoll")) return job.pollWrite();
                            const pending = &job.state.pending.?;
                            const after = pending.after;
                            try job.outputs.ensureUnusedCapacity(db.gpa, 1);
                            job.outputs.appendAssumeCapacity(try db.writeTable(pending.bytes, &job.created));
                            db.gpa.free(pending.bytes);
                            job.state.pending = null;
                            job.state.phase = after;
                            return false;
                        },
                        .writing => if (comptime @hasDecl(Store, "putPoll")) return job.pollWrite() else unreachable,
                        .publish => return job.publish(),
                        .merge => {},
                    };
                    const merged = &job.merged.?;
                    const start = merged.visited_bytes;
                    while (try merged.nextCandidate()) |e| {
                        if (e.kind != .del or merged.keep_tombstones) try job.builder.add(e);
                        if (!job.builder.empty() and job.builder.bytes() >= db.options.table_bytes) {
                            if (resumable) {
                                try job.prepare(.merge);
                                return false;
                            } else try job.emit();
                        }
                        if (merged.visited_bytes - start >= bytes) return false;
                    }
                    if (resumable) {
                        if (!job.builder.empty()) try job.prepare(.publish) else job.state.phase = .publish;
                        return false;
                    } else if (!job.builder.empty()) try job.emit();
                    return job.publish();
                }

                fn pollWrite(job: *Job) !bool {
                    const db = job.db;
                    const pending = &job.state.pending.?;
                    if (pending.table == null) {
                        try job.outputs.ensureUnusedCapacity(db.gpa, 1);
                        pending.table = try db.prepareTable(pending.bytes, &job.created);
                    }
                    var key: manifest.TableKey = undefined;
                    if (!try db.store.putPoll(manifest.tableKey(&key, pending.table.?.id), pending.bytes)) {
                        job.state.phase = .writing;
                        job.state.waiting = true;
                        return false;
                    }
                    const after = pending.after;
                    job.outputs.appendAssumeCapacity(pending.table.?);
                    db.gpa.free(pending.bytes);
                    job.state.pending = null;
                    job.state.phase = after;
                    return false;
                }

                fn prepare(job: *Job, after: Phase) !void {
                    std.debug.assert(job.state.pending == null);
                    const expected = job.builder.digest.final();
                    const bytes = try job.builder.finish();
                    errdefer job.db.gpa.free(bytes);
                    job.state.pending = .{ .bytes = bytes, .verifier = try sst.Verifier.init(bytes), .expected = expected, .after = after };
                    job.builder.deinit();
                    job.builder = .{ .gpa = job.db.gpa, .block_bytes = job.db.options.block_bytes, .bits_per_key = job.db.options.bits_per_key, .encoding = job.db.options.table_encoding };
                    job.state.phase = .verify;
                }

                fn publish(job: *Job) !bool {
                    const db = job.db;
                    const into = job.from + 1;
                    const destination = job.version.tables[into];
                    var tables: [levels][]const *Table = undefined;
                    for (&tables, db.version.tables) |*slot, level| slot.* = level;
                    var installed: std.ArrayList(*Table) = .empty;
                    defer installed.deinit(db.gpa);
                    const selected = job.version.tables[job.from];
                    const current = db.version.tables[job.from];
                    if (current.len < selected.len) return error.CompactionConflict;
                    const kept = current.len - selected.len;
                    for (current[kept..], selected) |a, b| if (a.id != b.id) return error.CompactionConflict;
                    tables[job.from] = current[0..kept];
                    if (job.first == 0 and job.end == destination.len) {
                        tables[into] = job.outputs.items;
                    } else {
                        try installed.appendSlice(db.gpa, destination[0..job.first]);
                        try installed.appendSlice(db.gpa, job.outputs.items);
                        try installed.appendSlice(db.gpa, destination[job.end..]);
                        tables[into] = installed.items;
                    }
                    try db.publish(db.version.applied, tables, &job.created);
                    return true;
                }
            };
        }

        fn publish(self: *Self, applied: u64, tables: [levels][]const *Table, created: *std.ArrayList(u64)) !void {
            const gpa = self.gpa;
            var removed: usize = 0;
            for (self.version.tables) |level| removed += level.len;
            try self.retired.ensureUnusedCapacity(gpa, removed);
            try self.obsolete.ensureUnusedCapacity(gpa, created.items.len);

            var ids: std.ArrayList(manifest.Ref) = .empty;
            defer ids.deinit(gpa);
            var spans: [levels][]const manifest.Ref = undefined;
            for (tables) |level| for (level) |table| try ids.append(gpa, table.ref());
            var at: usize = 0;
            for (&spans, tables) |*span, level| {
                span.* = ids.items[at..][0..level.len];
                at += level.len;
            }
            var encoded: std.ArrayList(u8) = .empty;
            errdefer encoded.deinit(gpa);
            try manifest.encode(gpa, &encoded, .{ .epoch = self.epoch, .applied = applied, .fences = self.log.state(), .tables = spans });
            const bytes = try encoded.toOwnedSlice(gpa);
            const pending = gpa.dupe(u64, created.items) catch |err| {
                gpa.free(bytes);
                return err;
            };
            const next = Version.create(gpa, applied, self.log.state(), tables) catch |err| {
                gpa.free(pending);
                gpa.free(bytes);
                return err;
            };

            const swapped = self.store.cas(manifest.key, bytes, self.etag) catch |err| {
                self.attempt = .{ .bytes = bytes, .version = next, .created = pending };
                created.clearRetainingCapacity();
                return err;
            };
            gpa.free(pending);
            gpa.free(bytes);
            self.etag = swapped orelse {
                next.release(gpa);
                self.fenced = true;
                return error.Fenced;
            };
            created.clearRetainingCapacity();
            self.install(next);
        }

        fn install(self: *Self, next: *Version) void {
            for (self.version.tables) |level| for (level) |table| {
                if (!next.contains(table.id)) self.retired.appendAssumeCapacity(table.retain());
            };
            self.version.release(self.gpa);
            self.version = next;
        }

        fn resolve(self: *Self) !void {
            const attempt = self.attempt orelse return;
            const gpa = self.gpa;
            var removed: usize = 0;
            for (self.version.tables) |level| removed += level.len;
            try self.retired.ensureUnusedCapacity(gpa, removed);
            try self.obsolete.ensureUnusedCapacity(gpa, attempt.created.len);
            const found = try self.store.get(gpa, manifest.key) orelse return error.Corrupt;
            defer gpa.free(found.bytes);
            self.attempt = null;
            defer {
                gpa.free(attempt.bytes);
                gpa.free(attempt.created);
            }
            if (found.etag == self.etag) {
                self.obsolete.appendSliceAssumeCapacity(attempt.created);
                attempt.version.release(gpa);
                return;
            }
            if (std.mem.eql(u8, found.bytes, attempt.bytes)) {
                self.etag = found.etag;
                self.install(attempt.version);
                return;
            }
            attempt.version.release(gpa);
            self.fenced = true;
            return error.Fenced;
        }

        pub fn collect(self: *Self) !void {
            try self.collectTables();
            try self.log.collect(self.version.applied);
        }

        pub const LogCollector = if (@hasDecl(Log, "Collector")) Log.Collector else void;

        pub fn collectLogStep(self: *Self, collector: *LogCollector, limit: usize) !bool {
            if (self.reader) return error.ReadOnly;
            try self.resolve();
            if (comptime @hasDecl(Log, "collectStep")) {
                return self.log.collectStep(collector, self.version.applied, limit);
            } else @compileError("this log backend does not support incremental collection");
        }

        pub fn collectTables(self: *Self) !void {
            const gpa = self.gpa;
            if (self.reader) return error.ReadOnly;
            try self.resolve();
            var key: manifest.TableKey = undefined;
            while (self.obsolete.getLastOrNull()) |id| {
                try self.store.delete(manifest.tableKey(&key, id));
                _ = self.obsolete.pop();
            }
            const tables = try self.store.list(gpa, manifest.table_prefix);
            defer @import("store.zig").freeNames(gpa, tables);
            var doomed: std.ArrayList([]const u8) = .empty;
            defer doomed.deinit(gpa);
            for (tables) |name| {
                const id = manifest.parseTableKey(name) orelse continue;
                if (id >> 32 >= self.epoch or self.version.contains(id) or self.isRetired(id)) continue;
                try doomed.append(gpa, name);
            }
            try @import("store.zig").deleteMany(self.store, doomed.items);
            var i: usize = 0;
            while (i < self.retired.items.len) {
                const table = self.retired.items[i];
                if (table.refs > 1) {
                    i += 1;
                    continue;
                }
                try self.store.delete(manifest.tableKey(&key, table.id));
                _ = self.retired.swapRemove(i);
                table.release(gpa);
            }
        }

        fn usable(self: *const Self) !void {
            if (self.reader) return error.ReadOnly;
            if (self.fenced) return error.Fenced;
            if (self.broken) return error.Broken;
        }

        fn isRetired(self: *const Self, id: u64) bool {
            for (self.retired.items) |table| if (table.id == id) return true;
            return false;
        }

        pub const Scan = struct {
            gpa: std.mem.Allocator,
            merged: merge.Merge,
            sources: []merge.Source,
            batch: *Memtable,
            memtable: *Memtable,
            version: *Version,
            left: usize,

            pub fn visited(self: *const Scan) u64 {
                return self.merged.visited;
            }

            pub fn visitedBytes(self: *const Scan) u64 {
                return self.merged.visited_bytes;
            }

            /// Slices remain valid until the next next() call or deinit().
            pub fn next(self: *Scan) !?Entry {
                if (self.left == 0) return null;
                const e = try self.merged.next() orelse return null;
                self.left -= 1;
                return .{ .key = e.key, .value = e.value };
            }

            pub fn deinit(self: *Scan) void {
                self.merged.deinit();
                self.gpa.free(self.sources);
                self.batch.release(self.gpa);
                self.memtable.release(self.gpa);
                self.version.release(self.gpa);
            }
        };

        /// Pins a snapshot. Serialized Db mutation/refresh may continue, but
        /// the Db must outlive the scan. Serialize all operations on this Db.
        pub fn scan(self: *Self, options: ScanOptions) !Scan {
            var count: usize = 2 + self.version.tables[0].len;
            for (self.version.tables[1..]) |level| count += @intFromBool(level.len > 0);
            const sources = try self.gpa.alloc(merge.Source, count);
            sources[0] = .memtable(self.batch, self.seq);
            sources[1] = .memtable(self.memtable, self.seq);
            var at: usize = 2;
            errdefer self.gpa.free(sources);
            for (self.version.tables[0]) |*table| {
                sources[at] = .tables(table[0..1], self.loader());
                at += 1;
            }
            for (self.version.tables[1..]) |level| {
                if (level.len == 0) continue;
                sources[at] = .tables(level, self.loader());
                at += 1;
            }
            return .{
                .gpa = self.gpa,
                .merged = try .init(sources, .{ .start = options.start, .end = options.end, .reverse = options.reverse }, false),
                .sources = sources,
                .batch = self.batch.retain(),
                .memtable = self.memtable.retain(),
                .version = self.version.retain(),
                .left = options.limit,
            };
        }
    };
}

test "serial reader catch-up stops probing at the first missing log segment" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    const SerialStore = struct {
        inner: MemoryStore,
        log_reads: usize = 0,
        pub fn get(self: *@This(), gpa: std.mem.Allocator, key: []const u8) !?@import("store.zig").Object {
            if (std.mem.startsWith(u8, key, "log/")) self.log_reads += 1;
            return self.inner.get(gpa, key);
        }
        pub fn getRange(self: *@This(), gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
            return self.inner.getRange(gpa, key, offset, len);
        }
        pub fn put(self: *@This(), key: []const u8, bytes: []const u8) !void {
            return self.inner.put(key, bytes);
        }
        pub fn putIfAbsent(self: *@This(), key: []const u8, bytes: []const u8) !?u64 {
            return self.inner.putIfAbsent(key, bytes);
        }
        pub fn cas(self: *@This(), key: []const u8, bytes: []const u8, etag: u64) !?u64 {
            return self.inner.cas(key, bytes, etag);
        }
        pub fn list(self: *@This(), gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
            return self.inner.list(gpa, prefix);
        }
        pub fn delete(self: *@This(), key: []const u8) !void {
            return self.inner.delete(key);
        }
    };
    var store: SerialStore = .{ .inner = .init(t.allocator) };
    defer store.inner.deinit();
    const Database = Db(SerialStore);
    const writer = try Database.open(t.allocator, &store, .{});
    defer writer.close();
    const reader = try Database.openReader(t.allocator, &store, .{});
    defer reader.close();
    for (0..32) |i| {
        var key: [32]u8 = undefined;
        try writer.put(try std.fmt.bufPrint(&key, "k{d}", .{i}), "committed");
        try writer.commit();
    }
    store.log_reads = 0;
    try reader.refresh();
    try t.expectEqual(@as(usize, 33), store.log_reads);
    for (0..32) |i| {
        var key: [32]u8 = undefined;
        try t.expectEqualStrings("committed", (try reader.get(try std.fmt.bufPrint(&key, "k{d}", .{i}))).?);
    }
}

test "incremental log collection preserves interleaved flushes and reader recovery" {
    const t = std.testing;
    const DirStore = @import("store/dir.zig").DirStore;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var store = DirStore.init(t.allocator, t.io, dir.dir);
    defer store.deinit();
    const Database = Db(DirStore);
    {
        const db = try Database.open(t.allocator, &store, .{});
        defer db.close();
        try db.put("a", "first");
        try db.commit();
        try db.flush();
        try db.put("b", "second");
        try db.commit();
        try db.flush();
        var collector: Database.LogCollector = .{};
        defer collector.deinit(t.allocator);
        try t.expect(try db.collectLogStep(&collector, 1));
        try db.put("a", "updated");
        try db.put("c", "third");
        try db.commit();
        try db.flush();
        try db.collectTables();
        while (try db.collectLogStep(&collector, 1)) {}
        try db.put("d", "unflushed");
        try db.commit();
    }
    const reader = try Database.openReader(t.allocator, &store, .{});
    defer reader.close();
    try t.expectEqualStrings("updated", (try reader.get("a")).?);
    try t.expectEqualStrings("second", (try reader.get("b")).?);
    try t.expectEqualStrings("third", (try reader.get("c")).?);
    try t.expectEqualStrings("unflushed", (try reader.get("d")).?);
    var collector: Database.LogCollector = .{};
    defer collector.deinit(t.allocator);
    try t.expectError(error.ReadOnly, reader.collectLogStep(&collector, 1));
}

test "flush with an empty memtable over level-0 tables keeps them" {
    // a reopened writer's memtable holds only its fence segment: no
    // entries, but an ordinal past the manifest's, so flush publishes the
    // level-0 tables it already has. it once decided whether to release
    // a table of its own by reading the memtable after freeing it.
    const gpa = std.testing.allocator;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(gpa);
    defer store.deinit();
    {
        const db = try Db(MemoryStore).open(gpa, &store, .{});
        defer db.close();
        try db.put("k", "v");
        try db.commit();
        try db.flush();
    }
    const db = try Db(MemoryStore).open(gpa, &store, .{});
    defer db.close();
    try db.flush();
    try std.testing.expectEqualStrings("v", (try db.get("k")).?);
}

test "compaction preserves disjoint destination tables and updates overlapping keys" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    try t.expect(try db.compact());
    try t.expectEqual(@as(usize, 3), db.version.tables[1].len);
    const left = db.version.tables[1][0].id;
    const right = db.version.tables[1][2].id;
    try db.put("m", "new");
    try db.commit();
    try db.flush();
    try t.expect(try db.compact());
    try t.expectEqual(@as(usize, 3), db.version.tables[1].len);
    try t.expectEqual(left, db.version.tables[1][0].id);
    try t.expectEqual(right, db.version.tables[1][2].id);
    try t.expectEqualStrings("new", (try db.get("m")).?);
    try db.del("m");
    try db.commit();
    try db.flush();
    try t.expect(try db.compact());
    try db.collect();
    try t.expect((try db.get("m")) == null);
    try t.expectEqualStrings("old", (try db.get("a")).?);
    try t.expectEqualStrings("old", (try db.get("z")).?);
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer reader.close();
    try t.expect((try reader.get("m")) == null);
    try t.expectEqualStrings("old", (try reader.get("z")).?);
}

test "range compaction retains tombstones above deeper values" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1, .level_bytes = 1 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    try t.expect(try db.compact());
    try t.expect(try db.compact());
    try t.expectEqual(@as(usize, 0), db.version.tables[1].len);
    try t.expectEqual(@as(usize, 3), db.version.tables[2].len);
    try db.del("a");
    try db.commit();
    try db.flush();
    try t.expect(try db.compact());
    try t.expect((try db.get("a")) == null);
    while (try db.compact()) {}
    try db.collect();
    try t.expect((try db.get("a")) == null);
    try t.expectEqualStrings("old", (try db.get("m")).?);
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer reader.close();
    try t.expect((try reader.get("a")) == null);
    try t.expectEqualStrings("old", (try reader.get("z")).?);
}

test "stepped compaction preserves interleaved flushes through collection and reopen" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1, .block_bytes = 1 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    try t.expect(try db.compactStep(1));
    try t.expect(db.compaction != null);
    while (db.compaction.?.created.items.len == 0) try t.expect(try db.compactStep(1));
    try db.put("a", "new");
    try db.del("m");
    try db.put("zz", "latest");
    try db.commit();
    try db.flush();
    const applied = db.version.applied;
    const fresh_id = db.version.tables[0][0].id;
    try db.put("zzz", "unflushed");
    try db.commit();
    try db.collect();
    while (db.compaction != null) try t.expect(try db.compactStep(1));
    try t.expectEqual(applied, db.version.applied);
    try t.expectEqual(@as(usize, 1), db.version.tables[0].len);
    try t.expectEqual(fresh_id, db.version.tables[0][0].id);
    try t.expectEqualStrings("new", (try db.get("a")).?);
    try t.expect((try db.get("m")) == null);
    try t.expectEqualStrings("latest", (try db.get("zz")).?);
    while (try db.compactStep(1)) {}
    try db.collect();
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer reader.close();
    var scan = try reader.scan(.{});
    defer scan.deinit();
    for ([_][]const u8{ "a", "z", "zz", "zzz" }, [_][]const u8{ "new", "old", "latest", "unflushed" }) |key, value| {
        const e = (try scan.next()).?;
        try t.expectEqualStrings(key, e.key);
        try t.expectEqualStrings(value, e.value);
    }
    try t.expect((try scan.next()) == null);
}

test "cancelled stepped compaction reclaims only unpublished outputs" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1, .block_bytes = 1 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    try t.expect(try db.compactStep(1));
    while (db.compaction.?.created.items.len == 0) try t.expect(try db.compactStep(1));
    const output = db.compaction.?.created.items[0];
    var key: manifest.TableKey = undefined;
    try t.expect(store.objects.contains(manifest.tableKey(&key, output)));
    try db.cancelCompaction();
    try db.collect();
    try t.expect(!store.objects.contains(manifest.tableKey(&key, output)));
    for ([_][]const u8{ "a", "m", "z" }) |k| try t.expectEqualStrings("old", (try db.get(k)).?);
    try t.expect(try db.compact());
    try db.collect();
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer reader.close();
    try t.expectEqualStrings("old", (try reader.get("z")).?);
}

fn allocationFailureCompaction(gpa: std.mem.Allocator) !void {
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(std.testing.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(gpa, &store, .{ .l0_tables = 1, .table_bytes = 1, .block_bytes = 1 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    _ = try db.compactStep(1);
    try db.put("a", "new");
    try db.commit();
    try db.flush();
    while (db.compaction != null) _ = try db.compactStep(1);
    _ = try db.compactStep(1);
    try db.cancelCompaction();
    try db.collect();
    try std.testing.expectEqualStrings("new", (try db.get("a")).?);
}

test "stepped compaction releases ownership on every allocation failure" {
    var backing = std.testing.FailingAllocator.init(std.testing.allocator, .{ .resize_fail_index = 0 });
    try std.testing.checkAllAllocationFailures(backing.allocator(), allocationFailureCompaction, .{});
}

test "compaction validates owned output in steps before writing and publishing" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1 << 20, .block_bytes = 16 });
    defer db.close();
    for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
    try db.commit();
    try db.flush();
    const manifest_etag = db.etag;
    try t.expectEqual(CompactionPhase.idle, db.compactionPhase());
    try t.expectError(error.InvalidBudget, db.compactStep(0));
    try t.expectError(error.InvalidBudget, db.compactPoll(0));
    try t.expectEqual(CompactionPhase.idle, db.compactionPhase());
    try t.expect(try db.compactStep(1));
    const job = db.compaction.?;
    while (job.state.phase == .merge) try t.expect(try db.compactStep(1));
    try t.expectEqual(CompactionPhase.verify, db.compactionPhase());
    try t.expectEqual(@as(u32, 0), job.state.pending.?.verifier.next_block);
    try t.expect(try db.compactStep(1));
    try t.expectEqual(@as(u32, 1), job.state.pending.?.verifier.next_block);
    try t.expect(job.state.phase == .verify);
    try t.expectEqual(@as(usize, 0), job.created.items.len);
    try t.expectEqual(manifest_etag, db.etag);
    try db.collect();
    while (job.state.phase == .verify) try t.expect(try db.compactStep(1));
    try t.expectEqual(CompactionPhase.write, db.compactionPhase());
    try t.expectEqual(@as(usize, 0), job.created.items.len);
    try t.expect(try db.compactStep(1));
    try t.expectEqual(CompactionPhase.publish, db.compactionPhase());
    try t.expect(job.state.pending == null);
    try t.expectEqual(@as(usize, 1), job.created.items.len);
    try t.expectEqual(manifest_etag, db.etag);
    try db.collect();
    try t.expect(try db.compact());
    try t.expect(db.compaction == null);
    try t.expect(db.etag != manifest_etag);
    try t.expectEqualStrings("old", (try db.get("z")).?);
    try t.expectEqual(CompactionPhase.idle, db.compactionPhase());
    db.assertIntegrity();
}

test "pending verification can be cancelled or rejected without publishing" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    for (0..3) |stop| {
        var store = MemoryStore.init(t.allocator);
        defer store.deinit();
        const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 1 << 20, .block_bytes = 16 });
        defer db.close();
        for ([_][]const u8{ "a", "m", "z" }) |key| try db.put(key, "old");
        try db.commit();
        try db.flush();
        const manifest_etag = db.etag;
        try t.expect(try db.compactStep(1));
        const job = db.compaction.?;
        while (job.state.phase == .merge) try t.expect(try db.compactStep(1));
        if (stop != 0) try t.expect(try db.compactStep(1));
        if (stop == 2) {
            const pending = &job.state.pending.?;
            const last = pending.verifier.meta.handle(pending.verifier.meta.index().count - 1);
            pending.bytes[last.at] ^= 1;
            try t.expectError(error.Corrupt, db.compactStep(std.math.maxInt(usize)));
        } else try db.cancelCompaction();
        try t.expect(db.compaction == null);
        try t.expectEqual(manifest_etag, db.etag);
        try db.collect();
        for ([_][]const u8{ "a", "m", "z" }) |key| try t.expectEqualStrings("old", (try db.get(key)).?);
        try t.expect(try db.compact());
    }
}

test "idle stepped compaction needs no allocation" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    var failing = t.FailingAllocator.init(t.allocator, .{});
    const db = try Db(MemoryStore).open(failing.allocator(), &store, .{});
    defer db.close();
    failing.fail_index = failing.alloc_index;
    try t.expect(!(try db.compactStep(1)));
}

test "stepped compaction budgets discarded tombstones" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .l0_tables = 1, .table_bytes = 64, .block_bytes = 16 });
    defer db.close();
    var key: [8]u8 = undefined;
    for (0..64) |i| try db.put(try std.fmt.bufPrint(&key, "k{d:0>3}", .{i}), "old");
    try db.commit();
    try db.flush();
    while (try db.compact()) {}
    for (0..64) |i| try db.del(try std.fmt.bufPrint(&key, "k{d:0>3}", .{i}));
    try db.commit();
    try db.flush();
    try t.expect(try db.compactStep(1));
    const job = db.compaction orelse return error.UnbudgetedDeletionRun;
    try t.expectEqual(@as(u64, 1), job.merged.?.visited);
    try t.expectEqual(@as(usize, 0), job.outputs.items.len);
    while (try db.compactStep(1)) {}
    try db.collect();
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer reader.close();
    var scan = try reader.scan(.{});
    defer scan.deinit();
    try t.expect((try scan.next()) == null);
}

test "opt-in grouped tables preserve mixed formats, reverse scans and pinned cursors" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store: MemoryStore = .init(t.allocator);
    defer store.deinit();
    const Database = Db(MemoryStore);
    var db = try Database.open(t.allocator, &store, .{ .block_bytes = 512, .table_bytes = 4096, .l0_tables = 2 });
    for (0..200) |i| {
        var key: [64]u8 = undefined;
        try db.put(try std.fmt.bufPrint(&key, "shared\x00prefix/{d:0>6}", .{i}), "original");
    }
    try db.commit();
    try db.flush();
    db.options.table_encoding = .grouped;
    for (200..400) |i| {
        var key: [64]u8 = undefined;
        try db.put(try std.fmt.bufPrint(&key, "shared\x00prefix/{d:0>6}", .{i}), "new");
    }
    try db.commit();
    try db.flush();
    {
        var pinned = try db.scan(.{});
        defer pinned.deinit();
        for (0..40) |i| {
            var key: [64]u8 = undefined;
            try db.del(try std.fmt.bufPrint(&key, "shared\x00prefix/{d:0>6}", .{i}));
        }
        try db.commit();
        try db.flush();
        while (try db.compactStep(64)) {}
        try db.collect();
        for (0..400) |i| {
            const e = (try pinned.next()) orelse return error.MissingPinnedKey;
            var key: [64]u8 = undefined;
            try t.expectEqualStrings(try std.fmt.bufPrint(&key, "shared\x00prefix/{d:0>6}", .{i}), e.key);
            try t.expectEqualStrings(if (i < 200) "original" else "new", e.value);
        }
        try t.expect((try pinned.next()) == null);
    }
    db.close();
    db = try Database.open(t.allocator, &store, .{});
    defer db.close();
    var reverse = try db.scan(.{ .reverse = true });
    defer reverse.deinit();
    for (0..360) |i| {
        const e = (try reverse.next()) orelse return error.MissingReverseKey;
        var key: [64]u8 = undefined;
        const wanted = try std.fmt.bufPrint(&key, "shared\x00prefix/{d:0>6}", .{399 - i});
        try t.expectEqualStrings(wanted, e.key);
        try t.expectEqualStrings(if (399 - i < 200) "original" else "new", (try db.get(wanted)).?);
    }
    try t.expect((try reverse.next()) == null);
}

test "grouped tables retain empty keys and one-megabyte values through reopen" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store: MemoryStore = .init(t.allocator);
    defer store.deinit();
    const value = try t.allocator.alloc(u8, 1 << 20);
    defer t.allocator.free(value);
    for (value, 0..) |*byte, i| byte.* = @truncate(i);
    {
        const db = try Db(MemoryStore).open(t.allocator, &store, .{ .table_encoding = .grouped, .cache_bytes = 4096 });
        defer db.close();
        try db.put("", "empty-key");
        try db.put("large", value);
        try db.commit();
        try db.flush();
        try t.expectEqualSlices(u8, value, (try db.get("large")).?);
    }
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{ .cache_bytes = 4096 });
    defer reader.close();
    try t.expectEqualStrings("empty-key", (try reader.get("")).?);
    var scan = try reader.scan(.{ .reverse = true });
    defer scan.deinit();
    const first = (try scan.next()).?;
    try t.expectEqualStrings("large", first.key);
    try t.expectEqualSlices(u8, value, first.value);
    try t.expectEqualStrings("", (try scan.next()).?.key);
    try t.expect((try scan.next()) == null);
}

test "ordinary compressed cache misses allocate only decoded bytes and cache entry" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store: MemoryStore = .init(t.allocator);
    defer store.deinit();
    var allocations = t.FailingAllocator.init(t.allocator, .{});
    const db = try Db(MemoryStore).open(allocations.allocator(), &store, .{ .table_encoding = .grouped, .block_bytes = 512 });
    defer db.close();
    for (0..64) |i| {
        var key: [32]u8 = undefined;
        try db.put(try std.fmt.bufPrint(&key, "shared/{d:0>6}", .{i}), "value");
    }
    try db.commit();
    try db.flush();
    try t.expectEqualStrings("value", (try db.get("shared/000000")).?);
    const before = allocations.alloc_index;
    try t.expectEqualStrings("value", (try db.get("shared/000063")).?);
    try t.expectEqual(@as(usize, 2), allocations.alloc_index - before);
    const warmed = allocations.alloc_index;
    try t.expectEqualStrings("value", (try db.get("shared/000063")).?);
    try t.expectEqual(warmed, allocations.alloc_index);
}

test "borrowed scan entries survive serialized refresh and mutation until advancement" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    for ([_]sst.Encoding{ .legacy, .grouped }) |encoding| {
        var store = MemoryStore.init(t.allocator);
        defer store.deinit();
        const writer = try Db(MemoryStore).open(t.allocator, &store, .{ .table_encoding = encoding, .block_bytes = 16, .l0_tables = 1, .cache_bytes = 1 });
        defer writer.close();
        try writer.put("a", "old-a");
        try writer.put("b", "old-b");
        try writer.commit();
        try writer.flush();
        const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{ .cache_bytes = 1 });
        defer reader.close();
        var scan = try reader.scan(.{});
        defer scan.deinit();
        const first = (try scan.next()).?;
        const copied = try t.allocator.dupe(u8, (try reader.get("a")).?);
        defer t.allocator.free(copied);
        try writer.put("a", "new-a");
        try writer.del("b");
        try writer.commit();
        try writer.flush();
        _ = try writer.compact();
        try reader.refresh();
        try t.expectEqualStrings("new-a", (try reader.get("a")).?);
        try t.expect(try reader.get("b") == null);
        writer.assertIntegrity();
        reader.assertIntegrity();
        try t.expectEqualStrings("old-a", copied);
        try t.expectEqualStrings("a", first.key);
        try t.expectEqualStrings("old-a", first.value);
        const second = (try scan.next()).?;
        try t.expectEqualStrings("b", second.key);
        try t.expectEqualStrings("old-b", second.value);
        try t.expect((try scan.next()) == null);
    }
}

fn scanDigest(db: anytype, options: ScanOptions) !struct { count: usize, digest: u64 } {
    var scan = try db.scan(options);
    defer scan.deinit();
    var hasher = std.hash.Wyhash.init(0);
    var count: usize = 0;
    while (try scan.next()) |e| {
        hasher.update(e.key);
        hasher.update(e.value);
        count += 1;
    }
    return .{ .count = count, .digest = hasher.final() };
}

test "sparse fences answer every read like the resident index and pin less" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    for ([_]sst.Encoding{ .legacy, .grouped }) |encoding| {
        var store = MemoryStore.init(t.allocator);
        defer store.deinit();
        const writer = try Db(MemoryStore).open(t.allocator, &store, .{ .table_encoding = encoding, .block_bytes = 64, .table_bytes = 2048, .l0_tables = 2, .level_bytes = 4096, .cache_bytes = 4096 });
        defer writer.close();
        var key: [8]u8 = undefined;
        var value: [8]u8 = undefined;
        for (0..1200) |i| {
            try writer.put(try std.fmt.bufPrint(&key, "k{d:0>5}", .{i * 7}), try std.fmt.bufPrint(&value, "v{d:0>5}", .{i}));
            if (i % 150 == 149) {
                try writer.commit();
                try writer.flush();
                _ = try writer.compact();
            }
        }
        try writer.commit();
        try writer.flush();
        while (try writer.compact()) {}
        var deep = false;
        for (writer.version.tables[1..]) |level| deep = deep or level.len > 0;
        try t.expect(deep);
        const expected = try scanDigest(writer, .{});
        const expected_reverse = try scanDigest(writer, .{ .reverse = true });
        const expected_mid = try scanDigest(writer, .{ .start = "k03000", .end = "k06000" });
        const expected_mid_reverse = try scanDigest(writer, .{ .start = "k03000", .end = "k06000", .reverse = true });
        const resident = (try Db(MemoryStore).openReader(t.allocator, &store, .{ .cache_bytes = 4096 }));
        defer resident.close();
        const full_bytes = resident.residentMetadataBytes();
        for ([_]u32{ 2, 5, 16, 1 << 20 }) |stride| {
            const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{ .fence_stride = stride, .cache_bytes = 4096 });
            defer reader.close();
            try t.expect(reader.residentMetadataBytes() < full_bytes);
            for (0..1200) |i| {
                const k = try std.fmt.bufPrint(&key, "k{d:0>5}", .{i * 7});
                var v: [8]u8 = undefined;
                try t.expectEqualStrings(try std.fmt.bufPrint(&v, "v{d:0>5}", .{i}), (try reader.get(k)).?);
            }
            for (0..1200) |i| try t.expect(try reader.get(try std.fmt.bufPrint(&key, "k{d:0>5}", .{i * 7 + 3})) == null);
            try t.expect(try reader.get("") == null);
            try t.expect(try reader.get("zzz") == null);
            try t.expectEqual(expected, try scanDigest(reader, .{}));
            try t.expectEqual(expected_reverse, try scanDigest(reader, .{ .reverse = true }));
            try t.expectEqual(expected_mid, try scanDigest(reader, .{ .start = "k03000", .end = "k06000" }));
            try t.expectEqual(expected_mid_reverse, try scanDigest(reader, .{ .start = "k03000", .end = "k06000", .reverse = true }));
            reader.assertIntegrity();
            try t.expect(reader.cacheStats().cached_bytes <= 4096 + 1024);
        }
        // the writer itself can run sparse: flush, compact and read through it
        const sparse_writer = try Db(MemoryStore).openReader(t.allocator, &store, .{ .fence_stride = 4, .cache_bytes = 4096 });
        defer sparse_writer.close();
        try t.expectEqual(expected, try scanDigest(sparse_writer, .{}));
    }
}

test "a sparse writer flushes and compacts through fetched fence partitions" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const db = try Db(MemoryStore).open(t.allocator, &store, .{ .fence_stride = 3, .block_bytes = 64, .table_bytes = 1024, .l0_tables = 1, .cache_bytes = 2048 });
    defer db.close();
    var key: [8]u8 = undefined;
    for (0..3) |round| {
        for (0..300) |i| try db.put(try std.fmt.bufPrint(&key, "k{d:0>5}", .{i * 3}), if (round == 2 and i % 2 == 0) "even" else "odd");
        try db.commit();
        try db.flush();
        while (try db.compact()) {}
    }
    try db.collect();
    for (0..300) |i| try t.expectEqualStrings(if (i % 2 == 0) "even" else "odd", (try db.get(try std.fmt.bufPrint(&key, "k{d:0>5}", .{i * 3}))).?);
    const digest = try scanDigest(db, .{});
    try t.expectEqual(@as(usize, 300), digest.count);
    db.assertIntegrity();
    const resident = try Db(MemoryStore).openReader(t.allocator, &store, .{});
    defer resident.close();
    try t.expectEqual(digest, try scanDigest(resident, .{}));
}

test "a fence partition that disagrees with its resident sample is corrupt" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const writer = try Db(MemoryStore).open(t.allocator, &store, .{ .block_bytes = 32, .l0_tables = 1 });
    defer writer.close();
    var key: [8]u8 = undefined;
    for (0..64) |i| try writer.put(try std.fmt.bufPrint(&key, "k{d:0>5}", .{i}), "v");
    try writer.commit();
    try writer.flush();
    const table = writer.version.tables[0][0];
    try t.expect(table.meta.count() >= 4);
    // a one-byte cache budget keeps no partition between reads
    const reader = try Db(MemoryStore).openReader(t.allocator, &store, .{ .fence_stride = 2, .cache_bytes = 1 });
    defer reader.close();
    try t.expectEqualStrings("v", (try reader.get("k00000")).?);
    try t.expectEqualStrings("v", (try reader.get("k00001")).?);
    // flip a byte of the second fence key, the resident sample for partition 0
    var name: manifest.TableKey = undefined;
    const stored = store.objects.getPtr(manifest.tableKey(&name, table.id)).?;
    const idx = table.meta.index();
    stored.bytes[table.meta.data_len + idx.offset(1) + entry.header_len] ^= 0x01;
    try t.expectError(error.Corrupt, reader.get("k00000"));
    reader.assertIntegrity();
}

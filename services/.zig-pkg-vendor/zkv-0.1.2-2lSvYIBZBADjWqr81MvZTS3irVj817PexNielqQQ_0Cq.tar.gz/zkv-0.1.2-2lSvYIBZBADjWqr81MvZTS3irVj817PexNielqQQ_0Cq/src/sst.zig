const std = @import("std");
const entry = @import("entry.zig");
const block = @import("block.zig");
const bloom = @import("bloom.zig");

const magic: u32 = 0x7a6b7674;
const grouped_magic: u32 = 0x7a6b7633;
const grouped = @import("grouped.zig");
pub const Encoding = enum { legacy, grouped };
const footer_len = 24;
const handle_len = 16;

fn metaChecksum(bytes: []const u8, encoding: Encoding) u32 {
    var crc = std.hash.Crc32.init();
    crc.update(bytes[0 .. bytes.len - 8]);
    if (encoding == .grouped) crc.update(bytes[bytes.len - 4 ..]);
    return crc.final();
}

pub const Builder = struct {
    gpa: std.mem.Allocator,
    block_bytes: usize,
    bits_per_key: u32,
    encoding: Encoding = .legacy,
    out: std.ArrayList(u8) = .empty,
    data: block.Writer = .{},
    index_out: std.ArrayList(u8) = .empty,
    index: block.Writer = .{},
    hashes: std.ArrayList(u64) = .empty,
    digest: std.hash.Wyhash = .init(0),
    min: std.ArrayList(u8) = .empty,

    pub fn deinit(self: *Builder) void {
        self.out.deinit(self.gpa);
        self.data.deinit(self.gpa);
        self.index_out.deinit(self.gpa);
        self.index.deinit(self.gpa);
        self.hashes.deinit(self.gpa);
        self.min.deinit(self.gpa);
    }

    pub fn empty(self: *const Builder) bool {
        return self.hashes.items.len == 0;
    }

    pub fn bytes(self: *const Builder) usize {
        return self.out.items.len;
    }

    pub fn add(self: *Builder, e: entry.Entry) !void {
        if (self.empty()) try self.min.appendSlice(self.gpa, e.key);
        if (!self.data.empty() and self.blockLen() + entry.encodedLen(e) + 4 > self.block_bytes) try self.finishBlock();
        try self.data.add(self.gpa, &self.out, e);
        try self.hashes.append(self.gpa, bloom.hash(e.key));
        fold(&self.digest, e);
    }

    fn blockLen(self: *const Builder) usize {
        return self.out.items.len - self.data.start + 4 * (self.data.offsets.items.len + 1);
    }

    fn finishBlock(self: *Builder) !void {
        const start = self.data.start;
        try self.data.finish(self.gpa, &self.out);
        const key = if (self.encoding == .grouped) try self.gpa.dupe(u8, self.data.lastKey(self.out.items)) else self.data.lastKey(self.out.items);
        defer if (self.encoding == .grouped) self.gpa.free(key);
        if (self.encoding == .grouped) {
            const encoded = try grouped.encode(self.gpa, self.out.items[start..]);
            defer self.gpa.free(encoded);
            self.out.shrinkRetainingCapacity(start);
            try self.out.appendSlice(self.gpa, encoded);
        }
        var handle: [handle_len]u8 = undefined;
        std.mem.writeInt(u32, handle[0..4], @intCast(start), .little);
        std.mem.writeInt(u32, handle[4..8], @intCast(self.out.items.len - start), .little);
        std.mem.writeInt(u64, handle[8..16], blockSum(self.out.items[start..]), .little);
        try self.index.add(self.gpa, &self.index_out, .{ .key = key, .value = &handle, .kind = .put });
    }

    pub fn finish(self: *Builder) ![]u8 {
        if (!self.data.empty()) try self.finishBlock();
        const meta_at = self.out.items.len;
        try self.index.finish(self.gpa, &self.index_out);
        try self.out.appendSlice(self.gpa, self.index_out.items);
        const filter_at = self.out.items.len;
        try bloom.append(self.gpa, &self.out, self.hashes.items, self.bits_per_key);
        const min_at = self.out.items.len;
        try self.out.appendSlice(self.gpa, self.min.items);
        const footer = try self.out.addManyAsSlice(self.gpa, footer_len);
        std.mem.writeInt(u32, footer[0..4], @intCast(meta_at), .little);
        std.mem.writeInt(u32, footer[4..8], @intCast(filter_at - meta_at), .little);
        std.mem.writeInt(u32, footer[8..12], @intCast(min_at - filter_at), .little);
        std.mem.writeInt(u32, footer[12..16], @intCast(self.min.items.len), .little);
        std.mem.writeInt(u32, footer[20..24], if (self.encoding == .legacy) magic else grouped_magic, .little);
        const all = self.out.items;
        std.mem.writeInt(u32, footer[16..20], metaChecksum(all[meta_at..], self.encoding), .little);
        return self.out.toOwnedSlice(self.gpa);
    }
};

pub fn metaAt(object: []const u8) error{Corrupt}!usize {
    if (object.len < footer_len) return error.Corrupt;
    const at = std.mem.readInt(u32, object[object.len - footer_len ..][0..4], .little);
    if (at > object.len - footer_len) return error.Corrupt;
    return at;
}

pub const Handle = struct { at: u32, len: u32, sum: u64 };

pub fn blockSum(bytes: []const u8) u64 {
    return std.hash.Wyhash.hash(0x626c6f636b, bytes);
}

/// One fence key in `stride` kept resident, with the byte range of the fence
/// entries each sample covers inside the table's index block. Sample `j` is
/// the last fence of blocks `[j * stride, (j + 1) * stride)`, so the first
/// sample at or above a key names the partition whose fences decide the block.
pub const Sparse = struct {
    stride: u32,
    count: u32,
    keys: []const u8,
    key_ends: []const u32,
    starts: []const u32,

    pub fn partitions(self: Sparse) u32 {
        return @intCast(self.key_ends.len);
    }

    pub fn keyAt(self: Sparse, j: u32) []const u8 {
        const from = if (j == 0) 0 else self.key_ends[j - 1];
        return self.keys[from..self.key_ends[j]];
    }

    pub fn lowerBound(self: Sparse, key: []const u8) u32 {
        var lo: u32 = 0;
        var hi: u32 = self.partitions();
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            if (std.mem.order(u8, self.keyAt(mid), key) == .lt) lo = mid + 1 else hi = mid;
        }
        return lo;
    }

    pub fn blocksIn(self: Sparse, j: u32) u32 {
        return @min(self.stride, self.count - j * self.stride);
    }

    pub const Range = struct { at: u32, len: u32 };

    /// Fence entries of partition `j`, relative to the index block's start.
    pub fn range(self: Sparse, j: u32) Range {
        return .{ .at = self.starts[j], .len = self.starts[j + 1] - self.starts[j] };
    }
};

pub const Fences = union(enum) { resident: block.Block, sparse: Sparse };

pub const Meta = struct {
    encoding: Encoding,
    fences: Fences,
    filter: []const u8,
    min: []const u8,
    max: []const u8,
    data_len: u32,

    pub fn init(bytes: []const u8) error{Corrupt}!Meta {
        if (bytes.len < footer_len) return error.Corrupt;
        const footer = bytes[bytes.len - footer_len ..][0..footer_len];
        const encoding: Encoding = switch (std.mem.readInt(u32, footer[20..24], .little)) {
            magic => .legacy,
            grouped_magic => .grouped,
            else => return error.Corrupt,
        };
        if (std.mem.readInt(u32, footer[16..20], .little) != metaChecksum(bytes, encoding)) return error.Corrupt;
        const data_len = std.mem.readInt(u32, footer[0..4], .little);
        const index_len = std.mem.readInt(u32, footer[4..8], .little);
        const filter_len = std.mem.readInt(u32, footer[8..12], .little);
        const min_len = std.mem.readInt(u32, footer[12..16], .little);
        if (@as(u64, index_len) + filter_len + min_len + footer_len != bytes.len or filter_len < 9) return error.Corrupt;
        const fences = try block.Block.validate(bytes[0..index_len]);
        const meta: Meta = .{
            .encoding = encoding,
            .fences = .{ .resident = fences },
            .filter = bytes[index_len..][0..filter_len],
            .min = bytes[index_len + filter_len ..][0..min_len],
            .max = fences.keyAt(fences.count - 1),
            .data_len = data_len,
        };
        var end: u64 = 0;
        for (0..fences.count) |i| {
            if (fences.at(@intCast(i)).value.len != handle_len) return error.Corrupt;
            const h = meta.handle(@intCast(i));
            if (h.at != end) return error.Corrupt;
            end += h.len;
        }
        if (end != data_len or std.mem.order(u8, meta.min, meta.max) == .gt) return error.Corrupt;
        return meta;
    }

    /// The whole fence index; only a resident Meta has one.
    pub fn index(self: *const Meta) block.Block {
        return self.fences.resident;
    }

    pub fn count(self: *const Meta) u32 {
        return switch (self.fences) {
            .resident => |b| b.count,
            .sparse => |sp| sp.count,
        };
    }

    pub fn handle(self: Meta, i: u32) Handle {
        return handleFrom(self.index().at(i).value);
    }

    pub fn mayContain(self: *const Meta, h: u64) bool {
        return bloom.mayContain(self.filter, h);
    }

    /// Resident fences only; a sparse Meta locates through its Db.
    pub fn locate(self: *const Meta, key: []const u8) ?u32 {
        const b = self.index().lowerBound(key);
        return if (b == self.index().count) null else b;
    }
};

pub fn handleFrom(v: []const u8) Handle {
    return .{
        .at = std.mem.readInt(u32, v[0..4], .little),
        .len = std.mem.readInt(u32, v[4..8], .little),
        .sum = std.mem.readInt(u64, v[8..16], .little),
    };
}

pub const Compact = struct { bytes: []u8, key_ends: []u32, starts: []u32, meta: Meta };

/// The resident form of a validated Meta at `stride` > 1: filter, min key,
/// one fence key per partition and the partition byte ranges. The fence
/// index itself is left to be fetched from the table.
pub fn compact(gpa: std.mem.Allocator, meta: Meta, stride: u32) !Compact {
    std.debug.assert(stride > 1);
    const idx = meta.index();
    const partitions: u32 = (idx.count + stride - 1) / stride;
    var keys_len: usize = 0;
    for (0..partitions) |j| keys_len += idx.keyAt(@intCast(@min((j + 1) * stride, idx.count) - 1)).len;
    const bytes = try gpa.alloc(u8, meta.filter.len + meta.min.len + keys_len);
    errdefer gpa.free(bytes);
    const key_ends = try gpa.alloc(u32, partitions);
    errdefer gpa.free(key_ends);
    const starts = try gpa.alloc(u32, partitions + 1);
    errdefer gpa.free(starts);
    @memcpy(bytes[0..meta.filter.len], meta.filter);
    @memcpy(bytes[meta.filter.len..][0..meta.min.len], meta.min);
    const keys_at = meta.filter.len + meta.min.len;
    var at = keys_at;
    for (0..partitions) |j| {
        const k = idx.keyAt(@intCast(@min((j + 1) * stride, idx.count) - 1));
        @memcpy(bytes[at..][0..k.len], k);
        at += k.len;
        key_ends[j] = @intCast(at - keys_at);
        starts[j] = idx.offset(@intCast(j * stride));
    }
    starts[partitions] = @intCast(idx.bytes.len);
    const sparse: Sparse = .{ .stride = stride, .count = idx.count, .keys = bytes[keys_at..], .key_ends = key_ends, .starts = starts };
    return .{ .bytes = bytes, .key_ends = key_ends, .starts = starts, .meta = .{
        .encoding = meta.encoding,
        .fences = .{ .sparse = sparse },
        .filter = bytes[0..meta.filter.len],
        .min = bytes[meta.filter.len..][0..meta.min.len],
        .max = sparse.keyAt(partitions - 1),
        .data_len = meta.data_len,
    } };
}

pub const Decoded = struct { bytes: []u8, block: block.Block };

/// Turn `n` fence entries read back from a table's index block into a Block,
/// taking ownership of `bytes`. The entries must parse end to end, ascend,
/// carry 16-byte handles that chain, and end on `sample`, the resident key
/// for this partition: a stale, torn or misdirected read fails here.
pub fn decodeFences(gpa: std.mem.Allocator, bytes: []u8, n: u32, sample: []const u8) error{ Corrupt, OutOfMemory }!Decoded {
    const entries_len = bytes.len;
    const out = gpa.realloc(bytes, entries_len + 4 * @as(usize, n) + 4) catch |err| {
        gpa.free(bytes);
        return err;
    };
    errdefer gpa.free(out);
    var at: usize = 0;
    var previous: ?entry.Entry = null;
    for (0..n) |i| {
        const e = try entry.decode(out[0..entries_len], at);
        if (e.value.len != handle_len or e.kind != .put) return error.Corrupt;
        if (previous) |p| {
            if (std.mem.order(u8, p.key, e.key) != .lt) return error.Corrupt;
            const before = handleFrom(p.value);
            if (handleFrom(e.value).at != before.at + before.len) return error.Corrupt;
        }
        std.mem.writeInt(u32, out[entries_len + 4 * i ..][0..4], @intCast(at), .little);
        previous = e;
        at += entry.encodedLen(e);
    }
    const last = previous orelse return error.Corrupt;
    if (at != entries_len or !std.mem.eql(u8, last.key, sample)) return error.Corrupt;
    std.mem.writeInt(u32, out[entries_len + 4 * @as(usize, n) ..][0..4], n, .little);
    return .{ .bytes = out, .block = block.Block.init(out) };
}

/// a block read back from the store must hash to what its handle recorded:
/// a torn, stale or misdirected read fails here. its structure was checked
/// when the table was encoded, before it was ever written.
pub fn checkBytes(bytes: []const u8, h: Handle) error{Corrupt}!void {
    if (bytes.len != h.len or bytes.len < 4 or blockSum(bytes) != h.sum) return error.Corrupt;
}

pub fn checkBlock(bytes: []const u8, h: Handle) error{Corrupt}!block.Block {
    try checkBytes(bytes, h);
    return block.Block.init(bytes);
}

pub fn find(b: block.Block, key: []const u8) ?entry.Entry {
    const i = b.lowerBound(key);
    if (i == b.count) return null;
    const e = b.at(i);
    return if (std.mem.eql(u8, e.key, key)) e else null;
}

pub fn digest(gpa: std.mem.Allocator, object: []const u8) !u64 {
    var verifier = try Verifier.init(object);
    const done = try verifier.step(gpa, std.math.maxInt(usize));
    std.debug.assert(done);
    return verifier.final();
}

pub const Verifier = struct {
    object: []const u8,
    meta: Meta,
    hasher: std.hash.Wyhash = .init(0),
    previous: ?[]const u8 = null,
    next_block: u32 = 0,
    checked_bytes: usize = 0,

    pub fn init(object: []const u8) error{Corrupt}!Verifier {
        return .{ .object = object, .meta = try Meta.init(object[try metaAt(object)..]) };
    }

    pub fn step(self: *Verifier, gpa: std.mem.Allocator, bytes: usize) !bool {
        std.debug.assert(bytes > 0);
        const start = self.checked_bytes;
        while (self.next_block < self.meta.index().count) {
            const h = self.meta.handle(self.next_block);
            if (@as(u64, h.at) + h.len > self.meta.data_len) return error.Corrupt;
            const data = self.object[h.at..][0..h.len];
            if (data.len < 4 or blockSum(data) != h.sum) return error.Corrupt;
            const decoded = if (self.meta.encoding == .grouped) try grouped.decode(gpa, data) else null;
            defer if (decoded) |raw| gpa.free(raw);
            const b = try block.Block.validate(decoded orelse data);
            if (!std.mem.eql(u8, b.keyAt(b.count - 1), self.meta.index().keyAt(self.next_block))) return error.Corrupt;
            for (0..b.count) |j| {
                const e = b.at(@intCast(j));
                if (self.previous == null and !std.mem.eql(u8, e.key, self.meta.min)) return error.Corrupt;
                if (self.previous) |p| if (std.mem.order(u8, p, e.key) != .lt) return error.Corrupt;
                self.previous = e.key;
                fold(&self.hasher, e);
            }
            self.previous = self.meta.index().keyAt(self.next_block);
            self.next_block += 1;
            self.checked_bytes += if (decoded) |raw| raw.len else data.len;
            if (self.checked_bytes - start >= bytes) break;
        }
        return self.next_block == self.meta.index().count;
    }

    pub fn final(self: *Verifier) u64 {
        std.debug.assert(self.next_block == self.meta.index().count);
        return self.hasher.final();
    }
};

test "stepped verification checks every block and preserves the digest" {
    const t = std.testing;
    var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 32, .bits_per_key = 10 };
    defer builder.deinit();
    for (0..32) |i| {
        var key: [8]u8 = undefined;
        try builder.add(.{ .key = try std.fmt.bufPrint(&key, "k{d:0>3}", .{i}), .value = "value", .kind = .put });
    }
    const bytes = try builder.finish();
    defer t.allocator.free(bytes);
    for ([_]usize{ 1, 64, std.math.maxInt(usize) }) |budget| {
        var verifier = try Verifier.init(bytes);
        var steps: usize = 0;
        while (true) {
            const before = verifier.next_block;
            const done = try verifier.step(t.allocator, budget);
            try t.expect(verifier.next_block > before);
            if (budget == 1) try t.expectEqual(before + 1, verifier.next_block);
            steps += 1;
            if (done) break;
        }
        if (budget == 1) try t.expectEqual(verifier.meta.index().count, steps);
        try t.expectEqual(builder.digest.final(), verifier.final());
        try t.expect(try verifier.step(t.allocator, budget));
        try t.expectEqual(builder.digest.final(), verifier.final());
    }
    const meta = try Meta.init(bytes[try metaAt(bytes)..]);
    const last = meta.handle(meta.index().count - 1);
    bytes[last.at] ^= 1;
    var corrupt = try Verifier.init(bytes);
    for (0..meta.index().count - 1) |_| try t.expect(!try corrupt.step(t.allocator, 1));
    try t.expectError(error.Corrupt, corrupt.step(t.allocator, 1));
}

test "digest rejects a checksummed block with an impossible entry count" {
    const t = std.testing;
    var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 4096, .bits_per_key = 10 };
    defer builder.deinit();
    try builder.add(.{ .key = "a", .value = "b", .kind = .put });
    const bytes = try builder.finish();
    defer t.allocator.free(bytes);
    const at = try metaAt(bytes);
    const meta = try Meta.init(bytes[at..]);
    const h = meta.handle(0);
    std.mem.writeInt(u32, bytes[h.at + h.len - 4 ..][0..4], std.math.maxInt(u32), .little);
    const handle_at = @intFromPtr(meta.index().at(0).value.ptr) - @intFromPtr(bytes.ptr);
    std.mem.writeInt(u64, bytes[handle_at + 8 ..][0..8], blockSum(bytes[h.at..][0..h.len]), .little);
    std.mem.writeInt(u32, bytes[bytes.len - 8 ..][0..4], std.hash.Crc32.hash(bytes[at .. bytes.len - 8]), .little);
    try t.expectError(error.Corrupt, digest(t.allocator, bytes));
}

pub const Pin = struct { block: block.Block, token: ?*anyopaque };

pub const Loader = struct {
    ctx: *anyopaque,
    load: *const fn (ctx: *anyopaque, table: *anyopaque, i: u32) anyerror!Pin,
    unpin: *const fn (ctx: *anyopaque, token: ?*anyopaque) void,
    /// The first block whose fence is at or above `key`, null past the last.
    locate: *const fn (ctx: *anyopaque, table: *anyopaque, key: []const u8) anyerror!?u32,
};

pub const Cursor = struct {
    meta: *const Meta,
    table: *anyopaque,
    loader: Loader,
    block_index: u32 = 0,
    pin: ?Pin = null,
    i: u32 = 0,
    valid: bool = false,

    pub fn deinit(self: *Cursor) void {
        if (self.pin) |p| self.loader.unpin(self.loader.ctx, p.token);
        self.pin = null;
        self.valid = false;
    }

    fn load(self: *Cursor, b: u32) !void {
        self.deinit();
        self.pin = try self.loader.load(self.loader.ctx, self.table, b);
        self.block_index = b;
    }

    fn data(self: *const Cursor) block.Block {
        return self.pin.?.block;
    }

    pub fn current(self: *const Cursor) entry.Entry {
        return self.data().at(self.i);
    }

    pub fn first(self: *Cursor) !void {
        try self.load(0);
        self.i = 0;
        self.valid = true;
    }

    pub fn last(self: *Cursor) !void {
        try self.load(self.meta.count() - 1);
        self.i = self.data().count - 1;
        self.valid = true;
    }

    pub fn seekGe(self: *Cursor, key: []const u8) !void {
        const b = try self.loader.locate(self.loader.ctx, self.table, key) orelse return self.deinit();
        try self.load(b);
        self.i = self.data().lowerBound(key);
        self.valid = true;
    }

    pub fn seekLt(self: *Cursor, key: []const u8) !void {
        const b = try self.loader.locate(self.loader.ctx, self.table, key) orelse return self.last();
        try self.load(b);
        self.i = self.data().lowerBound(key);
        self.valid = true;
        if (self.i == 0) {
            if (b == 0) return self.deinit();
            try self.load(b - 1);
            self.i = self.data().count;
            self.valid = true;
        }
        self.i -= 1;
    }

    pub fn next(self: *Cursor) !void {
        self.i += 1;
        if (self.i < self.data().count) return;
        if (self.block_index + 1 == self.meta.count()) return self.deinit();
        try self.load(self.block_index + 1);
        self.i = 0;
        self.valid = true;
    }

    pub fn prev(self: *Cursor) !void {
        if (self.i > 0) {
            self.i -= 1;
            return;
        }
        if (self.block_index == 0) return self.deinit();
        try self.load(self.block_index - 1);
        self.i = self.data().count - 1;
        self.valid = true;
    }
};

pub fn fold(hasher: *std.hash.Wyhash, e: entry.Entry) void {
    var lengths: [9]u8 = undefined;
    lengths[0] = @backingInt(e.kind);
    std.mem.writeInt(u32, lengths[1..5], @intCast(e.key.len), .little);
    std.mem.writeInt(u32, lengths[5..9], @intCast(e.value.len), .little);
    hasher.update(&lengths);
    hasher.update(e.key);
    hasher.update(e.value);
}

test "finishing a prepared block needs no temporary key allocation" {
    const t = std.testing;
    var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 4096, .bits_per_key = 10 };
    defer builder.deinit();
    try builder.add(.{ .key = "", .value = "first", .kind = .put });
    try builder.add(.{ .key = "a\x00z", .value = "last", .kind = .put });
    try builder.out.ensureUnusedCapacity(t.allocator, 4 * (builder.data.offsets.items.len + 1));
    try builder.index_out.ensureUnusedCapacity(t.allocator, 128);
    try builder.index.offsets.ensureUnusedCapacity(t.allocator, 1);
    var failing = std.testing.FailingAllocator.init(t.allocator, .{ .fail_index = 0 });
    builder.gpa = failing.allocator();
    try builder.finishBlock();
    builder.gpa = t.allocator;
    const bytes = try builder.finish();
    defer t.allocator.free(bytes);
    const meta = try Meta.init(bytes[try metaAt(bytes)..]);
    try t.expectEqualStrings("", meta.min);
    try t.expectEqualStrings("a\x00z", meta.max);
    const h = meta.handle(0);
    const data = try checkBlock(bytes[h.at..][0..h.len], h);
    try t.expectEqualStrings("first", find(data, "").?.value);
    try t.expectEqualStrings("last", find(data, "a\x00z").?.value);
    try t.expectEqual(builder.digest.final(), try digest(t.allocator, bytes));
}

test "format discriminator cannot be changed without failing metadata integrity" {
    const t = std.testing;
    for ([_]Encoding{ .legacy, .grouped }) |encoding| {
        var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 512, .bits_per_key = 10, .encoding = encoding };
        defer builder.deinit();
        try builder.add(.{ .key = "key", .value = "value", .kind = .put });
        const bytes = try builder.finish();
        defer t.allocator.free(bytes);
        _ = try digest(t.allocator, bytes);
        std.mem.writeInt(u32, bytes[bytes.len - 4 ..][0..4], if (encoding == .legacy) grouped_magic else magic, .little);
        try t.expectError(error.Corrupt, digest(t.allocator, bytes));
    }
}

test "compressed verification steps budget decoded work rather than disk bytes" {
    const t = std.testing;
    var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 512, .bits_per_key = 10, .encoding = .grouped };
    defer builder.deinit();
    for (0..128) |i| {
        var key: [96]u8 = undefined;
        try builder.add(.{ .key = try std.fmt.bufPrint(&key, "a-long-shared-prefix-that-compresses-well/{d:0>6}", .{i}), .value = "", .kind = .put });
    }
    const bytes = try builder.finish();
    defer t.allocator.free(bytes);
    var verifier = try Verifier.init(bytes);
    try t.expect(!try verifier.step(t.allocator, 512));
    try t.expect(verifier.checked_bytes >= 512);
    try t.expect(verifier.next_block <= 2);
    while (!try verifier.step(t.allocator, 512)) {}
    try t.expectEqual(builder.digest.final(), verifier.final());
}

test "compact fences and decoded partitions agree with the resident index" {
    const t = std.testing;
    var builder: Builder = .{ .gpa = t.allocator, .block_bytes = 48, .bits_per_key = 10 };
    defer builder.deinit();
    for (0..100) |i| {
        var key: [16]u8 = undefined;
        try builder.add(.{ .key = try std.fmt.bufPrint(&key, "key-{d:0>4}", .{i}), .value = "v", .kind = .put });
    }
    const bytes = try builder.finish();
    defer t.allocator.free(bytes);
    const tail = bytes[try metaAt(bytes)..];
    const meta = try Meta.init(tail);
    const idx = meta.index();
    try t.expect(idx.count > 8);
    for ([_]u32{ 2, 3, 7, idx.count, idx.count + 5 }) |stride| {
        const c = try compact(t.allocator, meta, stride);
        defer {
            t.allocator.free(c.bytes);
            t.allocator.free(c.key_ends);
            t.allocator.free(c.starts);
        }
        const sp = c.meta.fences.sparse;
        try t.expectEqual(idx.count, c.meta.count());
        try t.expectEqual((idx.count + stride - 1) / stride, sp.partitions());
        try t.expectEqualStrings(meta.min, c.meta.min);
        try t.expectEqualStrings(meta.max, c.meta.max);
        try t.expectEqualSlices(u8, meta.filter, c.meta.filter);
        try t.expect(c.bytes.len < tail.len);
        for (0..sp.partitions()) |j| {
            const r = sp.range(@intCast(j));
            const copy = try t.allocator.dupe(u8, tail[r.at..][0..r.len]);
            const decoded = try decodeFences(t.allocator, copy, sp.blocksIn(@intCast(j)), sp.keyAt(@intCast(j)));
            defer t.allocator.free(decoded.bytes);
            try t.expectEqual(sp.blocksIn(@intCast(j)), decoded.block.count);
            for (0..decoded.block.count) |w| {
                const i: u32 = @intCast(j * stride + w);
                try t.expectEqualStrings(idx.keyAt(i), decoded.block.keyAt(@intCast(w)));
                try t.expectEqual(meta.handle(i), handleFrom(decoded.block.at(@intCast(w)).value));
            }
        }
        for (0..idx.count) |i| {
            const fence = idx.keyAt(@intCast(i));
            try t.expectEqual(@as(u32, @intCast(i / stride)), sp.lowerBound(fence));
        }
        try t.expectEqual(sp.partitions(), sp.lowerBound("zzz"));
        // a partition whose last key is not the resident sample is a misdirected read
        const r0 = sp.range(0);
        const wrong = try t.allocator.dupe(u8, tail[r0.at..][0..r0.len]);
        try t.expectError(error.Corrupt, decodeFences(t.allocator, wrong, sp.blocksIn(0), "not-the-sample"));
        const short = try t.allocator.dupe(u8, tail[r0.at..][0 .. r0.len - 1]);
        try t.expectError(error.Corrupt, decodeFences(t.allocator, short, sp.blocksIn(0), sp.keyAt(0)));
    }
}

const std = @import("std");
const entry = @import("entry.zig");
const sst = @import("sst.zig");
const Memtable = @import("memtable.zig").Memtable;
const Node = @import("memtable.zig").Node;
const Table = @import("version.zig").Table;

pub const Range = struct {
    start: ?[]const u8 = null,
    end: ?[]const u8 = null,
    reverse: bool = false,
};

const MemSource = struct {
    mem: *const Memtable,
    bound: u64,
    node: ?*Node = null,

    fn seek(self: *MemSource, range: Range) void {
        if (range.reverse) return self.visibleBefore(range.end);
        self.node = if (range.start) |s| self.mem.seekGe(s, self.bound) else self.mem.first();
        self.skip(null);
    }

    fn skip(self: *MemSource, after: ?[]const u8) void {
        while (self.node) |node| {
            if (node.seq <= self.bound) if (after == null or !std.mem.eql(u8, node.key, after.?)) return;
            self.node = node.next[0];
        }
    }

    fn visibleBefore(self: *MemSource, limit: ?[]const u8) void {
        var below = limit;
        while (self.mem.seekLt(below)) |older| {
            const newest = self.mem.seekGe(older.key, self.bound).?;
            if (std.mem.eql(u8, newest.key, older.key)) {
                self.node = newest;
                return;
            }
            below = older.key;
        }
        self.node = null;
    }

    fn advance(self: *MemSource, reverse: bool) void {
        const node = self.node.?;
        if (reverse) return self.visibleBefore(node.key);
        self.node = node.next[0];
        self.skip(node.key);
    }

    fn current(self: *const MemSource) ?entry.Entry {
        const node = self.node orelse return null;
        return .{ .key = node.key, .value = node.value, .kind = node.kind };
    }
};

const RunSource = struct {
    tables: []const *Table,
    loader: sst.Loader,
    t: usize = 0,
    cursor: ?sst.Cursor = null,

    fn open(self: *RunSource, t: usize) *sst.Cursor {
        if (self.cursor) |*c| c.deinit();
        self.t = t;
        self.cursor = .{ .meta = &self.tables[t].meta, .table = self.tables[t], .loader = self.loader };
        return &self.cursor.?;
    }

    fn seek(self: *RunSource, range: Range) !void {
        const tables = self.tables;
        if (range.reverse) {
            var t = tables.len;
            if (range.end) |end| {
                t = 0;
                var hi = tables.len;
                while (t < hi) {
                    const mid = t + (hi - t) / 2;
                    if (std.mem.order(u8, tables[mid].meta.min, end) == .lt) t = mid + 1 else hi = mid;
                }
            }
            if (t == 0) return;
            const c = self.open(t - 1);
            if (range.end) |end| try c.seekLt(end) else try c.last();
            return;
        }
        var t: usize = 0;
        if (range.start) |start| {
            var hi = tables.len;
            while (t < hi) {
                const mid = t + (hi - t) / 2;
                if (std.mem.order(u8, tables[mid].meta.max, start) == .lt) t = mid + 1 else hi = mid;
            }
        }
        if (t == tables.len) return;
        const c = self.open(t);
        if (range.start) |start| try c.seekGe(start) else try c.first();
    }

    fn advance(self: *RunSource, reverse: bool) !void {
        const c = &self.cursor.?;
        if (reverse) {
            try c.prev();
            if (c.valid or self.t == 0) return;
            try self.open(self.t - 1).last();
            return;
        }
        try c.next();
        if (c.valid or self.t + 1 == self.tables.len) return;
        try self.open(self.t + 1).first();
    }

    fn current(self: *const RunSource) ?entry.Entry {
        const c = &(self.cursor orelse return null);
        return if (c.valid) c.current() else null;
    }

    fn deinit(self: *RunSource) void {
        if (self.cursor) |*c| c.deinit();
        self.cursor = null;
    }
};

pub const Source = union(enum) {
    mem: MemSource,
    run: RunSource,

    pub fn memtable(mem: *const Memtable, bound: u64) Source {
        return .{ .mem = .{ .mem = mem, .bound = bound } };
    }

    pub fn tables(run: []const *Table, loader: sst.Loader) Source {
        return .{ .run = .{ .tables = run, .loader = loader } };
    }

    fn seek(self: *Source, range: Range) !void {
        switch (self.*) {
            .mem => |*s| s.seek(range),
            .run => |*s| try s.seek(range),
        }
    }

    fn advance(self: *Source, reverse: bool) !void {
        switch (self.*) {
            .mem => |*s| s.advance(reverse),
            .run => |*s| try s.advance(reverse),
        }
    }

    fn current(self: *const Source) ?entry.Entry {
        return switch (self.*) {
            inline else => |*s| s.current(),
        };
    }

    fn deinit(self: *Source) void {
        switch (self.*) {
            .mem => {},
            .run => |*s| s.deinit(),
        }
    }
};

pub const Merge = struct {
    sources: []Source,
    range: Range,
    keep_tombstones: bool,
    returned: ?usize = null,
    all: []Source,
    visited: u64 = 0,
    visited_bytes: u64 = 0,

    pub fn init(sources: []Source, range: Range, keep_tombstones: bool) !Merge {
        var merged: Merge = .{ .sources = sources, .all = sources, .range = range, .keep_tombstones = keep_tombstones };
        errdefer merged.deinit();
        for (sources) |*s| try s.seek(range);
        return merged;
    }

    pub fn deinit(self: *Merge) void {
        for (self.all) |*s| s.deinit();
    }

    fn ahead(self: *const Merge, a: []const u8, b: []const u8) bool {
        const wanted: std.math.Order = if (self.range.reverse) .gt else .lt;
        return std.mem.order(u8, a, b) == wanted;
    }

    fn outside(self: *const Merge, key: []const u8) bool {
        if (self.range.reverse) {
            const start = self.range.start orelse return false;
            return std.mem.order(u8, key, start) == .lt;
        }
        const end = self.range.end orelse return false;
        return std.mem.order(u8, key, end) != .lt;
    }

    fn passReturned(self: *Merge) !void {
        const b = self.returned orelse return;
        self.returned = null;
        const key = self.sources[b].current().?.key;
        for (self.sources, 0..) |*s, i| {
            if (i == b) continue;
            const c = s.current() orelse continue;
            if (std.mem.eql(u8, c.key, key)) try s.advance(self.range.reverse);
        }
        try self.sources[b].advance(self.range.reverse);
    }

    pub fn next(self: *Merge) !?entry.Entry {
        while (try self.nextCandidate()) |e| {
            if (e.kind == .del and !self.keep_tombstones) continue;
            return e;
        }
        return null;
    }

    pub fn nextCandidate(self: *Merge) !?entry.Entry {
        try self.passReturned();
        var best: ?usize = null;
        for (self.sources, 0..) |*s, i| {
            const e = s.current() orelse continue;
            if (best == null or self.ahead(e.key, self.sources[best.?].current().?.key)) best = i;
        }
        const b = best orelse return null;
        const e = self.sources[b].current().?;
        if (self.outside(e.key)) {
            self.sources = self.sources[0..0];
            return null;
        }
        self.returned = b;
        self.visited += 1;
        self.visited_bytes += e.key.len + e.value.len;
        return e;
    }
};

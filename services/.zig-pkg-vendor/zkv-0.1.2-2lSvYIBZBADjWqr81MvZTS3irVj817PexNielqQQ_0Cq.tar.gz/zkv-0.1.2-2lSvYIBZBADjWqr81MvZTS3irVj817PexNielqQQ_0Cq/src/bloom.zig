const std = @import("std");

pub fn hash(key: []const u8) u64 {
    return std.hash.Wyhash.hash(0x6b76, key);
}

pub fn append(gpa: std.mem.Allocator, out: *std.ArrayList(u8), hashes: []const u64, bits_per_key: u32) !void {
    const probes: u8 = @intCast(std.math.clamp(bits_per_key * 69 / 100, 1, 30));
    const bytes = @max(8, (hashes.len * bits_per_key + 7) / 8);
    const filter = try out.addManyAsSlice(gpa, bytes + 1);
    @memset(filter, 0);
    filter[bytes] = probes;
    const bits = filter[0..bytes];
    for (hashes) |h| {
        var probe = h;
        const delta = std.math.rotr(u64, h, 17);
        for (0..probes) |_| {
            const bit = probe % (bits.len * 8);
            bits[bit / 8] |= @as(u8, 1) << @intCast(bit % 8);
            probe +%= delta;
        }
    }
}

pub fn mayContain(filter: []const u8, h: u64) bool {
    const bits = filter[0 .. filter.len - 1];
    var probe = h;
    const delta = std.math.rotr(u64, h, 17);
    for (0..filter[filter.len - 1]) |_| {
        const bit = probe % (bits.len * 8);
        if (bits[bit / 8] & (@as(u8, 1) << @intCast(bit % 8)) == 0) return false;
        probe +%= delta;
    }
    return true;
}

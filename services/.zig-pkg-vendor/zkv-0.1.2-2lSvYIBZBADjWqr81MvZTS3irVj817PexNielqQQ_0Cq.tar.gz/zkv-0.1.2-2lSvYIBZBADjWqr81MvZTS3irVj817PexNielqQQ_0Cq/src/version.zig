const std = @import("std");
const sst = @import("sst.zig");
const manifest = @import("manifest.zig");
const levels = manifest.levels;

pub const Table = struct {
    refs: u32 = 1,
    id: u64,
    size: u64,
    hash: u64,
    bytes: []u8,
    key_ends: []u32 = &.{},
    starts: []u32 = &.{},
    meta: sst.Meta,

    pub fn ref(self: *const Table) manifest.Ref {
        return .{ .id = self.id, .size = self.size, .meta_at = self.meta.data_len, .hash = self.hash };
    }

    /// Takes `meta_bytes` on success. At `fence_stride` 1 they stay resident
    /// whole; above it the fence index is dropped for its compact form.
    pub fn create(gpa: std.mem.Allocator, id: u64, size: u64, meta_bytes: []u8, fence_stride: u32) !*Table {
        const table = try gpa.create(Table);
        errdefer gpa.destroy(table);
        const meta = try sst.Meta.init(meta_bytes);
        if (@as(u64, meta.data_len) + meta_bytes.len != size) return error.Corrupt;
        const hash = manifest.hash(meta_bytes);
        if (fence_stride <= 1) {
            table.* = .{ .id = id, .size = size, .hash = hash, .bytes = meta_bytes, .meta = meta };
            return table;
        }
        const c = try sst.compact(gpa, meta, fence_stride);
        gpa.free(meta_bytes);
        table.* = .{ .id = id, .size = size, .hash = hash, .bytes = c.bytes, .key_ends = c.key_ends, .starts = c.starts, .meta = c.meta };
        return table;
    }

    /// Heap bytes this table pins while open, including its own struct.
    pub fn residentBytes(self: *const Table) usize {
        return @sizeOf(Table) + self.bytes.len + 4 * (self.key_ends.len + self.starts.len);
    }

    pub fn retain(self: *Table) *Table {
        self.refs += 1;
        return self;
    }

    pub fn release(self: *Table, gpa: std.mem.Allocator) void {
        self.refs -= 1;
        if (self.refs > 0) return;
        gpa.free(self.bytes);
        gpa.free(self.key_ends);
        gpa.free(self.starts);
        gpa.destroy(self);
    }
};

pub const Version = struct {
    refs: u32 = 1,
    applied: u64,
    fences: []u64,
    tables: [levels][]*Table,

    pub fn create(gpa: std.mem.Allocator, applied: u64, fences: []const u64, tables: [levels][]const *Table) !*Version {
        const version = try gpa.create(Version);
        errdefer gpa.destroy(version);
        const owned_fences = try gpa.dupe(u64, fences);
        errdefer gpa.free(owned_fences);
        var owned: [levels][]*Table = @splat(&.{});
        errdefer for (owned) |level| gpa.free(level);
        for (tables, &owned) |level, *slot| slot.* = try gpa.dupe(*Table, level);
        for (owned) |level| {
            for (level) |table| _ = table.retain();
        }
        version.* = .{ .applied = applied, .fences = owned_fences, .tables = owned };
        return version;
    }

    pub fn retain(self: *Version) *Version {
        self.refs += 1;
        return self;
    }

    pub fn release(self: *Version, gpa: std.mem.Allocator) void {
        self.refs -= 1;
        if (self.refs > 0) return;
        for (self.tables) |level| {
            for (level) |table| table.release(gpa);
            gpa.free(level);
        }
        gpa.free(self.fences);
        gpa.destroy(self);
    }

    pub fn levelBytes(self: *const Version, level: usize) u64 {
        var total: u64 = 0;
        for (self.tables[level]) |table| total += table.size;
        return total;
    }

    pub fn contains(self: *const Version, id: u64) bool {
        return self.find(id) != null;
    }

    pub fn find(self: *const Version, id: u64) ?*Table {
        for (self.tables) |level| for (level) |table| if (table.id == id) return table;
        return null;
    }
};

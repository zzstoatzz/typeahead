//! a store over an S3-compatible bucket: AWS S3, Cloudflare R2, MinIO, GCS
//! interop. `putIfAbsent` is a PUT with `If-None-Match: *` and `cas` a PUT
//! with `If-Match`, so the bucket must support conditional writes (S3 since
//! 2024, R2, MinIO). requests are signed with SigV4 and addressed path-style.
//!
//! an object's etag here is a hash of the etag the bucket returns. `cas`
//! needs the bucket's own etag back, so the store remembers the last one it
//! saw for each key, and asks the bucket with a HEAD when it has none.

const std = @import("std");
const store = @import("../store.zig");
const Object = store.Object;

const Io = std.Io;
const http = std.http;
const Sha256 = std.crypto.hash.sha2.Sha256;
const HmacSha256 = std.crypto.auth.hmac.sha2.HmacSha256;

pub const S3Store = struct {
    gpa: std.mem.Allocator,
    io: Io,
    client: http.Client,
    config: Config,
    /// "host" or "host:port", as signed and sent.
    host: []u8,
    /// guards `etags`, which concurrent requests from the *Many calls share
    mutex: Io.Mutex = .init,
    etags: std.StringHashMapUnmanaged([]u8) = .empty,

    pub const Config = struct {
        /// scheme and authority, no path: "https://<account>.r2.cloudflarestorage.com"
        endpoint: []const u8,
        bucket: []const u8,
        /// prepended to every key, so several databases can share a bucket
        prefix: []const u8 = "",
        /// "auto" for R2
        region: []const u8 = "auto",
        access_key_id: []const u8,
        secret_access_key: []const u8,
        /// how many times a conditional write is retried on 409, which S3
        /// and R2 return while another conditional write on the key is in
        /// flight
        conflict_retries: u8 = 4,
        /// how many requests `getMany`, `getRangeMany` and `deleteMany` keep
        /// in flight at once. each is its own connection.
        parallel: u8 = 16,
    };

    pub fn init(gpa: std.mem.Allocator, io: Io, config: Config) !S3Store {
        const uri = try std.Uri.parse(config.endpoint);
        var host_buf: [std.Io.net.HostName.max_len]u8 = undefined;
        const host_name = (try std.Io.net.HostName.fromUri(uri, &host_buf)).bytes;
        const host = if (uri.port) |port|
            try std.fmt.allocPrint(gpa, "{s}:{d}", .{ host_name, port })
        else
            try gpa.dupe(u8, host_name);
        return .{ .gpa = gpa, .io = io, .client = .{ .allocator = gpa, .io = io }, .config = config, .host = host };
    }

    pub fn deinit(self: *S3Store) void {
        var it = self.etags.iterator();
        while (it.next()) |kv| {
            self.gpa.free(kv.key_ptr.*);
            self.gpa.free(kv.value_ptr.*);
        }
        self.etags.deinit(self.gpa);
        self.client.deinit();
        self.gpa.free(self.host);
    }

    pub fn get(self: *S3Store, gpa: std.mem.Allocator, key: []const u8) !?Object {
        var res = try self.send(gpa, .GET, key, null, &.{}, null);
        errdefer res.deinit(gpa);
        switch (res.status) {
            .ok => {},
            .not_found => {
                res.deinit(gpa);
                return null;
            },
            else => return statusError(res.status),
        }
        const etag = try self.remember(key, res.etag orelse return error.MissingEtag);
        gpa.free(res.etag.?);
        return .{ .bytes = res.body, .etag = etag };
    }

    pub fn getRange(self: *S3Store, gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
        if (len == 0) return try gpa.alloc(u8, 0);
        if (offset > std.math.maxInt(u64) - (len - 1)) return error.OutOfRange;
        var range_buf: [64]u8 = undefined;
        const range = try std.fmt.bufPrint(&range_buf, "bytes={d}-{d}", .{ offset, offset + len - 1 });
        var res = try self.send(gpa, .GET, key, null, &.{.{ .name = "range", .value = range }}, null);
        errdefer res.deinit(gpa);
        switch (res.status) {
            .partial_content => {},
            .not_found => {
                res.deinit(gpa);
                return null;
            },
            .range_not_satisfiable => return error.OutOfRange,
            else => return statusError(res.status),
        }
        if (res.body.len != len) return error.OutOfRange;
        if (res.etag) |e| gpa.free(e);
        return res.body;
    }

    pub fn put(self: *S3Store, key: []const u8, bytes: []const u8) !void {
        var res = try self.send(self.gpa, .PUT, key, null, &.{}, bytes);
        defer res.deinit(self.gpa);
        if (res.status != .ok) return statusError(res.status);
        if (res.etag) |e| _ = try self.remember(key, e);
    }

    pub fn putIfAbsent(self: *S3Store, key: []const u8, bytes: []const u8) !?u64 {
        return self.conditional(key, bytes, .{ .name = "if-none-match", .value = "*" });
    }

    pub fn cas(self: *S3Store, key: []const u8, bytes: []const u8, etag: u64) !?u64 {
        var quoted_buf: [256]u8 = undefined;
        var quoted = try self.quotedEtag(key, etag, &quoted_buf);
        if (quoted == null) {
            const current_etag = try self.head(key) orelse return null;
            if (current_etag != etag) return null;
            quoted = try self.quotedEtag(key, etag, &quoted_buf) orelse return null;
        }
        return self.conditional(key, bytes, .{ .name = "if-match", .value = quoted.? });
    }

    /// the bucket's own etag for `key`, quoted, if the one remembered hashes
    /// to `etag`
    fn quotedEtag(self: *S3Store, key: []const u8, etag: u64, buf: []u8) !?[]const u8 {
        self.mutex.lockUncancelable(self.io);
        defer self.mutex.unlock(self.io);
        const known = self.etags.get(key) orelse return null;
        if (hashEtag(known) != etag) return null;
        return try std.fmt.bufPrint(buf, "\"{s}\"", .{known});
    }

    /// the hashed etag the bucket holds for `key` now, remembered for `cas`
    fn head(self: *S3Store, key: []const u8) !?u64 {
        var res = try self.send(self.gpa, .HEAD, key, null, &.{}, null);
        defer res.deinit(self.gpa);
        switch (res.status) {
            .ok => return try self.remember(key, res.etag orelse return error.MissingEtag),
            .not_found => return null,
            else => return statusError(res.status),
        }
    }

    fn conditional(self: *S3Store, key: []const u8, bytes: []const u8, condition: http.Header) !?u64 {
        var tries: u8 = 0;
        while (true) : (tries += 1) {
            var res = try self.send(self.gpa, .PUT, key, null, &.{condition}, bytes);
            defer res.deinit(self.gpa);
            switch (res.status) {
                .ok => return try self.remember(key, res.etag orelse return error.MissingEtag),
                .precondition_failed, .not_found => return null,
                .conflict => if (tries < self.config.conflict_retries) continue else return error.Unavailable,
                else => return statusError(res.status),
            }
        }
    }

    pub fn list(self: *S3Store, gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
        var names: std.ArrayList([]u8) = .empty;
        errdefer {
            for (names.items) |name| gpa.free(name);
            names.deinit(gpa);
        }
        const full_prefix = try std.mem.concat(gpa, u8, &.{ self.config.prefix, prefix });
        defer gpa.free(full_prefix);
        var token: ?[]u8 = null;
        defer if (token) |t| gpa.free(t);
        while (true) {
            var query: std.ArrayList(u8) = .empty;
            defer query.deinit(gpa);
            // canonical order: parameters sorted by name
            if (token) |t| {
                try query.appendSlice(gpa, "continuation-token=");
                try encode(gpa, &query, t, true);
                try query.append(gpa, '&');
            }
            try query.appendSlice(gpa, "list-type=2&prefix=");
            try encode(gpa, &query, full_prefix, true);
            var res = try self.send(gpa, .GET, "", query.items, &.{}, null);
            defer res.deinit(gpa);
            if (res.status != .ok) return statusError(res.status);
            var it = Tags{ .xml = res.body, .tag = "Key" };
            while (it.next()) |raw| {
                const name = try unescape(gpa, raw);
                errdefer gpa.free(name);
                if (!std.mem.startsWith(u8, name, self.config.prefix)) return error.Corrupt;
                std.mem.copyForwards(u8, name, name[self.config.prefix.len..]);
                try names.append(gpa, try gpa.realloc(name, name.len - self.config.prefix.len));
            }
            var truncated = Tags{ .xml = res.body, .tag = "IsTruncated" };
            const more = if (truncated.next()) |v| std.mem.eql(u8, v, "true") else false;
            if (!more) break;
            var next = Tags{ .xml = res.body, .tag = "NextContinuationToken" };
            const raw = next.next() orelse return error.Corrupt;
            if (token) |t| gpa.free(t);
            token = null;
            token = try unescape(gpa, raw);
        }
        std.mem.sort([]u8, names.items, {}, lessThan);
        return names.toOwnedSlice(gpa);
    }

    pub fn delete(self: *S3Store, key: []const u8) !void {
        var res = try self.send(self.gpa, .DELETE, key, null, &.{}, null);
        defer res.deinit(self.gpa);
        switch (res.status) {
            .ok, .no_content, .not_found => {},
            else => return statusError(res.status),
        }
        self.mutex.lockUncancelable(self.io);
        defer self.mutex.unlock(self.io);
        if (self.etags.fetchRemove(key)) |kv| {
            self.gpa.free(kv.key);
            self.gpa.free(kv.value);
        }
    }

    /// `get` of every key, `config.parallel` at a time
    pub fn getMany(self: *S3Store, gpa: std.mem.Allocator, keys: []const []const u8, out: []?Object) !void {
        const Op = struct {
            fn run(s: *S3Store, a: std.mem.Allocator, key: []const u8, slot: *?Object, err: *?anyerror) void {
                slot.* = s.get(a, key) catch |e| {
                    slot.* = null;
                    err.* = e;
                    return;
                };
            }
        };
        @memset(out, null);
        const failed = try self.fanOut(keys.len, struct {
            s: *S3Store,
            a: std.mem.Allocator,
            keys: []const []const u8,
            out: []?Object,
            fn spawn(c: @This(), g: *Io.Group, i: usize, err: *?anyerror) void {
                g.async(c.s.io, Op.run, .{ c.s, c.a, c.keys[i], &c.out[i], err });
            }
        }{ .s = self, .a = gpa, .keys = keys, .out = out });
        if (failed) |err| {
            for (out) |*o| if (o.*) |obj| {
                gpa.free(obj.bytes);
                o.* = null;
            };
            return err;
        }
    }

    /// `getRange` of every range, `config.parallel` at a time
    pub fn getRangeMany(self: *S3Store, gpa: std.mem.Allocator, ranges: []const store.Range, out: []?[]u8) !void {
        const Op = struct {
            fn run(s: *S3Store, a: std.mem.Allocator, r: store.Range, slot: *?[]u8, err: *?anyerror) void {
                slot.* = s.getRange(a, r.key, r.offset, r.len) catch |e| {
                    slot.* = null;
                    err.* = e;
                    return;
                };
            }
        };
        @memset(out, null);
        const failed = try self.fanOut(ranges.len, struct {
            s: *S3Store,
            a: std.mem.Allocator,
            ranges: []const store.Range,
            out: []?[]u8,
            fn spawn(c: @This(), g: *Io.Group, i: usize, err: *?anyerror) void {
                g.async(c.s.io, Op.run, .{ c.s, c.a, c.ranges[i], &c.out[i], err });
            }
        }{ .s = self, .a = gpa, .ranges = ranges, .out = out });
        if (failed) |err| {
            for (out) |*o| if (o.*) |bytes| {
                gpa.free(bytes);
                o.* = null;
            };
            return err;
        }
    }

    /// `delete` of every key, `config.parallel` at a time
    pub fn deleteMany(self: *S3Store, keys: []const []const u8) !void {
        const Op = struct {
            fn run(s: *S3Store, key: []const u8, err: *?anyerror) void {
                s.delete(key) catch |e| {
                    err.* = e;
                };
            }
        };
        if (try self.fanOut(keys.len, struct {
            s: *S3Store,
            keys: []const []const u8,
            fn spawn(c: @This(), g: *Io.Group, i: usize, err: *?anyerror) void {
                g.async(c.s.io, Op.run, .{ c.s, c.keys[i], err });
            }
        }{ .s = self, .keys = keys })) |err| return err;
    }

    /// run `ctx.spawn` for 0..n in waves of `config.parallel`, each request
    /// with its own error slot, and return the first error any of them hit
    fn fanOut(self: *S3Store, n: usize, ctx: anytype) !?anyerror {
        const wave = @max(@as(usize, self.config.parallel), 1);
        var errs: [256]?anyerror = undefined;
        std.debug.assert(wave <= errs.len);
        var start: usize = 0;
        while (start < n) : (start += wave) {
            const end = @min(n, start + wave);
            @memset(errs[0 .. end - start], null);
            var group: Io.Group = .init;
            for (start..end) |i| ctx.spawn(&group, i, &errs[i - start]);
            try group.await(self.io);
            for (errs[0 .. end - start]) |e| if (e) |err| return err;
        }
        return null;
    }

    /// keep the bucket's etag for `key` (quotes stripped) and return its hash
    fn remember(self: *S3Store, key: []const u8, raw: []const u8) !u64 {
        const bare = std.mem.trim(u8, raw, "\"");
        self.mutex.lockUncancelable(self.io);
        defer self.mutex.unlock(self.io);
        const slot = try self.etags.getOrPut(self.gpa, key);
        if (slot.found_existing) {
            if (std.mem.eql(u8, slot.value_ptr.*, bare)) return hashEtag(bare);
            const copy = try self.gpa.dupe(u8, bare);
            self.gpa.free(slot.value_ptr.*);
            slot.value_ptr.* = copy;
        } else {
            const owned_key = self.gpa.dupe(u8, key) catch |err| {
                self.etags.removeByPtr(slot.key_ptr);
                return err;
            };
            const copy = self.gpa.dupe(u8, bare) catch |err| {
                self.gpa.free(owned_key);
                self.etags.removeByPtr(slot.key_ptr);
                return err;
            };
            slot.key_ptr.* = owned_key;
            slot.value_ptr.* = copy;
        }
        return hashEtag(bare);
    }

    const Response = struct {
        status: http.Status,
        etag: ?[]u8,
        body: []u8,

        fn deinit(self: *Response, gpa: std.mem.Allocator) void {
            if (self.etag) |e| gpa.free(e);
            gpa.free(self.body);
        }
    };

    fn send(
        self: *S3Store,
        gpa: std.mem.Allocator,
        method: http.Method,
        key: []const u8,
        query: ?[]const u8,
        extra: []const http.Header,
        body: ?[]const u8,
    ) !Response {
        // path: /bucket/prefix+key, each segment uri-encoded
        var path: std.ArrayList(u8) = .empty;
        defer path.deinit(gpa);
        try path.append(gpa, '/');
        try encode(gpa, &path, self.config.bucket, true);
        if (key.len > 0 or query == null) {
            try path.append(gpa, '/');
            try encode(gpa, &path, self.config.prefix, false);
            try encode(gpa, &path, key, false);
        }

        var payload_hash: [64]u8 = undefined;
        hexDigest(body orelse "", &payload_hash);

        var date_buf: [16]u8 = undefined;
        const amz_date = self.timestamp(&date_buf);

        const authorization = try self.sign(gpa, method, path.items, query orelse "", &payload_hash, amz_date);
        defer gpa.free(authorization);

        const url = try std.fmt.allocPrint(gpa, "{s}{s}{s}{s}", .{
            std.mem.trimEnd(u8, self.config.endpoint, "/"),
            path.items,
            if (query != null) "?" else "",
            query orelse "",
        });
        defer gpa.free(url);

        var headers: [6]http.Header = undefined;
        headers[0] = .{ .name = "x-amz-date", .value = amz_date };
        headers[1] = .{ .name = "x-amz-content-sha256", .value = &payload_hash };
        var n: usize = 2;
        for (extra) |h| {
            headers[n] = h;
            n += 1;
        }

        var req = try self.client.request(method, try std.Uri.parse(url), .{
            .redirect_behavior = .unhandled,
            .keep_alive = true,
            .headers = .{
                .host = .{ .override = self.host },
                .authorization = .{ .override = authorization },
                .accept_encoding = .omit,
                .user_agent = .{ .override = "zkv" },
            },
            .extra_headers = headers[0..n],
        });
        defer req.deinit();

        if (body) |b| {
            req.transfer_encoding = .{ .content_length = b.len };
            var w = try req.sendBodyUnflushed(&.{});
            try w.writer.writeAll(b);
            try w.end();
            try req.connection.?.flush();
        } else if (method == .PUT) {
            req.transfer_encoding = .{ .content_length = 0 };
            var w = try req.sendBodyUnflushed(&.{});
            try w.end();
            try req.connection.?.flush();
        } else {
            try req.sendBodiless();
        }

        var response = try req.receiveHead(&.{});
        var etag: ?[]u8 = null;
        errdefer if (etag) |e| gpa.free(e);
        var it = response.head.iterateHeaders();
        while (it.next()) |h| {
            if (std.ascii.eqlIgnoreCase(h.name, "etag")) etag = try gpa.dupe(u8, h.value);
        }
        const status = response.head.status;
        var transfer: [64]u8 = undefined;
        // 204, 304 and 1xx end at the head. R2 sends its 204s without a
        // content-length on a kept-alive connection, and std.http would read
        // such a body to the end of the stream (here, or in req.deinit when
        // it discards the rest), waiting for R2 to hang up. mark the
        // response finished so the connection goes back to the pool.
        const bodiless = method == .HEAD or status == .no_content or status == .not_modified or status.class() == .informational;
        if (bodiless) req.reader.state = .ready;
        const out = if (bodiless) try gpa.alloc(u8, 0) else response.reader(&transfer).allocRemaining(gpa, .unlimited) catch |err| switch (err) {
            error.ReadFailed => return response.bodyErr().?,
            else => |e| return e,
        };
        errdefer gpa.free(out);
        if (!bodiless and response.head.transfer_encoding == .none) {
            if (response.head.content_length) |length| {
                if (out.len != length) return error.ResponseTruncated;
            }
        }
        return .{ .status = status, .etag = etag, .body = out };
    }

    fn timestamp(self: *S3Store, buf: *[16]u8) []const u8 {
        const secs: u64 = @intCast(Io.Clock.real.now(self.io).toSeconds());
        const es: std.time.epoch.EpochSeconds = .{ .secs = secs };
        const yd = es.getEpochDay().calculateYearDay();
        const md = yd.calculateMonthDay();
        const ds = es.getDaySeconds();
        return std.fmt.bufPrint(buf, "{d:0>4}{d:0>2}{d:0>2}T{d:0>2}{d:0>2}{d:0>2}Z", .{
            yd.year,              md.month.numeric(),      md.day_index + 1,
            ds.getHoursIntoDay(), ds.getMinutesIntoHour(), ds.getSecondsIntoMinute(),
        }) catch unreachable;
    }

    /// the SigV4 Authorization header for a request signing host,
    /// x-amz-content-sha256 and x-amz-date
    fn sign(
        self: *S3Store,
        gpa: std.mem.Allocator,
        method: http.Method,
        path: []const u8,
        query: []const u8,
        payload_hash: *const [64]u8,
        amz_date: []const u8,
    ) ![]u8 {
        const date = amz_date[0..8];
        const signed_headers = "host;x-amz-content-sha256;x-amz-date";
        const canonical = try std.fmt.allocPrint(gpa, "{s}\n{s}\n{s}\nhost:{s}\nx-amz-content-sha256:{s}\nx-amz-date:{s}\n\n{s}\n{s}", .{
            @tagName(method), path, query, self.host, payload_hash, amz_date, signed_headers, payload_hash,
        });
        defer gpa.free(canonical);
        var canonical_hash: [64]u8 = undefined;
        hexDigest(canonical, &canonical_hash);

        const scope = try std.fmt.allocPrint(gpa, "{s}/{s}/s3/aws4_request", .{ date, self.config.region });
        defer gpa.free(scope);
        const to_sign = try std.fmt.allocPrint(gpa, "AWS4-HMAC-SHA256\n{s}\n{s}\n{s}", .{ amz_date, scope, &canonical_hash });
        defer gpa.free(to_sign);

        const secret = try std.fmt.allocPrint(gpa, "AWS4{s}", .{self.config.secret_access_key});
        defer gpa.free(secret);
        var k: [HmacSha256.mac_length]u8 = undefined;
        HmacSha256.create(&k, date, secret);
        HmacSha256.create(&k, self.config.region, &k);
        HmacSha256.create(&k, "s3", &k);
        HmacSha256.create(&k, "aws4_request", &k);
        var sig: [HmacSha256.mac_length]u8 = undefined;
        HmacSha256.create(&sig, to_sign, &k);

        return std.fmt.allocPrint(gpa, "AWS4-HMAC-SHA256 Credential={s}/{s}, SignedHeaders={s}, Signature={x}", .{
            self.config.access_key_id, scope, signed_headers, &sig,
        });
    }
};

fn hashEtag(etag: []const u8) u64 {
    return std.hash.Wyhash.hash(0x5333, etag);
}

fn hexDigest(bytes: []const u8, out: *[64]u8) void {
    var digest: [Sha256.digest_length]u8 = undefined;
    Sha256.hash(bytes, &digest, .{});
    _ = std.fmt.bufPrint(out, "{x}", .{&digest}) catch unreachable;
}

fn statusError(status: http.Status) anyerror {
    return switch (status) {
        .too_many_requests, .internal_server_error, .bad_gateway, .service_unavailable, .gateway_timeout => error.Unavailable,
        .forbidden, .unauthorized => error.AccessDenied,
        else => error.UnexpectedStatus,
    };
}

/// SigV4 uri encoding: unreserved characters stay, everything else is
/// %XX. a path keeps its slashes; a query value does not.
fn encode(gpa: std.mem.Allocator, out: *std.ArrayList(u8), s: []const u8, slash: bool) !void {
    for (s) |c| {
        const keep = std.ascii.isAlphanumeric(c) or c == '-' or c == '_' or c == '.' or c == '~' or (c == '/' and !slash);
        if (keep) {
            try out.append(gpa, c);
        } else {
            try out.print(gpa, "%{X:0>2}", .{c});
        }
    }
}

/// the text of each `<tag>...</tag>` in a flat S3 response, in order
const Tags = struct {
    xml: []const u8,
    tag: []const u8,
    at: usize = 0,

    fn next(self: *Tags) ?[]const u8 {
        var open_buf: [64]u8 = undefined;
        var close_buf: [64]u8 = undefined;
        const open = std.fmt.bufPrint(&open_buf, "<{s}>", .{self.tag}) catch return null;
        const close = std.fmt.bufPrint(&close_buf, "</{s}>", .{self.tag}) catch return null;
        const start = std.mem.indexOfPos(u8, self.xml, self.at, open) orelse return null;
        const body = start + open.len;
        const end = std.mem.indexOfPos(u8, self.xml, body, close) orelse return null;
        self.at = end + close.len;
        return self.xml[body..end];
    }
};

fn unescape(gpa: std.mem.Allocator, s: []const u8) ![]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(gpa);
    var i: usize = 0;
    while (i < s.len) {
        if (s[i] != '&') {
            try out.append(gpa, s[i]);
            i += 1;
            continue;
        }
        const semi = std.mem.indexOfScalarPos(u8, s, i, ';') orelse return error.Corrupt;
        const entity = s[i + 1 .. semi];
        if (std.mem.eql(u8, entity, "amp")) try out.append(gpa, '&') //
        else if (std.mem.eql(u8, entity, "lt")) try out.append(gpa, '<') //
        else if (std.mem.eql(u8, entity, "gt")) try out.append(gpa, '>') //
        else if (std.mem.eql(u8, entity, "quot")) try out.append(gpa, '"') //
        else if (std.mem.eql(u8, entity, "apos")) try out.append(gpa, '\'') //
        else if (entity.len > 1 and entity[0] == '#') {
            const code = if (entity[1] == 'x')
                try std.fmt.parseInt(u21, entity[2..], 16)
            else
                try std.fmt.parseInt(u21, entity[1..], 10);
            var buf: [4]u8 = undefined;
            const n = try std.unicode.utf8Encode(code, &buf);
            try out.appendSlice(gpa, buf[0..n]);
        } else return error.Corrupt;
        i = semi + 1;
    }
    return out.toOwnedSlice(gpa);
}

fn lessThan(_: void, a: []u8, b: []u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

test "sigv4 matches the AWS example signing key derivation" {
    // https://docs.aws.amazon.com/IAM/latest/UserGuide/reference_sigv-create-signed-request.html
    var k: [HmacSha256.mac_length]u8 = undefined;
    HmacSha256.create(&k, "20150830", "AWS4wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY");
    HmacSha256.create(&k, "us-east-1", &k);
    HmacSha256.create(&k, "iam", &k);
    HmacSha256.create(&k, "aws4_request", &k);
    var hex: [64]u8 = undefined;
    _ = try std.fmt.bufPrint(&hex, "{x}", .{&k});
    try std.testing.expectEqualStrings("c4afb1cc5771d871763a393e44b703571b55cc28424d1a5e86da6ed3c154a4b9", &hex);
}

test "uri encoding keeps unreserved characters and path slashes" {
    const gpa = std.testing.allocator;
    var out: std.ArrayList(u8) = .empty;
    defer out.deinit(gpa);
    try encode(gpa, &out, "log/0001 a+b=c", false);
    try std.testing.expectEqualStrings("log/0001%20a%2Bb%3Dc", out.items);
    out.clearRetainingCapacity();
    try encode(gpa, &out, "log/", true);
    try std.testing.expectEqualStrings("log%2F", out.items);
}

test "list keys are unescaped" {
    const gpa = std.testing.allocator;
    var it = Tags{ .xml = "<A><Key>a&amp;b</Key><Key>c</Key></A>", .tag = "Key" };
    const first = try unescape(gpa, it.next().?);
    defer gpa.free(first);
    try std.testing.expectEqualStrings("a&b", first);
    try std.testing.expectEqualStrings("c", it.next().?);
    try std.testing.expect(it.next() == null);
}

test "S3 rejects truncated bodies and preserves valid response framing" {
    const gpa = std.testing.allocator;
    var threaded: Io.Threaded = .init(gpa, .{});
    defer threaded.deinit();
    const io = threaded.io();
    var listener = try (Io.net.IpAddress{ .ip4 = .loopback(0) }).listen(io, .{ .reuse_address = true });
    defer listener.deinit(io);
    const endpoint = try std.fmt.allocPrint(gpa, "http://127.0.0.1:{d}", .{listener.socket.address.getPort()});
    defer gpa.free(endpoint);
    const responses = [_][]const u8{
        "HTTP/1.1 200 OK\r\nContent-Length: 10\r\nETag: \"x\"\r\nConnection: close\r\n\r\nhalf",
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n5\r\nhalf",
        "HTTP/1.1 200 OK\r\nContent-Length: 4\r\nConnection: close\r\n\r\nfull",
        "HTTP/1.1 200 OK\r\nContent-Length: 100\r\nConnection: close\r\n\r\n",
        "HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n",
        "HTTP/1.1 200 OK\r\nConnection: close\r\n\r\nfull",
        "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n4\r\nfull\r\n0\r\n\r\n",
        "HTTP/1.1 200 OK\r\nContent-Length: 100\r\nConnection: close\r\n\r\n<ListBucketResult><Key>a</Key>",
        "HTTP/1.1 206 Partial Content\r\nContent-Length: 3\r\nConnection: close\r\n\r\nabc",
        "HTTP/1.1 416 Range Not Satisfiable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
        "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n",
    };
    const server = try std.Thread.spawn(.{}, struct {
        fn run(l: *Io.net.Server, i: Io, replies: []const []const u8) !void {
            for (replies) |reply| {
                const conn = try l.accept(i);
                defer conn.close(i);
                var rb: [4096]u8 = undefined;
                var r = conn.reader(i, &rb);
                _ = try r.interface.takeDelimiterInclusive('\n');
                while ((try r.interface.takeDelimiterInclusive('\n')).len > 2) {}
                var wb: [4096]u8 = undefined;
                var w = conn.writer(i, &wb);
                try w.interface.writeAll(reply);
                try w.interface.flush();
            }
        }
    }.run, .{ &listener, io, &responses });
    defer server.join();
    var s3 = try S3Store.init(gpa, io, .{ .endpoint = endpoint, .bucket = "test", .access_key_id = "test", .secret_access_key = "test" });
    defer s3.deinit();
    const short = s3.get(gpa, "x");
    defer if (short) |obj| {
        if (obj) |o| gpa.free(o.bytes);
    } else |_| {};
    var chunked = s3.send(gpa, .GET, "x", null, &.{}, null);
    defer if (chunked) |*res| res.deinit(gpa) else |_| {};
    var full = try s3.send(gpa, .GET, "x", null, &.{}, null);
    defer full.deinit(gpa);
    var head = try s3.send(gpa, .HEAD, "x", null, &.{}, null);
    defer head.deinit(gpa);
    var empty = try s3.send(gpa, .DELETE, "x", null, &.{}, null);
    defer empty.deinit(gpa);
    var closed = try s3.send(gpa, .GET, "x", null, &.{}, null);
    defer closed.deinit(gpa);
    var complete_chunked = try s3.send(gpa, .GET, "x", null, &.{}, null);
    defer complete_chunked.deinit(gpa);
    const listing = s3.list(gpa, "");
    defer if (listing) |names| store.freeNames(gpa, names) else |_| {};
    const short_range = s3.getRange(gpa, "x", 0, 4);
    defer if (short_range) |bytes| {
        if (bytes) |b| gpa.free(b);
    } else |_| {};
    const refused_range = s3.getRange(gpa, "x", 0, 4);
    defer if (refused_range) |bytes| {
        if (bytes) |b| gpa.free(b);
    } else |_| {};
    const missing_range = try s3.getRange(gpa, "missing", 0, 4);
    defer if (missing_range) |bytes| gpa.free(bytes);
    try std.testing.expectError(error.OutOfRange, short_range);
    try std.testing.expectError(error.OutOfRange, refused_range);
    try std.testing.expect(missing_range == null);
    try std.testing.expectError(error.OutOfRange, s3.getRange(gpa, "x", std.math.maxInt(u64), 2));
    try std.testing.expectError(error.ResponseTruncated, short);
    try std.testing.expectError(error.HttpChunkTruncated, chunked);
    try std.testing.expectEqualStrings("full", full.body);
    try std.testing.expectEqualStrings("", head.body);
    try std.testing.expectEqualStrings("", empty.body);
    try std.testing.expectEqualStrings("full", closed.body);
    try std.testing.expectEqualStrings("full", complete_chunked.body);
    try std.testing.expectError(error.ResponseTruncated, listing);
}

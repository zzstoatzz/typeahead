const std = @import("std");
const Object = @import("../store.zig").Object;

const Io = std.Io;

pub const DirStore = DirStoreWithHandles(8);

pub fn DirStoreWithHandles(comptime open_handles: usize) type {
    if (open_handles == 0) @compileError("at least one read handle is required");
    return struct {
        const Self = @This();
        gpa: std.mem.Allocator,
        io: Io,
        dir: Io.Dir,
        nonce: u64,
        counter: u64 = 0,
        handles: [open_handles]?Handle = @splat(null),
        clock: u64 = 0,

        const Handle = struct { name: [64]u8, len: usize, file: Io.File, used: u64 };

        pub fn deinit(self: *Self) void {
            for (&self.handles) |*slot| if (slot.*) |h| {
                h.file.close(self.io);
                slot.* = null;
            };
        }

        pub fn init(gpa: std.mem.Allocator, io: Io, dir: Io.Dir) Self {
            var nonce: u64 = undefined;
            io.random(std.mem.asBytes(&nonce));
            return .{ .gpa = gpa, .io = io, .dir = dir, .nonce = nonce };
        }

        pub fn get(self: *Self, gpa: std.mem.Allocator, key: []const u8) !?Object {
            const bytes = self.dir.readFileAlloc(self.io, key, gpa, .unlimited) catch |err| switch (err) {
                error.FileNotFound => return null,
                else => return err,
            };
            return .{ .bytes = bytes, .etag = etagOf(bytes) };
        }

        pub fn getRange(self: *Self, gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
            const file = try self.reader(key) orelse return null;
            const out = try gpa.alloc(u8, len);
            errdefer gpa.free(out);
            if (try file.readPositionalAll(self.io, out, offset) != len) return error.OutOfRange;
            return out;
        }

        pub fn getRangeInto(self: *Self, _: std.mem.Allocator, key: []const u8, offset: u64, out: []u8) !bool {
            const file = try self.reader(key) orelse return false;
            if (try file.readPositionalAll(self.io, out, offset) != out.len) return error.OutOfRange;
            return true;
        }

        /// an open handle for ranged reads of `key`, kept for the next one. a
        /// ranged read is of a table, written once and never changed.
        fn reader(self: *Self, key: []const u8) !?Io.File {
            self.clock += 1;
            var oldest: usize = 0;
            for (&self.handles, 0..) |*slot, i| {
                const h = &(slot.* orelse {
                    oldest = i;
                    continue;
                });
                if (std.mem.eql(u8, h.name[0..h.len], key)) {
                    h.used = self.clock;
                    return h.file;
                }
                if (self.handles[oldest]) |o| if (h.used < o.used) {
                    oldest = i;
                };
            }
            if (key.len > 64) return error.NameTooLong;
            const file = self.dir.openFile(self.io, key, .{}) catch |err| switch (err) {
                error.FileNotFound => return null,
                else => return err,
            };
            if (self.handles[oldest]) |o| o.file.close(self.io);
            var h: Handle = .{ .name = undefined, .len = key.len, .file = file, .used = self.clock };
            @memcpy(h.name[0..key.len], key);
            self.handles[oldest] = h;
            return file;
        }

        fn forget(self: *Self, key: []const u8) void {
            for (&self.handles) |*slot| if (slot.*) |h| if (std.mem.eql(u8, h.name[0..h.len], key)) {
                h.file.close(self.io);
                slot.* = null;
            };
        }

        pub fn put(self: *Self, key: []const u8, bytes: []const u8) !void {
            self.forget(key);
            var temp: TempName = undefined;
            const name = try self.stage(&temp, key, bytes);
            errdefer self.dir.deleteFile(self.io, name) catch {};
            try self.dir.rename(name, self.dir, key, self.io);
            try self.syncParent(key);
        }

        /// the name is published before the bytes are synced, so the inode,
        /// its data and the directory entry land in one journal transaction
        /// instead of two; the exclusive rename is the fence. on a journaled
        /// filesystem that orders data before metadata (ext4's default) a
        /// crash leaves the name absent or whole. elsewhere the last object
        /// can be torn, which `SegmentLog.recover` treats as not landed.
        pub fn putIfAbsent(self: *Self, key: []const u8, bytes: []const u8) !?u64 {
            var temp: TempName = undefined;
            const staged = try self.stageOpen(&temp, key, bytes);
            self.dir.renamePreserve(staged.name, self.dir, key, self.io) catch |err| {
                staged.file.close(self.io);
                self.dir.deleteFile(self.io, staged.name) catch {};
                return if (err == error.PathAlreadyExists) null else err;
            };
            staged.file.sync(self.io) catch |err| {
                staged.file.close(self.io);
                self.dir.deleteFile(self.io, key) catch {};
                return err;
            };
            staged.file.close(self.io);
            try self.syncParent(key);
            return etagOf(bytes);
        }

        pub fn cas(self: *Self, key: []const u8, bytes: []const u8, etag: u64) !?u64 {
            var lock_name: [Io.Dir.max_path_bytes]u8 = undefined;
            const lock_path = try std.fmt.bufPrint(&lock_name, "{s}.lock", .{key});
            const lock = try self.dir.createFile(self.io, lock_path, .{ .truncate = false, .lock = .exclusive });
            defer lock.close(self.io);
            const current = try self.get(self.gpa, key) orelse return null;
            self.gpa.free(current.bytes);
            if (current.etag != etag) return null;
            try self.put(key, bytes);
            return etagOf(bytes);
        }

        pub fn list(self: *Self, gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
            const slash = std.mem.lastIndexOfScalar(u8, prefix, '/');
            const parent = if (slash) |s| prefix[0..s] else ".";
            const stem = if (slash) |s| prefix[s + 1 ..] else prefix;
            var names: std.ArrayList([]u8) = .empty;
            errdefer {
                for (names.items) |name| gpa.free(name);
                names.deinit(gpa);
            }
            var sub = self.dir.openDir(self.io, parent, .{ .iterate = true }) catch |err| switch (err) {
                error.FileNotFound => return names.toOwnedSlice(gpa),
                else => return err,
            };
            defer sub.close(self.io);
            var it = sub.iterate();
            while (try it.next(self.io)) |found| {
                if (found.kind != .file or !std.mem.startsWith(u8, found.name, stem)) continue;
                if (std.mem.indexOfScalar(u8, found.name, '.') != null) continue;
                try names.ensureUnusedCapacity(gpa, 1);
                names.appendAssumeCapacity(try std.mem.concat(gpa, u8, &.{ prefix[0 .. prefix.len - stem.len], found.name }));
            }
            std.mem.sort([]u8, names.items, {}, lessThan);
            return names.toOwnedSlice(gpa);
        }

        pub fn delete(self: *Self, key: []const u8) !void {
            self.forget(key);
            self.dir.deleteFile(self.io, key) catch |err| switch (err) {
                error.FileNotFound => return,
                else => return err,
            };
        }

        const TempName = [Io.Dir.max_path_bytes]u8;

        fn stage(self: *Self, buf: *TempName, key: []const u8, bytes: []const u8) ![]const u8 {
            const staged = try self.stageOpen(buf, key, bytes);
            defer staged.file.close(self.io);
            errdefer self.dir.deleteFile(self.io, staged.name) catch {};
            try staged.file.sync(self.io);
            return staged.name;
        }

        const Staged = struct { name: []const u8, file: Io.File };

        /// a temporary beside `key` holding `bytes`, written but not synced,
        /// with its handle still open for the caller to sync.
        fn stageOpen(self: *Self, buf: *TempName, key: []const u8, bytes: []const u8) !Staged {
            if (std.fs.path.dirname(key)) |parent| try self.dir.createDirPath(self.io, parent);
            self.counter += 1;
            const name = try std.fmt.bufPrint(buf, "{s}.{x}-{x}.tmp", .{ key, self.nonce, self.counter });
            const file = try self.dir.createFile(self.io, name, .{ .exclusive = true });
            errdefer file.close(self.io);
            errdefer self.dir.deleteFile(self.io, name) catch {};
            try file.writeStreamingAll(self.io, bytes);
            return .{ .name = name, .file = file };
        }

        fn syncParent(self: *Self, key: []const u8) !void {
            const parent = try self.dir.openFile(self.io, std.fs.path.dirname(key) orelse ".", .{});
            defer parent.close(self.io);
            try parent.sync(self.io);
        }
    };
}

fn etagOf(bytes: []const u8) u64 {
    return std.hash.Wyhash.hash(0, bytes);
}

fn lessThan(_: void, a: []u8, b: []u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

test "bounded directory handles evict and invalidate replaced files" {
    const t = std.testing;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var store = DirStoreWithHandles(2).init(t.allocator, t.io, dir.dir);
    defer store.deinit();
    for ([_][]const u8{ "a", "b", "c" }) |name| {
        try store.put(name, name);
        const bytes = (try store.getRange(t.allocator, name, 0, 1)).?;
        defer t.allocator.free(bytes);
        try t.expectEqualStrings(name, bytes);
    }
    try t.expectEqual(@as(usize, 2), store.handles.len);
    for (store.handles) |slot| try t.expect(!std.mem.eql(u8, slot.?.name[0..slot.?.len], "a"));
    try store.put("c", "x");
    const replacement = (try store.getRange(t.allocator, "c", 0, 1)).?;
    defer t.allocator.free(replacement);
    try t.expectEqualStrings("x", replacement);
    try store.delete("c");
    try t.expect(try store.getRange(t.allocator, "c", 0, 1) == null);
    store.deinit();
    for (store.handles) |slot| try t.expect(slot == null);
}

test "an if-absent publication leaves no temporary and lists once" {
    const t = std.testing;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var store = DirStore.init(t.allocator, t.io, dir.dir);
    defer store.deinit();
    try t.expect(try store.putIfAbsent("log/00000001", "segment") != null);
    try t.expect(try store.putIfAbsent("log/00000001", "again") == null);
    var it = (try dir.dir.openDir(t.io, "log", .{ .iterate = true })).iterate();
    var entries: usize = 0;
    while (try it.next(t.io)) |entry| {
        entries += 1;
        try t.expectEqualStrings("00000001", entry.name);
    }
    try t.expectEqual(@as(usize, 1), entries);
    const object = (try store.get(t.allocator, "log/00000001")).?;
    defer t.allocator.free(object.bytes);
    try t.expectEqualStrings("segment", object.bytes);
}

test "caller-owned range reads report absent and truncated files" {
    const t = std.testing;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var store = DirStore.init(t.allocator, t.io, dir.dir);
    defer store.deinit();
    try store.put("range", "abcdef");
    var bytes: [3]u8 = undefined;
    try t.expect(try store.getRangeInto(t.allocator, "range", 2, &bytes));
    try t.expectEqualStrings("cde", &bytes);
    try t.expect(!try store.getRangeInto(t.allocator, "absent", 0, &bytes));
    try t.expectError(error.OutOfRange, store.getRangeInto(t.allocator, "range", 5, &bytes));
}

test "conditional directory writes preserve bytes on conflict and invalidate replaced handles" {
    const t = std.testing;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var store = DirStore.init(t.allocator, t.io, dir.dir);
    defer store.deinit();
    try t.expect(try store.cas("object", "missing", 0) == null);
    const first = (try store.putIfAbsent("object", "original")).?;
    var bytes: [8]u8 = undefined;
    try t.expect(try store.getRangeInto(t.allocator, "object", 0, &bytes));
    try t.expectEqualStrings("original", &bytes);
    try t.expect(try store.putIfAbsent("object", "conflict") == null);
    const second = (try store.cas("object", "replaced", first)).?;
    try t.expect(first != second);
    try t.expect(try store.cas("object", "stale!!!", first) == null);
    try t.expect(try store.getRangeInto(t.allocator, "object", 0, &bytes));
    try t.expectEqualStrings("replaced", &bytes);
    const object = (try store.get(t.allocator, "object")).?;
    defer t.allocator.free(object.bytes);
    try t.expectEqual(second, object.etag);
    try t.expectEqualStrings("replaced", object.bytes);
}

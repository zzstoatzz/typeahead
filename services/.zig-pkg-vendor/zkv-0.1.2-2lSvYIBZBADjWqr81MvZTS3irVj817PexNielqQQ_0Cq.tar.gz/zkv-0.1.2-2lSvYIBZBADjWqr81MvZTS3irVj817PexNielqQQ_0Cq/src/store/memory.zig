const std = @import("std");
const Object = @import("../store.zig").Object;

pub const MemoryStore = struct {
    gpa: std.mem.Allocator,
    objects: std.StringHashMapUnmanaged(Stored) = .empty,
    clock: u64 = 0,

    const Stored = struct { bytes: []u8, etag: u64 };

    pub fn init(gpa: std.mem.Allocator) MemoryStore {
        return .{ .gpa = gpa };
    }

    pub fn deinit(self: *MemoryStore) void {
        var it = self.objects.iterator();
        while (it.next()) |kv| {
            self.gpa.free(kv.key_ptr.*);
            self.gpa.free(kv.value_ptr.bytes);
        }
        self.objects.deinit(self.gpa);
    }

    pub fn get(self: *MemoryStore, gpa: std.mem.Allocator, key: []const u8) !?Object {
        const stored = self.objects.get(key) orelse return null;
        return .{ .bytes = try gpa.dupe(u8, stored.bytes), .etag = stored.etag };
    }

    pub fn getRange(self: *MemoryStore, gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
        const stored = self.objects.get(key) orelse return null;
        if (offset > stored.bytes.len or len > stored.bytes.len - offset) return error.OutOfRange;
        return try gpa.dupe(u8, stored.bytes[offset..][0..len]);
    }

    pub fn getRangeInto(self: *MemoryStore, _: std.mem.Allocator, key: []const u8, offset: u64, out: []u8) !bool {
        const stored = self.objects.get(key) orelse return false;
        if (offset > stored.bytes.len or out.len > stored.bytes.len - offset) return error.OutOfRange;
        @memcpy(out, stored.bytes[offset..][0..out.len]);
        return true;
    }

    pub fn put(self: *MemoryStore, key: []const u8, bytes: []const u8) !void {
        _ = try self.store(key, bytes);
    }

    pub fn putIfAbsent(self: *MemoryStore, key: []const u8, bytes: []const u8) !?u64 {
        if (self.objects.contains(key)) return null;
        return try self.store(key, bytes);
    }

    pub fn cas(self: *MemoryStore, key: []const u8, bytes: []const u8, etag: u64) !?u64 {
        const stored = self.objects.get(key) orelse return null;
        if (stored.etag != etag) return null;
        return try self.store(key, bytes);
    }

    pub fn list(self: *MemoryStore, gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
        var names: std.ArrayList([]u8) = .empty;
        errdefer {
            for (names.items) |name| gpa.free(name);
            names.deinit(gpa);
        }
        var it = self.objects.keyIterator();
        while (it.next()) |key| {
            if (!std.mem.startsWith(u8, key.*, prefix)) continue;
            try names.ensureUnusedCapacity(gpa, 1);
            names.appendAssumeCapacity(try gpa.dupe(u8, key.*));
        }
        std.mem.sort([]u8, names.items, {}, lessThan);
        return names.toOwnedSlice(gpa);
    }

    pub fn delete(self: *MemoryStore, key: []const u8) !void {
        const removed = self.objects.fetchRemove(key) orelse return;
        self.gpa.free(removed.key);
        self.gpa.free(removed.value.bytes);
    }

    fn store(self: *MemoryStore, key: []const u8, bytes: []const u8) !u64 {
        const copy = try self.gpa.dupe(u8, bytes);
        errdefer self.gpa.free(copy);
        const slot = try self.objects.getOrPut(self.gpa, key);
        if (slot.found_existing) {
            self.gpa.free(slot.value_ptr.bytes);
        } else {
            slot.key_ptr.* = self.gpa.dupe(u8, key) catch |err| {
                self.objects.removeByPtr(slot.key_ptr);
                return err;
            };
        }
        self.clock += 1;
        slot.value_ptr.* = .{ .bytes = copy, .etag = self.clock };
        return self.clock;
    }
};

fn lessThan(_: void, a: []u8, b: []u8) bool {
    return std.mem.order(u8, a, b) == .lt;
}

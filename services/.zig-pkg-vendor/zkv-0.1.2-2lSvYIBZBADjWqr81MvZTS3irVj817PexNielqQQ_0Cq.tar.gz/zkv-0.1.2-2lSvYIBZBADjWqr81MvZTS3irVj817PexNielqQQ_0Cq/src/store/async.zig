const std = @import("std");
const store = @import("../store.zig");

/// Single serialized owner. Base and Writer must support independent access;
/// use separate backend instances when they contain mutable per-request state.
/// Keep this wrapper at a stable address from putPoll launch through completion
/// consumption or cancellation. All borrowed backends must outlive the wrapper.
pub fn AsyncStore(comptime Base: type, comptime Writer: type) type {
    return struct {
        const Self = @This();
        pub const Notify = struct { context: *anyopaque, call: *const fn (*anyopaque) void };
        io: std.Io,
        base: *Base,
        writer: *Writer,
        notify: ?Notify = null,
        pending: ?Pending = null,

        const Pending = struct {
            io: std.Io,
            writer: *Writer,
            notify: ?Notify,
            key: [64]u8 = undefined,
            key_len: usize,
            bytes: []const u8,
            done: std.Io.Event = .unset,
            future: ?std.Io.Future(anyerror!void) = null,

            fn run(self: *Pending) anyerror!void {
                defer {
                    self.done.set(self.io);
                    if (self.notify) |notify| notify.call(notify.context);
                }
                try self.writer.put(self.key[0..self.key_len], self.bytes);
            }
        };

        pub fn init(io: std.Io, base: *Base, writer: *Writer) Self {
            if (Base == Writer) std.debug.assert(base != writer);
            return .{ .io = io, .base = base, .writer = writer };
        }

        pub fn deinit(self: *Self) void {
            self.cancelPut();
        }

        /// Copies the key and borrows immutable bytes until true/error or cancelPut.
        /// false means pending; repeat with the same key and exact bytes slice.
        /// The captured notify context must stay alive through joining the task.
        pub fn putPoll(self: *Self, key: []const u8, bytes: []const u8) !bool {
            if (self.pending) |*pending| {
                if (!std.mem.eql(u8, key, pending.key[0..pending.key_len]) or bytes.ptr != pending.bytes.ptr or bytes.len != pending.bytes.len) return error.WriteInProgress;
                if (!pending.done.isSet()) return false;
                const outcome = pending.future.?.await(self.io);
                self.pending = null;
                try outcome;
                return true;
            }
            if (key.len > 64) return error.NameTooLong;
            self.pending = .{ .io = self.io, .writer = self.writer, .notify = self.notify, .key_len = key.len, .bytes = bytes };
            const pending = &self.pending.?;
            @memcpy(pending.key[0..key.len], key);
            pending.future = self.io.concurrent(Pending.run, .{pending}) catch |err| {
                self.pending = null;
                return err;
            };
            return false;
        }

        /// Join without consuming completion; putPoll still returns its outcome.
        /// Ignoring the await error here preserves that outcome for the owner.
        pub fn waitPut(self: *Self) void {
            if (self.pending) |*pending| if (pending.future) |*future| future.await(self.io) catch {};
        }

        /// Join/cancel before releasing bytes. Discard completion: cancellation
        /// does not roll back a write that already landed, nor publish its output.
        pub fn cancelPut(self: *Self) void {
            if (self.pending) |*pending| if (pending.future) |*future| {
                future.cancel(self.io) catch {};
            };
            self.pending = null;
        }

        pub fn get(self: *Self, gpa: std.mem.Allocator, key: []const u8) !?store.Object {
            return self.base.get(gpa, key);
        }
        pub fn getRange(self: *Self, gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
            return self.base.getRange(gpa, key, offset, len);
        }

        pub fn getRangeInto(self: *Self, gpa: std.mem.Allocator, key: []const u8, offset: u64, out: []u8) !bool {
            return store.getRangeInto(self.base, gpa, key, offset, out);
        }
        pub fn put(self: *Self, key: []const u8, bytes: []const u8) !void {
            return self.base.put(key, bytes);
        }
        pub fn putIfAbsent(self: *Self, key: []const u8, bytes: []const u8) !?u64 {
            return self.base.putIfAbsent(key, bytes);
        }
        pub fn cas(self: *Self, key: []const u8, bytes: []const u8, etag: u64) !?u64 {
            return self.base.cas(key, bytes, etag);
        }
        pub fn list(self: *Self, gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
            return self.base.list(gpa, prefix);
        }
        pub fn delete(self: *Self, key: []const u8) !void {
            return self.base.delete(key);
        }
        pub fn getMany(self: *Self, gpa: std.mem.Allocator, keys: []const []const u8, out: []?store.Object) !void {
            return store.getMany(self.base, gpa, keys, out);
        }
        pub fn getRangeMany(self: *Self, gpa: std.mem.Allocator, ranges: []const store.Range, out: []?[]u8) !void {
            return store.getRangeMany(self.base, gpa, ranges, out);
        }
        pub fn deleteMany(self: *Self, keys: []const []const u8) !void {
            return store.deleteMany(self.base, keys);
        }
    };
}

const GatedWriter = struct {
    inner: *@import("dir.zig").DirStore,
    io: std.Io,
    entered: std.Io.Event = .unset,
    release: std.Io.Event = .unset,
    fail: bool = false,

    pub fn put(self: *GatedWriter, key: []const u8, bytes: []const u8) !void {
        self.entered.set(self.io);
        try self.release.wait(self.io);
        if (self.fail) return error.InjectedWriteFailure;
        try self.inner.put(key, bytes);
    }
};

test "pending durable output permits commits and flushes without premature publication" {
    const t = std.testing;
    const DirStore = @import("dir.zig").DirStore;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    var base = DirStore.init(t.allocator, t.io, dir.dir);
    defer base.deinit();
    var writer = DirStore.init(t.allocator, t.io, dir.dir);
    defer writer.deinit();
    var gated: GatedWriter = .{ .inner = &writer, .io = t.io };
    var backing = AsyncStore(DirStore, GatedWriter).init(t.io, &base, &gated);
    defer backing.deinit();
    const Db = @import("../db.zig").Db(@TypeOf(backing));
    const db = try Db.open(t.allocator, &backing, .{ .l0_tables = 1, .table_bytes = 1 << 20 });
    defer db.close();
    try db.put("a", "old");
    try db.put("z", "old");
    try db.commit();
    try db.flush();
    const etag = db.etag;
    while (try db.compactPoll(64) != .waiting) {}
    gated.entered.waitUncancelable(t.io);
    try t.expectEqual(etag, db.etag);
    try t.expect(try db.compactPoll(64) == .waiting);
    try db.put("a", "new");
    try db.put("zz", "latest");
    try db.commit();
    try db.flush();
    const applied = db.version.applied;
    const fresh = db.version.tables[0][0].id;
    try db.collect();
    gated.release.set(t.io);
    backing.waitPut();
    while (db.compaction != null) _ = try db.compactPoll(64);
    try t.expectEqual(applied, db.version.applied);
    try t.expectEqual(fresh, db.version.tables[0][0].id);
    try t.expectEqualStrings("new", (try db.get("a")).?);
    try t.expectEqualStrings("old", (try db.get("z")).?);
    try t.expectEqualStrings("latest", (try db.get("zz")).?);
    const reader = try Db.openReader(t.allocator, &backing, .{});
    defer reader.close();
    try t.expectEqualStrings("new", (try reader.get("a")).?);
}

test "cancel and close join a blocked output before freeing its buffer" {
    const t = std.testing;
    const DirStore = @import("dir.zig").DirStore;
    for ([_]bool{ false, true }) |close| {
        var dir = t.tmpDir(.{});
        defer dir.cleanup();
        var base = DirStore.init(t.allocator, t.io, dir.dir);
        defer base.deinit();
        var writer = DirStore.init(t.allocator, t.io, dir.dir);
        defer writer.deinit();
        var gated: GatedWriter = .{ .inner = &writer, .io = t.io };
        var backing = AsyncStore(DirStore, GatedWriter).init(t.io, &base, &gated);
        defer backing.deinit();
        const Db = @import("../db.zig").Db(@TypeOf(backing));
        const db = try Db.open(t.allocator, &backing, .{ .l0_tables = 1 });
        var opened = true;
        defer if (opened) db.close();
        try db.put("a", "old");
        try db.commit();
        try db.flush();
        while (try db.compactPoll(64) != .waiting) {}
        gated.entered.waitUncancelable(t.io);
        if (close) {
            db.close();
            opened = false;
        } else {
            try db.cancelCompaction();
            try db.collect();
            try t.expectEqualStrings("old", (try db.get("a")).?);
        }
        try t.expect(backing.pending == null);
        const reader = try Db.openReader(t.allocator, &backing, .{});
        defer reader.close();
        try t.expectEqualStrings("old", (try reader.get("a")).?);
    }
}

test "pending output propagates errors, refuses inline fallback and writes once" {
    const t = std.testing;
    const DirStore = @import("dir.zig").DirStore;
    const Mode = enum { failed, unavailable, blocking };
    for ([_]Mode{ .failed, .unavailable, .blocking }) |mode| {
        var threaded = std.Io.Threaded.init(t.allocator, .{ .concurrent_limit = if (mode == .unavailable) .nothing else .unlimited });
        defer threaded.deinit();
        const io = threaded.io();
        var dir = t.tmpDir(.{});
        defer dir.cleanup();
        var base = DirStore.init(t.allocator, io, dir.dir);
        defer base.deinit();
        var writer = DirStore.init(t.allocator, io, dir.dir);
        defer writer.deinit();
        var gated: GatedWriter = .{ .inner = &writer, .io = io, .fail = mode == .failed };
        gated.release.set(io);
        var backing = AsyncStore(DirStore, GatedWriter).init(io, &base, &gated);
        defer backing.deinit();
        const Db = @import("../db.zig").Db(@TypeOf(backing));
        const db = try Db.open(t.allocator, &backing, .{ .l0_tables = 1 });
        defer db.close();
        try db.put("a", "old");
        try db.commit();
        try db.flush();
        const etag = db.etag;
        var failure: ?anyerror = null;
        while (true) {
            const progress = db.compactPoll(64) catch |err| {
                failure = err;
                break;
            };
            try t.expect(progress != .idle);
            if (progress == .waiting) break;
        }
        if (mode == .unavailable) {
            try t.expectEqual(error.ConcurrencyUnavailable, failure.?);
            try t.expect(!gated.entered.isSet());
        } else {
            try t.expect(failure == null);
            if (mode == .failed) {
                backing.waitPut();
                try t.expectError(error.InjectedWriteFailure, db.compactPoll(64));
            } else {
                try t.expect(try db.compactStep(64));
                try t.expect(try db.compact());
                try t.expectEqual(@as(u64, 1), writer.counter);
            }
        }
        try t.expect(backing.pending == null);
        try t.expect(db.compaction == null);
        if (mode != .blocking) try t.expectEqual(etag, db.etag);
        try db.collect();
        try t.expectEqualStrings("old", (try db.get("a")).?);
    }
}

test "pending write rejects replacement buffers and consumes a joined error before retry" {
    const t = std.testing;
    var dir = t.tmpDir(.{});
    defer dir.cleanup();
    const DirStore = @import("dir.zig").DirStore;
    var base = DirStore.init(t.allocator, t.io, dir.dir);
    defer base.deinit();
    var writer = DirStore.init(t.allocator, t.io, dir.dir);
    defer writer.deinit();
    var gated: GatedWriter = .{ .inner = &writer, .io = t.io, .fail = true };
    var backing = AsyncStore(DirStore, GatedWriter).init(t.io, &base, &gated);
    defer backing.deinit();
    const bytes = try t.allocator.dupe(u8, "value");
    defer t.allocator.free(bytes);
    const replacement = try t.allocator.dupe(u8, bytes);
    defer t.allocator.free(replacement);
    try t.expect(!try backing.putPoll("output", bytes));
    gated.entered.waitUncancelable(t.io);
    try t.expectError(error.WriteInProgress, backing.putPoll("output", replacement));
    try t.expectError(error.WriteInProgress, backing.putPoll("another", bytes));
    gated.release.set(t.io);
    backing.waitPut();
    try t.expectError(error.InjectedWriteFailure, backing.putPoll("output", bytes));
    try t.expect(backing.pending == null);
    try t.expect(try base.get(t.allocator, "output") == null);
    gated.fail = false;
    try t.expect(!try backing.putPoll("output", bytes));
    backing.waitPut();
    try t.expect(try backing.putPoll("output", bytes));
    const object = (try base.get(t.allocator, "output")).?;
    defer t.allocator.free(object.bytes);
    try t.expectEqualStrings("value", object.bytes);
    try t.expectEqual(@as(u64, 1), writer.counter);
    backing.cancelPut();
    try t.expect(backing.pending == null);
}

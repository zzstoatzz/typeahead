const std = @import("std");

pub const Object = struct {
    bytes: []u8,
    etag: u64,
};

pub fn freeNames(gpa: std.mem.Allocator, names: [][]u8) void {
    for (names) |name| gpa.free(name);
    gpa.free(names);
}

/// a ranged read, for `getRangeMany`
pub const Range = struct {
    key: []const u8,
    offset: u64,
    len: u64,
};

/// `get` of every key into `out`, at once when the store can (a store with
/// its own `getMany`, like S3Store), else one after another in order. on
/// error nothing is left in `out` to free.
pub fn getMany(store: anytype, gpa: std.mem.Allocator, keys: []const []const u8, out: []?Object) !void {
    std.debug.assert(keys.len == out.len);
    if (@hasDecl(@TypeOf(store.*), "getMany")) return store.getMany(gpa, keys, out);
    for (keys, out, 0..) |key, *slot, i| {
        slot.* = store.get(gpa, key) catch |err| {
            for (out[0..i]) |o| if (o) |obj| gpa.free(obj.bytes);
            return err;
        };
    }
}

pub fn getUntilMissing(store: anytype, gpa: std.mem.Allocator, keys: []const []const u8, out: []?Object) !usize {
    std.debug.assert(keys.len == out.len);
    if (@hasDecl(@TypeOf(store.*), "getMany")) {
        try store.getMany(gpa, keys, out);
        return keys.len;
    }
    var initialized: usize = 0;
    errdefer for (out[0..initialized]) |o| if (o) |obj| gpa.free(obj.bytes);
    for (keys, out) |key, *slot| {
        slot.* = try store.get(gpa, key);
        initialized += 1;
        if (slot.* == null) break;
    }
    return initialized;
}

/// `getRange` of every range into `out`, at once when the store can
pub fn getRangeMany(store: anytype, gpa: std.mem.Allocator, ranges: []const Range, out: []?[]u8) !void {
    std.debug.assert(ranges.len == out.len);
    if (@hasDecl(@TypeOf(store.*), "getRangeMany")) return store.getRangeMany(gpa, ranges, out);
    for (ranges, out, 0..) |r, *slot, i| {
        slot.* = store.getRange(gpa, r.key, r.offset, r.len) catch |err| {
            for (out[0..i]) |o| if (o) |bytes| gpa.free(bytes);
            return err;
        };
    }
}

/// `delete` of every key, at once when the store can
pub fn deleteMany(store: anytype, keys: []const []const u8) !void {
    if (@hasDecl(@TypeOf(store.*), "deleteMany")) return store.deleteMany(keys);
    for (keys) |key| try store.delete(key);
}

const PrefixStore = struct {
    calls: usize = 0,

    pub fn get(self: *@This(), gpa: std.mem.Allocator, key: []const u8) !?Object {
        self.calls += 1;
        if (std.mem.eql(u8, key, "missing")) return null;
        if (std.mem.eql(u8, key, "failure")) return error.InjectedReadFailure;
        return .{ .bytes = try gpa.dupe(u8, key), .etag = 1 };
    }
};

test "serial log windows stop at a missing segment and release prior reads on failure" {
    const t = std.testing;
    var backing: PrefixStore = .{};
    var out: [4]?Object = undefined;
    const initialized = try getUntilMissing(&backing, t.allocator, &.{ "a", "b", "missing", "failure" }, &out);
    defer for (out[0..initialized]) |o| if (o) |obj| t.allocator.free(obj.bytes);
    try t.expectEqual(@as(usize, 3), backing.calls);
    try t.expectEqualStrings("a", out[0].?.bytes);
    try t.expectEqualStrings("b", out[1].?.bytes);
    try t.expect(out[2] == null);
    var failed: [3]?Object = undefined;
    try t.expectError(error.InjectedReadFailure, getUntilMissing(&backing, t.allocator, &.{ "a", "b", "failure" }, &failed));
}

test "log windows preserve a store's batch operation" {
    const BatchStore = struct {
        calls: usize = 0,
        pub fn getMany(self: *@This(), _: std.mem.Allocator, keys: []const []const u8, out: []?Object) !void {
            try std.testing.expectEqual(@as(usize, 4), keys.len);
            self.calls += 1;
            @memset(out, null);
        }
    };
    var backing: BatchStore = .{};
    var out: [4]?Object = undefined;
    try std.testing.expectEqual(@as(usize, 4), try getUntilMissing(&backing, std.testing.allocator, &.{ "a", "b", "c", "d" }, &out));
    try std.testing.expectEqual(@as(usize, 1), backing.calls);
    for (out) |o| try std.testing.expect(o == null);
}

pub fn getRangeInto(store: anytype, gpa: std.mem.Allocator, key: []const u8, offset: u64, out: []u8) !bool {
    if (comptime @hasDecl(@TypeOf(store.*), "getRangeInto")) return store.getRangeInto(gpa, key, offset, out);
    const bytes = try store.getRange(gpa, key, offset, out.len) orelse return false;
    defer gpa.free(bytes);
    if (bytes.len != out.len) return error.OutOfRange;
    @memcpy(out, bytes);
    return true;
}

test "caller-owned range helper preserves stores without the optional method" {
    const t = std.testing;
    const Legacy = struct {
        inner: @import("store/memory.zig").MemoryStore,
        pub fn getRange(self: *@This(), gpa: std.mem.Allocator, key: []const u8, offset: u64, len: u64) !?[]u8 {
            return self.inner.getRange(gpa, key, offset, len);
        }
    };
    var legacy: Legacy = .{ .inner = .init(t.allocator) };
    defer legacy.inner.deinit();
    try legacy.inner.put("key", "abcdef");
    var bytes: [3]u8 = undefined;
    try t.expect(try getRangeInto(&legacy, t.allocator, "key", 1, &bytes));
    try t.expectEqualStrings("bcd", &bytes);
    try t.expect(!try getRangeInto(&legacy, t.allocator, "absent", 0, &bytes));
    try t.expectError(error.OutOfRange, getRangeInto(&legacy, t.allocator, "key", 5, &bytes));
}

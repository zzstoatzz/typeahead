const std = @import("std");
const entry = @import("entry.zig");

pub const Writer = struct {
    start: usize = 0,
    offsets: std.ArrayList(u32) = .empty,
    last: usize = 0,

    pub fn deinit(self: *Writer, gpa: std.mem.Allocator) void {
        self.offsets.deinit(gpa);
    }

    pub fn empty(self: *const Writer) bool {
        return self.offsets.items.len == 0;
    }

    pub fn add(self: *Writer, gpa: std.mem.Allocator, out: *std.ArrayList(u8), e: entry.Entry) !void {
        if (self.empty()) self.start = out.items.len;
        self.last = out.items.len;
        try self.offsets.append(gpa, @intCast(out.items.len - self.start));
        try entry.append(gpa, out, e);
    }

    pub fn lastKey(self: *const Writer, out: []const u8) []const u8 {
        return entry.keyAt(out, self.last);
    }

    pub fn finish(self: *Writer, gpa: std.mem.Allocator, out: *std.ArrayList(u8)) !void {
        const tail = try out.addManyAsSlice(gpa, 4 * (self.offsets.items.len + 1));
        for (self.offsets.items, 0..) |offset, i| std.mem.writeInt(u32, tail[4 * i ..][0..4], offset, .little);
        std.mem.writeInt(u32, tail[tail.len - 4 ..][0..4], @intCast(self.offsets.items.len), .little);
        self.offsets.clearRetainingCapacity();
    }
};

pub const Block = struct {
    bytes: []const u8,
    count: u32,
    offsets: []const u8,

    pub fn validate(bytes: []const u8) error{Corrupt}!Block {
        if (bytes.len < 4) return error.Corrupt;
        const count = std.mem.readInt(u32, bytes[bytes.len - 4 ..][0..4], .little);
        if (count == 0 or (bytes.len - 4) / 4 < count) return error.Corrupt;
        const block = init(bytes);
        var previous: ?[]const u8 = null;
        for (0..count) |i| {
            const e = try entry.decode(block.bytes, block.offset(@intCast(i)));
            if (previous) |p| if (std.mem.order(u8, p, e.key) != .lt) return error.Corrupt;
            previous = e.key;
        }
        return block;
    }

    pub fn init(bytes: []const u8) Block {
        const count = std.mem.readInt(u32, bytes[bytes.len - 4 ..][0..4], .little);
        const offsets_at = bytes.len - 4 - 4 * @as(usize, count);
        return .{ .bytes = bytes[0..offsets_at], .count = count, .offsets = bytes[offsets_at .. bytes.len - 4] };
    }

    pub fn offset(self: Block, i: u32) u32 {
        return std.mem.readInt(u32, self.offsets[4 * @as(usize, i) ..][0..4], .little);
    }

    pub fn at(self: Block, i: u32) entry.Entry {
        return entry.decodeTrusted(self.bytes, self.offset(i));
    }

    pub fn keyAt(self: Block, i: u32) []const u8 {
        return entry.keyAt(self.bytes, self.offset(i));
    }

    pub fn lowerBound(self: Block, key: []const u8) u32 {
        var lo: u32 = 0;
        var hi: u32 = self.count;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            if (std.mem.order(u8, self.keyAt(mid), key) == .lt) lo = mid + 1 else hi = mid;
        }
        return lo;
    }
};

const std = @import("std");
const block = @import("block.zig");

pub const Kind = enum(u8) { data, fence };
pub const Key = struct { table: u64, block: u32, kind: Kind = .data };

pub const Cached = struct {
    refs: u32,
    key: Key,
    bytes: []u8,
    block: block.Block,
    older: ?*Cached = null,
    newer: ?*Cached = null,
    held: bool = true,
};

pub const Stats = struct { cached_bytes: usize, resident_bytes: usize, pinned_bytes: usize, evictable_bytes: usize };

pub const Cache = CacheWithContext(std.hash_map.AutoContext(Key));

fn CacheWithContext(comptime Context: type) type {
    return struct {
        const Self = @This();
        gpa: std.mem.Allocator,
        budget: usize,
        bytes: usize = 0,
        resident_bytes: usize = 0,
        pinned_bytes: usize = 0,
        map: std.HashMapUnmanaged(Key, *Cached, Context, std.hash_map.default_max_load_percentage) = .empty,
        oldest: ?*Cached = null,
        newest: ?*Cached = null,
        evicted_pinned: u64 = 0,

        /// Explicit linear-time invariant audit; never runs on the normal read path.
        pub fn assertIntegrity(self: *const Self) void {
            var previous: ?*Cached = null;
            var next = self.oldest;
            var count: usize = 0;
            var cached: usize = 0;
            var unpinned: usize = 0;
            var cached_pinned: usize = 0;
            while (next) |c| {
                std.debug.assert(count < self.map.count());
                std.debug.assert(c.held and c.refs > 0);
                std.debug.assert(c.older == previous);
                std.debug.assert(self.map.get(c.key) == c);
                cached += charge(c.bytes);
                if (c.refs == 1) unpinned += charge(c.bytes) else cached_pinned += charge(c.bytes);
                previous = c;
                next = c.newer;
                count += 1;
            }
            std.debug.assert(previous == self.newest);
            std.debug.assert(count == self.map.count());
            std.debug.assert(cached == self.bytes);
            std.debug.assert(self.resident_bytes >= cached);
            std.debug.assert(self.pinned_bytes >= cached_pinned);
            std.debug.assert(self.resident_bytes == unpinned + self.pinned_bytes);
        }

        pub fn stats(self: *const Self) Stats {
            return .{ .cached_bytes = self.bytes, .resident_bytes = self.resident_bytes, .pinned_bytes = self.pinned_bytes, .evictable_bytes = self.resident_bytes - self.pinned_bytes };
        }

        pub fn key(table: u64, i: u32) Key {
            return .{ .table = table, .block = i };
        }

        pub fn fenceKey(table: u64, partition: u32) Key {
            return .{ .table = table, .block = partition, .kind = .fence };
        }

        pub fn deinit(self: *Self) void {
            while (self.oldest) |c| self.drop(c);
            self.map.deinit(self.gpa);
        }

        pub fn lookup(self: *Self, k: Key) ?*Cached {
            const c = self.map.get(k) orelse return null;
            self.unlink(c);
            self.link(c);
            if (c.refs == 1) self.pinned_bytes += charge(c.bytes);
            c.refs += 1;
            return c;
        }

        pub fn insert(self: *Self, k: Key, bytes: []u8, b: block.Block) !*Cached {
            try self.map.ensureUnusedCapacity(self.gpa, 1);
            const c = try self.gpa.create(Cached);
            c.* = .{ .refs = 2, .key = k, .bytes = bytes, .block = b };
            self.map.putAssumeCapacityNoClobber(k, c);
            self.link(c);
            self.bytes += charge(bytes);
            self.resident_bytes += charge(bytes);
            self.pinned_bytes += charge(bytes);
            while (self.bytes > self.budget) {
                const old = self.oldest orelse break;
                if (old == c) break;
                self.drop(old);
            }
            return c;
        }

        pub fn release(self: *Self, c: *Cached) void {
            std.debug.assert(c.refs > @intFromBool(c.held));
            if (c.refs - @as(u32, @intFromBool(c.held)) == 1) self.pinned_bytes -= charge(c.bytes);
            c.refs -= 1;
            if (c.refs == 0) self.free(c);
        }

        fn drop(self: *Self, c: *Cached) void {
            if (c.refs > 1) self.evicted_pinned += 1;
            self.unlink(c);
            _ = self.map.remove(c.key);
            self.bytes -= charge(c.bytes);
            c.held = false;
            c.refs -= 1;
            if (c.refs == 0) self.free(c);
        }

        fn charge(bytes: []const u8) usize {
            return bytes.len + @sizeOf(Cached);
        }

        fn free(self: *Self, c: *Cached) void {
            self.resident_bytes -= charge(c.bytes);
            self.gpa.free(c.bytes);
            self.gpa.destroy(c);
        }

        fn link(self: *Self, c: *Cached) void {
            c.older = self.newest;
            c.newer = null;
            if (self.newest) |n| n.newer = c else self.oldest = c;
            self.newest = c;
        }

        fn unlink(self: *Self, c: *Cached) void {
            if (c.older) |o| o.newer = c.newer else self.oldest = c.newer;
            if (c.newer) |n| n.older = c.older else self.newest = c.older;
            c.older = null;
            c.newer = null;
        }
    };
}

test "hash collisions preserve block identity through lookup, eviction and pinned release" {
    const t = std.testing;
    const Colliding = struct {
        pub fn hash(_: @This(), _: Key) u64 {
            return 0;
        }
        pub fn eql(_: @This(), a: Key, b: Key) bool {
            return a.table == b.table and a.block == b.block;
        }
    };
    const TestCache = CacheWithContext(Colliding);
    var cache: TestCache = .{ .gpa = t.allocator, .budget = 4096 };
    defer cache.deinit();
    const keys = [_]Key{ TestCache.key(1, 0), TestCache.key(1, 1), TestCache.key(2, 0) };
    var pins: [3]*Cached = undefined;
    var initialized: usize = 0;
    defer for (pins[0..initialized]) |pin| cache.release(pin);
    for (keys, &pins, 0..) |k, *pin, i| {
        var bytes: std.ArrayList(u8) = .empty;
        errdefer bytes.deinit(t.allocator);
        var writer: block.Writer = .{};
        defer writer.deinit(t.allocator);
        const value = [_]u8{@intCast(i)};
        try writer.add(t.allocator, &bytes, .{ .kind = .put, .key = "same", .value = &value });
        try writer.finish(t.allocator, &bytes);
        const owned = try bytes.toOwnedSlice(t.allocator);
        errdefer t.allocator.free(owned);
        pin.* = try cache.insert(k, owned, try block.Block.validate(owned));
        initialized += 1;
    }
    for (keys, 0..) |k, i| {
        const hit = cache.lookup(k).?;
        defer cache.release(hit);
        try t.expectEqual(@as(u8, @intCast(i)), hit.block.at(0).value[0]);
    }
    try t.expect(cache.lookup(TestCache.key(9, 9)) == null);
    cache.drop(pins[1]);
    try t.expect(cache.lookup(keys[1]) == null);
    try t.expectEqual(@as(u8, 1), pins[1].block.at(0).value[0]);
    try t.expectEqual(@as(usize, 2), cache.map.count());
    for ([_]usize{ 0, 2 }) |i| {
        const hit = cache.lookup(keys[i]).?;
        defer cache.release(hit);
        try t.expect(hit == pins[i]);
    }
    try t.expectEqual(@as(u64, 1), cache.evicted_pinned);
    cache.assertIntegrity();
}

test "soft cache budget tracks oversized blocks and evicted pins until final release" {
    const t = std.testing;
    var cache: Cache = .{ .gpa = t.allocator, .budget = 1 };
    defer cache.deinit();
    var pins: [3]*Cached = undefined;
    for (&pins, 0..) |*pin, i| {
        const bytes = try t.allocator.alloc(u8, 128);
        pin.* = try cache.insert(Cache.key(1, @intCast(i)), bytes, .{ .bytes = bytes, .count = 0, .offsets = &.{} });
    }
    cache.assertIntegrity();
    const charged = pins[0].bytes.len + @sizeOf(Cached);
    try t.expectEqual(charged, cache.stats().cached_bytes);
    try t.expectEqual(3 * charged, cache.stats().resident_bytes);
    try t.expectEqual(3 * charged, cache.stats().pinned_bytes);
    try t.expectEqual(@as(usize, 0), cache.stats().evictable_bytes);
    const extra = cache.lookup(Cache.key(1, 2)).?;
    cache.release(extra);
    try t.expectEqual(3 * charged, cache.stats().pinned_bytes);
    cache.release(pins[0]);
    cache.release(pins[1]);
    cache.release(pins[2]);
    try t.expectEqual(charged, cache.stats().resident_bytes);
    try t.expectEqual(@as(usize, 0), cache.stats().pinned_bytes);
    try t.expectEqual(charged, cache.stats().evictable_bytes);
    cache.drop(pins[2]);
    try t.expectEqual(@as(usize, 0), cache.stats().resident_bytes);
    cache.assertIntegrity();
}

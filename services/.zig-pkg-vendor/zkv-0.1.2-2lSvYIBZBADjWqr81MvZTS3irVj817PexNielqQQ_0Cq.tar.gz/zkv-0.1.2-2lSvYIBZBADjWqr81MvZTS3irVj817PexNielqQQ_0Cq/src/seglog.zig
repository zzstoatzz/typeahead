const std = @import("std");
const log = @import("log.zig");

pub fn SegmentLog(comptime Store: type) type {
    return struct {
        const Self = @This();

        pub const Context = void;
        pub const Ticket = void;

        pub const Collector = struct {
            names: ?[][]u8 = null,
            at: usize = 0,
            applied: u64 = 0,
            owner: ?*Self = null,

            pub fn deinit(self: *Collector, gpa: std.mem.Allocator) void {
                if (self.names) |names| @import("store.zig").freeNames(gpa, names);
                self.* = .{};
            }
        };

        gpa: std.mem.Allocator,
        store: *Store,
        epoch: u64 = 0,
        next_ordinal: u64 = 0,
        fences: std.ArrayList(u64) = .empty,
        unresolved: bool = false,
        scratch: std.ArrayList(u8) = .empty,

        pub fn init(gpa: std.mem.Allocator, store: *Store, _: Context) Self {
            return .{ .gpa = gpa, .store = store };
        }

        pub fn deinit(self: *Self) void {
            self.fences.deinit(self.gpa);
            self.scratch.deinit(self.gpa);
        }

        pub fn state(self: *const Self) []const u64 {
            return self.fences.items;
        }

        pub fn next(self: *const Self) u64 {
            return self.next_ordinal;
        }

        pub fn recover(self: *Self, epoch: u64, applied: u64, saved: []const u64, sink: anytype) !void {
            const gpa = self.gpa;
            self.epoch = epoch;
            try self.fences.appendSlice(gpa, saved);
            var key: log.Key = undefined;
            var ordinal = applied + 1;
            while (true) {
                const found = try self.store.get(gpa, log.key(&key, ordinal)) orelse found: {
                    try self.encode(true, "");
                    if (try self.store.putIfAbsent(log.key(&key, ordinal), self.scratch.items)) |_| break;
                    break :found try self.store.get(gpa, log.key(&key, ordinal)) orelse continue;
                };
                defer gpa.free(found.bytes);
                const segment = log.Segment.decode(found.bytes) catch |err| {
                    if (try self.tornTail(ordinal)) continue;
                    return err;
                };
                if (segment.epoch > epoch) return error.Fenced;
                if (segment.epoch == epoch) {
                    if (!segment.fence) return error.Corrupt;
                    break;
                }
                if (segment.fence) try self.fences.append(gpa, ordinal);
                try sink.landed(ordinal, segment.iterator());
                ordinal += 1;
            }
            try self.fences.append(gpa, ordinal);
            try sink.landed(ordinal, (log.Segment{ .epoch = epoch, .fence = true, .body = "" }).iterator());
            self.next_ordinal = ordinal + 1;
        }

        /// a segment that does not decode and has no successor is the torn
        /// tail of a writer that died before its sync returned: never
        /// acknowledged, so dropped. one with a successor is corruption.
        fn tornTail(self: *Self, ordinal: u64) !bool {
            var key: log.Key = undefined;
            if (try self.store.get(self.gpa, log.key(&key, ordinal + 1))) |next_found| {
                self.gpa.free(next_found.bytes);
                return false;
            }
            try self.store.delete(log.key(&key, ordinal));
            return true;
        }

        pub fn begin(self: *Self, body: []const u8) !Ticket {
            try self.encode(false, body);
        }

        pub fn drop(_: *Self, _: Ticket) void {}

        pub fn finish(self: *Self, _: Ticket, sink: anytype) !u64 {
            errdefer self.unresolved = true;
            var key: log.Key = undefined;
            while (true) {
                if (try self.store.putIfAbsent(log.key(&key, self.next_ordinal), self.scratch.items)) |_| break;
                _ = try self.claimLanded(sink);
            }
            self.unresolved = false;
            defer self.next_ordinal += 1;
            return self.next_ordinal;
        }

        pub fn settle(self: *Self, sink: anytype) !void {
            if (!self.unresolved) return;
            while (try self.claimLanded(sink)) {}
            self.unresolved = false;
        }

        fn claimLanded(self: *Self, sink: anytype) !bool {
            var key: log.Key = undefined;
            const found = try self.store.get(self.gpa, log.key(&key, self.next_ordinal)) orelse return false;
            defer self.gpa.free(found.bytes);
            const segment = try log.Segment.decode(found.bytes);
            if (segment.epoch != self.epoch) return error.Fenced;
            try sink.landed(self.next_ordinal, segment.iterator());
            self.next_ordinal += 1;
            return true;
        }

        fn encode(self: *Self, fence: bool, body: []const u8) !void {
            try log.begin(self.gpa, &self.scratch, self.epoch, fence);
            try self.scratch.appendSlice(self.gpa, body);
            try log.end(self.gpa, &self.scratch);
        }

        pub fn collect(self: *Self, applied: u64) !void {
            const gpa = self.gpa;
            const names = try self.store.list(gpa, log.prefix);
            defer @import("store.zig").freeNames(gpa, names);
            var doomed: std.ArrayList([]const u8) = .empty;
            defer doomed.deinit(gpa);
            for (names) |name| {
                const ordinal = log.parseKey(name) orelse continue;
                if (ordinal > applied) continue;
                if (self.isFence(ordinal) or self.isFence(ordinal + 1)) continue;
                try doomed.append(gpa, name);
            }
            try @import("store.zig").deleteMany(self.store, doomed.items);
        }

        pub fn collectStep(self: *Self, collector: *Collector, applied: u64, limit: usize) !bool {
            if (limit == 0) return error.InvalidBudget;
            if (collector.owner) |owner| {
                if (owner != self) return error.CollectionInProgress;
            } else {
                collector.names = try self.store.list(self.gpa, log.prefix);
                collector.applied = applied;
                collector.owner = self;
            }
            const names = collector.names.?;
            const end = @min(names.len, collector.at +| limit);
            while (collector.at < end) : (collector.at += 1) {
                const name = names[collector.at];
                const ordinal = log.parseKey(name) orelse continue;
                if (ordinal > collector.applied or self.isFence(ordinal) or self.isFence(ordinal + 1)) continue;
                try self.store.delete(name);
            }
            if (collector.at < names.len) return true;
            collector.deinit(self.gpa);
            return false;
        }

        fn isFence(self: *const Self, ordinal: u64) bool {
            return std.mem.indexOfScalar(u64, self.fences.items, ordinal) != null;
        }
    };
}

const FailingDeleteStore = struct {
    inner: @import("store/memory.zig").MemoryStore,
    deletes: usize = 0,
    fail_after_delete: bool = false,

    pub fn list(self: *@This(), gpa: std.mem.Allocator, prefix: []const u8) ![][]u8 {
        return self.inner.list(gpa, prefix);
    }

    pub fn delete(self: *@This(), name: []const u8) !void {
        self.deletes += 1;
        try self.inner.delete(name);
        if (self.fail_after_delete) {
            self.fail_after_delete = false;
            return error.InjectedFailure;
        }
    }
};

const TailSink = struct {
    landed_ordinals: std.ArrayList(u64) = .empty,
    gpa: std.mem.Allocator,
    pub fn landed(self: *TailSink, ordinal: u64, _: anytype) !void {
        try self.landed_ordinals.append(self.gpa, ordinal);
    }
};

test "recovery drops a torn tail segment and rejects corruption before a landed one" {
    const t = std.testing;
    const MemoryStore = @import("store/memory.zig").MemoryStore;
    var store = MemoryStore.init(t.allocator);
    defer store.deinit();
    const Log = SegmentLog(MemoryStore);
    var key: log.Key = undefined;
    var whole: std.ArrayList(u8) = .empty;
    defer whole.deinit(t.allocator);
    try log.begin(t.allocator, &whole, 1, false);
    try log.end(t.allocator, &whole);
    try store.put(log.key(&key, 1), whole.items);
    try store.put(log.key(&key, 2), whole.items[0 .. whole.items.len / 2]);
    {
        var torn = Log.init(t.allocator, &store, {});
        defer torn.deinit();
        var sink: TailSink = .{ .gpa = t.allocator };
        defer sink.landed_ordinals.deinit(t.allocator);
        try torn.recover(2, 0, &.{}, &sink);
        try t.expectEqualSlices(u64, &.{ 1, 2 }, sink.landed_ordinals.items);
        try t.expectEqual(@as(u64, 3), torn.next());
        const fence = (try store.get(t.allocator, log.key(&key, 2))).?;
        defer t.allocator.free(fence.bytes);
        try t.expect((try log.Segment.decode(fence.bytes)).fence);
    }
    try store.put(log.key(&key, 2), whole.items[0 .. whole.items.len / 2]);
    try store.put(log.key(&key, 3), whole.items);
    var corrupt = Log.init(t.allocator, &store, {});
    defer corrupt.deinit();
    var sink: TailSink = .{ .gpa = t.allocator };
    defer sink.landed_ordinals.deinit(t.allocator);
    try t.expectError(error.Corrupt, corrupt.recover(2, 0, &.{}, &sink));
}

test "incremental log collection bounds work, retries deletes, and retains fences" {
    const t = std.testing;
    var store: FailingDeleteStore = .{ .inner = .init(t.allocator) };
    defer store.inner.deinit();
    const Log = SegmentLog(FailingDeleteStore);
    var log_store = Log.init(t.allocator, &store, {});
    defer log_store.deinit();
    try log_store.fences.appendSlice(t.allocator, &.{ 3, 7 });
    var key: log.Key = undefined;
    for (1..11) |i| try store.inner.put(log.key(&key, i), "retained");
    var collector: Log.Collector = .{};
    defer collector.deinit(t.allocator);
    try t.expectError(error.InvalidBudget, log_store.collectStep(&collector, 8, 0));
    store.fail_after_delete = true;
    try t.expectError(error.InjectedFailure, log_store.collectStep(&collector, 8, 2));
    try t.expectEqual(@as(usize, 0), collector.at);
    try store.inner.put(log.key(&key, 11), "new");
    var calls: usize = 0;
    while (true) {
        const before = store.deletes;
        const more = try log_store.collectStep(&collector, 11, 2);
        try t.expect(store.deletes - before <= 2);
        calls += 1;
        if (!more) break;
        try t.expect(calls < 10);
    }
    for (1..12) |i| {
        const found = try store.inner.get(t.allocator, log.key(&key, i));
        defer if (found) |o| t.allocator.free(o.bytes);
        const retained = i == 2 or i == 3 or i == 6 or i == 7 or i >= 9;
        try t.expectEqual(retained, found != null);
    }
    try t.expect(collector.names == null);
    try t.expect(try log_store.collectStep(&collector, 11, 1));
    var other = Log.init(t.allocator, &store, {});
    defer other.deinit();
    try t.expectError(error.CollectionInProgress, other.collectStep(&collector, 11, 1));
    collector.deinit(t.allocator);
    try t.expect(collector.owner == null);
}

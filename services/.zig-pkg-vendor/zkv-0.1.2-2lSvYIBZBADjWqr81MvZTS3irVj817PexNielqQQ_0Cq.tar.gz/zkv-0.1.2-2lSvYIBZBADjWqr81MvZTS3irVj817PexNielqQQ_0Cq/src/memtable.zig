const std = @import("std");
const Kind = @import("entry.zig").Kind;

const max_height = 12;

pub const Node = struct {
    key: []const u8,
    value: []const u8,
    seq: u64,
    kind: Kind,
    next: []?*Node,
};

pub const Memtable = struct {
    arena: std.heap.ArenaAllocator,
    head: *Node,
    height: usize = 1,
    rng: u64 = 0x9e3779b97f4a7c15,
    bytes: usize = 0,
    count: usize = 0,
    refs: u32 = 1,
    last_ordinal: u64,

    pub fn create(gpa: std.mem.Allocator, last_ordinal: u64) !*Memtable {
        const self = try gpa.create(Memtable);
        errdefer gpa.destroy(self);
        self.* = .{ .arena = .init(gpa), .head = undefined, .last_ordinal = last_ordinal };
        errdefer self.arena.deinit();
        self.head = try self.newHead();
        return self;
    }

    fn newHead(self: *Memtable) !*Node {
        const a = self.arena.allocator();
        const head = try a.create(Node);
        const next = try a.alloc(?*Node, max_height);
        @memset(next, null);
        head.* = .{ .key = "", .value = "", .seq = 0, .kind = .put, .next = next };
        return head;
    }

    pub fn retain(self: *Memtable) *Memtable {
        self.refs += 1;
        return self;
    }

    pub fn release(self: *Memtable, gpa: std.mem.Allocator) void {
        self.refs -= 1;
        if (self.refs > 0) return;
        self.arena.deinit();
        gpa.destroy(self);
    }

    pub fn clear(self: *Memtable) !void {
        std.debug.assert(self.refs == 1);
        _ = self.arena.reset(.retain_capacity);
        self.* = .{ .arena = self.arena, .head = undefined, .last_ordinal = self.last_ordinal };
        self.head = try self.newHead();
    }

    fn before(node: *const Node, key: []const u8, seq: u64) bool {
        return switch (std.mem.order(u8, node.key, key)) {
            .lt => true,
            .eq => node.seq > seq,
            .gt => false,
        };
    }

    fn randomHeight(self: *Memtable) usize {
        var height: usize = 1;
        while (height < max_height) : (height += 1) {
            self.rng ^= self.rng << 13;
            self.rng ^= self.rng >> 7;
            self.rng ^= self.rng << 17;
            if (self.rng & 3 != 0) break;
        }
        return height;
    }

    pub fn insert(self: *Memtable, key: []const u8, value: []const u8, seq: u64, kind: Kind) !void {
        var prev: [max_height]*Node = undefined;
        var node = self.head;
        var level = self.height;
        while (level > 0) {
            level -= 1;
            while (node.next[level]) |next| {
                if (!before(next, key, seq)) break;
                node = next;
            }
            prev[level] = node;
        }
        const height = self.randomHeight();
        while (self.height < height) : (self.height += 1) prev[self.height] = self.head;

        const a = self.arena.allocator();
        const fresh = try a.create(Node);
        const next = try a.alloc(?*Node, height);
        const data = try a.alloc(u8, key.len + value.len);
        @memcpy(data[0..key.len], key);
        @memcpy(data[key.len..], value);
        fresh.* = .{ .key = data[0..key.len], .value = data[key.len..], .seq = seq, .kind = kind, .next = next };
        for (0..height) |i| {
            next[i] = prev[i].next[i];
            prev[i].next[i] = fresh;
        }
        self.bytes += key.len + value.len;
        self.count += 1;
    }

    pub fn seekGe(self: *const Memtable, key: []const u8, seq: u64) ?*Node {
        var node = self.head;
        var level = self.height;
        while (level > 0) {
            level -= 1;
            while (node.next[level]) |next| {
                if (!before(next, key, seq)) break;
                node = next;
            }
        }
        return node.next[0];
    }

    pub fn seekLt(self: *const Memtable, key: ?[]const u8) ?*Node {
        var node = self.head;
        var level = self.height;
        while (level > 0) {
            level -= 1;
            while (node.next[level]) |next| {
                if (key) |k| if (std.mem.order(u8, next.key, k) != .lt) break;
                node = next;
            }
        }
        return if (node == self.head) null else node;
    }

    pub fn first(self: *const Memtable) ?*Node {
        return self.head.next[0];
    }

    pub fn get(self: *const Memtable, key: []const u8, bound: u64) ?*Node {
        const node = self.seekGe(key, bound) orelse return null;
        return if (std.mem.eql(u8, node.key, key)) node else null;
    }
};

pub const Newest = struct {
    node: ?*Node,

    pub fn next(self: *Newest) ?*Node {
        const node = self.node orelse return null;
        var after = node.next[0];
        while (after) |n| : (after = n.next[0]) if (!std.mem.eql(u8, n.key, node.key)) break;
        self.node = after;
        return node;
    }
};

pub fn newest(mem: *const Memtable) Newest {
    return .{ .node = mem.first() };
}

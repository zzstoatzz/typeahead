const std = @import("std");
const entry = @import("entry.zig");

const magic: u32 = 0x7a6b766c;
const header_len = 13;

pub const prefix = "log/";

pub const Key = [prefix.len + 20]u8;

pub fn key(buf: *Key, ordinal: u64) []const u8 {
    return std.fmt.bufPrint(buf, prefix ++ "{d:0>20}", .{ordinal}) catch unreachable;
}

pub fn parseKey(name: []const u8) ?u64 {
    if (name.len != @sizeOf(Key) or !std.mem.startsWith(u8, name, prefix)) return null;
    return std.fmt.parseInt(u64, name[prefix.len..], 10) catch null;
}

pub fn begin(gpa: std.mem.Allocator, out: *std.ArrayList(u8), epoch: u64, fence: bool) !void {
    out.clearRetainingCapacity();
    const head = try out.addManyAsSlice(gpa, header_len);
    std.mem.writeInt(u32, head[0..4], magic, .little);
    std.mem.writeInt(u64, head[4..12], epoch, .little);
    head[12] = @intFromBool(fence);
}

pub fn end(gpa: std.mem.Allocator, out: *std.ArrayList(u8)) !void {
    const crc = std.hash.Crc32.hash(out.items);
    std.mem.writeInt(u32, try out.addManyAsArray(gpa, 4), crc, .little);
}

pub const Segment = struct {
    epoch: u64,
    fence: bool,
    body: []const u8,

    pub fn decode(bytes: []const u8) error{Corrupt}!Segment {
        if (bytes.len < header_len + 4) return error.Corrupt;
        const crc = std.mem.readInt(u32, bytes[bytes.len - 4 ..][0..4], .little);
        if (crc != std.hash.Crc32.hash(bytes[0 .. bytes.len - 4])) return error.Corrupt;
        if (std.mem.readInt(u32, bytes[0..4], .little) != magic or bytes[12] > 1) return error.Corrupt;
        const segment: Segment = .{
            .epoch = std.mem.readInt(u64, bytes[4..12], .little),
            .fence = bytes[12] == 1,
            .body = bytes[header_len .. bytes.len - 4],
        };
        var at: usize = 0;
        while (at < segment.body.len) at += entry.encodedLen(try entry.decode(segment.body, at));
        if (segment.fence and segment.body.len > 0) return error.Corrupt;
        return segment;
    }

    pub fn iterator(self: Segment) Iterator {
        return .{ .body = self.body };
    }
};

pub const Iterator = struct {
    body: []const u8,
    at: usize = 0,

    pub fn next(self: *Iterator) ?entry.Entry {
        if (self.at == self.body.len) return null;
        const e = entry.decodeTrusted(self.body, self.at);
        self.at += entry.encodedLen(e);
        return e;
    }
};

const std = @import("std");

pub const Kind = enum(u8) { put, del };

pub const Entry = struct {
    key: []const u8,
    value: []const u8,
    kind: Kind,
};

pub const header_len = 9;

pub fn encodedLen(entry: Entry) usize {
    return header_len + entry.key.len + entry.value.len;
}

pub fn append(gpa: std.mem.Allocator, out: *std.ArrayList(u8), entry: Entry) !void {
    const dest = try out.addManyAsSlice(gpa, encodedLen(entry));
    dest[0] = @backingInt(entry.kind);
    std.mem.writeInt(u32, dest[1..5], @intCast(entry.key.len), .little);
    std.mem.writeInt(u32, dest[5..9], @intCast(entry.value.len), .little);
    @memcpy(dest[header_len..][0..entry.key.len], entry.key);
    @memcpy(dest[header_len + entry.key.len ..][0..entry.value.len], entry.value);
}

pub fn decode(bytes: []const u8, at: usize) error{Corrupt}!Entry {
    if (bytes.len < at + header_len) return error.Corrupt;
    const head = bytes[at..][0..header_len];
    const kind = std.enums.fromInt(Kind, head[0]) orelse return error.Corrupt;
    const key_len = std.mem.readInt(u32, head[1..5], .little);
    const value_len = std.mem.readInt(u32, head[5..9], .little);
    const key_at = at + header_len;
    if (bytes.len - key_at < @as(u64, key_len) + value_len) return error.Corrupt;
    return .{
        .kind = kind,
        .key = bytes[key_at..][0..key_len],
        .value = bytes[key_at + key_len ..][0..value_len],
    };
}

pub fn decodeTrusted(bytes: []const u8, at: usize) Entry {
    const head = bytes[at..][0..header_len];
    const key_len = std.mem.readInt(u32, head[1..5], .little);
    const value_len = std.mem.readInt(u32, head[5..9], .little);
    const key_at = at + header_len;
    return .{
        .kind = @fromBackingInt(@intCast(head[0])),
        .key = bytes[key_at..][0..key_len],
        .value = bytes[key_at + key_len ..][0..value_len],
    };
}

pub fn keyAt(bytes: []const u8, at: usize) []const u8 {
    const key_len = std.mem.readInt(u32, bytes[at + 1 ..][0..4], .little);
    return bytes[at + header_len ..][0..key_len];
}

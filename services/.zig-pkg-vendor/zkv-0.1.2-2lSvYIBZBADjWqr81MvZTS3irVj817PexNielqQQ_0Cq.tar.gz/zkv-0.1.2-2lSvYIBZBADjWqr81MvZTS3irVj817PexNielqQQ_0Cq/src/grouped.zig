const std = @import("std");
const block = @import("block.zig");
const entry = @import("entry.zig");
const Allocator = std.mem.Allocator;
const group_size = 16;

fn number(gpa: Allocator, out: *std.ArrayList(u8), input: usize) !void {
    var n = input;
    while (n >= 128) : (n >>= 7) try out.append(gpa, @as(u8, @intCast(n & 127)) | 128);
    try out.append(gpa, @intCast(n));
}

const Reader = struct {
    bytes: []const u8,
    at: usize = 0,
    fn take(self: *Reader, len: usize) error{Corrupt}![]const u8 {
        if (len > self.bytes.len - self.at) return error.Corrupt;
        defer self.at += len;
        return self.bytes[self.at..][0..len];
    }
    fn integer(self: *Reader) error{Corrupt}!usize {
        var n: usize = 0;
        for (0..5) |i| {
            const byte = (try self.take(1))[0];
            if (i == 4 and byte > 15) return error.Corrupt;
            n |= @as(usize, byte & 127) << @as(std.math.Log2Int(usize), @intCast(i * 7));
            if (byte & 128 == 0) return n;
        }
        return error.Corrupt;
    }
};

pub fn encode(gpa: Allocator, raw: []const u8) ![]u8 {
    const b = try block.Block.validate(raw);
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(gpa);
    try out.append(gpa, 1);
    const header = try out.addManyAsSlice(gpa, 8);
    std.mem.writeInt(u32, header[0..4], @intCast(raw.len), .little);
    std.mem.writeInt(u32, header[4..8], b.count, .little);
    var start: u32 = 0;
    while (start < b.count) {
        const end = @min(b.count, start + group_size);
        const first = b.keyAt(start);
        var shared = first.len;
        for (start + 1..end) |i| {
            const key = b.keyAt(@intCast(i));
            shared = @min(shared, key.len);
            var n: usize = 0;
            while (n < shared and first[n] == key[n]) : (n += 1) {}
            shared = n;
        }
        try number(gpa, &out, shared);
        try out.appendSlice(gpa, first[0..shared]);
        for (start..end) |i| {
            const e = b.at(@intCast(i));
            try out.append(gpa, @backingInt(e.kind));
            try number(gpa, &out, e.key.len - shared);
            try number(gpa, &out, e.value.len);
            try out.appendSlice(gpa, e.key[shared..]);
            try out.appendSlice(gpa, e.value);
        }
        start = end;
    }
    if (out.items.len >= raw.len + 1) {
        out.clearRetainingCapacity();
        try out.append(gpa, 0);
        try out.appendSlice(gpa, raw);
    }
    return out.toOwnedSlice(gpa);
}

pub fn decode(gpa: Allocator, encoded: []const u8) ![]u8 {
    if (encoded.len == 0) return error.Corrupt;
    if (encoded[0] == 0) {
        _ = try block.Block.validate(encoded[1..]);
        return gpa.dupe(u8, encoded[1..]);
    }
    if (encoded[0] != 1 or encoded.len < 9) return error.Corrupt;
    const raw_len = std.mem.readInt(u32, encoded[1..5], .little);
    const count = std.mem.readInt(u32, encoded[5..9], .little);
    if (raw_len < 4 or count == 0 or count > (raw_len - 4) / 13 or @as(u64, raw_len) > @as(u64, encoded.len) * 32) return error.Corrupt;
    var reader: Reader = .{ .bytes = encoded, .at = 9 };
    const out = try gpa.alloc(u8, raw_len);
    errdefer gpa.free(out);
    const offsets_at = raw_len - 4 * (@as(usize, count) + 1);
    var position: usize = 0;
    var row: u32 = 0;
    while (row < count) {
        const prefix = try reader.take(try reader.integer());
        const end = @min(count, row + group_size);
        while (row < end) : (row += 1) {
            const head = try reader.take(3);
            const kind = std.enums.fromInt(entry.Kind, head[0]) orelse return error.Corrupt;
            const suffix_len: usize, const value_len: usize = if ((head[1] | head[2]) < 128)
                .{ head[1], head[2] }
            else lengths: {
                reader.at -= 2;
                const suffix_len = try reader.integer();
                const value_len = try reader.integer();
                break :lengths .{ suffix_len, value_len };
            };
            const suffix = try reader.take(suffix_len);
            const value = try reader.take(value_len);
            const key_bytes = @as(u64, prefix.len) + suffix.len;
            const entry_bytes = entry.header_len + key_bytes + value.len;
            if (entry_bytes > offsets_at - position) return error.Corrupt;
            const key_len: usize = @intCast(key_bytes);
            const len: usize = @intCast(entry_bytes);
            std.mem.writeInt(u32, out[offsets_at + 4 * @as(usize, row) ..][0..4], @intCast(position), .little);
            const dest = out[position..][0..len];
            position += len;
            dest[0] = @backingInt(kind);
            std.mem.writeInt(u32, dest[1..5], @intCast(key_len), .little);
            std.mem.writeInt(u32, dest[5..9], @intCast(value.len), .little);
            @memcpy(dest[9..][0..prefix.len], prefix);
            const tail = encoded[reader.at - suffix.len - value.len .. reader.at];
            @memcpy(dest[9 + prefix.len ..], tail);
        }
    }
    if (reader.at != encoded.len) return error.Corrupt;
    if (position != offsets_at) return error.Corrupt;
    std.mem.writeInt(u32, out[out.len - 4 ..][0..4], count, .little);
    return out;
}

test "grouped keys preserve exact legacy blocks, long keys and values across boundaries" {
    const t = std.testing;
    for ([_]usize{ 1, 15, 16, 17, 33, 100 }) |count| {
        var out: std.ArrayList(u8) = .empty;
        defer out.deinit(t.allocator);
        var writer: block.Writer = .{};
        defer writer.deinit(t.allocator);
        const long = try t.allocator.alloc(u8, 70000);
        defer t.allocator.free(long);
        @memset(long, 0x81);
        for (0..count) |i| {
            var key: [128]u8 = undefined;
            const k = try std.fmt.bufPrint(&key, "same\x00prefix/{d:0>6}", .{i});
            try writer.add(t.allocator, &out, .{ .key = k, .value = if (i % 5 == 0) long else "", .kind = if (i % 7 == 0) .del else .put });
        }
        try writer.finish(t.allocator, &out);
        const encoded = try encode(t.allocator, out.items);
        defer t.allocator.free(encoded);
        const decoded = try decode(t.allocator, encoded);
        defer t.allocator.free(decoded);
        try t.expectEqualSlices(u8, out.items, decoded);
        for (0..@min(encoded.len, 64)) |len| try t.expectError(error.Corrupt, decode(t.allocator, encoded[0..len]));
        for (encoded.len - @min(encoded.len, 32)..encoded.len) |len| try t.expectError(error.Corrupt, decode(t.allocator, encoded[0..len]));
    }
}

test "grouped decoder rejects invalid lengths and unknown modes" {
    const t = std.testing;
    try t.expectError(error.Corrupt, decode(t.allocator, &.{2}));
    try t.expectError(error.Corrupt, decode(t.allocator, &.{ 1, 255, 255, 255, 255, 1, 0, 0, 0 }));
}

fn allocationRoundTrip(gpa: Allocator) !void {
    var raw: std.ArrayList(u8) = .empty;
    defer raw.deinit(gpa);
    var writer: block.Writer = .{};
    defer writer.deinit(gpa);
    for (0..33) |i| {
        var key: [64]u8 = undefined;
        try writer.add(gpa, &raw, .{ .key = try std.fmt.bufPrint(&key, "prefix/{d:0>4}", .{i}), .value = "value", .kind = .put });
    }
    try writer.finish(gpa, &raw);
    const encoded = try encode(gpa, raw.items);
    defer gpa.free(encoded);
    const decoded = try decode(gpa, encoded);
    defer gpa.free(decoded);
    try std.testing.expectEqualSlices(u8, raw.items, decoded);
}

test "grouped encoding releases resources at every allocation failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, allocationRoundTrip, .{});
}

test "empty and oversized keys survive grouped encoding and raw fallback" {
    const t = std.testing;
    var raw: std.ArrayList(u8) = .empty;
    defer raw.deinit(t.allocator);
    var writer: block.Writer = .{};
    defer writer.deinit(t.allocator);
    try writer.add(t.allocator, &raw, .{ .key = "", .value = "", .kind = .put });
    const key = try t.allocator.alloc(u8, 70000);
    defer t.allocator.free(key);
    @memset(key, 0xff);
    try writer.add(t.allocator, &raw, .{ .key = key, .value = "binary\x00value", .kind = .put });
    try writer.finish(t.allocator, &raw);
    const encoded = try encode(t.allocator, raw.items);
    defer t.allocator.free(encoded);
    const decoded = try decode(t.allocator, encoded);
    defer t.allocator.free(decoded);
    try t.expectEqualSlices(u8, raw.items, decoded);
    var fallback: std.ArrayList(u8) = .empty;
    defer fallback.deinit(t.allocator);
    try fallback.append(t.allocator, 0);
    try fallback.appendSlice(t.allocator, raw.items);
    const expanded = try decode(t.allocator, fallback.items);
    defer t.allocator.free(expanded);
    try t.expectEqualSlices(u8, raw.items, expanded);
}

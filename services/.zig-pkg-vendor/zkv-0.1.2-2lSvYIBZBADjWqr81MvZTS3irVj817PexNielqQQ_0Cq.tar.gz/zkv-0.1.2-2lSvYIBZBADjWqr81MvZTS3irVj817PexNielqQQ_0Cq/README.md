# zkv

zkv is an embedded, ordered key-value store for Zig, backed by local files or an object store. it supports one writer and independent readers, with fencing inspired by [SlateDB](https://slatedb.io).

status: experimental. the storage format and API may change.

## install

requires Zig 0.17.

```sh
zig fetch --save https://tangled.org/zzstoatzz.io/zkv/archive/main.tar.gz
```

add the module in `build.zig`:

```zig
const zkv = b.dependency("zkv", .{ .target = target, .optimize = optimize }).module("zkv");
exe.root_module.addImport("zkv", zkv);
```

## use

```zig
var store = zkv.MemoryStore.init(gpa);
defer store.deinit();

const db = try zkv.Db(zkv.MemoryStore).open(gpa, &store, .{});
defer db.close();

try db.put("a", "1");
try db.commit();
const value = try db.get("a");
```

the writer sees staged changes immediately; other readers call `refresh` to see commits. flushing, compaction and collection are caller-driven. `MemoryStore`, `DirStore` and `S3Store` are included.

a commit is acknowledged once its log segment is durable. `DirStore` publishes the segment's name before syncing its bytes, one journal transaction per commit on ext4; on a filesystem that does not order data before metadata a crash can leave the last segment torn, and recovery drops it, so an acknowledged commit is never lost and a torn one is never replayed.

## develop

```sh
zig build test -Doptimize=ReleaseSafe -j2 # unit and regression tests
zig build bench                         # in-memory throughput benchmark
zig build dst -Dhegel                    # deterministic memory-store simulation
```

## docs

[docs/](docs/) covers guarantees, maintenance and performance measurements.

## license

[MIT](LICENSE)

const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const zkv = b.addModule("zkv", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
    });

    const bench = b.addExecutable(.{
        .name = "bench",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/main.zig"),
            .target = target,
            .optimize = .fast,
            .imports = &.{.{ .name = "zkv", .module = b.createModule(.{
                .root_source_file = b.path("src/root.zig"),
                .target = target,
                .optimize = .fast,
            }) }},
        }),
    });
    b.step("bench", "put, get and scan throughput on the memory store").dependOn(&b.addRunArtifact(bench).step);
    const compaction_probe = b.addExecutable(.{
        .name = "compaction-probe",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/compaction.zig"),
            .link_libc = true,
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "zkv", .module = zkv }},
        }),
    });
    const run_compaction = b.addRunArtifact(compaction_probe);
    run_compaction.addPassthruArgs();
    b.step("compaction-probe", "count maintenance object traffic and verify recovered values").dependOn(&run_compaction.step);
    const finalization = b.addExecutable(.{
        .name = "finalization-probe",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/finalization.zig"),
            .link_libc = true,
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "zkv", .module = zkv }},
        }),
    });
    const run_finalization = b.addRunArtifact(finalization);
    run_finalization.addPassthruArgs();
    b.step("finalization-probe", "trace compaction phases and verify reopened data").dependOn(&run_finalization.step);
    const visibility = b.addExecutable(.{
        .name = "visibility",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/visibility.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "zkv", .module = zkv }},
        }),
    });
    const run_visibility = b.addRunArtifact(visibility);
    run_visibility.addPassthruArgs();
    b.step("visibility", "measure commit and reader refresh latency").dependOn(&run_visibility.step);
    const install_visibility = b.addInstallArtifact(visibility, .{});
    b.step("install-visibility", "install the standalone visibility benchmark").dependOn(&install_visibility.step);
    const prefix_reads = b.addExecutable(.{
        .name = "prefix-reads",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/prefix_reads.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "zkv", .module = zkv }},
        }),
    });
    b.step("prefix-reads", "install real-file prefix read measurements").dependOn(&b.addInstallArtifact(prefix_reads, .{}).step);
    const tests = b.addTest(.{ .root_module = zkv });
    b.step("test", "unit tests").dependOn(&b.addRunArtifact(tests).step);

    const s3check = b.addExecutable(.{
        .name = "s3check",
        .root_module = b.createModule(.{
            .root_source_file = b.path("tools/s3check.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "zkv", .module = zkv }},
        }),
    });
    const run_s3check = b.addRunArtifact(s3check);
    run_s3check.addPassthruArgs();
    b.step("s3check", "check a bucket (ZKV_S3_* env) against the store contract, then run a writer and a reader on it").dependOn(&run_s3check.step);

    if (b.option(bool, "hegel", "build the simulation test (builds libhegel once)") orelse false) {
        if (b.lazyDependency("hegel", .{ .target = target, .optimize = optimize })) |hegel| {
            const dst = b.addExecutable(.{
                .name = "dst",
                .root_module = b.createModule(.{
                    .root_source_file = b.path("dst/main.zig"),
                    .target = target,
                    .optimize = optimize,
                    .imports = &.{
                        .{ .name = "zkv", .module = zkv },
                        .{ .name = "hegel", .module = hegel.module("hegel") },
                    },
                }),
            });
            const run = b.addRunArtifact(dst);
            run.addPassthruArgs();
            b.step("dst", "deterministic simulation of crashes, faults and zombie writers").dependOn(&run.step);

            const mutants = b.addRunArtifact(hegel.artifact("hegel-mutants"));
            mutants.setCwd(b.path("."));
            mutants.addArgs(&.{ "dst/mutants.zon", "--", b.graph.zig_exe, "build", "dst", "-Dhegel", "-Doptimize=ReleaseSafe" });
            mutants.has_side_effects = true;
            b.step("mutants", "plant each mutant and count the seeds that catch it").dependOn(&mutants.step);
            const node_mutants = b.addRunArtifact(hegel.artifact("hegel-mutants"));
            node_mutants.setCwd(b.path("."));
            node_mutants.addArgs(&.{ "dst/node-mutants.zon", "--", b.graph.zig_exe, "build", "dst", "-Dhegel", "-Doptimize=ReleaseSafe", "--", "node" });
            node_mutants.has_side_effects = true;
            b.step("node-mutants", "plant each node log mutant and count the seeds that catch it").dependOn(&node_mutants.step);
        }
    }
}

//! HTTP Transport - wraps std.http.Client for AT Protocol requests
//!
//! provides a simple fetch() interface over zig's HTTP client.
//! requires std.Io for networking (zig 0.16+).

const std = @import("std");

/// Sent unless a caller overrides `user_agent`. std.http's default is
/// `zig/<version> (std.http)`, which tells a PDS operator nothing about who is
/// making the request or how to reach them. Anything crawling the network at
/// scale should say what it is: operators seeing unexplained load have no way
/// to ask about it otherwise, and every other atproto client on the network
/// identifies itself.
pub const default_user_agent = "zat/0.3.30 (+https://tangled.org/zat.dev/zat)";

pub const HttpTransport = struct {
    allocator: std.mem.Allocator,
    io: std.Io,
    http_client: std.http.Client,
    keep_alive: bool = true,
    /// Guards against a peer that accepts the connection and then trickles or
    /// stops. Without these a single slow origin holds a worker for as long as
    /// the caller's own deadline allows, and a pool of workers can sit "busy"
    /// while moving almost no bytes. Set any field to 0 to disable that check.
    stall: StallGuard = .{},
    /// Bounds connect, TLS, request send, and the wait for the response head —
    /// the phases StallGuard cannot see, because no body bytes exist yet. A
    /// peer that accepts and never answers, or a SYN that goes unanswered,
    /// otherwise blocks the caller until the kernel gives up (~2 minutes) or
    /// forever on an established socket. 0 disables.
    head_deadline_ns: u64 = 10 * std.time.ns_per_s,
    /// A pooled connection the origin closed while it sat idle looks identical
    /// to a request that failed, but nothing was ever delivered — so replaying
    /// an idempotent request on a fresh connection is safe, and skipping the
    /// replay turns routine housekeeping into a caller-visible error.
    dead_connection_attempts: usize = 3,
    /// Identify this client to the servers it calls. Applications built on zat
    /// should set their own; the default names zat so an operator can at least
    /// tell which library is calling.
    user_agent: []const u8 = default_user_agent,

    pub fn init(io: std.Io, allocator: std.mem.Allocator) HttpTransport {
        return .{
            .allocator = allocator,
            .io = io,
            .http_client = .{ .allocator = allocator, .io = io },
        };
    }

    /// Same as `init`, naming the calling application rather than zat.
    pub fn initWithUserAgent(io: std.Io, allocator: std.mem.Allocator, user_agent: []const u8) HttpTransport {
        var transport = init(io, allocator);
        if (user_agent.len > 0) transport.user_agent = user_agent;
        return transport;
    }

    pub fn deinit(self: *HttpTransport) void {
        self.http_client.deinit();
    }

    /// fetch a URL and write response to provided writer
    pub fn fetch(self: *HttpTransport, options: FetchOptions) !FetchResult {
        var headers: std.http.Client.Request.Headers = .{
            .content_type = if (options.payload != null) .{ .override = "application/json" } else .default,
            .user_agent = .{ .override = self.user_agent },
        };

        // apply custom headers
        if (options.authorization) |auth| {
            headers.authorization = .{ .override = auth };
        }
        if (options.content_type) |ct| {
            headers.content_type = .{ .override = ct };
        }

        // build extra headers array for accept and any custom headers
        var extra_buf: [8]std.http.Header = undefined;
        var extra_count: usize = 0;

        if (options.accept) |accept| {
            extra_buf[extra_count] = .{ .name = "accept", .value = accept };
            extra_count += 1;
        }

        if (options.extra_headers) |hdrs| {
            for (hdrs) |h| {
                if (extra_count < extra_buf.len) {
                    extra_buf[extra_count] = h;
                    extra_count += 1;
                }
            }
        }

        const extra = extra_buf[0..extra_count];
        var attempt: usize = 0;
        while (true) {
            attempt += 1;
            const result = self.fetchDeadlined(options, headers, extra);

            return result catch |err| {
                if (attempt < self.dead_connection_attempts and
                    isDeadConnection(err) and
                    isReplayable(options)) continue;
                return err;
            };
        }
    }

    const FetchProgress = struct {
        head_seen: std.atomic.Value(bool) = .init(false),
        done: std.atomic.Value(bool) = .init(false),
    };

    /// Run one fetch attempt under `head_deadline_ns`. The attempt runs as a
    /// task; the watcher cancels it if the response head has not arrived by
    /// the deadline. Once the head is seen the body is StallGuard's problem
    /// and the watcher steps aside.
    fn fetchDeadlined(
        self: *HttpTransport,
        options: FetchOptions,
        headers: std.http.Client.Request.Headers,
        extra_headers: []const std.http.Header,
    ) !FetchResult {
        var progress: FetchProgress = .{};
        if (self.head_deadline_ns == 0)
            return self.fetchOnce(options, headers, extra_headers, &progress);

        var future = self.io.async(fetchOnce, .{ self, options, headers, extra_headers, &progress });

        const tick_ns: u64 = 50 * std.time.ns_per_ms;
        var elapsed_ns: u64 = 0;
        while (!progress.done.load(.acquire)) {
            if (progress.head_seen.load(.acquire)) break;
            if (elapsed_ns >= self.head_deadline_ns) {
                if (future.cancel(self.io)) |completed| {
                    var result = completed;
                    result.deinit(self.allocator);
                } else |_| {}
                return error.ResponseHeadTimeout;
            }
            std.Io.Clock.Duration.sleep(
                .{ .raw = .fromNanoseconds(tick_ns), .clock = .awake },
                self.io,
            ) catch break;
            elapsed_ns += tick_ns;
        }

        return future.await(self.io);
    }

    fn fetchOnce(
        self: *HttpTransport,
        options: FetchOptions,
        headers: std.http.Client.Request.Headers,
        extra_headers: []const std.http.Header,
        progress: *FetchProgress,
    ) !FetchResult {
        defer progress.done.store(true, .release);
        if (options.resolved_connection) |resolved|
            return self.fetchResolved(options, resolved, headers, extra_headers, progress);
        return self.fetchUrl(options, headers, extra_headers, progress);
    }

    fn fetchUrl(
        self: *HttpTransport,
        options: FetchOptions,
        headers: std.http.Client.Request.Headers,
        extra_headers: []const std.http.Header,
        progress: *FetchProgress,
    ) !FetchResult {
        const uri = try std.Uri.parse(options.url);
        const redirect_behavior = redirectBehavior(options);
        var request = try self.http_client.request(options.method, uri, .{
            .headers = headers,
            .extra_headers = extra_headers,
            .keep_alive = self.keep_alive,
            .redirect_behavior = redirect_behavior,
        });
        defer request.deinit();

        if (options.payload) |payload| {
            request.transfer_encoding = .{ .content_length = payload.len };
            var body = try request.sendBodyUnflushed(&.{});
            try body.writer.writeAll(payload);
            try body.end();
            try request.connection.?.flush();
        } else {
            try request.sendBodiless();
        }

        const redirect_buffer = try self.allocRedirectBuffer(redirect_behavior);
        defer self.freeRedirectBuffer(redirect_buffer, redirect_behavior);

        var response = try request.receiveHead(redirect_buffer);
        progress.head_seen.store(true, .release);
        return try self.readFetchResult(options, &response);
    }

    fn fetchResolved(
        self: *HttpTransport,
        options: FetchOptions,
        resolved: ResolvedConnection,
        headers: std.http.Client.Request.Headers,
        extra_headers: []const std.http.Header,
        progress: *FetchProgress,
    ) !FetchResult {
        const uri = try std.Uri.parse(options.url);
        const protocol = std.http.Client.Protocol.fromUri(uri) orelse return error.UnsupportedUriScheme;

        var uri_host_buf: [std.Io.net.HostName.max_len]u8 = undefined;
        const uri_host = try uri.getHost(&uri_host_buf);
        if (!std.ascii.eqlIgnoreCase(uri_host.bytes, resolved.logical_host)) {
            return error.ResolvedHostMismatch;
        }

        const dial_host = try std.Io.net.HostName.init(resolved.dial_host);
        const logical_host = try std.Io.net.HostName.init(resolved.logical_host);
        const connection = try self.http_client.connectTcpOptions(.{
            .host = dial_host,
            .port = uri.port orelse defaultPort(protocol),
            .protocol = protocol,
            .proxied_host = logical_host,
        });

        const redirect_behavior = redirectBehavior(options);
        var request = self.http_client.request(options.method, uri, .{
            .connection = connection,
            .headers = headers,
            .extra_headers = extra_headers,
            .keep_alive = self.keep_alive,
            .redirect_behavior = redirect_behavior,
        }) catch |err| {
            self.http_client.connection_pool.release(connection, self.io);
            return err;
        };
        defer request.deinit();

        if (options.payload) |payload| {
            request.transfer_encoding = .{ .content_length = payload.len };
            var body = try request.sendBodyUnflushed(&.{});
            try body.writer.writeAll(payload);
            try body.end();
            try request.connection.?.flush();
        } else {
            try request.sendBodiless();
        }

        const redirect_buffer = try self.allocRedirectBuffer(redirect_behavior);
        defer self.freeRedirectBuffer(redirect_buffer, redirect_behavior);

        var response = try request.receiveHead(redirect_buffer);
        progress.head_seen.store(true, .release);
        return try self.readFetchResult(options, &response);
    }

    fn allocRedirectBuffer(self: *HttpTransport, behavior: std.http.Client.Request.RedirectBehavior) ![]u8 {
        if (behavior == .unhandled) return &.{};
        return try self.allocator.alloc(u8, 8 * 1024);
    }

    fn freeRedirectBuffer(self: *HttpTransport, buffer: []u8, behavior: std.http.Client.Request.RedirectBehavior) void {
        if (behavior != .unhandled) self.allocator.free(buffer);
    }

    fn readFetchResult(
        self: *HttpTransport,
        options: FetchOptions,
        response: *std.http.Client.Response,
    ) !FetchResult {
        const rate_limit = RateLimitHeaders.fromResponseHead(response.head);
        var oauth = if (options.capture_response_headers)
            try OAuthHeaders.fromResponseHead(self.allocator, response.head)
        else
            OAuthHeaders{};
        errdefer oauth.deinit(self.allocator);

        if (options.max_response_size) |max| {
            const body_buf = try self.allocator.alloc(u8, max);
            defer self.allocator.free(body_buf);
            var writer = std.Io.Writer.fixed(body_buf);
            const dbuf = try self.allocator.alloc(u8, decompressBufferLen(response.head.content_encoding));
            defer self.allocator.free(dbuf);
            try streamResponseBody(self.io, response, &writer, self.stall, dbuf);
            return .{
                .status = response.head.status,
                .body = try self.allocator.dupe(u8, writer.buffered()),
                .rate_limit = rate_limit,
                .oauth = oauth,
            };
        }

        var aw: std.Io.Writer.Allocating = .init(self.allocator);
        defer aw.deinit();
        const dbuf = try self.allocator.alloc(u8, decompressBufferLen(response.head.content_encoding));
        defer self.allocator.free(dbuf);
        try streamResponseBody(self.io, response, &aw.writer, self.stall, dbuf);
        return .{
            .status = response.head.status,
            .body = try self.allocator.dupe(u8, aw.written()),
            .rate_limit = rate_limit,
            .oauth = oauth,
        };
    }

    pub const FetchOptions = struct {
        url: []const u8,
        method: std.http.Method = .GET,
        payload: ?[]const u8 = null,
        authorization: ?[]const u8 = null,
        accept: ?[]const u8 = null,
        content_type: ?[]const u8 = null,
        extra_headers: ?[]const std.http.Header = null,
        max_response_size: ?usize = null,
        redirect_behavior: ?std.http.Client.Request.RedirectBehavior = null,
        resolved_connection: ?ResolvedConnection = null,
        capture_response_headers: bool = false,
    };

    pub const StallGuard = struct {
        /// Abort if no body bytes arrive for this long.
        idle_ns: u64 = 20 * std.time.ns_per_s,
        /// After `grace_ns`, abort if the average body rate is below this.
        /// Catches a trickle, which an idle timeout alone never fires on.
        min_bytes_per_s: u64 = 4 * 1024,
        /// Slow starts are normal; do not judge the rate before this.
        grace_ns: u64 = 10 * std.time.ns_per_s,
    };

    pub const ResolvedConnection = struct {
        /// Checked address to dial. Currently IPv4 text, which std.Io.net.HostName accepts.
        dial_host: []const u8,
        /// Original URL host, used by std.http for TLS/SNI and connection identity.
        logical_host: []const u8,
    };

    pub const FetchResult = struct {
        status: std.http.Status,
        body: []u8,
        rate_limit: RateLimitHeaders = .{},
        oauth: OAuthHeaders = .{},

        pub fn deinit(self: *FetchResult, allocator: std.mem.Allocator) void {
            allocator.free(self.body);
            self.oauth.deinit(allocator);
        }
    };

    pub const OAuthHeaders = struct {
        content_type: ?[]const u8 = null,
        dpop_nonce: ?[]const u8 = null,
        www_authenticate: ?[]const u8 = null,

        pub fn fromResponseHead(allocator: std.mem.Allocator, head: std.http.Client.Response.Head) !OAuthHeaders {
            var result: OAuthHeaders = .{};
            errdefer result.deinit(allocator);
            var it = head.iterateHeaders();
            while (it.next()) |header| {
                if (std.ascii.eqlIgnoreCase(header.name, "content-type")) {
                    result.content_type = try allocator.dupe(u8, header.value);
                } else if (std.ascii.eqlIgnoreCase(header.name, "dpop-nonce")) {
                    result.dpop_nonce = try allocator.dupe(u8, header.value);
                } else if (std.ascii.eqlIgnoreCase(header.name, "www-authenticate")) {
                    result.www_authenticate = try allocator.dupe(u8, header.value);
                }
            }
            return result;
        }

        pub fn deinit(self: *OAuthHeaders, allocator: std.mem.Allocator) void {
            if (self.content_type) |value| allocator.free(value);
            if (self.dpop_nonce) |value| allocator.free(value);
            if (self.www_authenticate) |value| allocator.free(value);
            self.* = .{};
        }
    };

    pub const RateLimitHeaders = struct {
        limit: ?u64 = null,
        remaining: ?u64 = null,
        reset: ?u64 = null,
        retry_after: ?u64 = null,

        pub fn fromResponseHead(head: std.http.Client.Response.Head) RateLimitHeaders {
            var result: RateLimitHeaders = .{};
            var it = head.iterateHeaders();
            while (it.next()) |header| {
                if (std.ascii.eqlIgnoreCase(header.name, "ratelimit-limit")) {
                    result.limit = parseHeaderInt(header.value);
                } else if (std.ascii.eqlIgnoreCase(header.name, "ratelimit-remaining")) {
                    result.remaining = parseHeaderInt(header.value);
                } else if (std.ascii.eqlIgnoreCase(header.name, "ratelimit-reset")) {
                    result.reset = parseHeaderInt(header.value);
                } else if (std.ascii.eqlIgnoreCase(header.name, "retry-after")) {
                    result.retry_after = parseHeaderInt(header.value);
                }
            }
            return result;
        }

        pub fn isEmpty(self: RateLimitHeaders) bool {
            return self.limit == null and self.remaining == null and self.reset == null and self.retry_after == null;
        }
    };
};

fn redirectBehavior(options: HttpTransport.FetchOptions) std.http.Client.Request.RedirectBehavior {
    return options.redirect_behavior orelse if (options.payload == null)
        std.http.Client.Request.RedirectBehavior.init(3)
    else
        .unhandled;
}

fn parseHeaderInt(value: []const u8) ?u64 {
    const trimmed = std.mem.trim(u8, value, " \t");
    return std.fmt.parseInt(u64, trimmed, 10) catch null;
}

const StreamProgress = struct {
    bytes: std.atomic.Value(u64) = .init(0),
    done: std.atomic.Value(bool) = .init(false),
};

fn streamBody(
    response: *std.http.Client.Response,
    writer: *std.Io.Writer,
    decompress_buffer: []u8,
    progress: *StreamProgress,
) !void {
    defer progress.done.store(true, .release);

    var transfer_buffer: [8 * 1024]u8 = undefined;
    var decompress: std.http.Decompress = undefined;
    const reader = response.readerDecompressing(&transfer_buffer, &decompress, decompress_buffer);

    var chunk: [64 * 1024]u8 = undefined;
    while (true) {
        var slices = [_][]u8{&chunk};
        const n = reader.readVec(&slices) catch |err| switch (err) {
            error.EndOfStream => return,
            // Null when the read was canceled rather than failing on its own.
            error.ReadFailed => return response.bodyErr() orelse error.ReadFailed,
            else => |e| return e,
        };
        if (n == 0) continue;
        writer.writeAll(chunk[0..n]) catch return error.ResponseTooLarge;
        _ = progress.bytes.fetchAdd(n, .release);
    }
}

/// A wall-clock check placed *after* a read cannot fire, because a peer that
/// simply stops sending leaves that read blocked in the kernel forever. So the
/// read runs as a task and the caller watches its byte counter, canceling when
/// progress dies.
fn streamResponseBody(
    io: std.Io,
    response: *std.http.Client.Response,
    writer: *std.Io.Writer,
    guard: HttpTransport.StallGuard,
    decompress_buffer: []u8,
) !void {
    var progress: StreamProgress = .{};
    if (guard.idle_ns == 0 and guard.min_bytes_per_s == 0)
        return streamBody(response, writer, decompress_buffer, &progress);

    var future = io.async(streamBody, .{ response, writer, decompress_buffer, &progress });

    const tick_ns: u64 = 100 * std.time.ns_per_ms;
    var idle_ns: u64 = 0;
    var elapsed_ns: u64 = 0;
    var last_bytes: u64 = 0;

    while (!progress.done.load(.acquire)) {
        std.Io.Clock.Duration.sleep(
            .{ .raw = .fromNanoseconds(tick_ns), .clock = .awake },
            io,
        ) catch break;
        elapsed_ns += tick_ns;

        const seen = progress.bytes.load(.acquire);
        if (seen != last_bytes) {
            last_bytes = seen;
            idle_ns = 0;
        } else {
            idle_ns += tick_ns;
        }

        if (guard.idle_ns != 0 and idle_ns >= guard.idle_ns) {
            future.cancel(io) catch {};
            return error.TransferStalled;
        }
        if (guard.min_bytes_per_s != 0 and elapsed_ns >= guard.grace_ns) {
            const secs = elapsed_ns / std.time.ns_per_s;
            if (secs > 0 and seen / secs < guard.min_bytes_per_s) {
                future.cancel(io) catch {};
                return error.TransferTooSlow;
            }
        }
    }

    return future.await(io);
}

/// The peer hung up without answering. Distinct from a mid-body failure: no
/// part of a response was seen, so the request provably did not take effect.
fn isDeadConnection(err: anyerror) bool {
    return switch (err) {
        error.ConnectionResetByPeer,
        error.BrokenPipe,
        error.EndOfStream,
        error.UnexpectedWriteFailure,
        error.HttpConnectionClosing,
        => true,
        else => false,
    };
}

fn isReplayable(options: HttpTransport.FetchOptions) bool {
    if (options.payload != null) return false;
    return switch (options.method) {
        .GET, .HEAD, .OPTIONS => true,
        else => false,
    };
}

/// A zero-length buffer works only while every response is `identity`; gzip
/// needs a real window. Sizing from the negotiated encoding keeps the identity
/// path allocation-free in practice (0 bytes) without capping compressed ones.
fn decompressBufferLen(encoding: std.http.ContentEncoding) usize {
    return encoding.minBufferCapacity();
}

fn defaultPort(protocol: std.http.Client.Protocol) u16 {
    return switch (protocol) {
        .plain => 80,
        .tls => 443,
    };
}

// === tests ===

test "transport init/deinit" {
    const io = std.Options.debug_io;
    var transport = HttpTransport.init(io, std.testing.allocator);
    defer transport.deinit();
}

test "transport fixed writer maps overflow to ResponseTooLarge" {
    var buf: [0]u8 = .{};
    var writer = std.Io.Writer.fixed(&buf);
    try std.testing.expectError(error.WriteFailed, writer.writeAll("x"));
}

test "resolved transport rejects mismatched logical host" {
    const io = std.Options.debug_io;
    var transport = HttpTransport.init(io, std.testing.allocator);
    defer transport.deinit();

    try std.testing.expectError(error.ResolvedHostMismatch, transport.fetch(.{
        .url = "http://example.com/",
        .resolved_connection = .{
            .dial_host = "127.0.0.1",
            .logical_host = "other.example",
        },
    }));
}

test "transport parses rate limit headers" {
    const response_bytes = "HTTP/1.1 429 Too Many Requests\r\n" ++
        "RateLimit-Limit: 3000\r\n" ++
        "ratelimit-remaining: 0\r\n" ++
        "RateLimit-Reset: 1710000000\r\n" ++
        "Retry-After: 2\r\n\r\n";

    const head = try std.http.Client.Response.Head.parse(response_bytes);
    const headers = HttpTransport.RateLimitHeaders.fromResponseHead(head);

    try std.testing.expectEqual(@as(?u64, 3000), headers.limit);
    try std.testing.expectEqual(@as(?u64, 0), headers.remaining);
    try std.testing.expectEqual(@as(?u64, 1710000000), headers.reset);
    try std.testing.expectEqual(@as(?u64, 2), headers.retry_after);
    try std.testing.expect(!headers.isEmpty());
}

test "transport parses oauth headers" {
    const response_bytes = "HTTP/1.1 401 Unauthorized\r\n" ++
        "DPoP-Nonce: nonce-123\r\n" ++
        "WWW-Authenticate: DPoP error=\"use_dpop_nonce\"\r\n\r\n";

    const head = try std.http.Client.Response.Head.parse(response_bytes);
    var headers = try HttpTransport.OAuthHeaders.fromResponseHead(std.testing.allocator, head);
    defer headers.deinit(std.testing.allocator);

    try std.testing.expectEqualStrings("nonce-123", headers.dpop_nonce.?);
    try std.testing.expectEqualStrings("DPoP error=\"use_dpop_nonce\"", headers.www_authenticate.?);
}

test "transport parses oauth content type header" {
    const response_bytes = "HTTP/1.1 200 OK\r\n" ++
        "Content-Type: application/json; charset=utf-8\r\n\r\n";

    const head = try std.http.Client.Response.Head.parse(response_bytes);
    var headers = try HttpTransport.OAuthHeaders.fromResponseHead(std.testing.allocator, head);
    defer headers.deinit(std.testing.allocator);

    try std.testing.expectEqualStrings("application/json; charset=utf-8", headers.content_type.?);
}

test "requests identify the client, and applications can name themselves" {
    // A PDS operator seeing load should be able to tell what is calling and
    // where to ask about it. std.http's default says neither.
    const testing = std.testing;
    var threaded: std.Io.Threaded = .init(testing.allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    var default_transport = HttpTransport.init(io, testing.allocator);
    defer default_transport.deinit();
    try testing.expectEqualStrings(default_user_agent, default_transport.user_agent);
    try testing.expect(std.mem.indexOf(u8, default_transport.user_agent, "http") != null);

    var named = HttpTransport.initWithUserAgent(io, testing.allocator, "stream/1.2.3 (+https://example.invalid)");
    defer named.deinit();
    try testing.expectEqualStrings("stream/1.2.3 (+https://example.invalid)", named.user_agent);

    // An empty override must not silently erase the identity.
    var empty = HttpTransport.initWithUserAgent(io, testing.allocator, "");
    defer empty.deinit();
    try testing.expectEqualStrings(default_user_agent, empty.user_agent);
}

// A loopback origin for transport tests. Each canned response is served on its
// own accepted connection; `serve` runs on a thread so the client can drive the
// exchange from the test body.
const TestOrigin = struct {
    listener: std.Io.net.Server,
    io: std.Io,

    fn init(io: std.Io) !TestOrigin {
        return .{
            .listener = try (std.Io.net.IpAddress{ .ip4 = .loopback(0) }).listen(io, .{ .reuse_address = true }),
            .io = io,
        };
    }
    fn deinit(self: *TestOrigin) void {
        self.listener.deinit(self.io);
    }
    fn port(self: *const TestOrigin) u16 {
        return self.listener.socket.address.getPort();
    }

    /// Accept one connection, read the request head, write `response` verbatim.
    /// Answers with headers promising a long body, dribbles a few bytes, then
    /// goes quiet — the shape of the slow-PDS transfers that pin a worker.
    fn serveStalling(self: *TestOrigin) !void {
        var conn = try self.listener.accept(self.io);
        defer conn.close(self.io);
        var rbuf: [4096]u8 = undefined;
        var reader = conn.reader(self.io, &rbuf);
        var scratch: [2048]u8 = undefined;
        var slices = [_][]u8{&scratch};
        _ = reader.interface.readVec(&slices) catch {};
        var wbuf: [4096]u8 = undefined;
        var writer = conn.writer(self.io, &wbuf);
        try writer.interface.writeAll(
            "HTTP/1.1 200 OK\r\nContent-Length: 1048576\r\n\r\nhello",
        );
        try writer.interface.flush();
        // Send nothing further and block until the client hangs up. A guarded
        // client returns quickly; an unguarded one waits here forever.
        var sink: [1]u8 = undefined;
        var tail = [_][]u8{&sink};
        _ = reader.interface.readVec(&tail) catch {};
    }

    /// Accepts, reads the request, then never answers — the shape of the
    /// wedged authority checks in the 2026-08-13 zlay stall: connection
    /// established, response head never arrives, nothing for StallGuard to
    /// measure.
    fn serveSilent(self: *TestOrigin) !void {
        var conn = try self.listener.accept(self.io);
        defer conn.close(self.io);
        var rbuf: [4096]u8 = undefined;
        var reader = conn.reader(self.io, &rbuf);
        var scratch: [2048]u8 = undefined;
        var slices = [_][]u8{&scratch};
        _ = reader.interface.readVec(&slices) catch {};
        // Say nothing and block until the client hangs up.
        var sink: [1]u8 = undefined;
        var tail = [_][]u8{&sink};
        _ = reader.interface.readVec(&tail) catch {};
    }

    /// Accepts, reads the request, then hangs up without answering — what a
    /// pooled connection reaped by the origin looks like on next reuse.
    fn serveDeadThenOk(self: *TestOrigin, response: []const u8) !void {
        {
            var dead = try self.listener.accept(self.io);
            var rbuf: [4096]u8 = undefined;
            var reader = dead.reader(self.io, &rbuf);
            var scratch: [2048]u8 = undefined;
            var slices = [_][]u8{&scratch};
            _ = reader.interface.readVec(&slices) catch {};
            dead.close(self.io);
        }
        try self.serveOnce(response);
    }

    fn serveOnce(self: *TestOrigin, response: []const u8) !void {
        var conn = try self.listener.accept(self.io);
        defer conn.close(self.io);
        var rbuf: [4096]u8 = undefined;
        var reader = conn.reader(self.io, &rbuf);
        // Read whatever the client sent; the request content is irrelevant here.
        var scratch: [2048]u8 = undefined;
        var slices = [_][]u8{&scratch};
        _ = reader.interface.readVec(&slices) catch {};
        var wbuf: [4096]u8 = undefined;
        var writer = conn.writer(self.io, &wbuf);
        try writer.interface.writeAll(response);
        try writer.interface.flush();
    }
};

test "gzip responses decode: the identity override was covering an empty decompress buffer" {
    const testing = std.testing;
    var threaded: std.Io.Threaded = .init(testing.allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    var origin = try TestOrigin.init(io);
    defer origin.deinit();

    // gzip of "hello zat" produced at comptime would need a compressor; instead
    // assert the *identity* path still works through readerDecompressing with a
    // real buffer, which is the change under test. A gzip body is exercised by
    // the live network suite.
    const body = "hello zat";
    var resp_buf: [256]u8 = undefined;
    const response = try std.fmt.bufPrint(&resp_buf, "HTTP/1.1 200 OK\r\nContent-Length: {d}\r\nConnection: close\r\n\r\n{s}", .{ body.len, body });

    const T = struct {
        fn run(o: *TestOrigin, r: []const u8) void {
            o.serveOnce(r) catch {};
        }
    };
    var th = try std.Thread.spawn(.{}, T.run, .{ &origin, response });
    defer th.join();

    var transport = HttpTransport.init(io, testing.allocator);
    defer transport.deinit();
    transport.keep_alive = false;

    var url_buf: [64]u8 = undefined;
    const url = try std.fmt.bufPrint(&url_buf, "http://127.0.0.1:{d}/", .{origin.port()});

    var res = try transport.fetch(.{ .url = url });
    defer res.deinit(testing.allocator);
    try testing.expectEqual(std.http.Status.ok, res.status);
    try testing.expectEqualStrings(body, res.body);
}

test "a stalled transfer is abandoned instead of pinning the caller" {
    const allocator = std.testing.allocator;
    var threaded: std.Io.Threaded = .init(allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    var origin = try TestOrigin.init(io);
    defer origin.deinit();
    const url = try std.fmt.allocPrint(allocator, "http://127.0.0.1:{d}/stall", .{origin.port()});
    defer allocator.free(url);

    var server = try std.Thread.spawn(.{}, struct {
        fn run(o: *TestOrigin) void {
            o.serveStalling() catch {};
        }
    }.run, .{&origin});
    defer server.join();

    var transport = HttpTransport.init(io, allocator);
    defer transport.deinit();
    transport.stall = .{
        .idle_ns = 400 * std.time.ns_per_ms,
        .min_bytes_per_s = 0,
        .grace_ns = 0,
    };

    // Unguarded, this call never returns: the origin holds the connection open
    // and simply stops sending.
    try std.testing.expectError(error.TransferStalled, transport.fetch(.{ .url = url }));
}

test "a gzip response decodes: the identity override was covering an empty decompress buffer" {
    const allocator = std.testing.allocator;
    var threaded: std.Io.Threaded = .init(allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    const payload = "zat" ** 512;
    var gz_buf: [64 * 1024]u8 = undefined;
    var gz = std.Io.Writer.fixed(&gz_buf);
    {
        var flate_buf: [std.compress.flate.max_window_len]u8 = undefined;
        var comp: std.compress.flate.Compress = try .init(&gz, &flate_buf, .gzip, .default);
        try comp.writer.writeAll(payload);
        try comp.finish();
    }

    var origin = try TestOrigin.init(io);
    defer origin.deinit();
    const url = try std.fmt.allocPrint(allocator, "http://127.0.0.1:{d}/gz", .{origin.port()});
    defer allocator.free(url);

    const response = try std.fmt.allocPrint(
        allocator,
        "HTTP/1.1 200 OK\r\nContent-Encoding: gzip\r\nContent-Length: {d}\r\n\r\n{s}",
        .{ gz.buffered().len, gz.buffered() },
    );
    defer allocator.free(response);

    var server = try std.Thread.spawn(.{}, struct {
        fn run(o: *TestOrigin, r: []const u8) void {
            o.serveOnce(r) catch {};
        }
    }.run, .{ &origin, response });
    defer server.join();

    var transport = HttpTransport.init(io, allocator);
    defer transport.deinit();
    var res = transport.fetch(.{ .url = url }) catch |err| {
        std.debug.print("fetch failed: {t}\n", .{err});
        return err;
    };
    defer res.deinit(allocator);

    try std.testing.expectEqualStrings(payload, res.body);
}

test "a peer that accepts and never answers is abandoned at the head deadline" {
    const allocator = std.testing.allocator;
    var threaded: std.Io.Threaded = .init(allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    var origin = try TestOrigin.init(io);
    defer origin.deinit();
    const url = try std.fmt.allocPrint(allocator, "http://127.0.0.1:{d}/silent", .{origin.port()});
    defer allocator.free(url);

    var server = try std.Thread.spawn(.{}, struct {
        fn run(o: *TestOrigin) void {
            o.serveSilent() catch {};
        }
    }.run, .{&origin});
    defer server.join();

    var transport = HttpTransport.init(io, allocator);
    defer transport.deinit();
    transport.head_deadline_ns = 300 * std.time.ns_per_ms;

    // Unguarded, this call sits in receiveHead until the peer or kernel gives
    // up — for a wedged keep-alive socket, never.
    try std.testing.expectError(error.ResponseHeadTimeout, transport.fetch(.{ .url = url }));
}

test "a connection closed before it answers is replayed, not surfaced" {
    const allocator = std.testing.allocator;
    var threaded: std.Io.Threaded = .init(allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();

    var origin = try TestOrigin.init(io);
    defer origin.deinit();
    const url = try std.fmt.allocPrint(allocator, "http://127.0.0.1:{d}/x", .{origin.port()});
    defer allocator.free(url);

    var server = try std.Thread.spawn(.{}, struct {
        fn run(o: *TestOrigin) void {
            o.serveDeadThenOk("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok") catch {};
        }
    }.run, .{&origin});
    defer server.join();

    var transport = HttpTransport.init(io, allocator);
    defer transport.deinit();

    var res = try transport.fetch(.{ .url = url });
    defer res.deinit(allocator);
    try std.testing.expectEqual(std.http.Status.ok, res.status);
    try std.testing.expectEqualStrings("ok", res.body);
}

test "a request that may have taken effect is never replayed" {
    try std.testing.expect(!isReplayable(.{ .url = "http://x/", .method = .POST }));
    try std.testing.expect(!isReplayable(.{ .url = "http://x/", .method = .GET, .payload = "b" }));
    try std.testing.expect(isReplayable(.{ .url = "http://x/", .method = .GET }));
}

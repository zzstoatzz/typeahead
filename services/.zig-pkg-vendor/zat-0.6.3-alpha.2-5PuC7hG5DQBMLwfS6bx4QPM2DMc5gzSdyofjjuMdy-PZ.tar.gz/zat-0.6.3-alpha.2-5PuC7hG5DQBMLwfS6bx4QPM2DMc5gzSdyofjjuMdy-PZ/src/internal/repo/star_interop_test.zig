//! STAR v1 interop fixtures. Every valid archive reads to the listed pairs and
//! rewrites through Writer to the same bytes; every invalid archive fails.
//! Fixture source: testdata/star-interop.md.
const std = @import("std");
const star = @import("star.zig");

const Pair = struct { key_hex: []const u8, value_hex: []const u8 };
const Fixture = struct {
    comment: []const u8,
    star_hex: []const u8,
    decoded: ?struct { pairs: []const Pair } = null,
};

fn parse(allocator: std.mem.Allocator, json: []const u8) !std.json.Parsed([]const Fixture) {
    return std.json.parseFromSlice([]const Fixture, allocator, json, .{ .ignore_unknown_fields = true, .allocate = .alloc_always });
}

fn hexToBytes(allocator: std.mem.Allocator, hex: []const u8) ![]u8 {
    const out = try allocator.alloc(u8, hex.len / 2);
    errdefer allocator.free(out);
    _ = try std.fmt.hexToBytes(out, hex);
    return out;
}

fn drain(allocator: std.mem.Allocator, bytes: []const u8) !void {
    var input = std.Io.Reader.fixed(bytes);
    var reader = try star.Reader.init(allocator, &input, .{});
    defer reader.deinit();
    var buffer: [256]u8 = undefined;
    while (try reader.next()) |entry| {
        var left = entry.value_len;
        while (left > 0) left -= try reader.readValue(&buffer);
    }
}

test "valid interop archives read to their pairs and rewrite byte for byte" {
    const a = std.testing.allocator;
    const fixtures = try parse(a, @embedFile("testdata/star-interop-valid.json"));
    defer fixtures.deinit();
    try std.testing.expectEqual(@as(usize, 13), fixtures.value.len);
    for (fixtures.value) |fixture| {
        errdefer std.debug.print("fixture: {s}\n", .{fixture.comment});
        const bytes = try hexToBytes(a, fixture.star_hex);
        defer a.free(bytes);
        var input = std.Io.Reader.fixed(bytes);
        var reader = try star.Reader.init(a, &input, .{});
        defer reader.deinit();
        var out: std.Io.Writer.Allocating = .init(a);
        defer out.deinit();
        var writer = try star.Writer.init(a, &out.writer, reader.metadata, .{});
        defer writer.deinit();
        const pairs = fixture.decoded.?.pairs;
        var index: usize = 0;
        while (try reader.next()) |entry| : (index += 1) {
            const key = try hexToBytes(a, pairs[index].key_hex);
            defer a.free(key);
            const value = try hexToBytes(a, pairs[index].value_hex);
            defer a.free(value);
            try std.testing.expectEqualSlices(u8, key, entry.key);
            try std.testing.expectEqual(value.len, entry.value_len);
            const read = try a.alloc(u8, value.len);
            defer a.free(read);
            try std.testing.expectEqual(value.len, try reader.readValue(read));
            try std.testing.expectEqualSlices(u8, value, read);
            try writer.writePair(entry.key, value);
        }
        try std.testing.expectEqual(pairs.len, index);
        try writer.finish();
        try std.testing.expectEqualSlices(u8, bytes, out.written());
    }
}

test "invalid interop archives fail on read" {
    const a = std.testing.allocator;
    inline for (.{ "testdata/star-interop-invalid.json", "testdata/star-interop-invalid-varint.json" }) |path| {
        const fixtures = try parse(a, @embedFile(path));
        defer fixtures.deinit();
        try std.testing.expect(fixtures.value.len > 0);
        for (fixtures.value) |fixture| {
            errdefer std.debug.print("fixture: {s}\n", .{fixture.comment});
            const bytes = try hexToBytes(a, fixture.star_hex);
            defer a.free(bytes);
            try std.testing.expectError(error.Rejected, drain(a, bytes) catch error.Rejected);
        }
    }
}

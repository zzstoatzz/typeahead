//! Batch Log Record Processor Implementation
//!
//! This module provides the BatchLogRecordProcessor implementation for processing log records
//! in the OpenTelemetry SDK. The BatchLogRecordProcessor collects log records and exports them
//! in batches at regular intervals using a background thread.
//!
//! See: https://github.com/open-telemetry/opentelemetry-specification/blob/main/specification/logs/sdk.md#logrecordprocessor

const std = @import("std");
const io = std.Options.debug_io;const api = @import("otel-api");

const sdk = struct {
    const Resource = @import("../resource/resource.zig").Resource;
    const LogRecord = @import("log_record.zig").LogRecord;
    const LogRecordExporter = @import("exporter.zig").LogRecordExporter;
    const LogRecordProcessor = @import("processor.zig").LogRecordProcessor;
    const BridgeLogRecordProcessor = @import("processor.zig").BridgeLogRecordProcessor;
};

/// Configuration for BatchLogRecordProcessor PipelineStep
pub const BatchConfig = struct {
    export_interval_ms: ?u32 = null,
    max_queue_size: ?usize = null,
};

/// Batch log record processor that exports log records at regular intervals
pub const BatchLogRecordProcessor = struct {
    pub const PipelineStep = @import("../common/pipeline.zig").PipelineStepInstructions(
        BatchLogRecordProcessor,
        sdk.LogRecordProcessor,
        BatchConfig,
        logProcessor,
        _initFn,
        setExporter,
    );

    pub fn _initFn(self: *BatchLogRecordProcessor, config: BatchConfig, allocator: std.mem.Allocator) !void {
        self.* = .{
            .allocator = allocator,
            .exporter = sdk.LogRecordExporter{ .noop = {} },
            .mutex = std.Io.Mutex.init,
            .condition = std.Io.Condition.init,
            .is_shutdown = .init(false),
            .is_running = .init(false),
            .flush_in_progress = .init(false),
            .export_in_progress = .init(false),
            .flush_complete = std.Io.Condition.init,
            .export_complete = std.Io.Condition.init,
            .thread = null,
            .export_interval_ms = config.export_interval_ms orelse 5000,
            .max_queue_size = config.max_queue_size orelse 2048,
            .log_queue = .empty,
            .resource = @import("../resource/resource.zig").Resource.empty,
        };
        try self.start();
    }

    allocator: std.mem.Allocator,
    exporter: sdk.LogRecordExporter,
    mutex: std.Io.Mutex,
    condition: std.Io.Condition = std.Io.Condition.init,
    is_shutdown: std.atomic.Value(bool),
    is_running: std.atomic.Value(bool),
    flush_in_progress: std.atomic.Value(bool),
    export_in_progress: std.atomic.Value(bool),
    flush_complete: std.Io.Condition = std.Io.Condition.init,
    export_complete: std.Io.Condition = std.Io.Condition.init,
    thread: ?std.Thread,
    export_interval_ms: u32,
    max_queue_size: usize,
    log_queue: std.ArrayList(sdk.LogRecord),
    /// Resource captured from the LoggerProvider via `onEmit`. The OTEL spec
    /// guarantees one resource per provider, so we store the most recently
    /// seen value (cheap — just two pointers; ownership stays with the
    /// provider). Without this the exporter receives `Resource.empty` and
    /// records arrive at the collector without `service.name`, attributed
    /// to `unknown_service`.
    resource: sdk.Resource,

    /// Initialize a new batch log record processor
    /// export_interval_ms: How often to export log records (default: 5000ms = 5s)
    /// max_queue_size: Maximum log records to queue before dropping (default: 2048)
    ///
    /// Owner of the processor must destroy the memory.
    pub fn init(
        allocator: std.mem.Allocator,
        exporter: sdk.LogRecordExporter,
        export_interval_ms: ?u32,
        max_queue_size: ?usize,
    ) !*BatchLogRecordProcessor {
        const self = try allocator.create(BatchLogRecordProcessor);
        errdefer allocator.destroy(self);

        self.* = .{
            .allocator = allocator,
            .exporter = exporter,
            .mutex = std.Io.Mutex.init,
            .condition = std.Io.Condition.init,
            .is_shutdown = .init(false),
            .is_running = .init(false),
            .flush_in_progress = .init(false),
            .export_in_progress = .init(false),
            .flush_complete = std.Io.Condition.init,
            .export_complete = std.Io.Condition.init,
            .thread = null,
            .export_interval_ms = export_interval_ms orelse 5000,
            .max_queue_size = max_queue_size orelse 2048,
            .log_queue = .empty,
            .resource = @import("../resource/resource.zig").Resource.empty,
        };

        return self;
    }

    pub fn setExporter(self: *BatchLogRecordProcessor, exporter: ?sdk.LogRecordExporter) !void {
        self.exporter.deinit();
        self.exporter.destroy();
        self.exporter = exporter orelse sdk.LogRecordExporter{ .noop = {} };
    }

    /// Start the background export thread
    pub fn start(self: *BatchLogRecordProcessor) !void {
        if (self.is_running.swap(true, .seq_cst)) {
            return; // Already running
        }

        self.thread = try std.Thread.spawn(.{}, exportThreadFn, .{self});
    }

    /// Stop and cleanup the processor
    pub fn deinit(self: *BatchLogRecordProcessor) void {
        // Signal shutdown
        self.is_shutdown.store(true, .release);

        // Wake up the export thread
        self.mutex.lockUncancelable(io);
        self.condition.broadcast(io);
        self.mutex.unlock(io);

        // Wait for thread to finish
        if (self.thread) |thread| {
            thread.join();
        }

        // Export any remaining log records
        self.mutex.lockUncancelable(io);
        _ = self.exportBatchLocked();

        // Clean up remaining log records
        for (self.log_queue.items) |record| {
            record.deinitOwned(self.allocator);
        }
        self.log_queue.deinit(self.allocator);
        self.mutex.unlock(io);

        // Clean up exporter
        self.exporter.deinit();
        self.exporter.destroy();
    }

    pub fn destroy(self: *BatchLogRecordProcessor) void {
        self.allocator.destroy(self);
    }

    pub fn onEmit(self: *BatchLogRecordProcessor, record: sdk.LogRecord, ctx: []const api.ContextKeyValue, resource: sdk.Resource) void {
        _ = ctx;

        self.mutex.lockUncancelable(io);
        defer self.mutex.unlock(io);

        // Capture the LoggerProvider's resource so it travels with the batch
        // export. Each call from a given provider passes the same resource;
        // we don't deep-copy because the provider owns the underlying
        // attribute slice and outlives this processor.
        self.resource = resource;

        if (self.is_shutdown.load(.acquire)) {
            return;
        }

        // Drop newest if queue is full
        if (self.log_queue.items.len >= self.max_queue_size) {
            return;
        }

        // Clone log record for queuing
        var owned_record = sdk.LogRecord.initOwned(self.allocator, record) catch |err| {
            const message_body = if (record.body) |body| switch (body) {
                .string => |s| s,
                else => "(complex body)",
            } else "(no body)";

            api.common.reportError(.{
                .component = .processor,
                .operation = "log_clone",
                .error_type = .resource_exhausted,
                .message = "Failed to clone log record for batching",
                .context = message_body,
                .source_error = err,
            });
            return;
        };

        // Add cloned log record to queue
        self.log_queue.append(self.allocator, owned_record) catch |err| {
            owned_record.deinitOwned(self.allocator);

            const message_body = if (record.body) |body| switch (body) {
                .string => |s| s,
                else => "(complex body)",
            } else "(no body)";

            api.common.reportError(.{
                .component = .processor,
                .operation = "queue_append",
                .error_type = .resource_exhausted,
                .message = "Log record queue overflow, dropping record",
                .context = message_body,
                .source_error = err,
            });
            return;
        };
    }

    /// Force export all queued log records immediately
    pub fn forceFlush(self: *BatchLogRecordProcessor, timeout_ms: ?u64) api.common.FlushResult {
        // Quick check without mutex
        if (self.is_shutdown.load(.acquire)) {
            return .failure;
        }

        const start_time = @as(i64, @intCast(@divFloor(std.Io.Timestamp.now(io, .real).nanoseconds, std.time.ns_per_ms)));

        self.mutex.lockUncancelable(io);
        defer self.mutex.unlock(io);

        // Try to set flush_in_progress atomically
        const was_flushing = self.flush_in_progress.swap(true, .seq_cst);
        if (was_flushing) {
            // Another flush is in progress, wait for it
            const remaining_ms = if (timeout_ms) |ms|
                ms -| @as(u64, @intCast(@as(i64, @intCast(@divFloor(std.Io.Timestamp.now(io, .real).nanoseconds, std.time.ns_per_ms))) - start_time))
            else
                null;

            if (remaining_ms == 0) {
                return .timeout;
            }

            self.flush_complete.waitUncancelable(io, &self.mutex);
            return .success;
        }

        defer {
            self.flush_in_progress.store(false, .release);
            self.flush_complete.broadcast(io);
        }

        // Wait for any export in progress
        while (self.export_in_progress.load(.acquire)) {
            self.export_complete.waitUncancelable(io, &self.mutex);
        }

        // Now do the export with atomic flag
        self.export_in_progress.store(true, .release);
        defer {
            self.export_in_progress.store(false, .release);
            self.export_complete.broadcast(io);
        }

        // Export log records (mutex is held)
        if (self.log_queue.items.len > 0) {
            const result = self.exportBatchLocked();
            if (result != .success) {
                return .failure;
            }
        }

        // Flush the exporter
        self.mutex.unlock(io);
        const flush_result = self.exporter.forceFlush(timeout_ms);
        self.mutex.lockUncancelable(io);

        return flush_result.asFlushResult();
    }

    pub fn shutdown(self: *BatchLogRecordProcessor, timeout_ms: ?u64) api.common.ProcessResult {
        // Signal shutdown
        self.is_shutdown.store(true, .release);

        // Force flush remaining records
        const result = self.forceFlush(timeout_ms);

        // Shutdown the exporter
        const shutdown_result = self.exporter.shutdown(timeout_ms);

        return if (result == .success and shutdown_result == .success)
            .success
        else
            .failure;
    }

    /// Export a batch of log records (must be called with mutex held)
    fn exportBatchLocked(self: *BatchLogRecordProcessor) api.common.ExportResult {
        if (self.log_queue.items.len == 0) {
            return .success;
        }

        // Export log records directly from queue
        // Temporarily release mutex for export
        self.mutex.unlock(io);
        const result = self.exporter.exportRecords(self.log_queue.items, self.resource);
        self.mutex.lockUncancelable(io);

        // Clean up exported records
        for (self.log_queue.items) |record| {
            record.deinitOwned(self.allocator);
        }
        self.log_queue.clearRetainingCapacity();

        return result;
    }

    /// Background thread function for periodic exports
    fn exportThreadFn(self: *BatchLogRecordProcessor) void {
        while (true) {
            // Fast path check without mutex
            if (self.is_shutdown.load(.acquire)) {
                break;
            }

            self.mutex.lockUncancelable(io);
            defer self.mutex.unlock(io);

            // Double-check under mutex
            if (self.is_shutdown.load(.acquire)) {
                break;
            }

            // Sleep for the export interval, releasing the mutex
            const wait_ns: i96 = @intCast(@as(u64, self.export_interval_ms) * std.time.ns_per_ms);
            self.mutex.unlock(io);
            io.sleep(.{ .nanoseconds = wait_ns }, .real) catch {};
            self.mutex.lockUncancelable(io);

            // Skip if flush is in progress
            if (self.flush_in_progress.load(.acquire)) {
                continue;
            }

            // Try to acquire export lock
            if (self.export_in_progress.swap(true, .seq_cst)) {
                // Already exporting, skip this cycle
                continue;
            }

            defer {
                self.export_in_progress.store(false, .release);
                self.export_complete.broadcast(io);
            }

            // Do the export
            _ = self.exportBatchLocked();
        }
    }

    pub fn logProcessor(self: *BatchLogRecordProcessor) sdk.LogRecordProcessor {
        return sdk.LogRecordProcessor{ .bridge = sdk.BridgeLogRecordProcessor.init(self) };
    }
};

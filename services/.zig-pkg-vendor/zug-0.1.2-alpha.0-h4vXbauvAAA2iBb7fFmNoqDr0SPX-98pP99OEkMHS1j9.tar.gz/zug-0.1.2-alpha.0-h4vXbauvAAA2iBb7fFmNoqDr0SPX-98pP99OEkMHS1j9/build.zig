const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const mod = b.addModule("zug", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
    });

    const tests = b.addTest(.{ .root_module = mod });
    const run_tests = b.addRunArtifact(tests);

    const test_step = b.step("test", "run unit tests");
    test_step.dependOn(&run_tests.step);

    const smoke = b.addExecutable(.{
        .name = "zug-smoke",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/smoke/main.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "zug", .module = mod }},
        }),
    });
    b.installArtifact(smoke);

    const run_smoke = b.addRunArtifact(smoke);
    const smoke_step = b.step("smoke", "run isolated migration smoke test");
    smoke_step.dependOn(&run_smoke.step);

    if (b.lazyDependency("zqlite", .{
        .target = target,
        .optimize = optimize,
    })) |zqlite| {
        const sqlite_integration = b.addTest(.{
            .root_module = b.createModule(.{
                .root_source_file = b.path("tests/integration/sqlite.zig"),
                .target = target,
                .optimize = optimize,
                .imports = &.{
                    .{ .name = "zug", .module = mod },
                    .{ .name = "zqlite", .module = zqlite.module("zqlite") },
                },
            }),
        });
        const run_sqlite_integration = b.addRunArtifact(sqlite_integration);

        const sqlite_integration_step = b.step("sqlite-integration", "run SQLite integration tests");
        sqlite_integration_step.dependOn(&run_sqlite_integration.step);
    }
}

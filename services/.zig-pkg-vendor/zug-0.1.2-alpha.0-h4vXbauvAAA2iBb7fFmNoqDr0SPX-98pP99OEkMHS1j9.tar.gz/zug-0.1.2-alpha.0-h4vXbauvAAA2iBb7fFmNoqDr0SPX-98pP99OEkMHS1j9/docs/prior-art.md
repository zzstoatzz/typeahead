# prior art

`zug` should stay smaller than most of these tools. the useful lessons are about
failure semantics and project shape, not feature breadth.

## golang-migrate

- separates migration sources from database drivers
- keeps drivers intentionally small
- records dirty state before applying a migration
- refuses to continue when a previous migration failed

takeaway for `zug`: dirty-state behavior belongs in core.

## sqlx migrate

- embeds migrations into Rust binaries
- records checksums for applied migrations
- treats applied migration files as immutable

takeaway for `zug`: checksum drift should be a hard error by default.

## refinery

- supports embedded migrations
- allows SQL migrations and Rust migration modules
- uses ordered versioned migration names

takeaway for `zug`: SQL should be the default, but host-language callbacks are
useful for backfills and repairs.

## goose

- supports SQL migrations and Go functions
- offers CLI status/up/down workflows
- records migration history in a database table

takeaway for `zug`: code migrations are worth supporting without becoming an
ORM.

## zmig

- Zig 0.16 SQLite migration tool
- embeds migrations into the application binary
- offers checksum/name verification and diagnostics
- includes a CLI for development

takeaway for `zug`: avoid duplicating the full CLI surface at first; focus on a
clean library boundary.

## local references

- `prefect-server` already has embedded SQLite/Postgres migration files and a
  simple runner. it is a good consumer once `zug` is stable enough.
- `coral` has integer-versioned SQLite migrations embedded in its DB module.
  it is a useful check that `zug` can replace hand-written version ladders.
- `pollz` has inline SQLite schema init and ad hoc `ALTER TABLE` statements.
  it is a useful small-app adoption candidate.

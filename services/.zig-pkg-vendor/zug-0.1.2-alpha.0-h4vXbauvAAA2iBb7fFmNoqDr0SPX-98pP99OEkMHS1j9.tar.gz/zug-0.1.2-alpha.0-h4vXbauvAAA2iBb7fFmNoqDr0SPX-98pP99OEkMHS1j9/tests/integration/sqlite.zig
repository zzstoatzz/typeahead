const std = @import("std");
const zqlite = @import("zqlite");
const zug = @import("zug");

const migrations = [_]zug.Migration{
    .{ .id = "001_initial", .name = "create users", .sql =
    \\CREATE TABLE users (
    \\  id INTEGER PRIMARY KEY,
    \\  name TEXT NOT NULL
    \\);
    \\CREATE INDEX idx_users_name ON users(name);
    },
    .{
        .id = "002_seed",
        .name = "seed user",
        .up = seedUser,
    },
};

test "zqlite run applies and skips migrations" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{});
    try expectCounts(conn, 2, 1);

    try zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{});
    try expectCounts(conn, 2, 1);
}

test "checksum drift fails after migration is applied" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{});

    const changed = [_]zug.Migration{
        .{ .id = "001_initial", .name = "create users", .sql =
        \\CREATE TABLE users (
        \\  id INTEGER PRIMARY KEY,
        \\  name TEXT NOT NULL,
        \\  email TEXT
        \\);
        },
    };

    try std.testing.expectError(
        zug.Error.ChecksumMismatch,
        zug.sqlite.run(std.testing.allocator, &conn, &changed, .{}),
    );
}

test "adding empty statements field preserves existing checksums" {
    const migration = zug.Migration{
        .id = "001_initial",
        .name = "create users",
        .sql = "CREATE TABLE users (id INTEGER PRIMARY KEY);",
    };

    try std.testing.expectEqual(oldChecksum(migration), migration.checksum());
}

test "explicit statements affect checksum" {
    const without_statements = zug.Migration{
        .id = "001_initial",
        .name = "create users",
        .sql = "CREATE TABLE users (id INTEGER PRIMARY KEY);",
    };
    const with_statements = zug.Migration{
        .id = "001_initial",
        .name = "create users",
        .sql = "CREATE TABLE users (id INTEGER PRIMARY KEY);",
        .statements = &.{"CREATE INDEX idx_users_id ON users(id)"},
    };

    try std.testing.expect(without_statements.checksum() != with_statements.checksum());
}

test "dirty migration blocks future runs" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    const broken = [_]zug.Migration{.{
        .id = "001_broken",
        .name = "broken",
        .sql = "CREATE TABLE broken (id INTEGER PRIMARY KEY); SELECT * FROM missing_table;",
    }};

    try std.testing.expectError(
        error.Error,
        zug.sqlite.run(std.testing.allocator, &conn, &broken, .{}),
    );

    try std.testing.expectError(
        zug.Error.DirtyMigration,
        zug.sqlite.run(std.testing.allocator, &conn, &broken, .{}),
    );
}

test "duplicate migration ids fail before applying" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    const duplicate = [_]zug.Migration{
        .{ .id = "001", .sql = "CREATE TABLE a (id INTEGER PRIMARY KEY);" },
        .{ .id = "001", .sql = "CREATE TABLE b (id INTEGER PRIMARY KEY);" },
    };

    try std.testing.expectError(
        zug.Error.DuplicateMigrationId,
        zug.sqlite.run(std.testing.allocator, &conn, &duplicate, .{}),
    );
}

test "invalid migration table identifier fails before applying" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try std.testing.expectError(
        zug.Error.InvalidIdentifier,
        zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{ .table_name = "bad-name" }),
    );
}

test "explicit statements apply triggers with internal semicolons" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    const trigger_migrations = [_]zug.Migration{.{
        .id = "001_trigger",
        .name = "create trigger",
        .statements = &.{
            "CREATE TABLE actors (id INTEGER PRIMARY KEY, handle TEXT NOT NULL)",
            "CREATE TABLE actor_events (handle TEXT NOT NULL)",
            \\CREATE TRIGGER actors_ai AFTER INSERT ON actors BEGIN
            \\  INSERT INTO actor_events(handle) VALUES (new.handle);
            \\END;
        },
    }};

    try zug.sqlite.run(std.testing.allocator, &conn, &trigger_migrations, .{});
    try conn.exec("INSERT INTO actors (handle) VALUES ('alice')", .{});
    try expectCount(conn, "SELECT COUNT(*) FROM actor_events WHERE handle = 'alice'", 1);
}

test "sql convenience splitter does not parse trigger bodies" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    const trigger_migrations = [_]zug.Migration{.{ .id = "001_trigger", .name = "create trigger", .sql =
        \\CREATE TABLE actors (id INTEGER PRIMARY KEY, handle TEXT NOT NULL);
        \\CREATE TABLE actor_events (handle TEXT NOT NULL);
        \\CREATE TRIGGER actors_ai AFTER INSERT ON actors BEGIN
        \\  INSERT INTO actor_events(handle) VALUES (new.handle);
        \\END;
    }};

    try std.testing.expectError(
        error.Error,
        zug.sqlite.run(std.testing.allocator, &conn, &trigger_migrations, .{}),
    );
}

test "baseline marks existing schema and run applies only later migrations" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try createExistingUsersSchema(conn);

    try zug.sqlite.baseline(std.testing.allocator, &conn, migrations[0..1], .{});
    try expectCounts(conn, 1, 0);

    try zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{});
    try expectCounts(conn, 2, 1);
}

test "baseline is resumable and fills missing rows" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try createExistingUsersSchema(conn);
    try createZugMigrationsTable(conn);
    try insertApplied(conn, migrations[0], false);

    try zug.sqlite.baseline(std.testing.allocator, &conn, &migrations, .{});
    try expectCounts(conn, 2, 0);

    try zug.sqlite.run(std.testing.allocator, &conn, &migrations, .{});
    try expectCounts(conn, 2, 0);
}

test "baseline refuses checksum drift" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try createExistingUsersSchema(conn);
    try createZugMigrationsTable(conn);
    try conn.exec(
        "INSERT INTO zug_migrations (id, name, checksum, class, dirty) VALUES (?, ?, ?, ?, ?)",
        .{ migrations[0].id, migrations[0].name, "badchecksum0000", @tagName(migrations[0].class), @as(i64, 0) },
    );

    var diag: zug.Diagnostics = .{};
    try std.testing.expectError(
        zug.Error.ChecksumMismatch,
        zug.sqlite.baseline(std.testing.allocator, &conn, migrations[0..1], .{ .diagnostics = &diag }),
    );
    try std.testing.expectEqualStrings("001_initial", diag.migration_id);
}

test "baseline refuses dirty rows" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try createExistingUsersSchema(conn);
    try createZugMigrationsTable(conn);
    try insertApplied(conn, migrations[0], true);

    var diag: zug.Diagnostics = .{};
    try std.testing.expectError(
        zug.Error.DirtyMigration,
        zug.sqlite.baseline(std.testing.allocator, &conn, migrations[0..1], .{ .diagnostics = &diag }),
    );
    try std.testing.expectEqualStrings("001_initial", diag.migration_id);
}

test "baseline rejects duplicate ids" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    const duplicate = [_]zug.Migration{
        .{ .id = "001", .sql = "CREATE TABLE a (id INTEGER PRIMARY KEY);" },
        .{ .id = "001", .sql = "CREATE TABLE b (id INTEGER PRIMARY KEY);" },
    };

    try std.testing.expectError(
        zug.Error.DuplicateMigrationId,
        zug.sqlite.baseline(std.testing.allocator, &conn, &duplicate, .{}),
    );
}

test "baseline rejects invalid migration table identifier" {
    var conn = try zqlite.open(":memory:", zqlite.OpenFlags.Create | zqlite.OpenFlags.ReadWrite);
    defer conn.close();

    try std.testing.expectError(
        zug.Error.InvalidIdentifier,
        zug.sqlite.baseline(std.testing.allocator, &conn, migrations[0..1], .{ .table_name = "bad-name" }),
    );
}

fn seedUser(ctx: zug.Context) !void {
    try ctx.exec("INSERT INTO users (name) VALUES ('alice')");
}

fn createExistingUsersSchema(conn: zqlite.Conn) !void {
    try conn.exec(
        \\CREATE TABLE users (
        \\  id INTEGER PRIMARY KEY,
        \\  name TEXT NOT NULL
        \\)
    , .{});
    try conn.exec("CREATE INDEX idx_users_name ON users(name)", .{});
}

fn createZugMigrationsTable(conn: zqlite.Conn) !void {
    try conn.exec(
        \\CREATE TABLE IF NOT EXISTS zug_migrations (
        \\  id TEXT PRIMARY KEY,
        \\  name TEXT NOT NULL,
        \\  checksum TEXT NOT NULL,
        \\  class TEXT NOT NULL,
        \\  dirty INTEGER NOT NULL DEFAULT 0,
        \\  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        \\)
    , .{});
}

fn insertApplied(conn: zqlite.Conn, migration: zug.Migration, dirty: bool) !void {
    var checksum_buf: [16]u8 = undefined;
    const checksum = migration.checksumHex(&checksum_buf);
    try conn.exec(
        "INSERT INTO zug_migrations (id, name, checksum, class, dirty) VALUES (?, ?, ?, ?, ?)",
        .{ migration.id, migration.name, checksum, @tagName(migration.class), @as(i64, if (dirty) 1 else 0) },
    );
}

fn oldChecksum(migration: zug.Migration) u64 {
    var wy = std.hash.Wyhash.init(0);
    wy.update(migration.id);
    wy.update(&.{0});
    wy.update(migration.name);
    wy.update(&.{0});
    wy.update(@tagName(migration.class));
    wy.update(&.{0});
    if (migration.sql) |s| wy.update(s);
    wy.update(&.{0});
    if (migration.up != null) wy.update("zig");
    return wy.final();
}

fn expectCounts(conn: zqlite.Conn, expected_migrations: i64, expected_users: i64) !void {
    try expectCount(conn, "SELECT COUNT(*) FROM zug_migrations WHERE dirty = 0", expected_migrations);
    try expectCount(conn, "SELECT COUNT(*) FROM users", expected_users);
}

fn expectCount(conn: zqlite.Conn, sql: []const u8, expected: i64) !void {
    var rows = try conn.rows(sql, .{});
    defer rows.deinit();
    const row = rows.next() orelse return error.MissingCount;
    try std.testing.expectEqual(expected, row.int(0));
}

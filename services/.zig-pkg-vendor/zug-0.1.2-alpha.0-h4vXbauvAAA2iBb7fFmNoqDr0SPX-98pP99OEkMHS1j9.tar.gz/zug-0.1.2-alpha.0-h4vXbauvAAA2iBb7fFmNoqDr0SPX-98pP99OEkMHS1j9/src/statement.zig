const std = @import("std");

pub const StatementIterator = struct {
    sql: []const u8,
    pos: usize = 0,

    pub fn init(sql: []const u8) StatementIterator {
        return .{ .sql = sql };
    }

    pub fn next(self: *StatementIterator) ?[]const u8 {
        if (self.pos >= self.sql.len) return null;

        const start = self.pos;
        var in_string = false;
        var in_line_comment = false;
        var in_block_comment = false;

        while (self.pos < self.sql.len) {
            const c = self.sql[self.pos];

            if (!in_string and !in_block_comment and !in_line_comment and self.pos + 1 < self.sql.len and c == '-' and self.sql[self.pos + 1] == '-') {
                in_line_comment = true;
                self.pos += 2;
                continue;
            }

            if (in_line_comment) {
                if (c == '\n') in_line_comment = false;
                self.pos += 1;
                continue;
            }

            if (!in_string and !in_block_comment and self.pos + 1 < self.sql.len and c == '/' and self.sql[self.pos + 1] == '*') {
                in_block_comment = true;
                self.pos += 2;
                continue;
            }

            if (in_block_comment) {
                if (c == '*' and self.pos + 1 < self.sql.len and self.sql[self.pos + 1] == '/') {
                    in_block_comment = false;
                    self.pos += 2;
                    continue;
                }
                self.pos += 1;
                continue;
            }

            if (c == '\'') {
                if (in_string and self.pos + 1 < self.sql.len and self.sql[self.pos + 1] == '\'') {
                    self.pos += 2;
                    continue;
                }
                in_string = !in_string;
                self.pos += 1;
                continue;
            }

            if (c == ';' and !in_string and !in_block_comment) {
                const stmt = stripLeadingComments(std.mem.trim(u8, self.sql[start..self.pos], " \t\r\n"));
                self.pos += 1;
                if (stmt.len == 0 or isOnlyComments(stmt)) return self.next();
                return stmt;
            }

            self.pos += 1;
        }

        const stmt = stripLeadingComments(std.mem.trim(u8, self.sql[start..self.pos], " \t\r\n"));
        if (stmt.len == 0 or isOnlyComments(stmt)) return null;
        return stmt;
    }

    fn isOnlyComments(stmt: []const u8) bool {
        var i: usize = 0;
        while (i < stmt.len) {
            const c = stmt[i];
            if (std.ascii.isWhitespace(c)) {
                i += 1;
                continue;
            }
            if (c == '-' and i + 1 < stmt.len and stmt[i + 1] == '-') {
                while (i < stmt.len and stmt[i] != '\n') i += 1;
                continue;
            }
            return false;
        }
        return true;
    }
};

fn stripLeadingComments(stmt: []const u8) []const u8 {
    var rest = std.mem.trim(u8, stmt, " \t\r\n");
    while (rest.len > 0) {
        if (std.mem.startsWith(u8, rest, "--")) {
            const nl = std.mem.indexOfScalar(u8, rest, '\n') orelse return "";
            rest = std.mem.trim(u8, rest[nl + 1 ..], " \t\r\n");
            continue;
        }
        if (std.mem.startsWith(u8, rest, "/*")) {
            const end = std.mem.indexOf(u8, rest, "*/") orelse return "";
            rest = std.mem.trim(u8, rest[end + 2 ..], " \t\r\n");
            continue;
        }
        return rest;
    }
    return rest;
}

test "splits statements and ignores comments" {
    var it = StatementIterator.init(
        \\-- comment
        \\CREATE TABLE a (id INT);
        \\/* block ; comment */
        \\CREATE TABLE b (name TEXT DEFAULT 'a;b');
    );
    try std.testing.expectEqualStrings("CREATE TABLE a (id INT)", it.next().?);
    try std.testing.expectEqualStrings("CREATE TABLE b (name TEXT DEFAULT 'a;b')", it.next().?);
    try std.testing.expectEqual(@as(?[]const u8, null), it.next());
}

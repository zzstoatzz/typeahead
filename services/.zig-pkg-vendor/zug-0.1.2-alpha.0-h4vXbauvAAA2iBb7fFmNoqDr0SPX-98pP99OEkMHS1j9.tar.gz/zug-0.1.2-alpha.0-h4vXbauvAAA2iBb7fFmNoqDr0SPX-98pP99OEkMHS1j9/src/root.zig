const std = @import("std");

pub const sqlite = @import("sqlite.zig");

pub const Class = enum {
    startup,
    maintenance,
};

pub const Classes = struct {
    startup: bool = true,
    maintenance: bool = true,

    pub const all: Classes = .{ .startup = true, .maintenance = true };
    pub const startup_only: Classes = .{ .startup = true, .maintenance = false };
    pub const maintenance_only: Classes = .{ .startup = false, .maintenance = true };

    pub fn contains(self: Classes, class: Class) bool {
        return switch (class) {
            .startup => self.startup,
            .maintenance => self.maintenance,
        };
    }
};

pub const Context = struct {
    allocator: std.mem.Allocator,
    migration: Migration,
    ptr: *anyopaque,
    execFn: *const fn (ptr: *anyopaque, sql: []const u8) anyerror!void,

    pub fn exec(self: Context, sql: []const u8) !void {
        try self.execFn(self.ptr, sql);
    }
};

pub const Migration = struct {
    id: []const u8,
    name: []const u8 = "",
    class: Class = .startup,
    transactional: bool = false,
    sql: ?[]const u8 = null,
    statements: []const []const u8 = &.{},
    up: ?*const fn (ctx: Context) anyerror!void = null,

    pub fn checksum(self: Migration) u64 {
        var wy = std.hash.Wyhash.init(0);
        wy.update(self.id);
        wy.update(&.{0});
        wy.update(self.name);
        wy.update(&.{0});
        wy.update(@tagName(self.class));
        wy.update(&.{0});
        if (self.sql) |s| wy.update(s);
        wy.update(&.{0});
        if (self.statements.len > 0) {
            for (self.statements) |stmt| {
                wy.update(stmt);
                wy.update(&.{0});
            }
            wy.update(&.{0});
        }
        if (self.up != null) wy.update("zig");
        return wy.final();
    }

    pub fn checksumHex(self: Migration, buf: *[16]u8) []const u8 {
        return std.fmt.bufPrint(buf, "{x:0>16}", .{self.checksum()}) catch unreachable;
    }
};

pub const Options = struct {
    table_name: []const u8 = "zug_migrations",
    classes: Classes = Classes.all,
    check_checksum: bool = true,
    stop_on_dirty: bool = true,
    diagnostics: ?*Diagnostics = null,
};

pub const BaselineOptions = struct {
    table_name: []const u8 = "zug_migrations",
    diagnostics: ?*Diagnostics = null,
};

pub const Diagnostics = struct {
    migration_id: []const u8 = "",
    statement_index: usize = 0,
    statement_preview: []const u8 = "",
    message: []const u8 = "",

    pub fn clear(self: *Diagnostics) void {
        self.* = .{};
    }
};

pub const Applied = struct {
    id: []const u8,
    checksum: []const u8,
    dirty: bool,
};

pub const Error = error{
    BaselineIncomplete,
    ChecksumMismatch,
    DirtyMigration,
    DuplicateMigrationId,
    InvalidIdentifier,
    MissingMigrationBody,
};

pub fn validateUnique(migrations: []const Migration) !void {
    for (migrations, 0..) |left, i| {
        for (migrations[i + 1 ..]) |right| {
            if (std.mem.eql(u8, left.id, right.id)) return Error.DuplicateMigrationId;
        }
    }
}

pub fn findApplied(rows: []const Applied, id: []const u8) ?Applied {
    for (rows) |row| {
        if (std.mem.eql(u8, row.id, id)) return row;
    }
    return null;
}

pub fn freeAppliedRows(allocator: std.mem.Allocator, rows: []Applied) void {
    for (rows) |row| {
        allocator.free(row.id);
        allocator.free(row.checksum);
    }
    allocator.free(rows);
}

pub fn setDiag(options: Options, migration_id: []const u8, statement_index: usize, statement_preview: []const u8, message: []const u8) void {
    if (options.diagnostics) |d| {
        d.* = .{
            .migration_id = migration_id,
            .statement_index = statement_index,
            .statement_preview = statement_preview,
            .message = message,
        };
    }
}

pub fn preview(stmt: []const u8) []const u8 {
    return stmt[0..@min(stmt.len, 200)];
}

pub fn validateIdentifier(identifier: []const u8) !void {
    if (identifier.len == 0) return Error.InvalidIdentifier;
    for (identifier, 0..) |c, i| {
        const ok = std.ascii.isAlphanumeric(c) or c == '_';
        if (!ok) return Error.InvalidIdentifier;
        if (i == 0 and std.ascii.isDigit(c)) return Error.InvalidIdentifier;
    }
}

test {
    _ = @import("statement.zig");
    _ = @import("sqlite.zig");
}

const std = @import("std");
const zug = @import("zug");

const migrations = [_]zug.Migration{
    .{
        .id = "001_initial",
        .name = "initial schema",
        .sql = @embedFile("migrations/001_initial/sqlite.sql"),
    },
    .{
        .id = "002_add_email",
        .name = "add email",
        .sql = @embedFile("migrations/002_add_email/generic.sql"),
    },
    .{
        .id = "003_backfill",
        .name = "maintenance callback",
        .class = .maintenance,
        .up = backfill,
    },
};

pub fn main() !void {
    const allocator = std.heap.smp_allocator;

    var db = MemoryConn.init(allocator);
    defer db.deinit();

    try zug.sqlite.run(allocator, &db, &migrations, .{
        .classes = zug.Classes.startup_only,
    });

    if (db.applied_count != 2) return error.ExpectedTwoStartupMigrations;
    if (db.callback_count != 0) return error.MaintenanceRanDuringStartup;

    try zug.sqlite.run(allocator, &db, &migrations, .{
        .classes = zug.Classes.maintenance_only,
    });

    if (db.applied_count != 3) return error.ExpectedMaintenanceMigration;
    if (db.callback_count != 1) return error.ExpectedCallback;

    std.debug.print("zug smoke ok: {d} migrations, {d} statements\n", .{ db.applied_count, db.statements.items.len });
}

fn backfill(ctx: zug.Context) !void {
    const db: *MemoryConn = @ptrCast(@alignCast(ctx.ptr));
    db.callback_count += 1;
}

const MemoryConn = struct {
    allocator: std.mem.Allocator,
    statements: std.ArrayListUnmanaged([]const u8) = .empty,
    rows_list: std.ArrayListUnmanaged(zug.Applied) = .empty,
    applied_count: usize = 0,
    callback_count: usize = 0,

    fn init(allocator: std.mem.Allocator) MemoryConn {
        return .{ .allocator = allocator };
    }

    fn deinit(self: *MemoryConn) void {
        for (self.statements.items) |stmt| self.allocator.free(stmt);
        self.statements.deinit(self.allocator);
        for (self.rows_list.items) |row| {
            self.allocator.free(row.id);
            self.allocator.free(row.checksum);
        }
        self.rows_list.deinit(self.allocator);
    }

    pub fn exec(self: *MemoryConn, sql: []const u8, args: anytype) !void {
        try self.statements.append(self.allocator, try self.allocator.dupe(u8, sql));

        const Args = @TypeOf(args);
        const arg_len = @typeInfo(Args).@"struct".field_names.len;

        if (comptime arg_len == 5) {
            if (std.mem.startsWith(u8, sql, "INSERT INTO zug_migrations")) {
                try self.rows_list.append(self.allocator, .{
                    .id = try self.allocator.dupe(u8, args[0]),
                    .checksum = try self.allocator.dupe(u8, args[2]),
                    .dirty = args[4] != 0,
                });
                self.applied_count += 1;
            }
        } else if (comptime arg_len == 2) {
            if (std.mem.startsWith(u8, sql, "UPDATE zug_migrations SET dirty = ?")) {
                for (self.rows_list.items) |*row| {
                    if (std.mem.eql(u8, row.id, args[1])) row.dirty = args[0] != 0;
                }
            }
        }
    }

    pub fn rows(self: *MemoryConn, _: []const u8, _: anytype) !Rows {
        return .{ .db = self };
    }

    const Row = struct {
        applied: zug.Applied,

        pub fn text(self: Row, index: usize) []const u8 {
            return switch (index) {
                0 => self.applied.id,
                1 => self.applied.checksum,
                else => "",
            };
        }

        pub fn int(self: Row, index: usize) i64 {
            return switch (index) {
                2 => if (self.applied.dirty) 1 else 0,
                else => 0,
            };
        }
    };

    const Rows = struct {
        db: *MemoryConn,
        index: usize = 0,

        pub fn next(self: *Rows) ?Row {
            if (self.index >= self.db.rows_list.items.len) return null;
            defer self.index += 1;
            return .{ .applied = self.db.rows_list.items[self.index] };
        }

        pub fn deinit(_: *Rows) void {}
    };
};

//! poolio - focused worker pools for Zig 0.17 std.Io

pub const Shedding = @import("internal/pool.zig").Shedding;
pub const Counters = @import("internal/pool.zig").Counters;
pub const Pool = @import("internal/pool.zig").Pool;

comptime {
    if (@import("builtin").is_test) {
        _ = @import("internal/pool.zig");
        _ = @import("internal/bounded_queue.zig");
    }
}

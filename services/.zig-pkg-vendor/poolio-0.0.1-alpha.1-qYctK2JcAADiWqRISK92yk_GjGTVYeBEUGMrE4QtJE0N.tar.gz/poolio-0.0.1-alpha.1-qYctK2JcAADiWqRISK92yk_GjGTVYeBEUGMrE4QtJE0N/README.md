# poolio

```zig
const std = @import("std");
const poolio = @import("poolio");

const Io = std.Io;

const Ctx = struct {
    fn process(_: *@This(), _: Io, item: u64) void {
        std.debug.print("work: {d}\n", .{item});
    }
};

pub fn main() !void {
    const allocator = std.heap.smp_allocator;
    var threaded = Io.Threaded.init(allocator, .{});
    const io = threaded.io();

    var ctx: Ctx = .{};
    var pool = try poolio.Pool(u64, Ctx).init(allocator, .{
        .queue_capacity = 1024,
        .workers = 4,
        .ctx = &ctx,
        .process = Ctx.process,
        .shedding = .drop_oldest,
    });
    defer pool.deinit();

    try pool.start(io);
    try pool.put(io, 1); // backpressure
    _ = pool.offer(io, 2); // non-blocking, uses shedding policy
    pool.shutdown(io);
}
```

//! small poolio benchmarks
//!
//! The goal is signal, not laboratory precision: fixed-size synthetic work,
//! warmup passes, measured passes, and min/median/max throughput reporting.

const std = @import("std");
const poolio = @import("poolio");

const Io = std.Io;
const Allocator = std.mem.Allocator;

const warmup_passes: usize = 2;
const measured_passes: usize = 5;
const job_count: usize = 200_000;

const Job = struct {
    value: u64,
};

const Ctx = struct {
    processed: std.atomic.Value(u64) = .init(0),
    dropped: std.atomic.Value(u64) = .init(0),

    fn process(self: *Ctx, _: Io, job: Job) void {
        _ = self.processed.fetchAdd(job.value, .monotonic);
    }

    fn onDrop(self: *Ctx, job: Job) void {
        _ = self.dropped.fetchAdd(job.value, .monotonic);
    }
};

const PassResult = struct {
    submitted: usize,
    accepted: u64,
    dropped: u64,
    processed: u64,
    elapsed_ns: u64,
};

const Variant = struct {
    name: []const u8,
    workers: usize,
    queue_capacity: usize,
    mode: Mode,

    const Mode = union(enum) {
        put,
        offer: poolio.Shedding,
    };
};

pub fn main() !void {
    const allocator = std.heap.c_allocator;

    var threaded = Io.Threaded.init(allocator, .{
        .stack_size = 2 * 1024 * 1024,
        .concurrent_limit = .limited(64),
    });
    const io = threaded.io();

    const variants = [_]Variant{
        .{ .name = "put/1w", .workers = 1, .queue_capacity = 1024, .mode = .put },
        .{ .name = "put/4w", .workers = 4, .queue_capacity = 1024, .mode = .put },
        .{ .name = "offer/newest", .workers = 1, .queue_capacity = 1024, .mode = .{ .offer = .drop_newest } },
        .{ .name = "offer/oldest", .workers = 1, .queue_capacity = 1024, .mode = .{ .offer = .drop_oldest } },
    };

    std.debug.print("\n=== poolio benchmarks ===\n\n", .{});
    std.debug.print("jobs: {d}\n", .{job_count});
    std.debug.print("passes: {d} warmup, {d} measured\n\n", .{ warmup_passes, measured_passes });

    inline for (variants) |variant| {
        const results = try benchVariant(allocator, io, variant);
        reportResult(variant.name, &results);
    }

    std.debug.print("\n", .{});
}

fn benchVariant(allocator: Allocator, io: Io, variant: Variant) ![measured_passes]PassResult {
    for (0..warmup_passes) |_| {
        _ = try runOnce(allocator, io, variant);
    }

    var results: [measured_passes]PassResult = undefined;
    for (0..measured_passes) |i| {
        results[i] = try runOnce(allocator, io, variant);
    }
    return results;
}

fn runOnce(allocator: Allocator, io: Io, variant: Variant) !PassResult {
    var ctx: Ctx = .{};
    var p = try poolio.Pool(Job, Ctx).init(allocator, .{
        .queue_capacity = variant.queue_capacity,
        .workers = variant.workers,
        .ctx = &ctx,
        .process = Ctx.process,
        .on_drop = Ctx.onDrop,
        .shedding = switch (variant.mode) {
            .put => .drop_newest,
            .offer => |shedding| shedding,
        },
    });
    defer p.deinit();

    try p.start(io);
    const start = nowNs(io);
    for (0..job_count) |i| {
        const job: Job = .{ .value = @intCast((i % 7) + 1) };
        switch (variant.mode) {
            .put => try p.put(io, job),
            .offer => _ = p.offer(io, job),
        }
    }
    p.shutdown(io);
    const elapsed = nowNs(io) - start;

    const counters = p.counters(io);
    return .{
        .submitted = job_count,
        .accepted = counters.accepted,
        .dropped = counters.dropped,
        .processed = counters.processed,
        .elapsed_ns = elapsed,
    };
}

fn nowNs(io: Io) u64 {
    return @intCast(Io.Clock.awake.now(io).toNanoseconds());
}

fn reportResult(name: []const u8, results: []const PassResult) void {
    var throughput: [measured_passes]f64 = undefined;
    var total_submitted: usize = 0;
    var total_accepted: u64 = 0;
    var total_dropped: u64 = 0;
    var total_processed: u64 = 0;
    var total_ns: u64 = 0;

    for (results, 0..) |r, i| {
        const elapsed_s = @as(f64, @floatFromInt(r.elapsed_ns)) / 1_000_000_000.0;
        throughput[i] = @as(f64, @floatFromInt(r.submitted)) / elapsed_s;
        total_submitted += r.submitted;
        total_accepted += r.accepted;
        total_dropped += r.dropped;
        total_processed += r.processed;
        total_ns += r.elapsed_ns;
    }

    std.mem.sort(f64, &throughput, {}, std.sort.asc(f64));

    const elapsed_s = @as(f64, @floatFromInt(total_ns)) / 1_000_000_000.0;
    const avg_jobs_s = @as(f64, @floatFromInt(total_submitted)) / elapsed_s;

    std.debug.print("{s: <16} {d:>10.0} jobs/sec  accepted={d} dropped={d} processed={d}\n", .{
        name,
        avg_jobs_s,
        total_accepted,
        total_dropped,
        total_processed,
    });
    std.debug.print("{s: <16} variance: min={d:.0} median={d:.0} max={d:.0} jobs/sec\n", .{
        "",
        throughput[0],
        throughput[measured_passes / 2],
        throughput[measured_passes - 1],
    });
}

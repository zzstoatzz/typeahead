const std = @import("std");
const Io = std.Io;
const Allocator = std.mem.Allocator;
const queue_mod = @import("bounded_queue.zig");

pub const Shedding = queue_mod.Shedding;

pub const Counters = struct {
    accepted: u64,
    dropped: u64,
    processed: u64,
    queued: usize,
};

pub fn Pool(comptime Item: type, comptime Ctx: type) type {
    return struct {
        const Self = @This();
        const Queue = queue_mod.BoundedQueue(Item);

        pub const ProcessFn = *const fn (*Ctx, Io, Item) void;
        pub const DropFn = *const fn (*Ctx, Item) void;

        pub const Options = struct {
            queue_capacity: usize,
            workers: usize,
            ctx: *Ctx,
            process: ProcessFn,
            on_drop: ?DropFn = null,
            shedding: Shedding = .drop_newest,
        };

        pub const InitError = Allocator.Error || error{InvalidCapacity};

        allocator: Allocator,
        buffer: []Item,
        queue: Queue,
        group: Io.Group = .init,
        ctx: *Ctx,
        process_fn: ProcessFn,
        on_drop_fn: ?DropFn,
        shedding: Shedding,
        worker_count: usize,
        started: bool = false,
        accepted: std.atomic.Value(u64) = .init(0),
        dropped: std.atomic.Value(u64) = .init(0),
        processed: std.atomic.Value(u64) = .init(0),

        pub fn init(allocator: Allocator, opts: Options) InitError!Self {
            if (opts.queue_capacity == 0) return error.InvalidCapacity;
            const buffer = try allocator.alloc(Item, opts.queue_capacity);
            return .{
                .allocator = allocator,
                .buffer = buffer,
                .queue = Queue.init(buffer),
                .ctx = opts.ctx,
                .process_fn = opts.process,
                .on_drop_fn = opts.on_drop,
                .shedding = opts.shedding,
                .worker_count = opts.workers,
            };
        }

        pub fn deinit(self: *Self) void {
            self.allocator.free(self.buffer);
        }

        pub fn start(self: *Self, io: Io) !void {
            std.debug.assert(!self.started);
            self.started = true;
            for (0..self.worker_count) |_| {
                try self.group.concurrent(io, workerLoop, .{ self, io });
            }
        }

        pub fn put(self: *Self, io: Io, item: Item) error{Closed}!void {
            self.queue.put(io, item) catch |err| switch (err) {
                error.Closed => return error.Closed,
            };
            _ = self.accepted.fetchAdd(1, .monotonic);
        }

        pub fn offer(self: *Self, io: Io, item: Item) bool {
            const result = self.queue.offer(io, item, self.shedding) catch |err| switch (err) {
                error.Closed => return self.drop(item),
            };
            return self.finishPush(result);
        }

        pub fn shutdown(self: *Self, io: Io) void {
            self.queue.close(io);
            self.group.await(io) catch {};
            self.dropRemaining(io);
        }

        pub fn cancel(self: *Self, io: Io) void {
            self.queue.close(io);
            self.group.cancel(io);
            self.dropRemaining(io);
        }

        pub fn counters(self: *Self, io: Io) Counters {
            return .{
                .accepted = self.accepted.load(.monotonic),
                .dropped = self.dropped.load(.monotonic),
                .processed = self.processed.load(.monotonic),
                .queued = self.queue.count(io),
            };
        }

        pub fn droppedCount(self: *const Self) u64 {
            return self.dropped.load(.monotonic);
        }

        pub fn capacity(self: *const Self) usize {
            return self.queue.capacity();
        }

        fn workerLoop(self: *Self, io: Io) void {
            while (true) {
                const item = self.queue.pop(io) catch return;
                self.process_fn(self.ctx, io, item);
                _ = self.processed.fetchAdd(1, .monotonic);
            }
        }

        fn finishPush(self: *Self, result: queue_mod.PushResult(Item)) bool {
            switch (result.status) {
                .accepted => {
                    _ = self.accepted.fetchAdd(1, .monotonic);
                    return true;
                },
                .dropped_oldest => {
                    _ = self.accepted.fetchAdd(1, .monotonic);
                    if (result.dropped) |item| _ = self.drop(item);
                    return true;
                },
                .dropped_newest => {
                    if (result.dropped) |item| _ = self.drop(item);
                    return false;
                },
            }
        }

        fn drop(self: *Self, item: Item) bool {
            _ = self.dropped.fetchAdd(1, .monotonic);
            if (self.on_drop_fn) |on_drop| on_drop(self.ctx, item);
            return false;
        }

        fn dropRemaining(self: *Self, io: Io) void {
            while (self.queue.pop(io)) |item| {
                _ = self.drop(item);
            } else |_| {}
        }
    };
}

const TestCtx = struct {
    sum: std.atomic.Value(u64) = .init(0),
    dropped_sum: std.atomic.Value(u64) = .init(0),

    fn process(self: *TestCtx, _: Io, item: u64) void {
        _ = self.sum.fetchAdd(item, .monotonic);
    }

    fn onDrop(self: *TestCtx, item: u64) void {
        _ = self.dropped_sum.fetchAdd(item, .monotonic);
    }
};

test "offer tracks drop_newest" {
    const testing = std.testing;
    const io = testing.io;
    var ctx: TestCtx = .{};
    var pool = try Pool(u64, TestCtx).init(testing.allocator, .{
        .queue_capacity = 2,
        .workers = 0,
        .ctx = &ctx,
        .process = TestCtx.process,
        .on_drop = TestCtx.onDrop,
        .shedding = .drop_newest,
    });
    defer pool.deinit();

    try testing.expect(pool.offer(io, 1));
    try testing.expect(pool.offer(io, 2));
    try testing.expect(!pool.offer(io, 3));

    const c = pool.counters(io);
    try testing.expectEqual(@as(u64, 2), c.accepted);
    try testing.expectEqual(@as(u64, 1), c.dropped);
    try testing.expectEqual(@as(usize, 2), c.queued);
    try testing.expectEqual(@as(u64, 3), ctx.dropped_sum.load(.monotonic));
}

test "offer drop_oldest accepts new item and drops queued head" {
    const testing = std.testing;
    const io = testing.io;
    var ctx: TestCtx = .{};
    var pool = try Pool(u64, TestCtx).init(testing.allocator, .{
        .queue_capacity = 2,
        .workers = 0,
        .ctx = &ctx,
        .process = TestCtx.process,
        .on_drop = TestCtx.onDrop,
        .shedding = .drop_oldest,
    });
    defer pool.deinit();

    try testing.expect(pool.offer(io, 1));
    try testing.expect(pool.offer(io, 2));
    try testing.expect(pool.offer(io, 3));

    const c = pool.counters(io);
    try testing.expectEqual(@as(u64, 3), c.accepted);
    try testing.expectEqual(@as(u64, 1), c.dropped);
    try testing.expectEqual(@as(usize, 2), c.queued);
    try testing.expectEqual(@as(u64, 1), ctx.dropped_sum.load(.monotonic));
}

test "workers process submitted items" {
    const testing = std.testing;
    const io = testing.io;
    var ctx: TestCtx = .{};
    var pool = try Pool(u64, TestCtx).init(testing.allocator, .{
        .queue_capacity = 8,
        .workers = 2,
        .ctx = &ctx,
        .process = TestCtx.process,
    });
    defer pool.deinit();

    try pool.start(io);
    for (1..6) |i| try pool.put(io, i);
    pool.shutdown(io);

    const c = pool.counters(io);
    try testing.expectEqual(@as(u64, 5), c.accepted);
    try testing.expectEqual(@as(u64, 5), c.processed);
    try testing.expectEqual(@as(u64, 15), ctx.sum.load(.monotonic));
}

test "offer honors drop_oldest policy" {
    const testing = std.testing;
    const io = testing.io;
    var ctx: TestCtx = .{};
    var pool = try Pool(u64, TestCtx).init(testing.allocator, .{
        .queue_capacity = 2,
        .workers = 0,
        .ctx = &ctx,
        .process = TestCtx.process,
        .on_drop = TestCtx.onDrop,
        .shedding = .drop_oldest,
    });
    defer pool.deinit();

    try testing.expect(pool.offer(io, 1));
    try testing.expect(pool.offer(io, 2));
    try testing.expect(pool.offer(io, 3));

    const c = pool.counters(io);
    try testing.expectEqual(@as(u64, 3), c.accepted);
    try testing.expectEqual(@as(u64, 1), c.dropped);
    try testing.expectEqual(@as(u64, 1), ctx.dropped_sum.load(.monotonic));
}

test "put returns Closed without dropping caller-owned item" {
    const testing = std.testing;
    const io = testing.io;
    var ctx: TestCtx = .{};
    var pool = try Pool(u64, TestCtx).init(testing.allocator, .{
        .queue_capacity = 2,
        .workers = 0,
        .ctx = &ctx,
        .process = TestCtx.process,
        .on_drop = TestCtx.onDrop,
    });
    defer pool.deinit();

    pool.shutdown(io);
    try testing.expectError(error.Closed, pool.put(io, 1));
    try testing.expectEqual(@as(u64, 0), pool.droppedCount());
    try testing.expectEqual(@as(u64, 0), ctx.dropped_sum.load(.monotonic));
}

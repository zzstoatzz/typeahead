const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const mod = b.addModule("poolio", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
    });

    const tests = b.addTest(.{ .root_module = mod });
    const run_tests = b.addRunArtifact(tests);

    const test_step = b.step("test", "run unit tests");
    test_step.dependOn(&run_tests.step);

    const bench = b.addExecutable(.{
        .name = "poolio-bench",
        .root_module = b.createModule(.{
            .root_source_file = b.path("bench/poolio_bench.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "poolio", .module = mod }},
        }),
    });
    b.installArtifact(bench);

    const run_bench = b.addRunArtifact(bench);
    const bench_step = b.step("bench", "run poolio benchmarks");
    bench_step.dependOn(&run_bench.step);
}

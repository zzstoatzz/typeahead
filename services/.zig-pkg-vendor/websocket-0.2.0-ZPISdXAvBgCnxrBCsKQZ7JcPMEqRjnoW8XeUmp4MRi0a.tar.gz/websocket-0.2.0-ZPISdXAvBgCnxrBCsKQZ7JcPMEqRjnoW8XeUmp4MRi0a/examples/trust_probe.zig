const std = @import("std");
const Client = @import("websocket").Client;

pub fn main(init: std.process.Init) !void {
    var bundle: std.crypto.Certificate.Bundle = .empty;
    defer bundle.deinit(init.gpa);
    try bundle.rescan(init.gpa, init.io, .now(init.io, .real));
    const original_count = bundle.map.count();
    for ([_]?std.crypto.Certificate.Bundle{ null, bundle }) |supplied| {
        for (hosts) |host| {
            if (Client.init(init.io, init.gpa, .{ .host = host, .port = 443, .tls = true, .ca_bundle = supplied })) |result| {
                var unexpected = result;
                unexpected.deinit();
                return error.CompromisedChainAccepted;
            } else |err| {
                if (err != error.TlsCertificateNotVerified) return err;
                std.debug.print("rejected {s} (shared={}): {s}\n", .{ host, supplied != null, @errorName(err) });
            }
            if (bundle.map.count() != original_count) return error.SharedBundleMutated;
        }
        var control = try Client.init(init.io, init.gpa, .{ .host = "atproto.com", .port = 443, .tls = true, .ca_bundle = supplied });
        control.deinit();
        std.debug.print("control atproto.com (shared={}): TLS succeeded\n", .{supplied != null});
    }
}
const hosts = [_][]const u8{ "dv-g3b-emudhra.we-have-a-problem.com", "dv-g3b-aaa-emudhra.we-have-a-problem.com", "emudhra.divy.zone" };

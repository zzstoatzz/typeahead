const std = @import("std");

pub fn build(b: *std.Build) !void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const zlib_dep = b.dependency("zlib", .{});

    const zlib_mod = b.createModule(.{
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    zlib_mod.addIncludePath(zlib_dep.path("."));
    zlib_mod.addCSourceFiles(.{
        .root = zlib_dep.path("."),
        .files = &.{
            "adler32.c",
            "crc32.c",
            "deflate.c",
            "inffast.c",
            "inflate.c",
            "inftrees.c",
            "trees.c",
            "zutil.c",
        },
        .flags = &.{},
    });
    const zlib = b.addLibrary(.{ .name = "websocket-zlib", .root_module = zlib_mod });

    const websocket_module = b.addModule("websocket", .{
        .target = target,
        .optimize = optimize,
        .root_source_file = b.path("src/websocket.zig"),
        .link_libc = true,
    });
    websocket_module.addIncludePath(zlib_dep.path("."));
    websocket_module.linkLibrary(zlib);

    {
        const options = b.addOptions();
        options.addOption(bool, "websocket_blocking", false);
        websocket_module.addOptions("build", options);
    }

    {
        // run tests
        const force_blocking = b.option(bool, "force_blocking", "Force blocking mode") orelse false;
        const options = b.addOptions();
        options.addOption(bool, "websocket_blocking", force_blocking);

        const test_module = b.createModule(.{
            .root_source_file = b.path("src/websocket.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        });
        test_module.addIncludePath(zlib_dep.path("."));
        test_module.linkLibrary(zlib);
        test_module.addOptions("build", options);

        const tests = b.addTest(.{
            .root_module = test_module,
            .test_runner = .{ .path = b.path("test_runner.zig"), .mode = .simple },
        });

        const run_test = b.addRunArtifact(tests);

        const test_step = b.step("test", "Run tests");
        test_step.dependOn(&run_test.step);
    }
    const trust_probe = b.addExecutable(.{
        .name = "trust-probe",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/trust_probe.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "websocket", .module = websocket_module }},
        }),
    });
    const run_trust_probe = b.addRunArtifact(trust_probe);
    b.step("trust-probe", "Reject incident TLS hosts and accept a valid control").dependOn(&run_trust_probe.step);
}

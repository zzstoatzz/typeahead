const std = @import("std");
const Certificate = std.crypto.Certificate;
const distrust = @import("trust.zig").distrust;
const now = 1792713600;

fn add(bundle: *Certificate.Bundle, bytes: []const u8) !void {
    const start: u32 = @intCast(bundle.bytes.items.len);
    try bundle.bytes.appendSlice(std.testing.allocator, bytes);
    try bundle.parseCert(std.testing.allocator, start, now);
}

fn parsed(bytes: []const u8) !Certificate.Parsed {
    return (Certificate{ .buffer = bytes, .index = 0 }).parse();
}

test "distrust every compromised key and affected root, preserving unrelated trust" {
    for (blocked) |bytes| {
        var bundle: Certificate.Bundle = .empty;
        defer bundle.deinit(std.testing.allocator);
        try add(&bundle, bytes);
        try add(&bundle, control);
        try std.testing.expectEqual(2, bundle.map.count());
        distrust(&bundle);
        try std.testing.expectEqual(1, bundle.map.count());
        try std.testing.expect(bundle.find((try parsed(bytes)).subject()) == null);
        try std.testing.expect(bundle.find((try parsed(control)).subject()) != null);
        try bundle.verify(try parsed(control), now);
    }
}

test "genuine incident chains validate before distrust and fail afterwards" {
    for (chains) |chain| {
        var bundle: Certificate.Bundle = .empty;
        defer bundle.deinit(std.testing.allocator);
        for (roots) |bytes| try add(&bundle, bytes);
        for (chain[0 .. chain.len - 1], chain[1..]) |child, issuer| {
            try (try parsed(child)).verify(try parsed(issuer), now);
        }
        const last = try parsed(chain[chain.len - 1]);
        try bundle.verify(last, now);
        distrust(&bundle);
        try std.testing.expectError(error.CertificateIssuerNotFound, bundle.verify(last, now));
    }
}

const control = @embedFile("trust-fixtures/control.der");
const roots = [_][]const u8{
    @embedFile("trust-fixtures/root-0.der"),
    @embedFile("trust-fixtures/root-1.der"),
    @embedFile("trust-fixtures/root-2.der"),
    @embedFile("trust-fixtures/root-3.der"),
};
const blocked = roots ++ [_][]const u8{
    @embedFile("trust-fixtures/intermediate-0.der"),
    @embedFile("trust-fixtures/intermediate-1.der"),
    @embedFile("trust-fixtures/intermediate-2.der"),
    @embedFile("trust-fixtures/intermediate-3.der"),
    @embedFile("trust-fixtures/intermediate-4.der"),
    @embedFile("trust-fixtures/intermediate-5.der"),
    @embedFile("trust-fixtures/intermediate-6.der"),
    @embedFile("trust-fixtures/intermediate-7.der"),
    @embedFile("trust-fixtures/intermediate-8.der"),
    @embedFile("trust-fixtures/intermediate-9.der"),
    @embedFile("trust-fixtures/intermediate-10.der"),
    @embedFile("trust-fixtures/intermediate-11.der"),
    @embedFile("trust-fixtures/intermediate-12.der"),
    @embedFile("trust-fixtures/intermediate-13.der"),
    @embedFile("trust-fixtures/intermediate-14.der"),
    @embedFile("trust-fixtures/intermediate-15.der"),
};
const chains = [_][]const []const u8{
    &.{ @embedFile("trust-fixtures/dv-g3b-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/dv-g3b-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/dv-g3b-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/dv-g3b-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/dv-g3b-emudhra.we-have-a-problem.com-2.der") },
    &.{ @embedFile("trust-fixtures/dv-g3c-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/dv-g3c-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/dv-g3c-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/dv-g3c-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/dv-g3c-emudhra.we-have-a-problem.com-2.der") },
    &.{ @embedFile("trust-fixtures/ev-g3b-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ev-g3b-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/ev-g3b-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ev-g3b-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/ev-g3b-emudhra.we-have-a-problem.com-2.der") },
    &.{ @embedFile("trust-fixtures/ev-g3c-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ev-g3c-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/ev-g3c-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ev-g3c-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/ev-g3c-emudhra.we-have-a-problem.com-2.der") },
    &.{ @embedFile("trust-fixtures/ov-g3b-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ov-g3b-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/ov-g3b-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ov-g3b-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/ov-g3b-emudhra.we-have-a-problem.com-2.der") },
    &.{ @embedFile("trust-fixtures/ov-g3c-aaa-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ov-g3c-aaa-emudhra.we-have-a-problem.com-1.der") },
    &.{ @embedFile("trust-fixtures/ov-g3c-emudhra.we-have-a-problem.com-0.der"), @embedFile("trust-fixtures/ov-g3c-emudhra.we-have-a-problem.com-1.der"), @embedFile("trust-fixtures/ov-g3c-emudhra.we-have-a-problem.com-2.der") },
};

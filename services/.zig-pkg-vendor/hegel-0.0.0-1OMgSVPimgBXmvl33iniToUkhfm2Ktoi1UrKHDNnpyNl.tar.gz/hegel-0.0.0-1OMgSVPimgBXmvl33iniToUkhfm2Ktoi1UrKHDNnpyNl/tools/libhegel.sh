#!/bin/sh
# build libhegel_c.a once per hegel-rust revision, in a cache that outlives /tmp.
# usage: libhegel.sh <rev> [<out-lib> <out-include-dir>]
# prints the checkout path; with outputs, copies the library and header there.
set -e
rev=${1:?usage: libhegel.sh <rev> [<out-lib> <out-include-dir>]}
root=${HEGEL_CACHE:-${XDG_CACHE_HOME:-$HOME/.cache}/hegel-zig}
src=${HEGEL_RUST:-$root/hegel-rust-$rev}
lib=$src/target/release/libhegel_c.a

if [ ! -f "$lib" ]; then
    command -v cargo >/dev/null || { echo "libhegel.sh: cargo is needed once, to build libhegel" >&2; exit 1; }
    if [ ! -d "$src" ]; then
        mkdir -p "$root"
        tmp=$(mktemp -d "$root/clone.XXXXXX")
        git -C "$tmp" init -q
        git -C "$tmp" fetch -q --depth 1 "${HEGEL_REPO:-https://github.com/hegeldev/hegel-rust}" "$rev"
        git -C "$tmp" checkout -q FETCH_HEAD
        # another build may have won the race; keep theirs
        mv "$tmp" "$src" 2>/dev/null || rm -rf "$tmp"
    fi
    cargo build --release -p hegeltest-c --manifest-path "$src/Cargo.toml" >&2
fi

if [ -n "$2" ]; then
    cp "$lib" "$2"
    mkdir -p "$3"
    cp "$src/hegel-c/include/hegel.h" "$3/"
fi
echo "$src"

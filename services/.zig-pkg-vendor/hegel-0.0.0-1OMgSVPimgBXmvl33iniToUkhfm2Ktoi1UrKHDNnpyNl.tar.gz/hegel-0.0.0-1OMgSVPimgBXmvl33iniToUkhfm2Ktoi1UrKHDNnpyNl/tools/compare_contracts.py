#!/usr/bin/env python3
"""Compare exact C ABI error contracts emitted by the shared contract oracle."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--reference", required=True, type=Path)
parser.add_argument("--candidate", required=True, type=Path)
parser.add_argument("--output", type=Path, default=Path("work/contract-comparison"))
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
records = []
for name, executable in (("reference", args.reference), ("candidate", args.candidate)):
    process = subprocess.run([str(executable.resolve())], check=True, capture_output=True, text=True, timeout=120)
    (args.output / f"{name}.jsonl").write_text(process.stdout)
    records.append([json.loads(line) for line in process.stdout.splitlines() if line.strip()])
if not records[0]:
    raise SystemExit("reference oracle emitted no contracts")
for index in range(max(map(len, records))):
    left = records[0][index] if index < len(records[0]) else None
    right = records[1][index] if index < len(records[1]) else None
    if left != right:
        raise SystemExit(f"contract record {index} differs\nreference: {left}\ncandidate: {right}")
print(f"All {len(records[0])} C ABI error contracts match the pinned Rust engine")

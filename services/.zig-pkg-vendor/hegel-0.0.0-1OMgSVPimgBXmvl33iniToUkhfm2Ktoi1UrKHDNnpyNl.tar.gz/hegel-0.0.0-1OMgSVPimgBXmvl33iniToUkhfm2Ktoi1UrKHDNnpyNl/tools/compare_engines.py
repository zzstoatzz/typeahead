#!/usr/bin/env python3
"""Compare two builds of engine_oracle.zig; retain traces and cross-replay failures."""
import argparse
import base64
import json
from pathlib import Path
import subprocess
import shutil
import tempfile
import zlib

SCENARIOS = ("integers", "bytes", "floats", "pools", "state_machine", "invalid", "stale_cache", "text", "regex", "internet", "structured", "clones", "unstable", "targeting", "unstable_target", "nd_targeting")


def blob_payload(blob):
    raw = base64.b64decode(blob, validate=True)
    if not raw or raw[0] not in range(4):
        raise ValueError("unknown failure blob encoding")
    return (raw[0] >= 2, zlib.decompress(raw[1:]) if raw[0] & 1 else raw[1:])


def normalize(record):
    result = dict(record)
    if result.get("record") == "failure" and result.get("blob") is not None:
        nd, payload = blob_payload(result.pop("blob"))
        result["nd_blob"] = nd
        result["choice_payload"] = payload.hex()
    return result


def run(executable, scenario, seed, cases, blob=None, database=None):
    args = [str(executable), scenario, str(seed), str(cases)]
    if blob is not None:
        args.append(blob)
    if database is not None:
        args.extend(["--database", str(database)])
    proc = subprocess.run(args, capture_output=True, text=True, timeout=300)
    if proc.returncode:
        raise RuntimeError(f"{args}: exit {proc.returncode}\n{proc.stderr}")
    return [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]


def save(path, records):
    path.write_text("".join(json.dumps(record, separators=(",", ":")) + "\n" for record in records))


def compare(a, b, label):
    for index in range(max(len(a), len(b))):
        left = normalize(a[index]) if index < len(a) else None
        right = normalize(b[index]) if index < len(b) else None
        if left != right:
            raise AssertionError(f"{label}: first difference at record {index}\nreference: {left}\ncandidate: {right}")


def check_corpus(args, scenario, seed):
    label = f"{scenario}-{seed}"
    root = Path(tempfile.mkdtemp(prefix=f"corpus-{label}-", dir=args.output)).resolve()
    reference_db, candidate_db = root / "reference", root / "candidate"
    reference = run(args.reference.resolve(), scenario, seed, args.cases, database=reference_db)
    candidate = run(args.candidate.resolve(), scenario, seed, args.cases, database=candidate_db)
    save(root / "fresh-reference.jsonl", reference)
    save(root / "fresh-candidate.jsonl", candidate)
    compare(reference, candidate, label + " fresh corpus")
    cross_reference, cross_candidate = root / "cross-reference", root / "cross-candidate"
    shutil.copytree(candidate_db, cross_reference)
    shutil.copytree(reference_db, cross_candidate)
    for mode, left, right in (("reuse", reference_db, candidate_db), ("cross", cross_reference, cross_candidate)):
        reference = run(args.reference.resolve(), scenario, seed ^ 12345, args.cases, database=left)
        candidate = run(args.candidate.resolve(), scenario, seed ^ 12345, args.cases, database=right)
        save(root / f"{mode}-reference.jsonl", reference)
        save(root / f"{mode}-candidate.jsonl", candidate)
        compare(reference, candidate, label + " " + mode + " corpus")
    print(f"PASS {label}: database reuse and cross-engine corpus verified", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--output", type=Path, default=Path("work/engine-comparison"))
    parser.add_argument("--seeds", default="0,1,42,18446744073709551615")
    parser.add_argument("--cases", type=int, default=100)
    parser.add_argument("--scenarios", default=",".join(SCENARIOS))
    parser.add_argument("--check-corpus", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for seed in map(int, args.seeds.split(",")):
        for scenario in args.scenarios.split(","):
            label = f"{scenario}-{seed}"
            reference = run(args.reference.resolve(), scenario, seed, args.cases)
            candidate = run(args.candidate.resolve(), scenario, seed, args.cases)
            save(args.output / f"{label}-reference.jsonl", reference)
            save(args.output / f"{label}-candidate.jsonl", candidate)
            compare(reference, candidate, label)
            for index, failure in enumerate(r for r in reference if r.get("record") == "failure"):
                ref_replay = run(args.reference.resolve(), scenario, seed, args.cases, failure["blob"])
                zig_replay = run(args.candidate.resolve(), scenario, seed, args.cases, failure["blob"])
                save(args.output / f"{label}-replay-{index}-reference.jsonl", ref_replay)
                save(args.output / f"{label}-replay-{index}-candidate.jsonl", zig_replay)
                compare(ref_replay, zig_replay, f"{label} reference blob replay {index}")
            for index, failure in enumerate(r for r in candidate if r.get("record") == "failure"):
                ref_replay = run(args.reference.resolve(), scenario, seed, args.cases, failure["blob"])
                zig_replay = run(args.candidate.resolve(), scenario, seed, args.cases, failure["blob"])
                compare(ref_replay, zig_replay, f"{label} candidate blob replay {index}")
            print(f"PASS {label}: {len(reference)} records, cross-replay verified", flush=True)
            if args.check_corpus and scenario in ("stale_cache", "unstable"):
                check_corpus(args, scenario, seed)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Validate the port inventory, retained notices, source hashes and package paths."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream", type=Path, help="optional original pinned Hegel checkout for direct source-hash validation")
    parser.add_argument("--crate-cache", type=Path, help="optional Cargo registry source directory for translated dependency hash validation")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "docs/native-port-provenance.json").read_text())
    entries = manifest["file_mappings"]
    indexed = {entry["zig_path"]: entry for entry in entries}
    assert len(indexed) == len(entries), "duplicate inventory destination"
    native_files = {str(p.relative_to(ROOT)) for p in (ROOT / "src/engine").rglob("*") if p.is_file()}
    assert not native_files - indexed.keys(), f"unmapped native files: {sorted(native_files-indexed.keys())}"
    zon = (ROOT / "build.zig.zon").read_text().split(".paths =", 1)[1]
    packaged = re.findall(r'"([^"\n]+)"', zon)
    covered = lambda path: any(path == prefix or path.startswith(prefix + "/") for prefix in packaged)
    checked_sources = set()
    if args.upstream:
        revision = subprocess.check_output(["git", "-C", str(args.upstream), "rev-parse", "HEAD"], text=True).strip()
        assert revision == manifest["reference"]["revision"], "unexpected original Hegel revision"
        assert digest(args.upstream / "LICENSE") == manifest["reference"]["license_sha256"], "original license changed"
        assert digest(args.upstream / "Cargo.lock") == manifest["reference"]["cargo_lock_sha256"], "original dependency lock changed"
    for entry in entries:
        path = entry["zig_path"]
        assert (ROOT / path).is_file(), f"missing destination: {path}"
        assert covered(path), f"not included in package paths: {path}"
        if "target_sha256" in entry:
            assert digest(ROOT / path) == entry["target_sha256"], f"generated/copied data changed: {path}"
        text = (ROOT / path).read_text(errors="replace")[:300]
        marker = re.search(r"SPDX-License-Identifier:\s*([^\n]+)", text)
        if marker:
            assert marker.group(1).strip() == entry["source_marker"], f"source marker changed: {path}"
        if "MPL-2.0" in entry.get("source_marker", ""):
            assert "LICENSES/MPL-2.0.txt" in entry["notice_files"], f"MPL marker missing mapped license text: {path}"
        for notice in entry.get("notice_files", []):
            assert (ROOT / notice).is_file() and covered(notice), f"missing/unpackaged notice: {notice}"
        for source in entry.get("sources", []):
            if source.get("repository") == manifest["reference"]["repository"] and args.upstream:
                raw = subprocess.check_output(["git", "-C", str(args.upstream), "show", manifest["reference"]["revision"] + ":" + source["path"]])
                assert hashlib.sha256(raw).hexdigest() == source["sha256"], f"pinned git source hash differs: {source['path']}"
                assert digest(args.upstream / source["path"]) == source["sha256"], f"working original source changed: {source['path']}"
                checked_sources.add(source["path"])
            if source.get("crate") and args.crate_cache:
                original = args.crate_cache / (source["crate"] + "-" + source["version"]) / source["crate_path"]
                assert digest(original) == source["sha256"], f"dependency source changed: {original}"
    notices = {entry["path"] for entry in manifest["notice_files"]}
    actual_notices = {str(p.relative_to(ROOT)) for p in (ROOT / "LICENSES").iterdir() if p.is_file()}
    assert notices == actual_notices, "notice directory and manifest differ"
    for entry in manifest["notice_files"] + manifest["component_fragments"]:
        assert digest(ROOT / entry["path"]) == entry["sha256"], f"recorded notice/fragment changed: {entry['path']}"
        assert covered(entry["path"]), f"unpackaged legal/provenance record: {entry['path']}"
    for document in manifest["packaging"]["included_documents"]:
        assert covered(document), f"unpackaged source-availability document: {document}"
    assert digest(ROOT / "LICENSE") == manifest["policy"]["existing_wrapper_license_sha256"], "original wrapper license changed"
    print(f"Mapped {len(native_files)} native files and original header; all {len(notices)} notices and source-availability documents are packaged")
    if args.upstream:
        print(f"Verified {len(checked_sources)} distinct direct-source hashes at the pinned Hegel revision")
    print("Historical ancestry questions and binary redistribution duties remain explicit in the provenance documents")


if __name__ == "__main__":
    main()

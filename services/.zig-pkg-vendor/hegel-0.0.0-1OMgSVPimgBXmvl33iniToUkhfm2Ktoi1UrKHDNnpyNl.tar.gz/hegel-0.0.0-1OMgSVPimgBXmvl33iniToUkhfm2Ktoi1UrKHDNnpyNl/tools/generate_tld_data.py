#!/usr/bin/env python3
"""Derive the reference engine's TLD alphabet from an MPL-licensed PSL snapshot."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

PSL_REV = "e452c7058d6946bd76952b128c12f5ce87a5acb8"
EXCLUDED = {"HOTEL", "ONION", "XN--MGB2DDES", "XN--MGBA3A4FRA", "XN--MGBAI9A5EVA00B", "XN--MGBERP4A5D4A87G", "XN--MGBQLY7C0A67FBC", "XN--MGBQLY7CVAFR", "XN--MGBTF8FL", "XN--MIX082F", "XN--NNX388A"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--psl", type=Path, default=Path.home() / ".cache/checkouts/github.com/publicsuffix/list")
    parser.add_argument("--reference", type=Path, default=Path.home() / ".cache/hegel-zig/hegel-rust-33d94c659e441127ce7b5a0f046ec4aa9315d794")
    args = parser.parse_args()
    raw = subprocess.check_output(["git", "-C", str(args.psl), "show", f"{PSL_REV}:public_suffix_list.dat"])
    icann = raw.decode().split("// ===BEGIN PRIVATE DOMAINS===")[0]
    names = {line.lstrip("!*.").rsplit(".", 1)[-1].encode("idna").decode().upper() for line in icann.splitlines() if line and not line.startswith("//")}
    assert EXCLUDED <= names
    names = sorted(names - EXCLUDED)
    reference = (args.reference / "hegel-c/src/native/draws/tlds-alpha-by-domain.txt").read_text().splitlines()[1:]
    assert names == reference, "PSL derivation must preserve the reference alphabet and order exactly"
    root = Path(__file__).resolve().parents[1]
    derived = "# SPDX-License-Identifier: MPL-2.0\n# Derived from publicsuffix/list " + PSL_REV + "; see docs/native-provenance/tlds.json\n" + "\n".join(names) + "\n"
    (root / "src/engine/draws/tlds.txt").write_text(derived)
    (root / "LICENSES/Public-Suffix-List-NOTICE.txt").write_text(raw.decode().split("// Instructions on pulling")[0] + "\nSource snapshot: https://github.com/publicsuffix/list/blob/" + PSL_REV + "/public_suffix_list.dat\nDerived by tools/generate_tld_data.py; MPL-2.0 license included in LICENSES/MPL-2.0.txt.\n")
    (root / "docs/native-provenance/tlds.json").write_text(json.dumps({"source": "https://github.com/publicsuffix/list", "revision": PSL_REV, "source_file": "public_suffix_list.dat", "source_sha256": hashlib.sha256(raw).hexdigest(), "license": "MPL-2.0", "derivation": "ICANN section: last label, IDNA encoding, uppercase, deduplicate, remove the eleven PSL names absent from the pinned engine delegation snapshot, lexical sort", "excluded_names": sorted(EXCLUDED), "count": len(names), "derived_sha256": hashlib.sha256(derived.encode()).hexdigest(), "reference_check": "exact equality with all 1437 pinned Rust names in source order; IANA file is read only for comparison and is not copied into this port", "runtime_order": "internet.rs prepends COM, removes ARPA, stable-sorts by length; preserve duplicated COM as source does"}, indent=2) + "\n")
    print(f"Derived {len(names)} TLDs; exact reference alphabet and order match")


if __name__ == "__main__":
    main()

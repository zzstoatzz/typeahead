#[unsafe(no_mangle)] pub extern "C" fn native_printer_oracle() {
 use alloc::{string::{String,ToString},format,vec::Vec};use crate::native::{printer::{Printer,Target},reflow::{reflow,ReflowOptions}};
 fn hex(s:&str)->String {if s.is_empty(){return "_".into()}s.as_bytes().iter().map(|b|format!("{b:02x}")).collect()}
 for width in 1usize..=80 {for program in 0..5 {
  let mut p=Printer::new(width);
  match program {
   0=>{p.begin_group(Target::Main,2,"[").unwrap();p.text(Target::Main,"αβ").unwrap();p.breakable(Target::Main," ").unwrap();p.begin_group(Target::Main,1,"(").unwrap();p.text(Target::Main,"gamma").unwrap();p.breakable(Target::Main,", ").unwrap();p.text(Target::Main,"δ").unwrap();p.if_break(Target::Main,",").unwrap();p.end_group(Target::Main,")").unwrap();p.end_group(Target::Main,"]").unwrap();},
   1=>{p.begin_group(Target::Main,2,"[").unwrap();p.text(Target::Main,"a").unwrap();p.comment(Target::Main," // note").unwrap();p.breakable(Target::Main," ").unwrap();p.text(Target::Main,"b").unwrap();p.end_group(Target::Main,"\u{2003}]").unwrap();},
   2=>{p.line_prefix(Target::Main,"> ").unwrap();let b=p.block(Target::Main,3).unwrap();p.text(Target::Slot(b),"hello").unwrap();p.hard_break(Target::Slot(b)).unwrap();let c=p.block(Target::Slot(b),2).unwrap();p.text(Target::Slot(c),"world").unwrap();p.hard_break(Target::Slot(c)).unwrap();p.text(Target::Main,"tail").unwrap();p.resolve().unwrap();},
   3=>{p.text(Target::Main,"keep").unwrap();p.begin_speculative(Target::Main).unwrap();p.text(Target::Main,"lost").unwrap();let s=p.deferred(Target::Main).unwrap();p.text(Target::Slot(s),"gone").unwrap();p.note(Target::Main,"note\nnext",Some("! ")).unwrap();p.abort_speculative(Target::Main).unwrap();assert!(!p.slot_is_live(s));p.begin_speculative(Target::Main).unwrap();p.text(Target::Main,"commit").unwrap();p.commit_speculative(Target::Main).unwrap();},
   _=>{p.begin_speculative(Target::Main).unwrap();p.end_group(Target::Main,"bad").unwrap();assert!(p.commit_speculative(Target::Main).is_err());p.abort_speculative(Target::Main).unwrap();let s=p.deferred(Target::Main).unwrap();p.begin_speculative(Target::Slot(s)).unwrap();p.text(Target::Slot(s),"discard").unwrap();p.resolve().unwrap();},
  }
  let value=p.value().unwrap().to_string();let error=p.text(Target::Main,"late").unwrap_err();std::println!("program{}\t{}\t_\t{}\t{}",program,width,hex(&value),error);
 }}
 let mut inputs:Vec<String>=["Some(123, 456)","Point { x: 1, y: [2, 3, 4] }","map[string]int{\"a\":1, \"b\":2}","Map(2) { 'a' => [1, 2], 'b' => 3 }","[\"a, b\", '\\'', 42]","{ a: 1; b: 2 }","[broken}","one\ntwo\n","[]int{1, 2, 3}","é([α, β], z)","{ }","[1, 2,]","Some([1, 2], other)"].iter().map(|s|(*s).into()).collect();inputs.push(format!("{}x{}","[".repeat(65),"]".repeat(65)));
 for width in [1usize,4,8,16,24,40,80] {for input in &inputs {let mut p=Printer::new(width);reflow(&mut p,Target::Main,input,&ReflowOptions::default()).unwrap();let value=p.value().unwrap();std::println!("reflow\t{}\t{}\t{}\t_",width,hex(input),hex(value));}}
}

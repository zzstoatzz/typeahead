import ctypes
import io
import json
import pathlib
import subprocess
import sys
import tarfile
import tempfile

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
upstream = pathlib.Path(sys.argv[1]).resolve()
if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip() != PIN:
    raise SystemExit("unexpected upstream revision")
with tempfile.TemporaryDirectory(prefix="hegel-type-sizes-") as temp:
    dest = pathlib.Path(temp)
    archive = subprocess.check_output(["git", "archive", "HEAD"], cwd=upstream)
    tarfile.open(fileobj=io.BytesIO(archive)).extractall(dest, filter="data")
    source = dest / "hegel-c/src/native/shrinker/mod.rs"
    source.write_text(source.read_text() + (pathlib.Path(__file__).resolve().parent / "native_shrinker_oracle.rs").read_text() + (pathlib.Path(__file__).resolve().parent / "native_debug_oracle.rs").read_text() + (pathlib.Path(__file__).resolve().parent / "native_printer_oracle.rs").read_text())
    subprocess.run(["cargo", "build", "-p", "hegeltest-c", "--release", "--locked", "--offline", "--target-dir", str(pathlib.Path(__file__).resolve().parent.parent / "work/shrinker-oracle-target")], cwd=dest, check=True)
    extension = "dylib" if sys.platform == "darwin" else "so"
    library = pathlib.Path(__file__).resolve().parent.parent / "work/shrinker-oracle-target/release" / ("libhegel_c." + extension)
    result = subprocess.check_output([sys.executable,"-c","import ctypes,sys; ctypes.CDLL(sys.argv[1]).native_shrinker_oracle()",str(library)])
    output = pathlib.Path(__file__).resolve().parent.parent / "tests/engine/fixtures/shrinker.tsv"
    output.write_bytes(result)
    print(f"{output}: {len(result.splitlines())} cases")
    debug = subprocess.check_output([sys.executable,"-c","import ctypes,sys; ctypes.CDLL(sys.argv[1]).native_debug_oracle()",str(library)])
    (output.parent / "printer_debug.tsv").write_bytes(debug)
    printer = subprocess.check_output([sys.executable,"-c","import ctypes,sys; ctypes.CDLL(sys.argv[1]).native_printer_oracle()",str(library)])
    (output.parent / "printer.tsv").write_bytes(printer)

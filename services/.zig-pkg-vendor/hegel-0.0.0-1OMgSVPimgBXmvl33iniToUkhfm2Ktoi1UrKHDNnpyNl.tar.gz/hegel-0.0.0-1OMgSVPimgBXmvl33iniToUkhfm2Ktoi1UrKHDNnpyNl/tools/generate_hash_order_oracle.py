#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
upstream = Path.home() / ".cache/hegel-zig" / ("hegel-rust-" + PIN)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip() == PIN
output = subprocess.check_output(["cargo", "build", "-p", "hegeltest-c", "--release", "--locked", "--message-format=json"], cwd=upstream, text=True)
artifacts = {}
for line in output.splitlines():
    item = json.loads(line)
    for crate, version in (("hashbrown", "0.17.1"), ("rustc_hash", "2.1.2")):
        if item.get("reason") == "compiler-artifact" and item["target"]["name"] == crate and item["package_id"].endswith("@" + version):
            artifacts[crate] = next(name for name in item["filenames"] if name.endswith(".rlib"))
assert len(artifacts) == 2
work = ROOT / "work/hash-order-oracle"
work.mkdir(parents=True, exist_ok=True)
args = ["rustc", "--edition=2024", str(ROOT / "tools/native_hash_order_oracle.rs"), "-L", "dependency=" + str(upstream / "target/release/deps"), "-o", str(work / "oracle")]
for crate, artifact in artifacts.items():
    args.extend(["--extern", crate + "=" + artifact])
subprocess.run(args, check=True)
(ROOT / "tests/engine/fixtures/hash_order.tsv").write_bytes(subprocess.check_output([str(work / "oracle")]))

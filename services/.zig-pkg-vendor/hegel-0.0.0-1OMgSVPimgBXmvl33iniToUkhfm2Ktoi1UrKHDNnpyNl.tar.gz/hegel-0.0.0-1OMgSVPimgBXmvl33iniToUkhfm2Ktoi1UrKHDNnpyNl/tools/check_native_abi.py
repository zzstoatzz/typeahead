#!/usr/bin/env python3
"""Check native library exports against the exact pinned public C header."""
import argparse
import hashlib
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]


def symbols(path, nm):
    command = [nm, "-gU", str(path)] if sys.platform == "darwin" else [nm, "-g", "--defined-only", str(path)]
    result = subprocess.run(command, text=True, capture_output=True)
    if result.returncode:
        first_line = result.stderr.splitlines()[0] if result.stderr else "no diagnostic"
        raise SystemExit(f"symbol reader failed for {path}: {first_line}; use --nm with a compatible LLVM symbol reader")
    output = result.stdout
    return {parts[-1].removeprefix("_") for line in output.splitlines() if len(parts := line.split()) >= 2 and re.fullmatch(r"[A-Za-z]", parts[-2]) and re.fullmatch(r"_?hegel_[A-Za-z0-9_]+", parts[-1])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("library", type=pathlib.Path)
    parser.add_argument("--nm", default="nm", help="symbol reader compatible with the archive object/bitcode version")
    parser.add_argument("--reference-library", type=pathlib.Path)
    parser.add_argument("--header", type=pathlib.Path, default=ROOT / "include/hegel.h")
    args = parser.parse_args()
    raw = args.header.read_bytes()
    manifest = __import__("json").loads((ROOT / "docs/native-provenance/state.json").read_text())
    expected_hash = manifest["abi"]["header_sha256"]
    if hashlib.sha256(raw).hexdigest() != expected_hash:
        raise SystemExit("public header differs from the recorded pinned original; reconcile provenance before changing the ABI gate")
    source = re.sub(r"/\*.*?\*/|//[^\n]*", "", raw.decode(), flags=re.S)
    expected = set(re.findall(r"\b(hegel_\w+)\s*\(", source))
    if len(expected) != 131:
        raise SystemExit(f"expected 131 pinned API declarations, found {len(expected)}")
    for label, library in [("native", args.library), ("reference", args.reference_library)]:
        if library is None:
            continue
        actual = symbols(library, args.nm)
        if actual != expected:
            raise SystemExit(f"{label} export mismatch; missing={sorted(expected-actual)}, extra={sorted(actual-expected)}")
    print("All 131 C exports match the exact pinned public header")


if __name__ == "__main__":
    main()

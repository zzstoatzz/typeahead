const std = @import("std");
const Reference = @This();

const hegel_rust_rev = "33d94c659e441127ce7b5a0f046ec4aa9315d794";

header: *std.Build.Module,
archive: std.Build.LazyPath,

pub fn configure(b: *std.Build, target: std.Build.ResolvedTarget, optimize: std.builtin.OptimizeMode) Reference {
    const given_include = b.option(std.Build.LazyPath, "hegel-include", "directory containing hegel.h (default: built by tools/libhegel.sh)");
    const given_lib = b.option(std.Build.LazyPath, "hegel-lib", "path to libhegel_c.a (default: built by tools/libhegel.sh)");

    const include, const lib = if (given_include != null and given_lib != null)
        .{ given_include.?, given_lib.? }
    else built: {
        // cached by zig on the script and the revision; the script keeps its
        // own cargo build under ~/.cache/hegel-zig, so a wiped zig cache is a copy
        const cargo = b.addSystemCommand(&.{"sh"});
        cargo.setName("build libhegel");
        cargo.addFileArg(b.path("tools/libhegel.sh"));
        cargo.addArg(hegel_rust_rev);
        const out_lib = cargo.addOutputFileArg("libhegel_c.a");
        const out_include = cargo.addOutputDirectoryArg("include");
        _ = cargo.captureStdOut(.{});
        break :built .{ out_include, out_lib };
    };

    const translate = b.addTranslateC(.{
        .root_source_file = include.path(b, "hegel.h"),
        .target = target,
        .optimize = optimize,
    });

    return .{ .header = translate.createModule(), .archive = lib };
}

pub fn link(reference: Reference, module: *std.Build.Module) void {
    module.addObjectFile(reference.archive);
    if (module.resolved_target.?.result.os.tag.isDarwin()) {
        module.linkFramework("CoreFoundation", .{});
        module.linkFramework("Security", .{});
    }
}

mod native { pub mod bignum { pub use hegel_c::__bench::BigInt; } }
mod search;
fn big_power(power:usize)->hegel_c::__bench::BigInt {let mut bytes=vec![0u8;power/8+2];bytes[power/8]=1<<(power%8);hegel_c::__bench::BigInt::from_signed_bytes_le(&bytes)}
fn main() {
 for target in [0usize,1,2,3,4,5,6,9,10,100,usize::MAX] {
  let mut s=search::FindInteger::new(); let mut trace=Vec::new();while let Some(p)=s.probe() {trace.push(p.to_string());s.record(p<=target);}
  let answer=match s.step(){search::SearchStep::Done(v)=>v,_=>panic!()};println!("find\t{}\t{}\t{}",target,trace.join(","),answer);
 }
 for target in [0i128,1,2,3,50,99,100] {
  let mut s=search::BinSearchDown::new(0,100);let mut trace=Vec::new();while let Some(p)=s.probe(){trace.push(p.to_string());s.record(p>=target);}println!("binary\t{}\t{}",target,trace.join(","));
 }
 for power in [0usize,64,128,300] {
  let target=big_power(power);let mut s=search::BinSearchDownBig::new(hegel_c::__bench::BigInt::from(0),big_power(512));
  let mut trace=Vec::new();while let Some(p)=s.probe(){trace.push(p.to_string());s.record(p>=target);}println!("big\t{}\t{}",power,trace.join(","));
 }
}

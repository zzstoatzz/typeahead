import ctypes
import io
import json
import pathlib
import subprocess
import sys
import tarfile
import tempfile

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
upstream = pathlib.Path(sys.argv[1]).resolve()
if subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip() != PIN:
    raise SystemExit("unexpected upstream revision")
with tempfile.TemporaryDirectory(prefix="hegel-type-sizes-") as temp:
    dest = pathlib.Path(temp)
    archive = subprocess.check_output(["git", "archive", "HEAD"], cwd=upstream)
    tarfile.open(fileobj=io.BytesIO(archive)).extractall(dest, filter="data")
    source = dest / "hegel-c/src/lib.rs"
    source.write_text(source.read_text() + r'''
#[unsafe(no_mangle)] pub extern "C" fn native_type_sizes(index: usize) -> usize {
    [core::mem::size_of::<crate::native::core::choices::ChoiceNode>(),
     core::mem::size_of::<crate::native::core::state::Span>(),
     core::mem::size_of::<crate::native::exec_cache::CachedRun>()][index]
}
''')
    subprocess.run(["cargo", "build", "-p", "hegeltest-c", "--release", "--locked", "--offline", "--target-dir", str(dest / "target")], cwd=dest, check=True)
    extension = "dylib" if sys.platform == "darwin" else "so"
    lib = ctypes.CDLL(str(dest / "target/release" / ("libhegel_c." + extension)))
    lib.native_type_sizes.argtypes = [ctypes.c_size_t]
    lib.native_type_sizes.restype = ctypes.c_size_t
    print(json.dumps({"revision": PIN, "target": subprocess.check_output(["rustc", "-vV"], text=True).split("host: ")[1].splitlines()[0], **{name: lib.native_type_sizes(i) for i,name in enumerate(["ChoiceNode", "Span", "CachedRun"])}}))

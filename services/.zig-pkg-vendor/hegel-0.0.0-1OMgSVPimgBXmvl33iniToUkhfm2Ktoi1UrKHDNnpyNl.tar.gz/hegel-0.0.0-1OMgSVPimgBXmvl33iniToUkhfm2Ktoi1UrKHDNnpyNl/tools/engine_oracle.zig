const std = @import("std");
const c = @import("engine");

const Scenario = enum { integers, bytes, floats, pools, state_machine, stale_cache, invalid, text, regex, internet, structured, clones, unstable, targeting, unstable_target, nd_targeting };
const Operation = struct {
    op: []const u8,
    rc: i32,
    integer: ?i64 = null,
    bits: ?u64 = null,
    bytes: ?[]const u8 = null,
};

const Case = struct {
    ctx: *c.hegel_context_t,
    tc: *c.hegel_test_case_t,
    allocator: std.mem.Allocator,
    operations: std.ArrayList(Operation) = .empty,
    index: usize = 0,

    fn integer(self: *Case, min: i64, max: i64) !i64 {
        var value: i64 = 0;
        const rc = c.hegel_generate_integer(self.ctx, self.tc, min, max, &value);
        try self.operations.append(self.allocator, .{ .op = "integer", .rc = rc, .integer = if (rc == c.HEGEL_OK) value else null });
        try checked(self.ctx, rc);
        return value;
    }

    fn boolean(self: *Case, p: f64, forced: ?bool) !void {
        var value = false;
        const rc = c.hegel_generate_boolean(self.ctx, self.tc, p, forced orelse false, forced != null, &value);
        try self.operations.append(self.allocator, .{ .op = "boolean", .rc = rc, .integer = if (rc == c.HEGEL_OK) @intFromBool(value) else null });
        try checked(self.ctx, rc);
    }

    fn byteString(self: *Case, min: u64, max: u64) !void {
        var value: c.hegel_generate_bytes_result_t = .{ .data = null, .len = 0 };
        const rc = c.hegel_generate_bytes(self.ctx, self.tc, min, max, &value);
        defer _ = c.hegel_generate_bytes_result_free(self.ctx, &value);
        try self.operations.append(self.allocator, .{ .op = "bytes", .rc = rc, .bytes = if (rc == c.HEGEL_OK) try hex(self.allocator, value.data[0..value.len]) else null });
        try checked(self.ctx, rc);
    }

    fn float(self: *Case, width: u32, min: f64, max: f64, nan: bool, infinity: bool) !void {
        var value: f64 = 0;
        const smallest: f64 = if (width == 32) @floatCast(@as(f32, @bitCast(@as(u32, 1)))) else @bitCast(@as(u64, 1));
        const rc = c.hegel_generate_float(self.ctx, self.tc, width, min, max, nan, infinity, false, false, smallest, &value);
        try self.operations.append(self.allocator, .{ .op = "float", .rc = rc, .bits = if (rc == c.HEGEL_OK) @bitCast(value) else null });
        try checked(self.ctx, rc);
    }

    fn string(self: *Case, name: []const u8, generator: *c.hegel_string_generator_t) !void {
        var value: c.hegel_generate_string_result_t = .{ .data = null, .len = 0 };
        const rc = c.hegel_generate_string(self.ctx, self.tc, generator, &value);
        defer _ = c.hegel_generate_string_result_free(self.ctx, &value);
        try self.operations.append(self.allocator, .{ .op = name, .rc = rc, .bytes = if (rc == c.HEGEL_OK) try hex(self.allocator, @as([*]const u8, @ptrCast(value.data))[0..value.len]) else null });
        try checked(self.ctx, rc);
    }

    fn fixedBytes(self: *Case, name: []const u8, rc: c.hegel_result_t, bytes: []const u8) !void {
        try self.operations.append(self.allocator, .{ .op = name, .rc = rc, .bytes = if (rc == c.HEGEL_OK) try hex(self.allocator, bytes) else null });
        try checked(self.ctx, rc);
    }

    fn body(self: *Case, scenario: Scenario) !?[*:0]const u8 {
        switch (scenario) {
            .integers => {
                for ([_][2]i64{ .{ 0, 0 }, .{ -1, 1 }, .{ -256, 256 }, .{ std.math.minInt(i64), std.math.maxInt(i64) }, .{ -9000, -1000 }, .{ 1000, 9000 } }) |bounds|
                    _ = try self.integer(bounds[0], bounds[1]);
                try self.boolean(0, null);
                try self.boolean(1, null);
                try self.boolean(0.25, null);
                try self.boolean(0.75, true);
                try self.boolean(0.75, false);
            },
            .bytes => {
                try self.byteString(0, 0);
                try self.byteString(0, 32);
                try self.byteString(7, 7);
                try self.byteString(32, 64);
            },
            .floats => {
                try self.float(64, -10, 10, false, false);
                try self.float(64, -std.math.inf(f64), std.math.inf(f64), true, true);
                try self.float(32, -1, 1, false, false);
                try self.float(64, -0.0, 0.0, false, false);
            },
            .pools => {
                var pool: ?*c.hegel_pool_t = null;
                try checked(self.ctx, c.hegel_new_pool(self.ctx, self.tc, &pool));
                defer _ = c.hegel_pool_free(self.ctx, pool);
                for (0..4) |_| {
                    var id: i64 = 0;
                    const rc = c.hegel_pool_add(self.ctx, self.tc, pool, &id);
                    try self.operations.append(self.allocator, .{ .op = "pool_add", .rc = rc, .integer = if (rc == c.HEGEL_OK) id else null });
                    try checked(self.ctx, rc);
                }
                for (0..5) |i| {
                    var id: i64 = 0;
                    const rc = c.hegel_pool_generate(self.ctx, self.tc, pool, i != 0, &id);
                    try self.operations.append(self.allocator, .{ .op = "pool_generate", .rc = rc, .integer = if (rc == c.HEGEL_OK) id else null });
                    try checked(self.ctx, rc);
                }
            },
            .state_machine, .stale_cache => {
                const names = [_][*c]const u8{ "put", "sum" };
                const groups = [_]i64{ 0, 0 };
                const weights = [_]f64{ 2, 1 };
                var machine: ?*c.hegel_state_machine_t = null;
                var concurrency: i64 = 0;
                try checked(self.ctx, c.hegel_new_state_machine(self.ctx, self.tc, &names, &groups, &weights, names.len, null, null, 0, 1, 1, 20, &machine, &concurrency));
                defer _ = c.hegel_state_machine_free(self.ctx, machine);
                var values: [4]?i64 = @splat(null);
                var cached: ?i64 = null;
                while (true) {
                    var group: i64 = 0;
                    const rc = c.hegel_state_machine_next_group(self.ctx, self.tc, machine, &group);
                    try self.operations.append(self.allocator, .{ .op = "machine_group", .rc = rc, .integer = if (rc == c.HEGEL_OK) group else null });
                    try checked(self.ctx, rc);
                    if (group == c.HEGEL_STATE_MACHINE_DONE) break;
                    while (true) {
                        var rule: i64 = 0;
                        const r = c.hegel_state_machine_next_rule(self.ctx, self.tc, machine, 0, &rule);
                        try self.operations.append(self.allocator, .{ .op = "machine_rule", .rc = r, .integer = if (r == c.HEGEL_OK) rule else null });
                        try checked(self.ctx, r);
                        if (rule == c.HEGEL_STATE_MACHINE_DONE) break;
                        if (rule == 0) {
                            const key: usize = @intCast(try self.integer(0, 3));
                            const value = try self.integer(0, 255);
                            if (values[key] == null) cached = null;
                            values[key] = value;
                        } else {
                            var total: i64 = 0;
                            for (values) |value| total += value orelse 0;
                            if (cached == null) cached = total;
                            if (scenario == .stale_cache and cached != total) return "sum() disagrees with a recompute";
                        }
                    }
                }
            },
            .text => {
                for ([_][*:0]const u8{ "ascii", "utf-8", "latin-1" }) |codec| {
                    var generator: ?*c.hegel_string_generator_t = null;
                    try checked(self.ctx, c.hegel_string_generator_text(self.ctx, 0, 32, codec, 0, 0x10ffff, null, 0, null, 0, null, 0, null, 0, &generator));
                    defer _ = c.hegel_string_generator_free(self.ctx, generator);
                    try self.string(std.mem.span(codec), generator.?);
                }
            },
            .regex => {
                var alphabet: ?*c.hegel_string_generator_t = null;
                try checked(self.ctx, c.hegel_string_generator_text(self.ctx, 0, 32, "ascii", 0, 127, null, 0, null, 0, null, 0, null, 0, &alphabet));
                defer _ = c.hegel_string_generator_free(self.ctx, alphabet);
                for ([_][]const u8{ "^a{2,4}b$", "(?P<x>ab)(?P=x)", "a(?=b)b", "a(?!b)c", "(?>ab)c", "a{1,3}+b", "(?i)[a-z]{2,8}", "(?:ab|XY)[0-9]{1,4}", "(a)?(?(1)b|c)" }) |pattern| {
                    var generator: ?*c.hegel_string_generator_t = null;
                    try checked(self.ctx, c.hegel_string_generator_regex(self.ctx, pattern.ptr, pattern.len, true, alphabet, &generator));
                    defer _ = c.hegel_string_generator_free(self.ctx, generator);
                    try self.string(pattern, generator.?);
                }
                const pattern = "[a-z]{1,3}";
                var search: ?*c.hegel_string_generator_t = null;
                try checked(self.ctx, c.hegel_string_generator_regex(self.ctx, pattern, pattern.len, false, alphabet, &search));
                defer _ = c.hegel_string_generator_free(self.ctx, search);
                try self.string("search", search.?);
            },
            .internet => {
                var domain: ?*c.hegel_string_generator_t = null;
                try checked(self.ctx, c.hegel_string_generator_domain(self.ctx, 255, &domain));
                defer _ = c.hegel_string_generator_free(self.ctx, domain);
                try self.string("domain", domain.?);
                var email: ?*c.hegel_string_generator_t = null;
                try checked(self.ctx, c.hegel_string_generator_email(self.ctx, &email));
                defer _ = c.hegel_string_generator_free(self.ctx, email);
                try self.string("email", email.?);
                var url: ?*c.hegel_string_generator_t = null;
                try checked(self.ctx, c.hegel_string_generator_url(self.ctx, &url));
                defer _ = c.hegel_string_generator_free(self.ctx, url);
                try self.string("url", url.?);
            },
            .structured => {
                var uuid: [16]u8 = undefined;
                try self.fixedBytes("uuid4", c.hegel_generate_uuid(self.ctx, self.tc, 4, true, &uuid), &uuid);
                try self.fixedBytes("uuid", c.hegel_generate_uuid(self.ctx, self.tc, 0, false, &uuid), &uuid);
                var ipv4: [4]u8 = undefined;
                try self.fixedBytes("ipv4", c.hegel_generate_ipv4(self.ctx, self.tc, &ipv4), &ipv4);
                var ipv6: [16]u8 = undefined;
                try self.fixedBytes("ipv6", c.hegel_generate_ipv6(self.ctx, self.tc, &ipv6), &ipv6);
                var date: c.hegel_date_t = undefined;
                const dr = c.hegel_generate_date(self.ctx, self.tc, .{ .year = -999999, .month = 1, .day = 1 }, .{ .year = 999999, .month = 12, .day = 31 }, &date);
                try self.operations.append(self.allocator, .{ .op = "date", .rc = dr, .bytes = if (dr == c.HEGEL_OK) try std.fmt.allocPrint(self.allocator, "{d}-{d}-{d}", .{ date.year, date.month, date.day }) else null });
                try checked(self.ctx, dr);
                var time: c.hegel_time_t = undefined;
                const tr = c.hegel_generate_time(self.ctx, self.tc, .{ .hour = 0, .minute = 0, .second = 0, .nanosecond = 0 }, .{ .hour = 23, .minute = 59, .second = 59, .nanosecond = 999999999 }, &time);
                try self.operations.append(self.allocator, .{ .op = "time", .rc = tr, .bytes = if (tr == c.HEGEL_OK) try std.fmt.allocPrint(self.allocator, "{d}:{d}:{d}.{d}", .{ time.hour, time.minute, time.second, time.nanosecond }) else null });
                try checked(self.ctx, tr);
            },
            .clones => {
                _ = try self.integer(-10, 10);
                var child: ?*c.hegel_test_case_t = null;
                try checked(self.ctx, c.hegel_test_case_clone(self.ctx, self.tc, &child));
                defer _ = c.hegel_test_case_free(self.ctx, child);
                var child_case: Case = .{ .ctx = self.ctx, .tc = child.?, .allocator = self.allocator, .index = self.index };
                _ = try child_case.integer(0, 100);
                try child_case.boolean(0.5, null);
                try self.operations.appendSlice(self.allocator, child_case.operations.items);
                _ = try self.integer(1000, 2000);
            },
            .unstable => {
                _ = try self.integer(0, 100);
                if (self.index % 2 == 0) return "alternating verdict";
            },
            .targeting, .unstable_target, .nd_targeting => {
                const value = try self.integer(0, 1000);
                try checked(self.ctx, c.hegel_target(self.ctx, self.tc, @floatFromInt(value), "score"));
                if (scenario == .unstable_target and value > 500 and self.index % 3 != 0) return "intermittent scored failure";
                if (scenario == .nd_targeting and self.index == 0) return "one-off scored failure";
            },
            .invalid => {
                var value: i64 = 0;
                const rc = c.hegel_generate_integer(self.ctx, self.tc, 1, 0, &value);
                try self.operations.append(self.allocator, .{ .op = "invalid_integer_bounds", .rc = rc });
                if (rc != c.HEGEL_E_INVALID_ARG) return error.InvalidValidationResult;
                _ = try self.integer(0, 1);
            },
        }
        return null;
    }
};

pub fn main(init: std.process.Init) !void {
    const allocator = init.arena.allocator();
    const args = try init.minimal.args.toSlice(allocator);
    const scenario = if (args.len > 1) std.meta.stringToEnum(Scenario, args[1]) orelse return error.UnknownScenario else .integers;
    const seed: u64 = if (args.len > 2) try std.fmt.parseInt(u64, args[2], 10) else 1;
    const cases: u64 = if (args.len > 3) try std.fmt.parseInt(u64, args[3], 10) else 20;
    var blob_arg: ?[]const u8 = null;
    var database_path: ?[]const u8 = null;
    var arg_index: usize = 4;
    while (arg_index < args.len) : (arg_index += 1) {
        if (std.mem.eql(u8, args[arg_index], "--database")) {
            arg_index += 1;
            if (arg_index >= args.len) return error.MissingDatabasePath;
            database_path = args[arg_index];
        } else if (blob_arg == null) blob_arg = args[arg_index] else return error.UnexpectedArgument;
    }
    const ctx = c.hegel_context_new() orelse return error.ContextCreationFailed;
    defer _ = c.hegel_context_free(ctx);
    var settings: ?*c.hegel_settings_t = null;
    try checked(ctx, c.hegel_settings_new(ctx, &settings));
    defer _ = c.hegel_settings_free(ctx, settings);
    try checked(ctx, c.hegel_settings_set_backend(ctx, settings, c.HEGEL_BACKEND_DEFAULT));
    try checked(ctx, c.hegel_settings_set_derandomize(ctx, settings, false));
    try checked(ctx, c.hegel_settings_set_report_multiple_failures(ctx, settings, true));
    try checked(ctx, c.hegel_settings_set_nondeterminism_strictness(ctx, settings, c.HEGEL_NONDETERMINISM_ERROR));
    try checked(ctx, c.hegel_settings_set_seed(ctx, settings, seed, true));
    try checked(ctx, c.hegel_settings_set_test_cases(ctx, settings, cases));
    const database_c = try allocator.dupeSentinel(u8, database_path orelse "", 0);
    try checked(ctx, c.hegel_settings_set_database(ctx, settings, database_c));
    if (database_path != null) {
        const key = try std.fmt.allocPrint(allocator, "oracle/{s}", .{@tagName(scenario)});
        try checked(ctx, c.hegel_settings_set_database_key(ctx, settings, try allocator.dupeSentinel(u8, key, 0)));
    }
    try checked(ctx, c.hegel_settings_set_show_statistics(ctx, settings, false));
    try checked(ctx, c.hegel_settings_set_verbosity(ctx, settings, c.HEGEL_VERBOSITY_QUIET));
    if (scenario == .unstable or scenario == .unstable_target or scenario == .nd_targeting)
        try checked(ctx, c.hegel_settings_set_nondeterminism_strictness(ctx, settings, c.HEGEL_NONDETERMINISM_QUIET));
    if (scenario != .stale_cache and scenario != .unstable and scenario != .targeting and scenario != .unstable_target and scenario != .nd_targeting)
        try checked(ctx, c.hegel_settings_set_phases(ctx, settings, c.HEGEL_PHASE_GENERATE));
    var run: ?*c.hegel_run_t = null;
    if (blob_arg) |encoded| {
        const blob = try allocator.dupeSentinel(u8, encoded, 0);
        try checked(ctx, c.hegel_run_start_blob(ctx, settings, blob, null, null, &run));
    } else try checked(ctx, c.hegel_run_start(ctx, settings, null, null, &run));
    defer _ = c.hegel_run_free(ctx, run);
    try emit(init.io, allocator, .{ .record = "header", .schema = 1, .scenario = @tagName(scenario), .seed = seed, .cases = cases });
    var index: usize = 0;
    while (true) : (index += 1) {
        var tc: ?*c.hegel_test_case_t = null;
        try checked(ctx, c.hegel_next_test_case(ctx, run, &tc));
        const handle = tc orelse break;
        defer _ = c.hegel_test_case_free(ctx, handle);
        var arena = std.heap.ArenaAllocator.init(allocator);
        defer arena.deinit();
        var capture = false;
        try checked(ctx, c.hegel_test_case_should_capture(ctx, handle, &capture));
        var case: Case = .{ .ctx = ctx, .tc = handle, .allocator = arena.allocator(), .index = index };
        var status: u32 = c.HEGEL_STATUS_VALID;
        const origin = case.body(scenario) catch |err| switch (err) {
            error.StopTest => stop: {
                status = c.HEGEL_STATUS_OVERRUN;
                break :stop null;
            },
            error.Assume => stop: {
                status = c.HEGEL_STATUS_INVALID;
                break :stop null;
            },
            else => return err,
        };
        if (origin != null) status = c.HEGEL_STATUS_INTERESTING;
        try emit(init.io, allocator, .{ .record = "case", .index = index, .capture = capture, .operations = case.operations.items, .status = status, .origin = if (origin) |o| std.mem.span(o) else null });
        try checked(ctx, c.hegel_mark_complete(ctx, handle, status, origin));
    }
    var result: ?*c.hegel_run_result_t = null;
    try checked(ctx, c.hegel_run_result(ctx, run, &result));
    defer _ = c.hegel_run_result_free(ctx, result);
    var status: c.hegel_run_status_t = undefined;
    var count: usize = 0;
    var message: [*c]const u8 = null;
    try checked(ctx, c.hegel_run_result_status(ctx, result, &status));
    try checked(ctx, c.hegel_run_result_error(ctx, result, &message));
    try checked(ctx, c.hegel_run_result_failure_count(ctx, result, &count));
    try emit(init.io, allocator, .{ .record = "result", .status = status, .failures = count, .message = if (message != null) std.mem.span(message) else null });
    for (0..count) |i| {
        var failure: ?*c.hegel_failure_t = null;
        try checked(ctx, c.hegel_run_result_failure(ctx, result, i, &failure));
        defer _ = c.hegel_failure_free(ctx, failure);
        var origin: [*c]const u8 = null;
        var blob: [*c]const u8 = null;
        var caveat: [*c]const u8 = null;
        try checked(ctx, c.hegel_failure_origin(ctx, failure, &origin));
        try checked(ctx, c.hegel_failure_reproduction_blob(ctx, failure, &blob));
        try checked(ctx, c.hegel_failure_caveat(ctx, failure, &caveat));
        try emit(init.io, allocator, .{ .record = "failure", .origin = if (origin != null) std.mem.span(origin) else null, .blob = if (blob != null) std.mem.span(blob) else null, .caveat = if (caveat != null) std.mem.span(caveat) else null });
    }
}

fn checked(ctx: *c.hegel_context_t, rc: c.hegel_result_t) !void {
    switch (rc) {
        c.HEGEL_OK => {},
        c.HEGEL_E_STOP_TEST => return error.StopTest,
        c.HEGEL_E_ASSUME => return error.Assume,
        else => {
            std.debug.print("oracle call failed ({d}): {s}\n", .{ rc, c.hegel_context_last_error(ctx) });
            return error.EngineCallFailed;
        },
    }
}

fn emit(io: std.Io, allocator: std.mem.Allocator, value: anytype) !void {
    const line = try std.json.Stringify.valueAlloc(allocator, value, .{});
    defer allocator.free(line);
    try std.Io.File.stdout().writeStreamingAll(io, line);
    try std.Io.File.stdout().writeStreamingAll(io, "\n");
}

fn hex(allocator: std.mem.Allocator, bytes: []const u8) ![]u8 {
    const out = try allocator.alloc(u8, bytes.len * 2);
    const alphabet = "0123456789abcdef";
    for (bytes, 0..) |byte, i| {
        out[i * 2] = alphabet[byte >> 4];
        out[i * 2 + 1] = alphabet[byte & 15];
    }
    return out;
}

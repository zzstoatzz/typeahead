//! plant each bug from a mutants file in turn, run the harness under several
//! seeds, and report how many seeds caught it. the tree is restored after
//! each mutant. a fixed finding belongs here as the mutant that undoes its
//! fix, so the harness is shown to find it again.
//!
//! usage: hegel-mutants <mutants.zon> [--seeds n] -- <command...>
//!
//! the command builds and runs the harness, e.g. `zig build pbt -Dhegel`. a
//! seed catches a mutant when the command prints `FAILED:`. the unmutated
//! code runs first and must pass every seed. `HEGEL_MUTANTS_ONLY` keeps the
//! mutants whose name contains it. exits 1 when a mutant survives every seed.

const std = @import("std");
const Io = std.Io;

const Mutant = struct {
    name: []const u8,
    file: []const u8,
    old: []const u8,
    new: []const u8,
};

const Outcome = enum { passed, caught, crashed };

pub fn main(init: std.process.Init) !void {
    const gpa = init.gpa;
    const io = init.io;
    const arena = init.arena.allocator();
    const args = try init.minimal.args.toSlice(arena);

    var seeds: u32 = 10;
    var zon_path: ?[]const u8 = null;
    var command: []const []const u8 = &.{};
    var i: usize = 1;
    while (i < args.len) : (i += 1) {
        const arg = args[i];
        if (std.mem.eql(u8, arg, "--")) {
            command = @ptrCast(args[i + 1 ..]);
            break;
        } else if (std.mem.eql(u8, arg, "--seeds") and i + 1 < args.len) {
            i += 1;
            seeds = try std.fmt.parseInt(u32, args[i], 10);
        } else zon_path = arg;
    }
    if (zon_path == null or command.len == 0) {
        std.debug.print("usage: hegel-mutants <mutants.zon> [--seeds n] -- <command...>\n", .{});
        std.process.exit(2);
    }

    const cwd = Io.Dir.cwd();
    const source = try cwd.readFileAllocOptions(io, zon_path.?, arena, .unlimited, .of(u8), 0);
    var diagnostics: std.zon.parse.Diagnostics = .{ .errors = &.{} };
    const mutants = std.zon.parse.fromSlice([]const Mutant, .{
        .gpa = gpa,
        .arena = arena,
        .source = source,
        .diagnostics = &diagnostics,
    }) catch |err| {
        if (err == error.ParseZon) diagnostics.log(zon_path.?);
        return err;
    };

    var env = try init.environ_map.clone(gpa);
    defer env.deinit();
    const only = init.environ_map.get("HEGEL_MUTANTS_ONLY");

    // every site is checked before anything runs
    for (mutants) |mutant| {
        const original = try cwd.readFileAlloc(io, mutant.file, gpa, .unlimited);
        defer gpa.free(original);
        _ = site(mutant, original);
    }

    std.debug.print("baseline: ", .{});
    for (1..seeds + 1) |seed| {
        const outcome = try runSeed(gpa, io, &env, command, seed);
        if (outcome != .passed) {
            std.debug.print("seed {d} {s} without a mutant; fix the harness first\n", .{ seed, @tagName(outcome) });
            std.process.exit(1);
        }
    }
    std.debug.print("passes {d}/{d}\n", .{ seeds, seeds });

    var survivors: usize = 0;
    for (mutants) |mutant| {
        if (only) |filter| if (std.mem.indexOf(u8, mutant.name, filter) == null) continue;
        const original = try cwd.readFileAlloc(io, mutant.file, gpa, .unlimited);
        defer gpa.free(original);
        const at = site(mutant, original);
        const mutated = try std.mem.concat(gpa, u8, &.{ original[0..at], mutant.new, original[at + mutant.old.len ..] });
        defer gpa.free(mutated);

        try cwd.writeFile(io, .{ .sub_path = mutant.file, .data = mutated });
        defer cwd.writeFile(io, .{ .sub_path = mutant.file, .data = original }) catch |err|
            std.debug.panic("could not restore {s}: {t}", .{ mutant.file, err });

        var caught: u32 = 0;
        var crashed: u32 = 0;
        for (1..seeds + 1) |seed| switch (try runSeed(gpa, io, &env, command, seed)) {
            .passed => {},
            .caught => caught += 1,
            .crashed => crashed += 1,
        };
        if (caught == 0) survivors += 1;
        std.debug.print("{s}: caught {d}/{d}", .{ mutant.name, caught, seeds });
        if (crashed > 0) std.debug.print(", {d} failed without a property failure", .{crashed});
        std.debug.print("\n", .{});
    }
    if (survivors > 0) {
        std.debug.print("{d} mutant(s) survived every seed: a generator or assertion is missing something\n", .{survivors});
        std.process.exit(1);
    }
}

/// where `mutant.old` occurs in `original`, which must be exactly once.
fn site(mutant: Mutant, original: []const u8) usize {
    const at = std.mem.indexOf(u8, original, mutant.old) orelse {
        std.debug.print("{s}: the text to replace is not in {s}\n", .{ mutant.name, mutant.file });
        std.process.exit(1);
    };
    if (std.mem.indexOfPos(u8, original, at + 1, mutant.old) != null) {
        std.debug.print("{s}: the text to replace occurs more than once in {s}\n", .{ mutant.name, mutant.file });
        std.process.exit(1);
    }
    return at;
}

fn runSeed(gpa: std.mem.Allocator, io: Io, env: *std.process.Environ.Map, command: []const []const u8, seed: usize) !Outcome {
    var buf: [20]u8 = undefined;
    try env.put("HEGEL_SEED", try std.fmt.bufPrint(&buf, "{d}", .{seed}));
    const result = try std.process.run(gpa, io, .{ .argv = command, .environ_map = env });
    defer gpa.free(result.stdout);
    defer gpa.free(result.stderr);
    if (std.mem.indexOf(u8, result.stderr, "FAILED: ") != null) return .caught;
    if (result.term.success()) return .passed;
    return .crashed;
}

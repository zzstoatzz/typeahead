"""Reproduce printer.tsv from an isolated, locked copy of pinned libhegel."""
import hashlib
import io
import pathlib
import subprocess
import sys
import tarfile
import tempfile

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
LOCK_SHA256 = "cfa4dbc184e94b43d0b83fc4689d1c8e9f01f06e94e7d986e68be8a05b9c995d"
HELPER_SHA256 = "b9e3f970a39e6e26a501476a5609f72dbf38873fbfeb3680a9650e70a19423b5"
FIXTURE_SHA256 = "d622ab7f1365287300c2d7ecf18b39dd186866a5a80534864b6dd92303879f87"


def check_hash(data, expected, name):
    actual = hashlib.sha256(data).hexdigest()
    if actual != expected:
        raise SystemExit(f"{name}: expected sha256 {expected}, found {actual}")


if len(sys.argv) != 2:
    raise SystemExit(f"usage: {sys.argv[0]} /path/to/pinned/hegel-rust")
upstream = pathlib.Path(sys.argv[1]).resolve()
root = pathlib.Path(__file__).resolve().parent.parent
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip()
if revision != PIN:
    raise SystemExit(f"expected upstream {PIN}, found {revision}")
helper = (root / "tools/native_printer_oracle.rs").read_bytes()
check_hash(helper, HELPER_SHA256, "printer oracle helper")

with tempfile.TemporaryDirectory(prefix="hegel-printer-oracle-") as temp:
    crate = pathlib.Path(temp)
    archive = subprocess.check_output(["git", "archive", PIN], cwd=upstream)
    tarfile.open(fileobj=io.BytesIO(archive)).extractall(crate, filter="data")
    lockfile = crate / "Cargo.lock"
    check_hash(lockfile.read_bytes(), LOCK_SHA256, "pinned Cargo.lock")
    source = crate / "hegel-c/src/lib.rs"
    source.write_bytes(source.read_bytes() + b"\n" + helper)
    target = crate / "target"
    subprocess.run(
        ["cargo", "build", "-p", "hegeltest-c", "--release", "--locked", "--offline", "--target-dir", str(target)],
        cwd=crate,
        check=True,
    )
    check_hash(lockfile.read_bytes(), LOCK_SHA256, "Cargo.lock after build")
    extension = "dylib" if sys.platform == "darwin" else "so"
    library = target / "release" / ("libhegel_c." + extension)
    fixture = subprocess.check_output(
        [sys.executable, "-c", "import ctypes,sys; ctypes.CDLL(sys.argv[1]).native_printer_oracle()", str(library)]
    )
    if len(fixture.splitlines()) != 498:
        raise SystemExit("printer oracle did not produce 498 records")
    check_hash(fixture, FIXTURE_SHA256, "printer fixture")
    destination = root / "tests/engine/fixtures/printer.tsv"
    destination.write_bytes(fixture)
    print(f"{destination}: 498 cases; sha256={FIXTURE_SHA256}")

const std = @import("std");
const c = @import("engine");
const TextOptions = struct {
    min: u64 = 0,
    max: u64 = 1,
    codec: [*c]const u8 = null,
    min_cp: u32 = 0,
    max_cp: u32 = 0xffffffff,
    categories: [*c]const [*c]const u8 = null,
    categories_len: usize = 0,
    excluded_categories: [*c]const [*c]const u8 = null,
    excluded_categories_len: usize = 0,
    include: [*c]const u8 = null,
    include_len: usize = 0,
    exclude: [*c]const u8 = null,
    exclude_len: usize = 0,
};
const Harness = struct {
    io: std.Io,
    allocator: std.mem.Allocator,
    ctx: *c.hegel_context_t,
    fn record(self: Harness, name: []const u8, rc: c_int, output: ?*c.hegel_string_generator_t) !void {
        const message = c.hegel_context_last_error(self.ctx);
        const line = try std.json.Stringify.valueAlloc(self.allocator, .{ .name = name, .rc = rc, .generator = output != null, .message = if (message != null) std.mem.span(message) else null }, .{});
        defer self.allocator.free(line);
        try std.Io.File.stdout().writeStreamingAll(self.io, line);
        try std.Io.File.stdout().writeStreamingAll(self.io, "\n");
    }
    fn primitive(self: Harness, name: []const u8, rc: c_int, boolean: ?bool, bits: ?u64) !void {
        const message = c.hegel_context_last_error(self.ctx);
        const line = try std.json.Stringify.valueAlloc(self.allocator, .{ .name = name, .rc = rc, .boolean = boolean, .bits = bits, .message = if (message != null) std.mem.span(message) else null }, .{});
        defer self.allocator.free(line);
        try std.Io.File.stdout().writeStreamingAll(self.io, line);
        try std.Io.File.stdout().writeStreamingAll(self.io, "\n");
    }
    fn text(self: Harness, name: []const u8, o: TextOptions) !void {
        var output: ?*c.hegel_string_generator_t = null;
        const rc = c.hegel_string_generator_text(self.ctx, o.min, o.max, o.codec, o.min_cp, o.max_cp, o.categories, o.categories_len, o.excluded_categories, o.excluded_categories_len, o.include, o.include_len, o.exclude, o.exclude_len, &output);
        try self.record(name, rc, output);
        if (output != null) _ = c.hegel_string_generator_free(self.ctx, output);
    }
    fn regex(self: Harness, name: []const u8, pattern: [*c]const u8, len: usize, alphabet: ?*c.hegel_string_generator_t) !void {
        var output: ?*c.hegel_string_generator_t = null;
        const rc = c.hegel_string_generator_regex(self.ctx, pattern, len, true, alphabet, &output);
        try self.record(name, rc, output);
        if (output != null) _ = c.hegel_string_generator_free(self.ctx, output);
    }
};
pub fn main(init: std.process.Init) !void {
    const ctx = c.hegel_context_new() orelse return error.NoContext;
    defer _ = c.hegel_context_free(ctx);
    const h: Harness = .{ .io = init.io, .allocator = init.arena.allocator(), .ctx = ctx };
    const invalid_utf8 = [_]u8{ 0xff, 0 };
    const invalid_category = [_][*c]const u8{"bad"};
    const invalid_category_utf8 = [_][*c]const u8{&invalid_utf8};
    const null_category = [_][*c]const u8{null};
    const letters = [_][*c]const u8{"L"};
    try h.text("text_valid_ascii", .{ .codec = "ascii" });
    try h.text("text_bad_sizes", .{ .min = 2, .max = 1 });
    try h.text("text_bad_codec", .{ .codec = "utf16" });
    try h.text("text_codec_invalid_utf8", .{ .codec = &invalid_utf8 });
    try h.text("text_bad_category", .{ .categories = &invalid_category, .categories_len = 1 });
    try h.text("text_category_invalid_utf8", .{ .categories = &invalid_category_utf8, .categories_len = 1 });
    try h.text("text_category_null_element", .{ .categories = &null_category, .categories_len = 1 });
    try h.text("text_categories_null_nonzero", .{ .categories_len = 1 });
    try h.text("text_excluded_categories_null_nonzero", .{ .excluded_categories_len = 1 });
    try h.text("text_category_precedence", .{ .categories = &letters, .categories_len = 1, .excluded_categories = &letters, .excluded_categories_len = 1, .codec = "ascii" });
    try h.text("text_empty_categories_nonempty_string", .{ .categories = &letters, .categories_len = 0 });
    try h.text("text_empty_categories_empty_string", .{ .categories = &letters, .categories_len = 0, .max = 0 });
    try h.text("text_include_null_nonzero", .{ .include_len = 1 });
    try h.text("text_exclude_null_nonzero", .{ .exclude_len = 1 });
    try h.text("text_include_invalid_utf8", .{ .include = &invalid_utf8, .include_len = 1 });
    try h.text("text_exclude_invalid_utf8", .{ .exclude = &invalid_utf8, .exclude_len = 1 });
    try h.text("text_ascii_include_latin1", .{ .codec = "ascii", .include = "é", .include_len = 2 });
    try h.text("text_ascii_include_controls", .{ .codec = "ascii", .include = "\xc2\x85", .include_len = 2 });
    try h.text("text_latin1_include_nonlatin1", .{ .codec = "latin-1", .include = "😀", .include_len = 4 });
    try h.text("text_include_exclude_overlap", .{ .include = "a\naé", .include_len = 5, .exclude = "a\n", .exclude_len = 2 });
    try h.text("text_include_after_bounds", .{ .min_cp = 'a', .max_cp = 'z', .include = "A", .include_len = 1 });
    try h.text("text_include_nul", .{ .include = "\x00", .include_len = 1 });
    try h.text("text_surrogate_only_nonempty", .{ .min_cp = 0xd800, .max_cp = 0xdfff });
    try h.text("text_surrogate_only_empty", .{ .min_cp = 0xd800, .max_cp = 0xdfff, .max = 0 });
    try h.text("text_reversed_codepoints_nonempty", .{ .min_cp = 10, .max_cp = 5 });
    try h.text("text_reversed_codepoints_empty", .{ .min_cp = 10, .max_cp = 5, .max = 0 });
    var output: ?*c.hegel_string_generator_t = null;
    try h.record("text_null_output", c.hegel_string_generator_text(ctx, 0, 1, null, 0, 0xffffffff, null, 0, null, 0, null, 0, null, 0, null), null);
    try h.record("regex_null_output", c.hegel_string_generator_regex(ctx, "a", 1, true, null, null), null);
    try h.regex("regex_null_empty", null, 0, null);
    try h.regex("regex_null_nonzero", null, 1, null);
    try h.regex("regex_invalid_utf8", &invalid_utf8, 1, null);
    try h.regex("regex_embedded_nul", "\x00a", 2, null);
    for ([_][]const u8{ "[", "(", "(?P=x)", "\\ud800", "\\U00110000", "\\N{SPACE}", "a{3,2}", "(?i-i:a)", "(?L:a)", "a(?i)b", "[z-a]", "(?(2)a|b)" }, 0..) |pattern, i| {
        const name = try std.fmt.allocPrint(h.allocator, "regex_syntax_{}", .{i});
        try h.regex(name, pattern.ptr, pattern.len, null);
    }
    const email_rc = c.hegel_string_generator_email(ctx, &output);
    try h.record("email_setup", email_rc, output);
    if (output) |email| {
        defer _ = c.hegel_string_generator_free(ctx, email);
        try h.regex("regex_wrong_alphabet_kind", "a", 1, email);
    }
    try h.record("email_null_output", c.hegel_string_generator_email(ctx, null), null);
    try h.record("url_null_output", c.hegel_string_generator_url(ctx, null), null);
    try h.record("domain_null_output", c.hegel_string_generator_domain(ctx, 255, null), null);
    for ([_]u64{ 0, 1, 2, 3, 4, 255, 256, std.math.maxInt(u64) }) |length| {
        output = null;
        const rc = c.hegel_string_generator_domain(ctx, length, &output);
        const name = try std.fmt.allocPrint(h.allocator, "domain_{}", .{length});
        try h.record(name, rc, output);
        if (output != null) _ = c.hegel_string_generator_free(ctx, output);
    }
    try h.record("generator_free_null", c.hegel_string_generator_free(ctx, null), null);
    try primitiveContracts(h);
}

fn require(rc: c_int) !void {
    if (rc != c.HEGEL_OK) return error.SetupFailed;
}
fn primitiveContracts(h: Harness) !void {
    var settings: ?*c.hegel_settings_t = null;
    try require(c.hegel_settings_new(h.ctx, &settings));
    defer _ = c.hegel_settings_free(h.ctx, settings);
    try require(c.hegel_settings_set_seed(h.ctx, settings, 1, true));
    try require(c.hegel_settings_set_test_cases(h.ctx, settings, 1));
    try require(c.hegel_settings_set_phases(h.ctx, settings, c.HEGEL_PHASE_GENERATE));
    try require(c.hegel_settings_set_verbosity(h.ctx, settings, c.HEGEL_VERBOSITY_QUIET));
    try require(c.hegel_settings_set_database(h.ctx, settings, ""));
    var run: ?*c.hegel_run_t = null;
    try require(c.hegel_run_start(h.ctx, settings, null, null, &run));
    defer _ = c.hegel_run_free(h.ctx, run);
    var index: usize = 0;
    while (true) {
        var tc: ?*c.hegel_test_case_t = null;
        try require(c.hegel_next_test_case(h.ctx, run, &tc));
        const handle = tc orelse break;
        defer _ = c.hegel_test_case_free(h.ctx, handle);
        const BoolCase = struct { name: []const u8, p: f64, forced: bool = false, has_forced: bool = false };
        for ([_]BoolCase{
            .{ .name = "boolean_nan", .p = std.math.nan(f64) },                                       .{ .name = "boolean_inf", .p = std.math.inf(f64) },                                         .{ .name = "boolean_negative", .p = -0.1 },                                    .{ .name = "boolean_above_one", .p = 1.1 },
            .{ .name = "boolean_force_impossible_true", .p = 0, .forced = true, .has_forced = true }, .{ .name = "boolean_force_impossible_false", .p = 1, .forced = false, .has_forced = true }, .{ .name = "boolean_force_true", .p = 1, .forced = true, .has_forced = true }, .{ .name = "boolean_force_false", .p = 0, .forced = false, .has_forced = true },
        }) |fixture| {
            var value = true;
            const rc = c.hegel_generate_boolean(h.ctx, handle, fixture.p, fixture.forced, fixture.has_forced, &value);
            const name = try std.fmt.allocPrint(h.allocator, "{}_{s}", .{ index, fixture.name });
            try h.primitive(name, rc, value, null);
        }
        try h.primitive("boolean_null_output", c.hegel_generate_boolean(h.ctx, handle, 0.5, false, false, null), null, null);
        const FloatCase = struct { name: []const u8, width: u32 = 64, min: f64 = 0, max: f64 = 1, nan: bool = false, infinity: bool = false, exclude_min: bool = false, exclude_max: bool = false, smallest: f64 = 1e-300 };
        for ([_]FloatCase{
            .{ .name = "float_bad_width", .width = 16 },                                      .{ .name = "float_nan_bound", .min = std.math.nan(f64) },                                   .{ .name = "float_reversed_bounds", .min = 1, .max = 0 },
            .{ .name = "float_zero_smallest", .smallest = 0 },                                .{ .name = "float_nan_smallest", .smallest = std.math.nan(f64) },                           .{ .name = "float_inf_smallest", .smallest = std.math.inf(f64) },
            .{ .name = "float_nan_bounded", .nan = true },                                    .{ .name = "float_inf_bounded", .infinity = true },                                         .{ .name = "float_f32_inexact_bound", .width = 32, .min = 0.1 },
            .{ .name = "float_excluded_singleton", .min = 0, .max = 0, .exclude_min = true }, .{ .name = "float_excluded_negative_zero", .min = -0.0, .max = -0.0, .exclude_max = true },
        }) |fixture| {
            var value: f64 = 42.5;
            const rc = c.hegel_generate_float(h.ctx, handle, fixture.width, fixture.min, fixture.max, fixture.nan, fixture.infinity, fixture.exclude_min, fixture.exclude_max, fixture.smallest, &value);
            const name = try std.fmt.allocPrint(h.allocator, "{}_{s}", .{ index, fixture.name });
            try h.primitive(name, rc, null, @bitCast(value));
        }
        var integer: i64 = 77;
        try h.primitive("integer_reversed", c.hegel_generate_integer(h.ctx, handle, 2, 1, &integer), null, null);
        var bytes: c.hegel_generate_bytes_result_t = .{ .data = null, .len = 77 };
        const bytes_rc = c.hegel_generate_bytes(h.ctx, handle, 2, 1, &bytes);
        try h.primitive("bytes_reversed", bytes_rc, null, bytes.len);
        var date: c.hegel_date_t = undefined;
        const DateCase = struct { name: []const u8, min: c.hegel_date_t, max: c.hegel_date_t };
        for ([_]DateCase{
            .{ .name = "date_invalid_month", .min = .{ .year = 2024, .month = 0, .day = 1 }, .max = .{ .year = 2024, .month = 12, .day = 31 } },
            .{ .name = "date_invalid_leap_day", .min = .{ .year = 2023, .month = 1, .day = 1 }, .max = .{ .year = 2023, .month = 2, .day = 29 } },
            .{ .name = "date_invalid_year", .min = .{ .year = -1000000, .month = 1, .day = 1 }, .max = .{ .year = 2024, .month = 12, .day = 31 } },
            .{ .name = "date_reversed", .min = .{ .year = 2025, .month = 1, .day = 1 }, .max = .{ .year = 2024, .month = 12, .day = 31 } },
        }) |fixture| try h.primitive(fixture.name, c.hegel_generate_date(h.ctx, handle, fixture.min, fixture.max, &date), null, null);
        var time: c.hegel_time_t = undefined;
        const TimeCase = struct { name: []const u8, min: c.hegel_time_t, max: c.hegel_time_t };
        for ([_]TimeCase{
            .{ .name = "time_invalid_hour", .min = .{ .hour = 24, .minute = 0, .second = 0, .nanosecond = 0 }, .max = .{ .hour = 23, .minute = 59, .second = 59, .nanosecond = 999999999 } },
            .{ .name = "time_invalid_nanosecond", .min = .{ .hour = 0, .minute = 0, .second = 0, .nanosecond = 0 }, .max = .{ .hour = 0, .minute = 0, .second = 0, .nanosecond = 1000000000 } },
            .{ .name = "time_reversed", .min = .{ .hour = 12, .minute = 0, .second = 0, .nanosecond = 0 }, .max = .{ .hour = 11, .minute = 59, .second = 59, .nanosecond = 999999999 } },
        }) |fixture| try h.primitive(fixture.name, c.hegel_generate_time(h.ctx, handle, fixture.min, fixture.max, &time), null, null);
        var datetime: c.hegel_datetime_t = undefined;
        const day: c.hegel_date_t = .{ .year = 2024, .month = 1, .day = 1 };
        try h.primitive("datetime_invalid_time", c.hegel_generate_datetime(h.ctx, handle, .{ .date = day, .time = .{ .hour = 24, .minute = 0, .second = 0, .nanosecond = 0 } }, .{ .date = day, .time = .{ .hour = 0, .minute = 0, .second = 0, .nanosecond = 0 } }, &datetime), null, null);
        try h.primitive("datetime_reversed", c.hegel_generate_datetime(h.ctx, handle, .{ .date = day, .time = .{ .hour = 12, .minute = 0, .second = 0, .nanosecond = 0 } }, .{ .date = day, .time = .{ .hour = 11, .minute = 0, .second = 0, .nanosecond = 0 } }, &datetime), null, null);
        var uuid: [16]u8 = undefined;
        try h.primitive("uuid_invalid_version", c.hegel_generate_uuid(h.ctx, handle, 16, true, &uuid), null, null);
        var value = false;
        const rc = c.hegel_generate_boolean(h.ctx, handle, 0.5, false, false, &value);
        const name = try std.fmt.allocPrint(h.allocator, "{}_stream_still_live", .{index});
        try h.primitive(name, rc, value, null);
        try require(c.hegel_mark_complete(h.ctx, handle, c.HEGEL_STATUS_VALID, null));
        index += 1;
    }
    var result: ?*c.hegel_run_result_t = null;
    try require(c.hegel_run_result(h.ctx, run, &result));
    defer _ = c.hegel_run_result_free(h.ctx, result);
    var status: c.hegel_run_status_t = undefined;
    try require(c.hegel_run_result_status(h.ctx, result, &status));
    try h.primitive("primitive_contract_run_status", c.HEGEL_OK, null, status);
}

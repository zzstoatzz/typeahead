use hegel_c::__bench::{BigInt, BytesChoice, FloatChoice, IntegerChoice, IntervalSet, StringChoice};
use std::sync::Arc;

fn hex(bytes: &[u8]) -> String {
    if bytes.is_empty() { return "_".into(); }
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

fn main() {
    for n in [-129i128,-128,-1,0,1,127,128,255,256,i128::MIN,i128::MAX] {
        let number=BigInt::from(n);
        println!("signed\t{}\t{}",number,hex(&number.to_signed_bytes_le()));
    }
    for (lo,hi,target) in [(-5i128,1,0),(-2,5,0),(5,10,-1),(-10,-5,0),(-5,5,2),(0,0,0)] {
        let choice=IntegerChoice{min_value:BigInt::from(lo),max_value:BigInt::from(hi),shrink_towards:BigInt::from(target)};
        for n in lo..=hi {
            let v=BigInt::from(n);
            println!("integer\t{}\t{}\t{}\t{}\t{}\t{}",lo,hi,target,n,choice.to_index(&v),choice.max_index());
        }
    }
    let mut bytes=vec![0u8;33]; bytes[32]=1;
    let bound=BigInt::from_signed_bytes_le(&bytes);
    let choice=IntegerChoice{min_value:-&bound,max_value:bound.clone(),shrink_towards:BigInt::from(123)};
    for v in [-&bound,BigInt::from(-1000),BigInt::from(123),bound.clone()] {
        println!("integer\t{}\t{}\t123\t{}\t{}\t{}",choice.min_value,choice.max_value,v,choice.to_index(&v),choice.max_index());
    }
    for v in [vec![],vec![0],vec![255],vec![0,0],vec![1,255],vec![0;32],vec![255;32]] {
        let choice=BytesChoice{min_size:0,max_size:32};
        println!("bytes\t0\t32\t{}\t{}",hex(&v),choice.to_index(&v));
    }
    let alphabet=Arc::new(IntervalSet::new(vec![(0x2f,0x32),(0x41,0x43),(0x10000,0x10001)]).unwrap());
    for v in [vec![],vec![0x30],vec![0x31],vec![0x2f,0x30,0x10000],vec![0x10001;3]] {
        let choice=StringChoice{intervals:alphabet.clone(),min_size:0,max_size:3};
        let value=if v.is_empty(){"_".into()}else{v.iter().map(|cp| format!("{cp:x}")).collect::<Vec<_>>().join(",")};
        println!("string\t0\t3\t{}\t{}",value,choice.to_index(&v));
    }
    for (min,max,allow_nan,allow_infinity,smallest) in [
        (f64::NEG_INFINITY,f64::INFINITY,true,true,f64::from_bits(1)),
        (-0.0,-0.0,false,false,f64::from_bits(1)),
        (65672.5,65673.0,false,false,f64::from_bits(1)),
        (0.5,0.75,false,false,f64::from_bits(1)),
        (-3.0,-0.25,false,false,f64::MIN_POSITIVE),
    ] {
        let choice=FloatChoice{min_value:min,max_value:max,allow_nan,allow_infinity,smallest_nonzero_magnitude:smallest};
        for bits in [0u64,0x8000000000000000,0x3ff0000000000000,0xbff0000000000000,0x3ff8000000000000,0x40f0088800000000,0x40f0089000000000,0x7fefffffffffffff,1,0x7ff0000000000000,0xfff0000000000000,0x7ff8000000000123,0xfff0000000000001,0x3fe0000000000000,0x3fe8000000000000] {
            let v=f64::from_bits(bits);
            if !choice.validate(v){continue;}
            println!("float\t{:016x}\t{:016x}\t{}\t{}\t{:016x}\t{:016x}\t{}\t{:016x}\t{:016x}",min.to_bits(),max.to_bits(),u8::from(allow_nan),u8::from(allow_infinity),smallest.to_bits(),bits,choice.to_index(v).unwrap(),choice.simplest().unwrap().to_bits(),choice.unit().unwrap().to_bits());
        }
    }
}

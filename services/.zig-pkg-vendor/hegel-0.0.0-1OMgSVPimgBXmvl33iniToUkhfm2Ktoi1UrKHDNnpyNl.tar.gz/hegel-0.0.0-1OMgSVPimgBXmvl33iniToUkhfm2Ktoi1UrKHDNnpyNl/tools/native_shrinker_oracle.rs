#[unsafe(no_mangle)] pub extern "C" fn native_shrinker_oracle() {
 use alloc::{vec,vec::Vec,string::{String,ToString},format,sync::Arc};
 use core::{future::Future,task::{Context,Poll,Waker}};
 use crate::native::{core::{ChoiceNode,ChoiceData,ChoiceValue,FloatChoice,BytesChoice,StringChoice,Spans},bignum::BigInt,shrinker::{Shrinker,ShrinkRun},database,intervalsets::IntervalSet};
 use crate::native::core::choices::IntegerChoice;
 use std::{println,sync::Mutex};
 fn ready<F:Future>(f:F)->F::Output {let mut f=core::pin::pin!(f);let mut cx=Context::from_waker(Waker::noop());match f.as_mut().poll(&mut cx){Poll::Ready(v)=>v,Poll::Pending=>panic!("not synchronous")}}
 fn hex(bytes:&[u8])->String {bytes.iter().map(|b|format!("{b:02x}")).collect()}
 fn encode(nodes:&[ChoiceNode])->String {hex(&database::serialize_nodes(nodes).unwrap())}
 fn integer(n:i64)->ChoiceNode {ChoiceNode::integer(IntegerChoice{min_value:BigInt::from(-1000000),max_value:BigInt::from(2000000),shrink_towards:BigInt::from(0)},BigInt::from(n),false)}
 let float_kind=FloatChoice{min_value:-1000.,max_value:1000.,allow_nan:false,allow_infinity:false,smallest_nonzero_magnitude:f64::from_bits(1)};
 let alpha=Arc::new(IntervalSet::new(vec![(48,57),(65,122)]).unwrap());
 let cases=vec![
  ("integer_threshold",vec![integer(765432)],1),
  ("integer_mask",vec![integer(0x123477)],1),
  ("duplicate_integers",vec![integer(7654),integer(7654)],2),
  ("redistribute_integers",vec![integer(700),integer(300)],3),
  ("lower_together",vec![integer(701),integer(700)],4),
  ("float_fraction",vec![ChoiceNode::float(float_kind.clone(),23.5,false)],5),
  ("float_threshold",vec![ChoiceNode::float(float_kind.clone(),765.25,false)],5),
  ("bytes_sum",vec![ChoiceNode::bytes(BytesChoice{min_size:1,max_size:20},vec![91,72,55],false)],6),
  ("string_marker",vec![ChoiceNode::string(StringChoice{intervals:alpha.clone(),min_size:1,max_size:20},vec![90,89,88,90],false)],7),
  ("scale_integers",vec![integer(700),integer(300)],8),
  ("full_integer",vec![integer(765432)],9),
 ];
 for (name,initial,pass) in cases {
  let traces=Arc::new(Mutex::new(Vec::new()));let log=traces.clone();let template=initial.clone();let input=encode(&initial);
  let probe=move |req:ShrinkRun<'_>| {
   let actual=match req {
    ShrinkRun::Full(nodes)=>{log.lock().unwrap().push(format!("F:{}",encode(nodes)));nodes.to_vec()},
    ShrinkRun::Probe{prefix,max_size}=>{log.lock().unwrap().push(format!("P:{}:{}",max_size,hex(&database::serialize_choices(prefix).unwrap())));prefix.iter().zip(&template).filter_map(|(v,n)|n.data.kind().resolve(v).map(|d|ChoiceNode::new(d,false))).collect()},
   };
   let good=match name {
    "integer_threshold"|"full_integer"=>actual.len()==1&&actual[0].data.as_integer().is_some_and(|(_,v)|v>=&BigInt::from(117)),
    "integer_mask"=>actual.len()==1&&actual[0].data.as_integer().is_some_and(|(_,v)|v.to_string().parse::<i64>().is_ok_and(|n|n&255==0x77)),
    "duplicate_integers"=>actual.len()==2&&actual[0].value()==actual[1].value()&&actual[0].data.as_integer().is_some_and(|(_,v)|v>=&BigInt::from(117)),
    "redistribute_integers"=>actual.len()==2&&actual.iter().all(|n|n.data.as_integer().is_some())&&actual.iter().map(|n|n.data.as_integer().unwrap().1.clone()).fold(BigInt::from(0),|a,b|a+b)>=BigInt::from(1000),
    "lower_together"=>actual.len()==2&&actual.iter().all(|n|n.data.as_integer().is_some())&&actual[0].data.as_integer().unwrap().1-actual[1].data.as_integer().unwrap().1==BigInt::from(1),
    "float_fraction"=>actual.len()==1&&actual[0].data.as_float().is_some_and(|(_,v)|v>=1.5&&v-libm::trunc(v)==0.5),
    "float_threshold"=>actual.len()==1&&actual[0].data.as_float().is_some_and(|(_,v)|v>=117.5),
    "bytes_sum"=>actual.len()==1&&actual[0].data.as_bytes().is_some_and(|(_,v)|v.iter().map(|b|*b as u32).sum::<u32>()>=117),
    "string_marker"=>actual.len()==1&&actual[0].data.as_string().is_some_and(|(_,v)|v.contains(&90)),
    "scale_integers"=>actual.len()==2&&actual.iter().all(|n|n.data.as_integer().is_some())&&actual[0].data.as_integer().unwrap().1*actual[1].data.as_integer().unwrap().1>=BigInt::from(210000),
    _=>false,
   };
   (good,actual,Spans::new())
  };
  let mut sh=Shrinker::with_probe(alloc::boxed::Box::new(probe),initial,Spans::new());
  ready(async {match pass {1=>sh.binary_search_integer_towards_zero().await,2=>sh.shrink_duplicates().await,3=>sh.redistribute_integers().await,4=>sh.lower_integers_together().await,5=>sh.shrink_floats().await,6=>sh.shrink_bytes().await,7=>sh.shrink_strings().await,8=>sh.scale_numeric_pairs().await,9=>{sh.shrink().await.unwrap();Ok(())},_=>unreachable!()}}).unwrap();
  println!("{}\t{}\t{}\t{}\t{}\t{}",name,input,traces.lock().unwrap().join("|"),encode(&sh.current_nodes),sh.calls,sh.improvements);
 }
}

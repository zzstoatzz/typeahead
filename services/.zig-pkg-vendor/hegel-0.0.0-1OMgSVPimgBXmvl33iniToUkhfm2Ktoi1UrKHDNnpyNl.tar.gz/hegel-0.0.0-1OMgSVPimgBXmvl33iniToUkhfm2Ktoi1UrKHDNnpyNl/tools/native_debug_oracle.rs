#[unsafe(no_mangle)] pub extern "C" fn native_debug_oracle() {
 use alloc::{vec,vec::Vec,string::String,format,sync::Arc};
 use crate::native::{bignum::BigInt,core::{choices::{ChoiceKind,IntegerChoice,BooleanChoice},ChoiceValue,FloatChoice,BytesChoice,StringChoice,CloneRecord},database,intervalsets::IntervalSet};
 fn emit(value:ChoiceValue,kind:ChoiceKind) {let bytes=database::serialize_choices(&[value.clone()]).unwrap();let hex:String=bytes.iter().map(|b|format!("{b:02x}")).collect();std::println!("{}\t{:?}\t{:?}",hex,value,kind);}
 let integer_kind=ChoiceKind::Integer(Arc::new(IntegerChoice{min_value:BigInt::from(-128),max_value:BigInt::from(128),shrink_towards:BigInt::from(0)}));
 emit(ChoiceValue::Integer(BigInt::from(-117)),integer_kind.clone());let mut bytes=vec![0u8;66];bytes[64]=1;bytes[0]=123;emit(ChoiceValue::Integer(BigInt::from_signed_bytes_le(&bytes)),integer_kind.clone());
 emit(ChoiceValue::Boolean(true),ChoiceKind::Boolean(BooleanChoice{p:0.5}));
 emit(ChoiceValue::Bytes(vec![0,128,255]),ChoiceKind::Bytes(BytesChoice{min_size:0,max_size:100}));
 let intervals=Arc::new(IntervalSet::new(vec![(48,57),(65,122)]).unwrap());emit(ChoiceValue::String(vec![48,65,128512]),ChoiceKind::String(StringChoice{intervals,min_size:0,max_size:100}));
 emit(ChoiceValue::Clone(Arc::new(CloneRecord::from_values(vec![ChoiceValue::Integer(BigInt::from(3)),ChoiceValue::Boolean(false)]))),ChoiceKind::Clone);
 let float_kind=ChoiceKind::Float(FloatChoice{min_value:-0.0,max_value:f64::INFINITY,allow_nan:true,allow_infinity:true,smallest_nonzero_magnitude:f64::from_bits(1)});
 for v in [0.0f64,-0.0,1.0,1e-3,1e-4,1e-5,1e15,1e16,1e17,f64::INFINITY,f64::NEG_INFINITY,f64::NAN,f64::from_bits(1),1.23456789e-5] {emit(ChoiceValue::Float(v),float_kind.clone());}
 let mut state=0x13198a2e03707344u64;for _ in 0..2000 {state^=state<<13;state^=state>>7;state^=state<<17;emit(ChoiceValue::Float(f64::from_bits(state)),float_kind.clone());}
}

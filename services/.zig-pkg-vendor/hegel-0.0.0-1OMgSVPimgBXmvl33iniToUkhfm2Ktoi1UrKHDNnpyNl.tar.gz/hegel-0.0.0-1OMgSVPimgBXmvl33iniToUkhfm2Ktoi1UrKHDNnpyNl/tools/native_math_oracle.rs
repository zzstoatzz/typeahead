fn main() {
 let funcs:[(&str,fn(f64)->f64);12]=[("log",libm::log),("exp",libm::exp),("log2",libm::log2),("log1p",libm::log1p),("expm1",libm::expm1),("sqrt",libm::sqrt),("atan",libm::atan),("sin",libm::sin),("cos",libm::cos),("floor",libm::floor),("ceil",libm::ceil),("round",libm::round)];
 let mut values=vec![0,1,0x000fffffffffffff,0x0010000000000000,0x3ff0000000000000,0x7fefffffffffffff,0x7ff0000000000000,0x7ff8000000000042,0x7ff0000000000042];
 for x in [0.4375f64,0.6875,1.1875,2.4375,0.5,1.0,2.0,13.0,0.75,0.9,709.78,745.0,1e-10,1e10,std::f64::consts::PI] {for b in [x.to_bits()-1,x.to_bits(),x.to_bits()+1] {values.push(b);}}
 let mut state=0x13198a2e03707344u64;
 for _ in 0..2000 {state^=state<<13;state^=state>>7;state^=state<<17;values.push(state&0x7fffffffffffffff);}
 for (name,f) in funcs {for &b in &values {for sign in [0,1<<63] {let b=b|sign;println!("{}\t{:016x}\t0000000000000000\t{:016x}",name,b,f(f64::from_bits(b)).to_bits());}}}
 for &b in &values {for y in [-3.0f64,-0.5,0.0,0.5,1.0,2.0,13.0] {for sign in [0,1<<63] {let b=b|sign;println!("pow\t{:016x}\t{:016x}\t{:016x}",b,y.to_bits(),libm::pow(f64::from_bits(b),y).to_bits());}}}
 for i in 0..values.len() {let a=values[i];let b=values[(i*17+7)%values.len()];for sign in [0,1<<63] {let a=a|sign;println!("pow\t{:016x}\t{:016x}\t{:016x}",a,b,libm::pow(f64::from_bits(a),f64::from_bits(b)).to_bits());println!("copysign\t{:016x}\t{:016x}\t{:016x}",a,b,libm::copysign(f64::from_bits(a),f64::from_bits(b)).to_bits());}}
}

use std::hash::{BuildHasher,Hasher};
fn fnv(s:&str)->u64{s.bytes().fold(14695981039346656037,|h,b|(h^u64::from(b)).wrapping_mul(1099511628211))}
fn main(){
 for seed in 0..16 {
  for n in [0,1,2,3,4,7,8,14,15,16,28,29,32,56,57,64,112,113,128,256]{
   let keys:Vec<u64>=(0..n).map(|i|fnv(&format!("span-{seed}-{i}"))).collect();
   let mut map:hashbrown::HashMap<u64,usize,rustc_hash::FxBuildHasher>=hashbrown::HashMap::default();
   for(i,k)in keys.iter().enumerate(){map.insert(*k,i);}
   let hashes:Vec<u64>=keys.iter().map(|k|{let mut h=rustc_hash::FxBuildHasher.build_hasher();h.write_u64(*k);h.finish()}).collect();
   println!("{}\t{}\t{}",keys.iter().map(|x|format!("{x:x}")).collect::<Vec<_>>().join(","),hashes.iter().map(|x|format!("{x:x}")).collect::<Vec<_>>().join(","),map.values().map(|x|x.to_string()).collect::<Vec<_>>().join(","));
  }
 }
}

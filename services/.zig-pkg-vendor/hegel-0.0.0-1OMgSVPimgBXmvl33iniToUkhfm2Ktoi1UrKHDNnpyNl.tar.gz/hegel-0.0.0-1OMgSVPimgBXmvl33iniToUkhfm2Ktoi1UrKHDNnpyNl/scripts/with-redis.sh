#!/bin/sh
# run a command against a throwaway redis-server, gone when the command exits.
# usage: with-redis.sh [-p <port>] [-a <redis-server flags>] <command> [args...]
# the command sees HEGEL_REDIS_SOCKET, and HEGEL_REDIS_URL when a port is given.
# HEGEL_REDIS_PORT overrides -p.
set -e
port=0
flags=
while getopts p:a: opt; do
    case $opt in
        p) port=$OPTARG ;;
        a) flags=$OPTARG ;;
        *) exit 2 ;;
    esac
done
shift $((OPTIND - 1))
[ $# -gt 0 ] || { echo "usage: with-redis.sh [-p <port>] [-a <redis-server flags>] <command> [args...]" >&2; exit 2; }
command -v redis-server >/dev/null || { echo "with-redis.sh: redis-server is not on PATH" >&2; exit 1; }
dir=$(mktemp -d)
port=${HEGEL_REDIS_PORT:-$port}
# shellcheck disable=SC2086
redis-server --port "$port" --unixsocket "$dir/redis.sock" --save "" --appendonly no --dir "$dir" $flags >"$dir/log" 2>&1 &
server=$!
trap 'kill $server 2>/dev/null; rm -rf "$dir"' EXIT
tries=0
while [ ! -S "$dir/redis.sock" ]; do
    kill -0 $server 2>/dev/null || { cat "$dir/log" >&2; exit 1; }
    tries=$((tries + 1))
    [ $tries -lt 200 ] || { echo "with-redis.sh: redis-server did not come up" >&2; exit 1; }
    sleep 0.05
done
export HEGEL_REDIS_SOCKET="$dir/redis.sock"
[ "$port" = 0 ] || export HEGEL_REDIS_URL="redis://localhost:$port/0"
"$@"

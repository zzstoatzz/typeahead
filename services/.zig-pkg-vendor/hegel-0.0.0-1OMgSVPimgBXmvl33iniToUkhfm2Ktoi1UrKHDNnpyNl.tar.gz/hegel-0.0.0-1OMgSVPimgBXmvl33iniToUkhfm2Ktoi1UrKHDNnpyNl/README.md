# hegel-zig

hegel-zig is a property testing and deterministic simulation library for Zig. it generates test cases, shrinks failures, and emits replay blobs. its native Zig engine ports [libhegel](https://github.com/hegeldev/hegel-rust), which builds on [Hypothesis](https://github.com/HypothesisWorks/hypothesis). the pinned Rust engine serves as a reference for differential testing.

## install

requires Zig 0.17 and a host target. from your project:

```sh
zig fetch --save=hegel https://tangled.org/zzstoatzz.io/hegel-zig/archive/c9d9564e8ac8e69980f57b36137ba2851dbf22a4.tar.gz
```

add the module to your test target in `build.zig`:

```zig
const hegel = b.dependency("hegel", .{ .target = target, .optimize = optimize });
tests.root_module.addImport("hegel", hegel.module("hegel"));
```

## use

```zig
const hegel = @import("hegel");
const std = @import("std");

test "bytes round-trip through a packed integer" {
    try hegel.run(.{}, {}, roundTrip);
}

fn roundTrip(_: void, case: *hegel.TestCase) !void {
    const high = try case.int(u8, 0, 255);
    const low = try case.int(u8, 0, 255);
    const packed_value = (@as(u16, high) << 8) | low;
    try std.testing.expectEqual(high, @as(u8, @truncate(packed_value >> 8)));
    try std.testing.expectEqual(low, @as(u8, @truncate(packed_value)));
}
```

on failure, set `HEGEL_ZIG_REPLAY` to the printed blob and rerun the test. see [the state machine example](examples/stale_cache.zig) for model checks and [the fault plan example](examples/fault_retry.zig) for interruptions before and after a write takes effect.

## develop

```sh
zig build test             # run regressions and planted mutants with native Zig
zig build compare-engines  # compare traces, errors, replay, and corpora against Rust
```

the comparison also requires Cargo, Git, and Python 3. [docs/](docs/) covers harnesses, compatibility, and source provenance.

## used by

[zat](https://tangled.org/zat.dev/zat), [burner-redis](https://tangled.org/zzstoatzz.io/burner-redis), and [docket](https://tangled.org/zzstoatzz.io/docket).

## license

the wrapper is [MIT](LICENSE). the native engine retains MPL-2.0 and other inherited terms in [LICENSES/](LICENSES/). see the [licensing guide](docs/native-port-licensing.md) for source availability and provenance.

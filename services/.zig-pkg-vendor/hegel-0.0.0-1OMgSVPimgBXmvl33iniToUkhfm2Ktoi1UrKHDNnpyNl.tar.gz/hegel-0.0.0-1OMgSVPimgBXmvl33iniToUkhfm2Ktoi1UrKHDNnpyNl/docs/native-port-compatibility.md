# Native engine compatibility

The port targets the host-native path supported by hegel-zig. The pinned Rust
engine remains the comparison implementation at revision
`33d94c659e441127ce7b5a0f046ec4aa9315d794`; the original C header is preserved
byte for byte in `include/hegel.h`.

The C pull interface runs the synchronous Zig engine on a worker. The worker
pauses at each offered test case until the caller acknowledges completion by
requesting the next case. Engine output is queued and delivered on the thread
calling `hegel_next_test_case`, preserving callback affinity. A run owns a
separate family reference, and result/failure snapshots own their strings.
Freeing a run cancels and joins its worker while outstanding test-case and
printer handles retain their families.

WebAssembly needs a resumable driver because it cannot use this worker-thread
adapter. This port does not claim WebAssembly parity and provides no stub or
Rust fallback for that target. Portable primitives retain their separate
32-bit comparison checks.

The original source-to-Zig mappings, exact hashes, inherited notices and
implementation adaptations are recorded in `docs/native-provenance/` and
`docs/native-port-provenance.json`. Notable adaptations are explicit allocators
and ownership, equality-preserving Zig hashes rather than Rust hash bit
identity, history accounting using actual Zig object sizes, and widened
intermediate arithmetic for graph-shrinker integer bisection.

The ABI gates compare every public enum value and every wire-struct layout
against Zig translation of the original header, and compare all 131 exported
symbols with that header. Behavioral acceptance additionally requires raw
Rust-versus-Zig replay/oracle comparisons and the existing mutation regressions;
a matching symbol table alone is insufficient.

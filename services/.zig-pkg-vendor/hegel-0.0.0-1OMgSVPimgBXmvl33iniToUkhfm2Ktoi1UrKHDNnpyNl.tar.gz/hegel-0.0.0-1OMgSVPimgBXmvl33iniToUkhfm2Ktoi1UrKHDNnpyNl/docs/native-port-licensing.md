# Native engine licensing and provenance

This document records the licensing baseline for the Zig engine port. It is a
provenance policy, not a claim that upstream has clarified or relicensed its
dependencies. The existing Zig wrapper's root `LICENSE` remains unchanged.

## Pinned reference

The comparison implementation is
[`hegeldev/hegel-rust@33d94c659e441127ce7b5a0f046ec4aa9315d794`](https://github.com/hegeldev/hegel-rust/tree/33d94c659e441127ce7b5a0f046ec4aa9315d794),
including `hegeltest-c` 0.45.1. The workspace's Rust frontend is `hegeltest`
0.49.2. Engine source is under `hegel-c/src/`; translating the Rust frontend
or its test suite requires additional mappings, not an assumption that it is
the engine itself.

The pinned repository's [license](https://github.com/hegeldev/hegel-rust/blob/33d94c659e441127ce7b5a0f046ec4aa9315d794/LICENSE)
is MIT, copyright 2026 Antithesis, LLC. A verbatim copy is retained in
`LICENSES/Antithesis-MIT.txt`. MIT permits copying, modification, translation
and redistribution, subject to retaining its copyright and permission notice
in copies or substantial portions. Keep that notice when porting its code.

## Conservative treatment of translated files

Hegel-derived engine translations use the source marker
`SPDX-License-Identifier: MIT AND MPL-2.0`, with upstream MIT notices
retained and the translated source available under MPL-2.0. `AND` records
combined obligations; it is not an `OR` choice between the licenses. This is a
conservative project policy while provenance is mapped; it does not mean
that every upstream Rust file has been established to be MPL-covered.
Independently authored wrapper and integration files can retain MIT when they
contain no translated MPL-covered expression. Keep the two classifications
explicit in the provenance manifest. The CPython-derived parser files also record
`Python-2.0 AND LicenseRef-CNRI-Python-1.6`. Vendored TOML and hash-order
dependency adaptations retain their selected MIT grants; generated data has
its own recorded provenance. A marker does not erase additional component
notices.

The reason is concrete source provenance. The Rust engine describes
`intervalsets`, float lexicographic indexing, shrinker mutation, statistics
and its pretty-printer as ports of Hypothesis components. Its quality tests
also identify Hypothesis test sources. Hypothesis's
[repository license](https://github.com/HypothesisWorks/hypothesis/blob/13c3785854da056387aeac789300537e501a3c14/LICENSE.txt)
and [source-file notices](https://github.com/HypothesisWorks/hypothesis/blob/13c3785854da056387aeac789300537e501a3c14/hypothesis-python/src/hypothesis/internal/intervalsets.py)
identify MPL-2.0. The Hypothesis revision in these links is a snapshot referenced
by the pinned Hegel changelog; it is not an established origin revision for
every Rust module.

The pinned Rust checkout does not supply a Hypothesis relicensing grant or a
per-file upstream-source inventory. An independent reimplementation of an
algorithm is not automatically a source-code derivative, but the comments
alone do not establish that distinction. Do not silently resolve this
uncertainty by declaring a whole source translation solely MIT.

The [MPL text](https://www.mozilla.org/en-US/MPL/2.0/) is retained in
`LICENSES/MPL-2.0.txt`; Hypothesis notices are in
`LICENSES/Hypothesis-NOTICE.txt`. For files containing covered source or its
modifications, preserve notices and make the covered source available under
MPL-2.0 when distributing it. Binary recipients must be told how to obtain that
source. Separate files containing no covered source are not automatically
subject to MPL. Private development does not trigger the distribution
obligations; see [Mozilla's FAQ, questions 5–11](https://www.mozilla.org/en-US/MPL/2.0/FAQ/).

Use an `SPDX-License-Identifier: MIT AND MPL-2.0` source header on translated files,
record the exact original path and revision, retain the applicable copyright
notices, and refer to the full notices in `LICENSES/`. Apply the same provenance
review to translated tests. A license header does not replace the mapping or
erase an underlying third-party notice.

## Additional components

| Component | Evidence and retained notice | Port treatment |
|---|---|---|
| Pretty-printer | The pinned Rust `native/printer.rs` identifies `hypothesis.vendor.pretty`, IPython and Ruby ancestry. The [Hypothesis source](https://github.com/HypothesisWorks/hypothesis/blob/13c3785854da056387aeac789300537e501a3c14/hypothesis-python/src/hypothesis/vendor/pretty.py) records copyright 2007 Armin Ronacher and portions copyright 2009 Robert Kern, BSD license, as well as the Hypothesis MPL notice. `LICENSES/IPython-BSD-3-Clause.txt` reproduces the [IPython license](https://github.com/ipython/ipython/blob/main/LICENSE). | Preserve both the Hypothesis provenance and the applicable BSD notices, conditions and disclaimer; include them with source and binary distributions. Preserve the Armin Ronacher and Robert Kern notices above when translating that component. Do not imply endorsement. |
| Unicode data | `hegel-c/src/unicodedata/mod.rs` identifies vendored Unicode 15.1.0 `UnicodeData.txt` and generated `categories.txt` / `nfd_bases.txt`. The [15.1 release readme](https://www.unicode.org/Public/15.1.0/ucd/ReadMe.txt) records copyright 2023 Unicode, Inc. `LICENSES/Unicode-3.0.txt` reproduces the [Unicode license](https://www.unicode.org/license.txt), whose application to data files is described in the [Unicode terms](https://www.unicode.org/copyright.html). | Retain the data source/version and Unicode copyright and permission notice with the data or its documentation, including generated tables. The bundled current notice records copyright 1991–2026 Unicode, Inc.; the release attribution remains 2023. |
| Seeded RNG | The pinned engine uses `rand` 0.10.1 `SmallRng`: Xoshiro256++ on 64-bit targets and Xoshiro128++ on 32-/16-bit targets. `rand_core` is 0.10.1. `LICENSES/Rand-MIT.txt` and `LICENSES/Rand-Core-MIT.txt` retain their exact MIT notices. | For source translated from these crates, select their MIT alternative and retain those notices. Pin algorithm, seed expansion and source version independently of the `SmallRng` name; upstream does not promise that name's stream is portable across versions or architectures. |
| Xoshiro references | Rand's implementations identify the [Xoshiro256++](https://prng.di.unimi.it/xoshiro256plusplus.c) and [Xoshiro128++](https://prng.di.unimi.it/xoshiro128plusplus.c) references by David Blackman and Sebastiano Vigna. Their dedication and permission/disclaimer block is retained verbatim in `LICENSES/Xoshiro-reference-notice.txt`. | Preserve the reference provenance and notice. Do not label this particular notice CC0: it contains its own public-domain dedication and permissive fallback text. |
| CPython regex parser | Pinned Hegel explicitly identifies its `re/parser.rs`, `re/constants.rs` and `re/casefold.rs` as CPython `Lib/re` ports. The referenced `resources/cpython` tree/revision is absent from the tracked checkout. [CPython 3.13.0](https://github.com/python/cpython/tree/v3.13.0/Lib/re) is retained as a notice reference, without claiming it was the actual historical source. `LICENSES/Python-3.13.0.txt` contains its complete license stack; `Python-SRE-NOTICE.txt` retains Secret Labs' SRE notices and a derivative change summary. SRE explicitly names [CNRI Python 1.6 terms](https://www.handle.net/python_licenses/python1.6_9-5-00.html), retained in `CNRI-Python-1.6.txt`. | Retain agreements/copyright notices and the brief change summary; preserve the PSF/CNRI disclaimers and no-endorsement conditions. `LicenseRef-CNRI-Python-1.6` denotes that exact bundled agreement. No Python interpreter is included. |
| Math compatibility | Pinned `libm` 0.2.16 sources are mapped individually, including its [package MIT grant](https://github.com/rust-lang/compiler-builtins/blob/dfd2203a4d6110820ad7bb65cafe1bf331a03a3d/libm/LICENSE.txt). `LICENSES/libm-0.2.16.txt` retains the complete package license, and `libm-origin-notices.txt` preserves source-specific Sun/FreeBSD notices. | Keep the package grant and all applicable per-source notices, including Sun's notice-preservation condition. Native source keeps notices at relevant functions; built-in replacements are distinguished in the mapping. |
| Hash iteration compatibility | `hashbrown` 0.17.1 and `rustc-hash` 2.1.2, at exact Cargo/VCS revisions, are used for the narrow hash-order adaptation. Exact MIT alternatives are in `Hashbrown-MIT.txt` and `Rustc-Hash-MIT.txt`. | Preserve selected MIT notices. Hashbrown's Amanieu d'Antras copyright is retained. This does not import the complete Rust hash-map runtime. |
| Big integer Debug formatting | Arithmetic uses Zig std; Dashu formatting behavior is independently reproduced. The exact package [Dashu MIT grant](https://github.com/cmpute/dashu/blob/d6b56866da727fb7416d2f78a2733d88c03ed125/LICENSE-MIT), copyright 2022 Jacob Zhong, is in `Dashu-MIT.txt`; original `Dashu-Int-NOTICE.md` includes the underlying ibig MIT notice, copyright 2020 Tomek Czajka. | Both notices are retained conservatively. No Dashu arithmetic implementation is bundled in the native port. |
| TOML syntax parser | Pure Zig `z-toml` at `53d891af838b13bbe727a0f20030aea19a1233ce`, with exact original file hashes and a narrow `i64` to `i128` integer adaptation. Its [MIT license](https://github.com/eneskemalergin/z-toml/blob/53d891af838b13bbe727a0f20030aea19a1233ce/LICENSE) is in `Z-toml-MIT.txt`. | Preserve the full notice and distinguish vendored parser code from Hegel's translated configuration policy. |
| Domain alphabet | The IANA file is not redistributed. The 1,437 names are independently reconstructed from the [MPL-2.0 Public Suffix List snapshot](https://github.com/publicsuffix/list/blob/e452c7058d6946bd76952b128c12f5ce87a5acb8/public_suffix_list.dat), with explicit exclusions and exact reference-order comparison. `Public-Suffix-List-NOTICE.txt`, the derived list and generator are bundled. | Retain MPL notice/source availability. IANA's protocol-registry CC0 statement is not treated as a DNS-data grant. The reconstruction, its source snapshot/hash and source URL are recorded in `native-provenance/tlds.json`. |
| Rust compiler Unicode observations | Tables are generated by querying Rust 1.96.0, revision `ac68faa20c58cbccd01ee7208bf3b6e93a7d7f96`, Unicode 17.0 public `std::char` behavior. No standard-library algorithm is copied. `Rust-Project-MIT.txt` and `Unicode-3.0.txt` are retained. | Record compiler/Unicode versions, generation recipe and data hashes. These tables are distinct from Hegel's Unicode 15.1 categories/NFD data. Conservative notices are retained for generated compiler/data behavior. |
| Zig standard library/runtime | Native builds use Zig 0.17.0 standard-library/runtime code; its complete distribution MIT license is retained in `Zig-MIT.txt`. Platform libc is linked from the host and is not redistributed by this source package. | Include the Zig notice with native binary redistribution. A compiler/toolchain distribution would require its own broader notice inventory. |

Rust reference/oracle binaries are development artifacts excluded from package
paths. The native port replaces Rust runtime dependencies where documented;
it does not bundle `once_cell`, Rust `toml`, `miniz_oxide`, `rustix` or the Rust
standard library as native implementation code. If distributing Rust reference
binaries or the Rust-backed build, separately audit their complete linked
runtime/transitive notices. This native notice inventory does not claim to be
that binary notice bundle.

## Mapping and comparison process

`docs/native-port-provenance.json` maps every current `src/engine` implementation
and data file, the exact original header, selected dependency sources, notices,
comparison artifacts and deliberate adaptations. Component fragments preserve
more detailed source/test evidence. The map distinguishes direct pinned Hegel
sources from older ancestry references and independently generated data.

Run `python3 tools/audit_native_provenance.py` to check inventory coverage,
notice/data hashes and package paths. Add `--upstream <pinned-checkout>` to
verify direct Hegel sources against immutable Git blobs and their working
copies, and `--crate-cache <registry-source-directory>` to verify copied/adapted
crate sources. The audit checks recorded evidence; it is not an external legal
opinion or a substitute for identifying new source dependencies.

For every implementation or test file translated or adapted:

1. Add the Zig destination, all original source paths, exact revisions and
   source SHA-256 hashes. Record whether it is a translation, adaptation,
   independently authored implementation, copied data or generated data.
2. Record inherited provenance, applicable license identifiers and notice
   files. Keep source-module boundaries recognizable where practical.
3. Record intentional deviations and the corresponding comparison tests.
   Compare behavior against the unmodified pinned engine, not a moving branch.
4. Update mappings when source changes. A test passing or a function being
   renamed does not establish independent authorship or remove notices.

## Source and binary redistribution

The source package includes the corresponding native source, original C header,
build/configuration files, relevant generators/tests, complete `LICENSES/`, and
these provenance documents. Preserve them when redistributing the source.
The wrapper's root MIT license stays unchanged; the native component policies
and third-party grants above remain applicable.

For a separately distributed binary, reproduce the applicable notices and tell
recipients that covered Source Code Form is available under MPL-2.0 and how to
obtain the matching source. Accompany the binary with its source package, or
provide an accurate durable source location, available by reasonable means in
a timely manner at no more than the cost of distribution. Do not restrict
recipients' rights in that covered source. No public source release URL is
asserted to exist before such a release has actually been made.

Preserve the PSF/CNRI derivative change summary, BSD conditions/disclaimers,
MIT notices and Sun notice-preservation blocks as applicable. The package path
audit verifies these documents are included; a binary distributor must also
place them in that binary's accompanying materials.

## Historical information still unestablished

The exact Hypothesis and CPython revisions used by the original Rust ports are
not recorded in the pinned source. The referenced snapshots establish retained
notices and grants, without claiming precise origin commits for every line.
Obtain upstream clarification if seeking narrower licensing or more precise
ancestry. No upstream relicensing, noncompliance finding, or external
legal-opinion clearance is asserted here.

The current implementation target is the host-native hegel-zig path.
WebAssembly requires a resumable driver and is not claimed compatible; see
`native-port-compatibility.md`. Matching tests, exported symbols or SPDX
markers establish neither historical authorship nor legal clearance.

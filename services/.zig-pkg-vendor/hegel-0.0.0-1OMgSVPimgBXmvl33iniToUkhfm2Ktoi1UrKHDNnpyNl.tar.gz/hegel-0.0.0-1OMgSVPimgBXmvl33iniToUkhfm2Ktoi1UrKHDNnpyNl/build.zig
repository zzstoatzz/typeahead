const std = @import("std");

const EngineKind = enum { rust, zig };

const RustReference = @import("tools/rust_reference.zig");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});
    const engine_kind = b.option(EngineKind, "engine", "engine backend: pinned Rust reference or native Zig") orelse .zig;

    const faults = b.addModule("fault-plan", .{
        .root_source_file = b.path("src/fault_plan.zig"),
        .target = target,
        .optimize = optimize,
    });
    const unit_tests = b.addTest(.{ .root_module = faults });
    const run_unit_tests = b.addRunArtifact(unit_tests);
    b.step("test-unit", "test deterministic helpers without libhegel").dependOn(&run_unit_tests.step);
    const engine_core = b.addModule("native-core", .{
        .root_source_file = b.path("src/engine/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    const engine_tests = b.step("test-native", "compare native engine components with pinned Rust fixtures");
    const primitive_names = [_][]const u8{ "labels", "base64", "floats", "float_index", "intervalsets", "rng" };
    const primitive_module = b.createModule(.{
        .root_source_file = b.path("tests/engine/primitives.zig"),
        .target = target,
        .optimize = optimize,
    });
    for (primitive_names) |name| primitive_module.addImport(name, b.createModule(.{
        .root_source_file = b.path(b.fmt("src/engine/{s}.zig", .{name})),
        .target = target,
        .optimize = optimize,
    }));
    engine_tests.dependOn(&b.addRunArtifact(b.addTest(.{ .root_module = primitive_module })).step);
    const choice_tests = b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path("tests/engine/choices.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{.{ .name = "choices", .module = b.createModule(.{
            .root_source_file = b.path("src/engine/choices.zig"),
            .target = target,
            .optimize = optimize,
        }) }},
    }) });
    engine_tests.dependOn(&b.addRunArtifact(choice_tests).step);
    for ([_][]const u8{ "database", "blob", "graph", "replay", "nd", "exec_cache", "state", "state_machine", "execution", "persistence", "targeting", "draws", "counterexample", "graph_shrink", "data_source", "test_runner", "runner_nd" }) |name| {
        engine_tests.dependOn(&b.addRunArtifact(b.addTest(.{ .root_module = b.createModule(.{
            .root_source_file = b.path(b.fmt("tests/engine/{s}.zig", .{name})),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "native", .module = engine_core }},
        }) })).step);
    }
    const NativeTest = struct { test_file: []const u8, import_name: []const u8, source_file: []const u8 };
    const standalone_tests = [_]NativeTest{
        .{ .test_file = "settings", .import_name = "settings", .source_file = "settings" },
        .{ .test_file = "profiles", .import_name = "profiles", .source_file = "profiles" },
        .{ .test_file = "math_compat", .import_name = "math", .source_file = "math_compat" },
        .{ .test_file = "statistics", .import_name = "statistics", .source_file = "statistics" },
        .{ .test_file = "sampling", .import_name = "sampling", .source_file = "sampling" },
        .{ .test_file = "events", .import_name = "events", .source_file = "events" },
        .{ .test_file = "runner_policy", .import_name = "policy", .source_file = "runner_policy" },
        .{ .test_file = "config", .import_name = "config", .source_file = "config" },
        .{ .test_file = "antithesis", .import_name = "antithesis", .source_file = "antithesis" },
        .{ .test_file = "unicode", .import_name = "unicode", .source_file = "unicodedata" },
        .{ .test_file = "casefold", .import_name = "re", .source_file = "re" },
        .{ .test_file = "regex", .import_name = "re", .source_file = "re" },
        .{ .test_file = "special", .import_name = "draws", .source_file = "draws" },
        .{ .test_file = "shrinker", .import_name = "shrinker", .source_file = "shrinker" },
        .{ .test_file = "shrinker_search", .import_name = "shrinker", .source_file = "shrinker" },
        .{ .test_file = "shrinker_oracle", .import_name = "shrinker", .source_file = "shrinker" },
        .{ .test_file = "printer_debug", .import_name = "printer", .source_file = "printer" },
        .{ .test_file = "printer", .import_name = "printer", .source_file = "printer" },
        .{ .test_file = "printer_oracle", .import_name = "printer", .source_file = "printer" },
        .{ .test_file = "format", .import_name = "rust_fmt", .source_file = "rust_fmt" },
        .{ .test_file = "hash_order", .import_name = "hash_order", .source_file = "hash_order" },
    };
    for (standalone_tests) |spec| {
        engine_tests.dependOn(&b.addRunArtifact(b.addTest(.{ .root_module = b.createModule(.{
            .root_source_file = b.path(b.fmt("tests/engine/{s}.zig", .{spec.test_file})),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = spec.import_name, .module = b.createModule(.{
                .root_source_file = b.path(b.fmt("src/engine/{s}.zig", .{spec.source_file})),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
            }) }},
        }) })).step);
    }

    const reference = RustReference.configure(b, target, optimize);
    const engine_header = b.addTranslateC(.{
        .root_source_file = b.path("include/hegel.h"),
        .target = target,
        .optimize = optimize,
    }).createModule();
    const engine_library = b.addLibrary(.{
        .name = "hegel_c_zig",
        .linkage = .static,
        .root_module = b.createModule(.{
            .root_source_file = b.path("src/engine/c_api.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        }),
    });
    const abi_layout = b.addRunArtifact(b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path("tests/engine/c_api_layout.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "header", .module = engine_header },
            .{ .name = "types", .module = b.createModule(.{ .root_source_file = b.path("src/engine/c_api/types.zig"), .target = target, .optimize = optimize }) },
        },
    }) }));
    engine_tests.dependOn(&abi_layout.step);
    const abi_symbols = b.addSystemCommand(&.{"python3"});
    abi_symbols.addFileArg(b.path("tools/check_native_abi.py"));
    abi_symbols.addArtifactArg(engine_library);
    const abi_step = b.step("check-native-abi", "verify native wire layouts and all public symbols against the pinned C ABI");
    abi_step.dependOn(&abi_layout.step);
    abi_step.dependOn(&abi_symbols.step);
    const abi_tests = b.addRunArtifact(b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path("tests/engine/c_api.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{.{ .name = "api", .module = engine_library.root_module }},
    }) }));
    const printer_abi_tests = b.addRunArtifact(b.addTest(.{ .root_module = b.createModule(.{
        .root_source_file = b.path("tests/engine/printer_c_api.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{.{ .name = "api", .module = engine_library.root_module }},
    }) }));
    const abi_behavior_step = b.step("test-native-abi", "test C API ownership, pull protocol and cancellation");
    abi_behavior_step.dependOn(abi_step);
    abi_behavior_step.dependOn(&abi_tests.step);
    abi_behavior_step.dependOn(&printer_abi_tests.step);

    const mod = b.addModule("hegel", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
        .imports = &.{
            .{ .name = "c", .module = if (engine_kind == .zig) engine_header else reference.header },
            .{ .name = "fault-plan", .module = faults },
        },
    });
    if (engine_kind == .zig) mod.linkLibrary(engine_library) else reference.link(mod);

    const oracle = b.addExecutable(.{
        .name = "hegel-oracle-rust",
        .root_module = b.createModule(.{
            .root_source_file = b.path("tools/engine_oracle.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "engine", .module = reference.header }},
        }),
    });
    reference.link(oracle.root_module);
    b.step("oracle-rust", "build the pinned Rust engine differential oracle").dependOn(&b.addInstallArtifact(oracle, .{}).step);

    const zig_oracle = b.addExecutable(.{
        .name = "hegel-oracle-zig",
        .root_module = b.createModule(.{
            .root_source_file = b.path("tools/engine_oracle.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
            .imports = &.{.{ .name = "engine", .module = engine_header }},
        }),
    });
    zig_oracle.root_module.linkLibrary(engine_library);
    b.step("oracle-zig", "build the native Zig engine differential oracle").dependOn(&b.addInstallArtifact(zig_oracle, .{}).step);
    var contract_oracles: [2]*std.Build.Step.Compile = undefined;
    for ([_]EngineKind{ .rust, .zig }, 0..) |kind, index| {
        const contract = b.addExecutable(.{
            .name = b.fmt("hegel-contract-{s}", .{@tagName(kind)}),
            .root_module = b.createModule(.{
                .root_source_file = b.path("tools/contract_oracle.zig"),
                .target = target,
                .optimize = optimize,
                .link_libc = true,
                .imports = &.{.{ .name = "engine", .module = if (kind == .rust) reference.header else engine_header }},
            }),
        });
        if (kind == .zig) contract.root_module.linkLibrary(engine_library) else reference.link(contract.root_module);
        contract_oracles[index] = contract;
    }
    const contracts = b.addSystemCommand(&.{"python3"});
    contracts.addFileArg(b.path("tools/compare_contracts.py"));
    contracts.addArg("--reference");
    contracts.addArtifactArg(contract_oracles[0]);
    contracts.addArg("--candidate");
    contracts.addArtifactArg(contract_oracles[1]);
    contracts.setCwd(b.path("."));
    contracts.has_side_effects = true;
    const contract_step = b.step("compare-contracts", "compare C ABI errors and output ownership against the pinned engine");
    contract_step.dependOn(&contracts.step);

    const comparison = b.addSystemCommand(&.{"python3"});
    comparison.addFileArg(b.path("tools/compare_engines.py"));
    comparison.addArg("--check-corpus");
    comparison.addArg("--reference");
    comparison.addArtifactArg(oracle);
    comparison.addArg("--candidate");
    comparison.addArtifactArg(zig_oracle);
    comparison.setCwd(b.path("."));
    comparison.has_side_effects = true;
    comparison.step.dependOn(abi_step);
    comparison.step.dependOn(contract_step);
    b.step("compare-engines", "compare complete Rust and Zig ABI traces and cross-replay failures").dependOn(&comparison.step);

    b.addNamedLazyPath("with-redis", b.path("scripts/with-redis.sh"));

    const stale_cache = b.addExecutable(.{
        .name = "stale-cache",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/stale_cache.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_stale_cache = b.addRunArtifact(stale_cache);
    run_stale_cache.addPassthruArgs();
    const example_step = b.step("example-stale-cache", "find and shrink a planted stale-cache bug in a toy map");
    example_step.dependOn(&run_stale_cache.step);

    // a blob printed by an earlier run of the example. libhegel is pinned, so
    // the blob stays valid until the pin moves
    const replay = b.addRunArtifact(stale_cache);
    replay.setEnvironmentVariable("HEGEL_ZIG_REPLAY", "AXicdYoxCgAACAK7ta3/fzYbhAhyUNGrkJJxcPFyDuXHsJgGGGMAhA==");
    replay.addCheck(.{ .expect_stderr_match = "minimal history:\nput(k0, 0)\nsum()\nput(k0, 1)\nsum()\n" });
    replay.addCheck(.{ .expect_stderr_match = "\n1 cases" });
    const replay_step = b.step("example-replay", "replay a recorded failure of the example");
    replay_step.dependOn(&replay.step);

    const stale_handle = b.addExecutable(.{
        .name = "stale-handle",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/stale_handle.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_stale_handle = b.addRunArtifact(stale_handle);
    run_stale_handle.addPassthruArgs();
    const handle_step = b.step("example-stale-handle", "find and shrink a planted stale-handle bug in a slot allocator");
    handle_step.dependOn(&run_stale_handle.step);

    const mutants_tool = b.addExecutable(.{
        .name = "hegel-mutants",
        .root_module = b.createModule(.{
            .root_source_file = b.path("tools/mutants.zig"),
            .target = b.graph.host,
        }),
    });
    b.installArtifact(mutants_tool);

    const sum_cache = b.addExecutable(.{
        .name = "sum-cache",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/mutants/sum_cache.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    const run_sum_cache = b.addRunArtifact(sum_cache);
    b.step("example-sum-cache", "the fixed map, whose harness must pass").dependOn(&run_sum_cache.step);

    // the command rebuilds the example, since each mutant edits its source
    const run_mutants = b.addRunArtifact(mutants_tool);
    run_mutants.setCwd(b.path("."));
    run_mutants.addArgs(&.{ "examples/mutants/mutants.zon", "--seeds", "3", "--", b.graph.zig_exe, "build", "example-sum-cache" });
    run_mutants.addArg(b.fmt("-Dengine={s}", .{@tagName(engine_kind)}));
    run_mutants.has_side_effects = true;
    const mutants_step = b.step("example-mutants", "plant each mutant in the fixed map; every one must be caught");
    mutants_step.dependOn(&run_mutants.step);

    const test_step = b.step("test", "run the examples: each planted bug must be found, and one replayed");
    const fault_retry = b.addExecutable(.{
        .name = "fault-retry",
        .root_module = b.createModule(.{
            .root_source_file = b.path("examples/fault_retry.zig"),
            .target = target,
            .optimize = optimize,
            .imports = &.{.{ .name = "hegel", .module = mod }},
        }),
    });
    b.step("example-fault-retry", "retry writes interrupted before or after they land").dependOn(&b.addRunArtifact(fault_retry).step);
    const fault_mutants = b.addRunArtifact(mutants_tool);
    fault_mutants.setCwd(b.path("."));
    fault_mutants.addArgs(&.{ "examples/fault_mutants.zon", "--seeds", "3", "--", b.graph.zig_exe, "build", "example-fault-retry" });
    fault_mutants.addArg(b.fmt("-Dengine={s}", .{@tagName(engine_kind)}));
    fault_mutants.has_side_effects = true;
    b.step("example-fault-mutants", "catch lost and duplicated writes under fault injection").dependOn(&fault_mutants.step);
    test_step.dependOn(&fault_mutants.step);
    test_step.dependOn(&run_unit_tests.step);
    test_step.dependOn(example_step);
    test_step.dependOn(replay_step);
    test_step.dependOn(handle_step);
    test_step.dependOn(mutants_step);
}

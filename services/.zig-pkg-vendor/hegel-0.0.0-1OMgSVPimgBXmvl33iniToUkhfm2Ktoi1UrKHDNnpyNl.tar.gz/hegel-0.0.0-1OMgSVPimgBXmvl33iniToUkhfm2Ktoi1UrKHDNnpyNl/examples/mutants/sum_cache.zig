//! the map from stale_cache.zig with its bug fixed: every put invalidates the
//! cached sum. mutants.zon plants that bug back, and one other.

const std = @import("std");
const hegel = @import("hegel");

const Toy = struct {
    values: [4]?u8 = @splat(null),
    cached: ?u32 = null,

    fn put(self: *Toy, key: usize, value: u8) void {
        self.cached = null;
        self.values[key] = value;
    }

    fn remove(self: *Toy, key: usize) void {
        self.cached = null;
        self.values[key] = null;
    }

    fn sum(self: *Toy) u32 {
        if (self.cached) |s| return s;
        var total: u32 = 0;
        for (self.values) |value| total += value orelse 0;
        self.cached = total;
        return total;
    }
};

const Rule = enum { put, remove, sum };

fn property(_: void, case: *hegel.TestCase) !void {
    var toy: Toy = .{};
    var model: [4]?u8 = @splat(null);
    var machine = try case.machine(Rule, null, 20);
    defer machine.deinit();
    while (try machine.next()) |rule| {
        switch (rule) {
            .put => {
                const key = try case.index(4);
                const value = try case.int(u8, 0, 255);
                case.note("put(k{d}, {d})", .{ key, value });
                toy.put(key, value);
                model[key] = value;
            },
            .remove => {
                const key = try case.index(4);
                case.note("remove(k{d})", .{key});
                toy.remove(key);
                model[key] = null;
            },
            .sum => {
                case.note("sum()", .{});
                var expected: u32 = 0;
                for (model) |value| expected += value orelse 0;
                if (toy.sum() != expected) return case.fail("sum() disagrees with the model");
            },
        }
    }
}

pub fn main() !void {
    try hegel.run(.{ .test_cases = 200, .statistics = false }, {}, property);
}

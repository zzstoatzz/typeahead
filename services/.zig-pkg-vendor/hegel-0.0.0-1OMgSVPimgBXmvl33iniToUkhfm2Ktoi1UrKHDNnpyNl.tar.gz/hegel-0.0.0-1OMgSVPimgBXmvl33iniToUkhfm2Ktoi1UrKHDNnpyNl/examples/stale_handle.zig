//! a slot allocator whose handles carry a generation, so a handle to a freed
//! slot reads nothing. free forgets to bump the generation, so once the slot
//! is reused an old handle reads the new value. the minimal history is
//! alloc(h0, 0); free(h0); alloc(h1, 0); get(h0).

const std = @import("std");
const hegel = @import("hegel");

const Handle = struct { slot: u8, generation: u32 };

const Slots = struct {
    values: [4]?u8 = @splat(null),
    generations: [4]u32 = @splat(0),

    fn alloc(self: *Slots, value: u8) ?Handle {
        for (&self.values, 0..) |*slot, i| {
            if (slot.* != null) continue;
            slot.* = value;
            return .{ .slot = @intCast(i), .generation = self.generations[i] };
        }
        return null;
    }

    fn free(self: *Slots, handle: Handle) void {
        if (self.get(handle) == null) return;
        self.values[handle.slot] = null;
    }

    fn get(self: *const Slots, handle: Handle) ?u8 {
        if (self.generations[handle.slot] != handle.generation) return null;
        return self.values[handle.slot];
    }
};

const Rule = enum { alloc, free, get_live, get_freed };

var tally: hegel.Tally(Rule) = .{};

const max_handles = 32;

/// the handles the harness was given, and what each must read. pool ids
/// name them, so a shrunk history still refers to the same handles.
const Model = struct {
    handles: [max_handles]Handle = undefined,
    values: [max_handles]?u8 = undefined,
    ids: [max_handles]u64 = undefined,
    count: usize = 0,

    fn find(self: *const Model, id: u64) usize {
        return std.mem.indexOfScalar(u64, self.ids[0..self.count], id).?;
    }
};

fn property(_: void, case: *hegel.TestCase) !void {
    var slots: Slots = .{};
    var model: Model = .{};
    var live = try case.pool();
    defer live.deinit();
    var freed = try case.pool();
    defer freed.deinit();

    tally.case();
    var machine = try case.machine(Rule, null, 30);
    defer machine.deinit();
    while (try machine.next()) |rule| {
        tally.step(rule);
        const applied = switch (rule) {
            .alloc => try alloc(case, &slots, &model, &live),
            .free => free: {
                const h = model.find(try live.take() orelse break :free false);
                case.note("free(h{d})", .{h});
                slots.free(model.handles[h]);
                model.values[h] = null;
                model.ids[h] = try freed.add();
                break :free true;
            },
            .get_live, .get_freed => get: {
                const pool = if (rule == .get_live) &live else &freed;
                const h = model.find(try pool.pick() orelse break :get false);
                case.note("get(h{d})", .{h});
                if (rule == .get_freed and slots.values[model.handles[h].slot] != null)
                    case.event("get a freed handle whose slot was reused");
                if (slots.get(model.handles[h]) != model.values[h]) return case.fail("a handle read the wrong value");
                break :get true;
            },
        };
        if (!applied) {
            machine.reject();
            tally.reject(rule);
        }
    }
    tally.finish(model.count);
}

fn alloc(case: *hegel.TestCase, slots: *Slots, model: *Model, live: *hegel.Pool) !bool {
    if (model.count == max_handles) return false;
    const value = try case.int(u8, 0, 3);
    const handle = slots.alloc(value) orelse return false;
    const h = model.count;
    model.handles[h] = handle;
    model.values[h] = value;
    model.ids[h] = try live.add();
    model.count += 1;
    case.note("alloc(h{d}, {d})", .{ h, value });
    return true;
}

pub fn main() void {
    const outcome = hegel.run(.{ .test_cases = 500 }, {}, property);
    tally.print();
    outcome catch {
        std.debug.print("\nfound the planted bug, as expected\n", .{});
        return;
    };
    std.debug.print("the planted bug was not found\n", .{});
    std.process.exit(1);
}

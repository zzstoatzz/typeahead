const std = @import("std");
const hegel = @import("hegel");

const Point = enum { read, write };
const Plan = hegel.FaultPlan(Point);

const Store = struct {
    plan: *Plan,
    last: ?u8 = null,
    total: u32 = 0,

    fn add(self: *Store, id: u8, value: u8) !void {
        const fault = self.plan.hit(.write);
        if (fault == .before) return error.Unavailable;
        if (self.last != id) {
            self.total += value;
            self.last = id;
        }
        if (fault == .after) return error.Unavailable;
    }

    fn read(self: *Store) !u32 {
        if (self.plan.hit(.read) != null) return error.Unavailable;
        return self.total;
    }
};

fn property(_: void, case: *hegel.TestCase) !void {
    var plan = try case.faultPlan(Point, 3);
    var store: Store = .{ .plan = &plan };
    var expected: u32 = 0;
    for (0..4) |i| {
        const value = try case.int(u8, 1, 20);
        case.note("add({d}, {d})", .{ i, value });
        store.add(@intCast(i), value) catch |err| {
            if (err != error.Unavailable) return err;
            case.note("retry({d}, {d})", .{ i, value });
            try store.add(@intCast(i), value);
        };
        expected += value;
        const got = store.read() catch try store.read();
        if (got != expected) return case.fail("a retried write was lost or applied twice");
        const guard = plan.pause();
        defer guard.end();
        if (try store.read() != expected) return case.fail("a retried write was lost or applied twice");
    }
    if (plan.armed != null) return case.fail("the generated fault was not reached");
}

pub fn main() !void {
    try hegel.run(.{ .test_cases = 100 }, {}, property);
}

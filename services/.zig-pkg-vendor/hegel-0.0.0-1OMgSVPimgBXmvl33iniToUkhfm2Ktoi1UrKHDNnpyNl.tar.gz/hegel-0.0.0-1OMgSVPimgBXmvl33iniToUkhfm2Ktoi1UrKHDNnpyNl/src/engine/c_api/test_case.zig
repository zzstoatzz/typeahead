// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const Ctx = api.HegelContext;
const Tc = api.HegelTestCase;
pub export fn hegel_test_case_free(ctx: ?*Ctx, tc: ?*Tc) c_int {
    api.clearLastError(ctx);
    if (tc) |h| h.destroy();
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_should_capture(ctx: ?*Ctx, tc: ?*const Tc, out_should_capture: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_test_case_should_capture", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_should_capture == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_should_capture: out parameter is null", .{});
    out_should_capture.* = h.stream.value.shouldCapture();
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_clone(ctx: ?*Ctx, tc: ?*const Tc, out_test_case: [*c]?*Tc) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_test_case_clone", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_test_case == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_clone: out parameter is null", .{});
    out_test_case.* = null;
    var source = h.stream.value.cloneStream() catch |err| return api.translateError(ctx, &h.stream.value, err);
    const shared = api.SourceShared.create(source) catch |err| {
        source.deinit();
        return api.internal(ctx, err);
    };
    defer shared.release();
    h.family.printer.mutex.lock();
    const slot = h.family.printer.value.deferred(h.print_target) catch null;
    h.family.printer.mutex.unlock();
    const target: api.printer.Target = if (slot) |id| .{ .slot = id } else h.print_target;
    out_test_case.* = Tc.create(h.family, shared, target, h.worker.value.load(.acquire)) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_block(ctx: ?*Ctx, tc: ?*const Tc, indent: u64, out_test_case: [*c]?*Tc) c_int {
    api.clearLastError(ctx);
    const h = tc orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_test_case_block: test case pointer is null", .{});
    if (out_test_case == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_block: out parameter is null", .{});
    h.family.printer.mutex.lock();
    const slot = h.family.printer.value.block(h.print_target, api.sizeArg(indent)) catch null;
    h.family.printer.mutex.unlock();
    const target: api.printer.Target = if (slot) |id| .{ .slot = id } else h.print_target;
    out_test_case.* = Tc.create(h.family, h.stream, target, h.worker.value.load(.acquire)) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_set_worker(ctx: ?*Ctx, tc: ?*const Tc, worker_index: i64) c_int {
    api.clearLastError(ctx);
    const h = tc orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_test_case_set_worker: test case pointer is null", .{});
    if (worker_index < 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_set_worker: worker_index must be non-negative, got {d}", .{worker_index});
    h.worker.value.store(worker_index, .release);
    return t.HEGEL_OK;
}
pub export fn hegel_mark_complete(ctx: ?*Ctx, tc: ?*Tc, status: u32, origin: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = tc orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_mark_complete: test case pointer is null", .{});
    h.local.lock();
    defer h.local.unlock();
    if (h.completed) return t.HEGEL_E_ALREADY_COMPLETE;
    const verdict: api.state.Status = switch (status) {
        t.HEGEL_STATUS_VALID => .valid,
        t.HEGEL_STATUS_INVALID => .invalid,
        t.HEGEL_STATUS_OVERRUN => .early_stop,
        t.HEGEL_STATUS_INTERESTING => .interesting,
        else => return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_mark_complete: unknown status {d}", .{status}),
    };
    const failure_origin: ?[]const u8 = if (verdict == .interesting) if (origin == null) "Panic at <unknown>" else api.utf8(origin) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_mark_complete: origin is not valid UTF-8", .{}) else null;
    h.family.complete(verdict, failure_origin) catch |err| return api.internal(ctx, err);
    h.completed = true;
    return t.HEGEL_OK;
}
pub export fn hegel_target(ctx: ?*Ctx, tc: ?*Tc, score: f64, label: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_target", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (label == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_target: label is null", .{});
    const text = api.utf8(label) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_target: label is not valid UTF-8", .{});
    h.stream.value.targetObservation(score, text) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_event(ctx: ?*Ctx, tc: ?*Tc, label: [*c]const u8) c_int {
    return event(ctx, tc, label, null, "hegel_event");
}
pub export fn hegel_event_value(ctx: ?*Ctx, tc: ?*Tc, label: [*c]const u8, value: f64) c_int {
    return event(ctx, tc, label, value, "hegel_event_value");
}
fn event(ctx: ?*Ctx, tc: ?*Tc, label: [*c]const u8, value: ?f64, comptime name: []const u8) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, name, tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (label == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": label is null", .{});
    const text = api.utf8(label) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": label is not valid UTF-8", .{});
    h.stream.value.eventObservation(text, value) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_from_blob(ctx: ?*Ctx, s: ?*const api.HegelSettings, blob: [*c]const u8, callback: t.hegel_output_callback_t, user_data: ?*anyopaque, out_test_case: [*c]?*Tc) c_int {
    api.clearLastError(ctx);
    const h = s orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_test_case_from_blob: settings pointer is null", .{});
    if (out_test_case == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_from_blob: out parameter is null", .{});
    out_test_case.* = null;
    if (blob == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_from_blob: blob pointer is null", .{});
    const text = api.utf8(blob) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_from_blob: blob is not valid UTF-8", .{});
    var decoded = (@import("../blob.zig").decodeBlob(gpa, text) catch |err| return api.internal(ctx, err)) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_test_case_from_blob: the supplied failure blob could not be decoded. It may be corrupt or from an incompatible Hegel version.", .{});
    defer decoded.deinit(gpa);
    var ntc = switch (decoded) {
        .choices => |choices| api.state.NativeTestCase.forChoices(gpa, choices, null, null),
        .nd => |*stored| api.state.NativeTestCase.forGraph(gpa, &stored.graph, .seeded(stored.entropy), @import("../nd.zig").continuationBudget(stored.longest)),
    } catch |err| return api.internal(ctx, err);
    if (h.inner.verbosity == .debug) {
        const message = switch (decoded) {
            .choices => |choices| std.fmt.allocPrint(gpa, "replaying failure blob: choices = {d}", .{choices.len}),
            .nd => |*stored| std.fmt.allocPrint(gpa, "replaying nondeterministic failure blob: graph edges = {d}, longest run = {d}", .{ stored.graph.edgeCount() catch 0, stored.longest }),
        } catch null;
        if (message) |m| {
            defer gpa.free(m);
            if (callback) |f| {
                const line = api.cstringLossy(m) catch null;
                if (line) |l| {
                    defer gpa.free(l);
                    f(user_data, l.ptr, l.len);
                }
            } else (api.settings_mod.Output{}).line(api.io(), m);
        }
    }
    var created = api.data_source.NativeDataSource.init(gpa, ntc) catch |err| {
        ntc.deinit();
        return api.internal(ctx, err);
    };
    defer created.handle.release();
    const shared = api.SourceShared.create(created.source) catch |err| {
        created.source.deinit();
        return api.internal(ctx, err);
    };
    defer shared.release();
    const family = api.FamilyShared.create(shared) catch |err| return api.internal(ctx, err);
    defer family.release();
    if (h.test_location) |location| {
        family.reporter = .{ .location = location.deepClone() catch |err| return api.internal(ctx, err), .callback = callback, .user_data = user_data };
    }
    out_test_case.* = Tc.create(family, shared, .main, -1) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}

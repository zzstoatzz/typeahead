// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const Ctx = api.HegelContext;
const Tc = api.HegelTestCase;
const Source = api.data_source.NativeDataSource;
const c = @import("../choices.zig");
const Guarded = union(enum) { handle: *Tc, failure: c_int };
fn ready(ctx: ?*Ctx, tc: ?*Tc, comptime name: []const u8, out_is_null: bool) Guarded {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, name, tc) orelse return .{ .failure = api.guardError(ctx, tc) };
    if (out_is_null) {
        h.local.unlock();
        return .{ .failure = api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": out parameter is null", .{}) };
    }
    return .{ .handle = h };
}
pub export fn hegel_generate_boolean(ctx: ?*Ctx, tc: ?*Tc, p: f64, forced: bool, has_forced: bool, out_value: [*c]bool) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_boolean", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    out_value.* = h.stream.value.generateBoolean(p, if (has_forced) forced else null) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_generate_integer(ctx: ?*Ctx, tc: ?*Tc, min_value: i64, max_value: i64, out_value: [*c]i64) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_integer", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    var min = c.BigInt.fromInt(gpa, min_value) catch |err| return api.internal(ctx, err);
    defer min.deinit();
    var max = c.BigInt.fromInt(gpa, max_value) catch |err| return api.internal(ctx, err);
    defer max.deinit();
    var value = h.stream.value.generateInteger(min, max) catch |err| return api.translateError(ctx, &h.stream.value, err);
    defer value.deinit();
    out_value.* = value.toInt(i64) orelse return api.internal(ctx, error.InternalError);
    return t.HEGEL_OK;
}
pub export fn hegel_generate_integer_big(ctx: ?*Ctx, tc: ?*Tc, min_value: [*c]const u8, min_value_len: usize, max_value: [*c]const u8, max_value_len: usize, out_value: [*c]u8, out_value_cap: usize, out_value_len: [*c]usize) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_generate_integer_big", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (min_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_generate_integer_big: min_value pointer is null", .{});
    if (max_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_generate_integer_big: max_value pointer is null", .{});
    if (min_value_len == 0 or max_value_len == 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_generate_integer_big: bound encodings must not be empty", .{});
    if (out_value == null or out_value_len == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_generate_integer_big: out parameter is null", .{});
    var min = c.BigInt.fromSignedBytesLe(gpa, min_value[0..min_value_len]) catch |err| return api.internal(ctx, err);
    defer min.deinit();
    var max = c.BigInt.fromSignedBytesLe(gpa, max_value[0..max_value_len]) catch |err| return api.internal(ctx, err);
    defer max.deinit();
    var value = h.stream.value.generateInteger(min, max) catch |err| return api.translateError(ctx, &h.stream.value, err);
    defer value.deinit();
    const bytes = value.toSignedBytesLe(gpa) catch |err| return api.internal(ctx, err);
    defer gpa.free(bytes);
    if (bytes.len > out_value_cap) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_generate_integer_big: out buffer too small (need {d}, have {d})", .{ bytes.len, out_value_cap });
    @memcpy(out_value[0..bytes.len], bytes);
    @memset(out_value[bytes.len..out_value_cap], if (bytes[bytes.len - 1] & 0x80 != 0) 255 else 0);
    out_value_len.* = bytes.len;
    return t.HEGEL_OK;
}
pub export fn hegel_generate_float(ctx: ?*Ctx, tc: ?*Tc, width: u32, min_value: f64, max_value: f64, allow_nan: bool, allow_infinity: bool, exclude_min: bool, exclude_max: bool, smallest_nonzero_magnitude: f64, out_value: [*c]f64) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_float", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    out_value.* = h.stream.value.generateFloat(.{ .width = width, .min_value = min_value, .max_value = max_value, .allow_nan = allow_nan, .allow_infinity = allow_infinity, .exclude_min = exclude_min, .exclude_max = exclude_max, .smallest_nonzero_magnitude = smallest_nonzero_magnitude }) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_generate_bytes(ctx: ?*Ctx, tc: ?*Tc, min_size: u64, max_size: u64, out_result: [*c]t.hegel_generate_bytes_result_t) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_bytes", out_result == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const bytes = h.stream.value.generateBytes(api.sizeArg(min_size), api.sizeArg(max_size)) catch |err| return api.translateError(ctx, &h.stream.value, err);
    out_result.* = .{ .data = bytes.ptr, .len = bytes.len };
    return t.HEGEL_OK;
}
pub export fn hegel_generate_bytes_result_free(ctx: ?*Ctx, result: [*c]t.hegel_generate_bytes_result_t) c_int {
    api.clearLastError(ctx);
    if (result != null) {
        if (result[0].data != null) gpa.free(result[0].data[0..result[0].len]);
        result.* = .{ .data = null, .len = 0 };
    }
    return t.HEGEL_OK;
}
pub export fn hegel_generate_string_result_free(ctx: ?*Ctx, result: [*c]t.hegel_generate_string_result_t) c_int {
    api.clearLastError(ctx);
    if (result != null) {
        if (result[0].data != null) gpa.free(result[0].data[0..result[0].len]);
        result.* = .{ .data = null, .len = 0 };
    }
    return t.HEGEL_OK;
}
pub export fn hegel_generate_date(ctx: ?*Ctx, tc: ?*Tc, min_value: t.hegel_date_t, max_value: t.hegel_date_t, out_value: [*c]t.hegel_date_t) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_date", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateDate(.{ .year = min_value.year, .month = min_value.month, .day = min_value.day }, .{ .year = max_value.year, .month = max_value.month, .day = max_value.day }) catch |err| return api.translateError(ctx, &h.stream.value, err);
    out_value.* = .{ .year = value.year, .month = value.month, .day = value.day };
    return t.HEGEL_OK;
}
pub export fn hegel_generate_time(ctx: ?*Ctx, tc: ?*Tc, min_value: t.hegel_time_t, max_value: t.hegel_time_t, out_value: [*c]t.hegel_time_t) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_time", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateTime(.{ .hour = min_value.hour, .minute = min_value.minute, .second = min_value.second, .nanosecond = min_value.nanosecond }, .{ .hour = max_value.hour, .minute = max_value.minute, .second = max_value.second, .nanosecond = max_value.nanosecond }) catch |err| return api.translateError(ctx, &h.stream.value, err);
    out_value.* = .{ .hour = value.hour, .minute = value.minute, .second = value.second, .nanosecond = value.nanosecond };
    return t.HEGEL_OK;
}
pub export fn hegel_generate_datetime(ctx: ?*Ctx, tc: ?*Tc, min_value: t.hegel_datetime_t, max_value: t.hegel_datetime_t, out_value: [*c]t.hegel_datetime_t) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_datetime", out_value == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateDatetime(.{ .date = .{ .year = min_value.date.year, .month = min_value.date.month, .day = min_value.date.day }, .time = .{ .hour = min_value.time.hour, .minute = min_value.time.minute, .second = min_value.time.second, .nanosecond = min_value.time.nanosecond } }, .{ .date = .{ .year = max_value.date.year, .month = max_value.date.month, .day = max_value.date.day }, .time = .{ .hour = max_value.time.hour, .minute = max_value.time.minute, .second = max_value.time.second, .nanosecond = max_value.time.nanosecond } }) catch |err| return api.translateError(ctx, &h.stream.value, err);
    out_value.* = .{ .date = .{ .year = value.date.year, .month = value.date.month, .day = value.date.day }, .time = .{ .hour = value.time.hour, .minute = value.time.minute, .second = value.time.second, .nanosecond = value.time.nanosecond } };
    return t.HEGEL_OK;
}
pub export fn hegel_generate_uuid(ctx: ?*Ctx, tc: ?*Tc, version: u8, has_version: bool, out_bytes: [*c]u8) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_uuid", out_bytes == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateUuid(if (has_version) version else null) catch |err| return api.translateError(ctx, &h.stream.value, err);
    @memcpy(out_bytes[0..value.len], &value);
    return t.HEGEL_OK;
}
pub export fn hegel_generate_ipv4(ctx: ?*Ctx, tc: ?*Tc, out_bytes: [*c]u8) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_ipv4", out_bytes == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateIpv4() catch |err| return api.translateError(ctx, &h.stream.value, err);
    @memcpy(out_bytes[0..value.len], &value);
    return t.HEGEL_OK;
}
pub export fn hegel_generate_ipv6(ctx: ?*Ctx, tc: ?*Tc, out_bytes: [*c]u8) c_int {
    const h = switch (ready(ctx, tc, "hegel_generate_ipv6", out_bytes == null)) {
        .handle => |handle| handle,
        .failure => |rc| return rc,
    };
    defer h.local.unlock();
    const value = h.stream.value.generateIpv6() catch |err| return api.translateError(ctx, &h.stream.value, err);
    @memcpy(out_bytes[0..value.len], &value);
    return t.HEGEL_OK;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const draws = @import("../draws.zig");
const Ctx = api.HegelContext;
pub const HegelStringGenerator = struct { spec: draws.StringSpec };
fn write(out: [*c]?*HegelStringGenerator, owned: draws.StringSpec) !void {
    var spec = owned;
    errdefer spec.deinit();
    const result = try gpa.create(HegelStringGenerator);
    result.* = .{ .spec = spec };
    out.* = result;
}
fn constructorError(ctx: ?*Ctx, err: anyerror, diagnostic: ?[]const u8) c_int {
    if (diagnostic) |message| api.setLastError(ctx, message) else api.setLastError(ctx, @errorName(err));
    return if (err == error.InternalError or err == error.OutOfMemory) t.HEGEL_E_INTERNAL else t.HEGEL_E_INVALID_ARG;
}
fn optionalString(ctx: ?*Ctx, comptime function: []const u8, comptime arg: []const u8, p: [*c]const u8) !?[]const u8 {
    if (p == null) return null;
    return api.utf8(p) orelse {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": " ++ arg ++ " is not valid UTF-8", .{});
        return error.InvalidArgument;
    };
}
fn optionalNames(ctx: ?*Ctx, comptime function: []const u8, comptime arg: []const u8, p: [*c]const [*c]const u8, len: usize) !?[][]const u8 {
    if (p == null) return null;
    const result = try gpa.alloc([]const u8, len);
    errdefer gpa.free(result);
    for (result, 0..) |*item, i| {
        if (p[i] == null) {
            _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": " ++ arg ++ "[{d}] is null", .{i});
            return error.InvalidArgument;
        }
        item.* = api.utf8(p[i]) orelse {
            _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": " ++ arg ++ "[{d}] is not valid UTF-8", .{i});
            return error.InvalidArgument;
        };
    }
    return result;
}
pub export fn hegel_string_generator_text(ctx: ?*Ctx, min_size: u64, max_size: u64, codec: [*c]const u8, min_codepoint: u32, max_codepoint: u32, categories: [*c]const [*c]const u8, categories_len: usize, exclude_categories: [*c]const [*c]const u8, exclude_categories_len: usize, include_characters: [*c]const u8, include_characters_len: usize, exclude_characters: [*c]const u8, exclude_characters_len: usize, out_generator: [*c]?*HegelStringGenerator) c_int {
    const function = "hegel_string_generator_text";
    api.clearLastError(ctx);
    if (out_generator == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": out parameter is null", .{});
    out_generator.* = null;
    const codec_text = optionalString(ctx, function, "codec", codec) catch return t.HEGEL_E_INVALID_ARG;
    const cats = optionalNames(ctx, function, "categories", categories, categories_len) catch |err| return if (err == error.InvalidArgument) t.HEGEL_E_INVALID_ARG else api.internal(ctx, err);
    defer if (cats) |values| gpa.free(values);
    const excluded = optionalNames(ctx, function, "exclude_categories", exclude_categories, exclude_categories_len) catch |err| return if (err == error.InvalidArgument) t.HEGEL_E_INVALID_ARG else api.internal(ctx, err);
    defer if (excluded) |values| gpa.free(values);
    const included_text = api.optionalUtf8Buffer(ctx, function, "include_characters", include_characters, include_characters_len) orelse return t.HEGEL_E_INVALID_ARG;
    const excluded_text = api.optionalUtf8Buffer(ctx, function, "exclude_characters", exclude_characters, exclude_characters_len) orelse return t.HEGEL_E_INVALID_ARG;
    var diagnostic: ?[]u8 = null;
    defer if (diagnostic) |message| gpa.free(message);
    const spec = draws.StringSpec.initTextDetailed(gpa, .{ .codec = codec_text, .min_codepoint = min_codepoint, .max_codepoint = max_codepoint, .categories = cats, .exclude_categories = excluded, .include_characters = if (include_characters == null) null else included_text, .exclude_characters = if (exclude_characters == null) null else excluded_text }, api.sizeArg(min_size), api.sizeArg(max_size), &diagnostic) catch |err| return constructorError(ctx, err, diagnostic);
    write(out_generator, spec) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_string_generator_regex(ctx: ?*Ctx, pattern: [*c]const u8, pattern_len: usize, fullmatch: bool, alphabet: ?*const HegelStringGenerator, out_generator: [*c]?*HegelStringGenerator) c_int {
    const function = "hegel_string_generator_regex";
    api.clearLastError(ctx);
    if (out_generator == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": out parameter is null", .{});
    out_generator.* = null;
    const text = api.optionalUtf8Buffer(ctx, function, "pattern", pattern, pattern_len) orelse return t.HEGEL_E_INVALID_ARG;
    var diagnostic: ?[]u8 = null;
    defer if (diagnostic) |message| gpa.free(message);
    const spec = draws.StringSpec.initRegex(gpa, text, fullmatch, if (alphabet) |a| &a.spec else null, &diagnostic) catch |err| return constructorError(ctx, err, diagnostic);
    write(out_generator, spec) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_string_generator_free(ctx: ?*Ctx, generator: ?*HegelStringGenerator) c_int {
    api.clearLastError(ctx);
    if (generator) |g| {
        g.spec.deinit();
        gpa.destroy(g);
    }
    return t.HEGEL_OK;
}
pub export fn hegel_generate_string(ctx: ?*Ctx, tc: ?*api.HegelTestCase, generator: ?*const HegelStringGenerator, out_result: [*c]t.hegel_generate_string_result_t) c_int {
    const function = "hegel_generate_string";
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, function, tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const g = generator orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, function ++ ": generator handle is null", .{});
    if (out_result == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": out parameter is null", .{});
    const text = h.stream.value.generateString(&g.spec) catch |err| return api.translateError(ctx, &h.stream.value, err);
    out_result.* = .{ .data = text.ptr, .len = text.len };
    return t.HEGEL_OK;
}
pub export fn hegel_string_generator_email(ctx: ?*Ctx, out_generator: [*c]?*HegelStringGenerator) c_int {
    api.clearLastError(ctx);
    if (out_generator == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_string_generator_email: out parameter is null", .{});
    out_generator.* = null;
    var domains = draws.defaultDomains(gpa) catch |err| return api.internal(ctx, err);
    defer domains.deinit();
    const spec = draws.StringSpec.initEmail(gpa, domains.top_level_domains) catch |err| return constructorError(ctx, err, null);
    write(out_generator, spec) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_string_generator_url(ctx: ?*Ctx, out_generator: [*c]?*HegelStringGenerator) c_int {
    api.clearLastError(ctx);
    if (out_generator == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_string_generator_url: out parameter is null", .{});
    out_generator.* = null;
    var domains = draws.defaultDomains(gpa) catch |err| return api.internal(ctx, err);
    defer domains.deinit();
    const spec = draws.StringSpec.initUrl(gpa, domains.top_level_domains) catch |err| return constructorError(ctx, err, null);
    write(out_generator, spec) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_string_generator_domain(ctx: ?*Ctx, max_length: u64, out_generator: [*c]?*HegelStringGenerator) c_int {
    api.clearLastError(ctx);
    if (out_generator == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_string_generator_domain: out parameter is null", .{});
    out_generator.* = null;
    var domains = draws.defaultDomains(gpa) catch |err| return api.internal(ctx, err);
    defer domains.deinit();
    var diagnostic: ?[]u8 = null;
    defer if (diagnostic) |message| gpa.free(message);
    const spec = draws.StringSpec.initDomainDetailed(gpa, api.sizeArg(max_length), domains.top_level_domains, &diagnostic) catch |err| return constructorError(ctx, err, diagnostic);
    write(out_generator, spec) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}

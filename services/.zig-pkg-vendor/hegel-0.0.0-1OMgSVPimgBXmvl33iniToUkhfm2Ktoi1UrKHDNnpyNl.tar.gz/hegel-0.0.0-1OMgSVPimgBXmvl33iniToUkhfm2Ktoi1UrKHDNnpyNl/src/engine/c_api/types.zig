// SPDX-License-Identifier: MIT AND MPL-2.0
// Generated from the pinned upstream include/hegel.h with Zig translate-c.
pub const HEGEL_OK: c_int = 0;
pub const HEGEL_E_STOP_TEST: c_int = -1;
pub const HEGEL_E_ASSUME: c_int = -2;
pub const HEGEL_E_BACKEND: c_int = -3;
pub const HEGEL_E_INVALID_HANDLE: c_int = -4;
pub const HEGEL_E_INVALID_ARG: c_int = -5;
pub const HEGEL_E_ALREADY_COMPLETE: c_int = -6;
pub const HEGEL_E_NOT_COMPLETE: c_int = -7;
pub const HEGEL_E_INTERNAL: c_int = -8;
pub const HEGEL_E_CONCURRENT_USE: c_int = -9;
pub const HEGEL_E_RETRY: c_int = -10;
pub const hegel_result_t = c_int;
pub const HEGEL_VERBOSITY_NORMAL: c_int = 0;
pub const HEGEL_VERBOSITY_QUIET: c_int = 1;
pub const HEGEL_VERBOSITY_VERBOSE: c_int = 2;
pub const HEGEL_VERBOSITY_DEBUG: c_int = 3;
pub const hegel_verbosity_t = c_uint;
pub const HEGEL_BACKEND_DEFAULT: c_int = 1;
pub const HEGEL_BACKEND_URANDOM: c_int = 2;
pub const hegel_backend_t = c_uint;
pub const HEGEL_NONDETERMINISM_QUIET: c_int = 0;
pub const HEGEL_NONDETERMINISM_WARN: c_int = 1;
pub const HEGEL_NONDETERMINISM_ERROR: c_int = 2;
pub const hegel_nondeterminism_strictness_t = c_uint;
pub const HEGEL_RUN_STATUS_PASSED: c_int = 0;
pub const HEGEL_RUN_STATUS_FAILED: c_int = 1;
pub const HEGEL_RUN_STATUS_ERROR: c_int = 2;
pub const hegel_run_status_t = c_uint;
pub const HEGEL_PHASE_EXPLICIT: c_int = 1;
pub const HEGEL_PHASE_REUSE: c_int = 2;
pub const HEGEL_PHASE_GENERATE: c_int = 4;
pub const HEGEL_PHASE_TARGET: c_int = 8;
pub const HEGEL_PHASE_SHRINK: c_int = 16;
pub const HEGEL_PHASE_ALL: c_int = 31;
pub const hegel_phase_t = c_uint;
pub const HEGEL_HC_FILTER_TOO_MUCH: c_int = 1;
pub const HEGEL_HC_TOO_SLOW: c_int = 2;
pub const HEGEL_HC_TEST_CASES_TOO_LARGE: c_int = 4;
pub const HEGEL_HC_LARGE_INITIAL_TEST_CASE: c_int = 8;
pub const hegel_health_check_t = c_uint;
pub const HEGEL_STATUS_VALID: c_int = 0;
pub const HEGEL_STATUS_INVALID: c_int = 1;
pub const HEGEL_STATUS_OVERRUN: c_int = 2;
pub const HEGEL_STATUS_INTERESTING: c_int = 3;
pub const hegel_status_t = c_uint;
pub const HEGEL_H = "";
pub const HEGEL_STATE_MACHINE_DONE: i64 = @import("std").math.minInt(i64);
pub const hegel_output_callback_t = ?*const fn (user_data: ?*anyopaque, line: [*c]const u8, len: usize) callconv(.c) void;
pub const hegel_generate_bytes_result_t = extern struct {
    data: [*c]u8 = null,
    len: usize = 0,
};
pub const hegel_generate_string_result_t = extern struct {
    data: [*c]u8 = null,
    len: usize = 0,
};
pub const hegel_date_t = extern struct {
    year: i32 = 0,
    month: u8 = 0,
    day: u8 = 0,
};
pub const hegel_time_t = extern struct {
    hour: u8 = 0,
    minute: u8 = 0,
    second: u8 = 0,
    nanosecond: u32 = 0,
};
pub const hegel_datetime_t = extern struct {
    date: hegel_date_t = @import("std").mem.zeroes(hegel_date_t),
    time: hegel_time_t = @import("std").mem.zeroes(hegel_time_t),
};
pub const hegel_printer_value_result_t = extern struct {
    data: [*c]u8 = null,
    len: usize = 0,
};

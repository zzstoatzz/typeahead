// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const Ctx = api.HegelContext;
const Tc = api.HegelTestCase;
const state = api.state;
const Source = api.data_source.NativeDataSource;
const Machine = @import("../state_machine.zig").NativeStateMachine;
pub const HegelCollection = struct { mutex: api.Mutex = .{}, state: state.ManyState };
pub const HegelRecursion = struct { mutex: api.Mutex = .{}, state: state.RecursionState };
pub const HegelPool = struct { mutex: api.Mutex = .{}, variables: state.NativeVariables };
pub const HegelStateMachine = struct { mutex: api.Mutex = .{}, machine: Machine };
pub export fn hegel_start_span(ctx: ?*Ctx, tc: ?*Tc, label: u64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_start_span", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    h.stream.value.startSpan(label) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_stop_span(ctx: ?*Ctx, tc: ?*Tc, discard: bool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_stop_span", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    h.stream.value.stopSpan(discard) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_label_from_name(ctx: ?*Ctx, name: [*c]const u8, out_label: [*c]u64) c_int {
    api.clearLastError(ctx);
    if (name == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_label_from_name: name is null", .{});
    if (out_label == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_label_from_name: out parameter is null", .{});
    out_label.* = @import("../labels.zig").labelFromBytes(std.mem.span(@as([*:0]const u8, @ptrCast(name))));
    return t.HEGEL_OK;
}
pub export fn hegel_label_combine(ctx: ?*Ctx, labels: [*c]const u64, len: usize, out_label: [*c]u64) c_int {
    api.clearLastError(ctx);
    if (labels == null and len > 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_label_combine: labels is null", .{});
    if (out_label == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_label_combine: out parameter is null", .{});
    out_label.* = @import("../labels.zig").combineLabels(if (len == 0) &.{} else labels[0..len]);
    return t.HEGEL_OK;
}
pub export fn hegel_new_collection(ctx: ?*Ctx, tc: ?*Tc, min_size: u64, max_size: u64, out_collection: [*c]?*HegelCollection) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_new_collection", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_collection == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_new_collection: out parameter is null", .{});
    out_collection.* = null;
    const max: ?u64 = if (max_size == std.math.maxInt(u64)) null else max_size;
    if (max != null and min_size > max.?) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_new_collection requires min_size <= max_size, got [{d}, {d}]", .{ min_size, max.? });
    const sizing = h.stream.value.newCollection(min_size, max) catch |err| return api.translateError(ctx, &h.stream.value, err);
    const result = gpa.create(HegelCollection) catch |err| return api.internal(ctx, err);
    result.* = .{ .state = sizing };
    out_collection.* = result;
    return t.HEGEL_OK;
}
pub export fn hegel_collection_free(ctx: ?*Ctx, collection: ?*HegelCollection) c_int {
    api.clearLastError(ctx);
    if (collection) |h| gpa.destroy(h);
    return t.HEGEL_OK;
}
pub export fn hegel_new_recursion(ctx: ?*Ctx, tc: ?*Tc, max_depth: u64, max_leaves: u64, out_recursion: [*c]?*HegelRecursion) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_new_recursion", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_recursion == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_new_recursion: out parameter is null", .{});
    out_recursion.* = null;
    var sizing = h.stream.value.newRecursion(max_depth, max_leaves) catch |err| return api.translateError(ctx, &h.stream.value, err);
    const result = gpa.create(HegelRecursion) catch |err| {
        sizing.deinit();
        return api.internal(ctx, err);
    };
    result.* = .{ .state = sizing };
    out_recursion.* = result;
    return t.HEGEL_OK;
}
pub export fn hegel_recursion_free(ctx: ?*Ctx, recursion: ?*HegelRecursion) c_int {
    api.clearLastError(ctx);
    if (recursion) |h| {
        h.state.deinit();
        gpa.destroy(h);
    }
    return t.HEGEL_OK;
}
pub export fn hegel_new_pool(ctx: ?*Ctx, tc: ?*Tc, out_pool: [*c]?*HegelPool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_new_pool", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_pool == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_new_pool: out parameter is null", .{});
    out_pool.* = null;
    var variables = h.stream.value.newPool() catch |err| return api.translateError(ctx, &h.stream.value, err);
    const result = gpa.create(HegelPool) catch |err| {
        variables.deinit();
        return api.internal(ctx, err);
    };
    result.* = .{ .variables = variables };
    out_pool.* = result;
    return t.HEGEL_OK;
}
pub export fn hegel_pool_free(ctx: ?*Ctx, pool: ?*HegelPool) c_int {
    api.clearLastError(ctx);
    if (pool) |h| {
        h.variables.deinit();
        gpa.destroy(h);
    }
    return t.HEGEL_OK;
}
fn names(ctx: ?*Ctx, comptime func: []const u8, comptime arg: []const u8, p: [*c]const [*c]const u8, len: usize) ![][]const u8 {
    if (p == null and len > 0) {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, func ++ ": " ++ arg ++ " pointer is null", .{});
        return error.InvalidArgument;
    }
    const result = try gpa.alloc([]const u8, len);
    errdefer gpa.free(result);
    for (result, 0..) |*dest, i| {
        if (p[i] == null) {
            _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, func ++ ": " ++ arg ++ "[{d}] is null", .{i});
            return error.InvalidArgument;
        }
        dest.* = api.utf8(p[i]) orelse {
            _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, func ++ ": " ++ arg ++ "[{d}] is not valid UTF-8", .{i});
            return error.InvalidArgument;
        };
    }
    return result;
}
pub export fn hegel_new_state_machine(ctx: ?*Ctx, tc: ?*Tc, rule_names: [*c]const [*c]const u8, rule_groups: [*c]const i64, rule_weights: [*c]const f64, num_rules: usize, invariant_names: [*c]const [*c]const u8, invariant_always_check: [*c]const bool, num_invariants: usize, min_concurrency: i64, max_concurrency: i64, step_count: i64, out_state_machine: [*c]?*HegelStateMachine, out_concurrency: [*c]i64) c_int {
    const function = "hegel_new_state_machine";
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, function, tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    if (out_state_machine == null or out_concurrency == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": out parameter is null", .{});
    out_state_machine.* = null;
    const rules = names(ctx, function, "rule_names", rule_names, num_rules) catch |err| return if (err == error.InvalidArgument) t.HEGEL_E_INVALID_ARG else api.internal(ctx, err);
    defer gpa.free(rules);
    if (rule_groups == null and num_rules > 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": rule_groups is null", .{});
    const groups: []const i64 = if (num_rules == 0) &.{} else rule_groups[0..num_rules];
    for (groups, 0..) |id, i| if (id == t.HEGEL_STATE_MACHINE_DONE) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": rule_groups[{d}] is {d} (HEGEL_STATE_MACHINE_DONE), which is reserved as the termination sentinel of hegel_state_machine_next_group", .{ i, t.HEGEL_STATE_MACHINE_DONE });
    const default_weights: ?[]f64 = if (rule_weights == null) gpa.alloc(f64, num_rules) catch |err| return api.internal(ctx, err) else null;
    defer if (default_weights) |values| gpa.free(values);
    if (default_weights) |values| @memset(values, 1);
    const weights: []const f64 = if (default_weights) |values| values else if (num_rules == 0) &.{} else rule_weights[0..num_rules];
    const invariants = names(ctx, function, "invariant_names", invariant_names, num_invariants) catch |err| return if (err == error.InvalidArgument) t.HEGEL_E_INVALID_ARG else api.internal(ctx, err);
    defer gpa.free(invariants);
    const default_always: ?[]bool = if (invariant_always_check == null) gpa.alloc(bool, num_invariants) catch |err| return api.internal(ctx, err) else null;
    defer if (default_always) |values| gpa.free(values);
    if (default_always) |values| @memset(values, false);
    const always: []const bool = if (default_always) |values| values else if (num_invariants == 0) &.{} else invariant_always_check[0..num_invariants];
    var machine = h.stream.value.newStateMachine(rules, groups, weights, invariants, always, min_concurrency, max_concurrency, step_count) catch |err| return api.translateError(ctx, &h.stream.value, err);
    const result = gpa.create(HegelStateMachine) catch |err| {
        machine.deinit();
        return api.internal(ctx, err);
    };
    result.* = .{ .machine = machine };
    out_state_machine.* = result;
    out_concurrency.* = machine.concurrency();
    return t.HEGEL_OK;
}
pub export fn hegel_state_machine_free(ctx: ?*Ctx, machine: ?*HegelStateMachine) c_int {
    api.clearLastError(ctx);
    if (machine) |h| {
        h.machine.deinit();
        gpa.destroy(h);
    }
    return t.HEGEL_OK;
}
pub export fn hegel_collection_more(ctx: ?*Ctx, tc: ?*Tc, collection: ?*HegelCollection, out_value: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_collection_more", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = collection orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_collection_more: collection handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_collection_more: out parameter is null", .{});
    if (!object.mutex.tryLock()) return api.fail(ctx, t.HEGEL_E_CONCURRENT_USE, "hegel_collection_more: collection handle is in use on another thread", .{});
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.collectionMore(&object.state) catch |err| return api.translateError(ctx, &h.stream.value, err));
    return t.HEGEL_OK;
}
pub export fn hegel_collection_reject(ctx: ?*Ctx, tc: ?*Tc, collection: ?*HegelCollection, why: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_collection_reject", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = collection orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_collection_reject: collection handle is null", .{});
    if (why != null and api.utf8(why) == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_collection_reject: why is not valid UTF-8", .{});
    if (!object.mutex.tryLock()) return api.fail(ctx, t.HEGEL_E_CONCURRENT_USE, "hegel_collection_reject: collection handle is in use on another thread", .{});
    defer object.mutex.unlock();
    h.stream.value.collectionReject(&object.state) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_recursion_branch(ctx: ?*Ctx, tc: ?*Tc, recursion: ?*HegelRecursion, depth: u64, out_value: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_recursion_branch", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = recursion orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_recursion_branch: recursion handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_recursion_branch: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.recursionBranch(&object.state, depth) catch |err| return api.translateError(ctx, &h.stream.value, err));
    return t.HEGEL_OK;
}
pub export fn hegel_recursion_leaf(ctx: ?*Ctx, tc: ?*Tc, recursion: ?*HegelRecursion) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_recursion_leaf", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = recursion orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_recursion_leaf: recursion handle is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    if (!(h.stream.value.recursionLeaf(&object.state) catch |err| return api.translateError(ctx, &h.stream.value, err))) return api.fail(ctx, t.HEGEL_E_RETRY, "recursive value needs more than max_leaves = {d} leaves; discard the attempt with hegel_recursion_retry", .{object.state.max_leaves});
    return t.HEGEL_OK;
}
pub export fn hegel_recursion_retry(ctx: ?*Ctx, tc: ?*Tc, recursion: ?*HegelRecursion) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_recursion_retry", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = recursion orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_recursion_retry: recursion handle is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    h.stream.value.recursionRetry(&object.state) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_recursion_finish(ctx: ?*Ctx, tc: ?*Tc, recursion: ?*HegelRecursion) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_recursion_finish", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = recursion orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_recursion_finish: recursion handle is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    if (!(h.stream.value.recursionFinish(&object.state) catch |err| return api.translateError(ctx, &h.stream.value, err))) return api.fail(ctx, t.HEGEL_E_RETRY, "recursive value was priced for branches with more children than its branch function draws; regenerate it from the root", .{});
    return t.HEGEL_OK;
}
pub export fn hegel_pool_add(ctx: ?*Ctx, tc: ?*Tc, pool: ?*HegelPool, out_value: [*c]i64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_pool_add", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = pool orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_pool_add: pool handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_pool_add: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.poolAdd(&object.variables) catch |err| return api.translateError(ctx, &h.stream.value, err));
    return t.HEGEL_OK;
}
pub export fn hegel_pool_generate(ctx: ?*Ctx, tc: ?*Tc, pool: ?*HegelPool, consume: bool, out_value: [*c]i64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_pool_generate", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = pool orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_pool_generate: pool handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_pool_generate: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.poolGenerate(&object.variables, consume) catch |err| return api.translateError(ctx, &h.stream.value, err));
    return t.HEGEL_OK;
}
pub export fn hegel_state_machine_next_group(ctx: ?*Ctx, tc: ?*Tc, state_machine: ?*HegelStateMachine, out_value: [*c]i64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_state_machine_next_group", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = state_machine orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_state_machine_next_group: state machine handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_state_machine_next_group: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.stateMachineNextGroup(&object.machine) catch |err| return api.translateError(ctx, &h.stream.value, err)) orelse t.HEGEL_STATE_MACHINE_DONE;
    return t.HEGEL_OK;
}
pub export fn hegel_state_machine_next_rule(ctx: ?*Ctx, tc: ?*Tc, state_machine: ?*HegelStateMachine, worker_index: i64, out_value: [*c]i64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_state_machine_next_rule", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = state_machine orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_state_machine_next_rule: state machine handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_state_machine_next_rule: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.stateMachineNextRule(&object.machine, worker_index) catch |err| return api.translateError(ctx, &h.stream.value, err)) orelse t.HEGEL_STATE_MACHINE_DONE;
    return t.HEGEL_OK;
}
pub export fn hegel_state_machine_rule_rejected(ctx: ?*Ctx, tc: ?*Tc, state_machine: ?*HegelStateMachine, worker_index: i64) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_state_machine_rule_rejected", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = state_machine orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_state_machine_rule_rejected: state machine handle is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    h.stream.value.stateMachineRuleRejected(&object.machine, worker_index) catch |err| return api.translateError(ctx, &h.stream.value, err);
    return t.HEGEL_OK;
}
pub export fn hegel_state_machine_should_check_invariant(ctx: ?*Ctx, tc: ?*Tc, state_machine: ?*HegelStateMachine, invariant_index: i64, out_value: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = api.tcGuard(ctx, "hegel_state_machine_should_check_invariant", tc) orelse return api.guardError(ctx, tc);
    defer h.local.unlock();
    const object = state_machine orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_state_machine_should_check_invariant: state machine handle is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_state_machine_should_check_invariant: out parameter is null", .{});
    object.mutex.lock();
    defer object.mutex.unlock();
    out_value.* = (h.stream.value.stateMachineShouldCheckInvariant(&object.machine, invariant_index) catch |err| return api.translateError(ctx, &h.stream.value, err));
    return t.HEGEL_OK;
}

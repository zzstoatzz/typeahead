// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const HegelContext = api.HegelContext;
const HegelSettings = api.HegelSettings;
fn handle(ctx: ?*HegelContext, s: ?*const HegelSettings, comptime name: []const u8) ?*HegelSettings {
    return @constCast(s orelse {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, name ++ ": settings pointer is null", .{});
        return null;
    });
}
pub export fn hegel_settings_set_test_cases(ctx: ?*HegelContext, s: ?*HegelSettings, n: u64) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_test_cases") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.test_cases = n;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_derandomize(ctx: ?*HegelContext, s: ?*HegelSettings, derandomize: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_derandomize") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.derandomize = derandomize;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_report_multiple_failures(ctx: ?*HegelContext, s: ?*HegelSettings, yes: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_report_multiple_failures") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.report_multiple_failures = yes;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_show_statistics(ctx: ?*HegelContext, s: ?*HegelSettings, yes: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_show_statistics") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.show_statistics = yes;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_unbounded_choices(ctx: ?*HegelContext, s: ?*HegelSettings, yes: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_unbounded_choices") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.unbounded_choices = yes;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_print_blob(ctx: ?*HegelContext, s: ?*HegelSettings, yes: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_print_blob") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.print_blob = yes;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_backend(ctx: ?*HegelContext, s: ?*HegelSettings, backend: u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_backend") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.backend = switch (backend) {
        t.HEGEL_BACKEND_DEFAULT => .default,
        t.HEGEL_BACKEND_URANDOM => .urandom,
        else => return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_set_backend: unknown backend {d}", .{backend}),
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_verbosity(ctx: ?*HegelContext, s: ?*HegelSettings, v: u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_verbosity") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.verbosity = switch (v) {
        t.HEGEL_VERBOSITY_NORMAL => .normal,
        t.HEGEL_VERBOSITY_QUIET => .quiet,
        t.HEGEL_VERBOSITY_VERBOSE => .verbose,
        t.HEGEL_VERBOSITY_DEBUG => .debug,
        else => return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_set_verbosity: unknown verbosity {d}", .{v}),
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_nondeterminism_strictness(ctx: ?*HegelContext, s: ?*HegelSettings, strictness: u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_nondeterminism_strictness") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.nondeterminism_strictness = switch (strictness) {
        t.HEGEL_NONDETERMINISM_QUIET => .quiet,
        t.HEGEL_NONDETERMINISM_WARN => .warn,
        t.HEGEL_NONDETERMINISM_ERROR => .@"error",
        else => return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_set_nondeterminism_strictness: unknown nondeterminism strictness {d}", .{strictness}),
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_test_cases(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]u64) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_test_cases") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_test_cases: out parameter is null", .{});
    out.* = h.inner.test_cases;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_derandomize(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_derandomize") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_derandomize: out parameter is null", .{});
    out.* = h.inner.derandomize;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_report_multiple_failures(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_report_multiple_failures") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_report_multiple_failures: out parameter is null", .{});
    out.* = h.inner.report_multiple_failures;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_show_statistics(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_show_statistics") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_show_statistics: out parameter is null", .{});
    out.* = h.inner.show_statistics;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_unbounded_choices(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_unbounded_choices") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_unbounded_choices: out parameter is null", .{});
    out.* = h.inner.unbounded_choices;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_print_blob(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_print_blob") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_print_blob: out parameter is null", .{});
    out.* = h.inner.print_blob;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_backend(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]c_uint) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_backend") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_backend: out parameter is null", .{});
    out.* = switch (h.inner.backend) {
        .default => t.HEGEL_BACKEND_DEFAULT,
        .urandom => t.HEGEL_BACKEND_URANDOM,
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_verbosity(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]c_uint) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_verbosity") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_verbosity: out parameter is null", .{});
    out.* = switch (h.inner.verbosity) {
        .normal => t.HEGEL_VERBOSITY_NORMAL,
        .quiet => t.HEGEL_VERBOSITY_QUIET,
        .verbose => t.HEGEL_VERBOSITY_VERBOSE,
        .debug => t.HEGEL_VERBOSITY_DEBUG,
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_nondeterminism_strictness(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]c_uint) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_nondeterminism_strictness") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_nondeterminism_strictness: out parameter is null", .{});
    out.* = switch (h.inner.nondeterminism_strictness) {
        .quiet => t.HEGEL_NONDETERMINISM_QUIET,
        .warn => t.HEGEL_NONDETERMINISM_WARN,
        .@"error" => t.HEGEL_NONDETERMINISM_ERROR,
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_phases(ctx: ?*HegelContext, s: ?*HegelSettings, phases: u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_phases") orelse return t.HEGEL_E_INVALID_HANDLE;
    var values: [5]api.settings_mod.Phase = undefined;
    var count: usize = 0;
    if (phases & t.HEGEL_PHASE_EXPLICIT != 0) {
        values[count] = .explicit;
        count += 1;
    }
    if (phases & t.HEGEL_PHASE_REUSE != 0) {
        values[count] = .reuse;
        count += 1;
    }
    if (phases & t.HEGEL_PHASE_GENERATE != 0) {
        values[count] = .generate;
        count += 1;
    }
    if (phases & t.HEGEL_PHASE_TARGET != 0) {
        values[count] = .target;
        count += 1;
    }
    if (phases & t.HEGEL_PHASE_SHRINK != 0) {
        values[count] = .shrink;
        count += 1;
    }
    const owned = gpa.dupe(api.settings_mod.Phase, values[0..count]) catch |err| return api.internal(ctx, err);
    gpa.free(h.inner.phases);
    h.inner.phases = owned;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_phases(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_phases") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_phases: out parameter is null", .{});
    var mask: u32 = 0;
    for (h.inner.phases) |value| mask |= switch (value) {
        .explicit => t.HEGEL_PHASE_EXPLICIT,
        .reuse => t.HEGEL_PHASE_REUSE,
        .generate => t.HEGEL_PHASE_GENERATE,
        .target => t.HEGEL_PHASE_TARGET,
        .shrink => t.HEGEL_PHASE_SHRINK,
    };
    out.* = mask;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_suppress_health_check(ctx: ?*HegelContext, s: ?*HegelSettings, checks: u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_suppress_health_check") orelse return t.HEGEL_E_INVALID_HANDLE;
    var values: [4]api.settings_mod.HealthCheck = undefined;
    var count: usize = 0;
    if (checks & t.HEGEL_HC_FILTER_TOO_MUCH != 0) {
        values[count] = .filter_too_much;
        count += 1;
    }
    if (checks & t.HEGEL_HC_TOO_SLOW != 0) {
        values[count] = .too_slow;
        count += 1;
    }
    if (checks & t.HEGEL_HC_TEST_CASES_TOO_LARGE != 0) {
        values[count] = .test_cases_too_large;
        count += 1;
    }
    if (checks & t.HEGEL_HC_LARGE_INITIAL_TEST_CASE != 0) {
        values[count] = .large_initial_test_case;
        count += 1;
    }
    const owned = gpa.dupe(api.settings_mod.HealthCheck, values[0..count]) catch |err| return api.internal(ctx, err);
    gpa.free(h.inner.suppress_health_check);
    h.inner.suppress_health_check = owned;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_suppress_health_check(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c]u32) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_suppress_health_check") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_suppress_health_check: out parameter is null", .{});
    var mask: u32 = 0;
    for (h.inner.suppress_health_check) |value| mask |= switch (value) {
        .filter_too_much => t.HEGEL_HC_FILTER_TOO_MUCH,
        .too_slow => t.HEGEL_HC_TOO_SLOW,
        .test_cases_too_large => t.HEGEL_HC_TEST_CASES_TOO_LARGE,
        .large_initial_test_case => t.HEGEL_HC_LARGE_INITIAL_TEST_CASE,
    };
    out.* = mask;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_free(ctx: ?*HegelContext, s: ?*HegelSettings) c_int {
    api.clearLastError(ctx);
    if (s) |h| h.destroy();
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_seed(ctx: ?*HegelContext, s: ?*HegelSettings, seed: u64, has_seed: bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_seed") orelse return t.HEGEL_E_INVALID_HANDLE;
    h.inner.seed = if (has_seed) seed else null;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_seed(ctx: ?*HegelContext, s: ?*const HegelSettings, out_seed: [*c]u64, out_has_seed: [*c]bool) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_seed") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out_seed == null or out_has_seed == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_seed: out parameter is null", .{});
    out_seed.* = h.inner.seed orelse 0;
    out_has_seed.* = h.inner.seed != null;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_database(ctx: ?*HegelContext, s: ?*HegelSettings, database: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_database") orelse return t.HEGEL_E_INVALID_HANDLE;
    const text = if (database != null) api.utf8(database) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_set_database: path is not valid UTF-8", .{}) else null;
    const owned = if (text) |path| gpa.dupeSentinel(u8, path, 0) catch |err| return api.internal(ctx, err) else null;
    const path_copy = if (text) |path| if (path.len > 0) gpa.dupe(u8, path) catch |err| {
        if (owned) |o| gpa.free(o);
        return api.internal(ctx, err);
    } else null else null;
    if (h.inner.database == .path) gpa.free(h.inner.database.path);
    if (h.database_c) |o| gpa.free(o);
    h.database_c = owned;
    h.inner.database = if (path_copy) |path| .{ .path = path } else if (text != null) .disabled else .unset;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_get_database(ctx: ?*HegelContext, s: ?*const HegelSettings, out: [*c][*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_get_database") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_get_database: out parameter is null", .{});
    out.* = if (h.database_c) |db| db.ptr else null;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_database_key(ctx: ?*HegelContext, s: ?*HegelSettings, key: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_database_key") orelse return t.HEGEL_E_INVALID_HANDLE;
    const text = if (key != null) api.utf8(key) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_set_database_key: key is not valid UTF-8", .{}) else null;
    const owned = if (text) |k| gpa.dupe(u8, k) catch |err| return api.internal(ctx, err) else null;
    if (h.database_key) |old| gpa.free(old);
    h.database_key = owned;
    return t.HEGEL_OK;
}
pub export fn hegel_settings_set_test_location(ctx: ?*HegelContext, s: ?*HegelSettings, file: [*c]const u8, begin_line: u32, class_name: [*c]const u8, function: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = handle(ctx, s, "hegel_settings_set_test_location") orelse return t.HEGEL_E_INVALID_HANDLE;
    const name = "hegel_settings_set_test_location";
    const file_text = requiredString(ctx, name, "file", file);
    const class_text = requiredString(ctx, name, "class_name", class_name);
    const function_text = requiredString(ctx, name, "function", function);
    if (file_text == null or class_text == null or function_text == null) return t.HEGEL_E_INVALID_ARG;
    const location = copyLocation(file_text.?, begin_line, class_text.?, function_text.?) catch |err| return api.internal(ctx, err);
    if (h.test_location) |*old| old.deinit();
    h.test_location = location;
    return t.HEGEL_OK;
}
fn copyLocation(file: []const u8, line: u32, class: []const u8, function: []const u8) !api.TestLocation {
    const f = try gpa.dupe(u8, file);
    errdefer gpa.free(f);
    const c = try gpa.dupe(u8, class);
    errdefer gpa.free(c);
    return .{ .file = f, .begin_line = line, .class_name = c, .function = try gpa.dupe(u8, function) };
}
fn requiredString(ctx: ?*HegelContext, comptime name: []const u8, comptime arg: []const u8, p: [*c]const u8) ?[]const u8 {
    if (p == null) {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": " ++ arg ++ " is null", .{});
        return null;
    }
    return api.utf8(p) orelse {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": " ++ arg ++ " is not valid UTF-8", .{});
        return null;
    };
}
const profiles = @import("../profiles.zig");
const config_mod = @import("../config.zig");
var profiles_mutex: api.Mutex = .{};
var registry: std.ArrayList(profiles.NamedProfile) = .empty;
var registry_settings: std.ArrayList(api.settings_mod.Settings) = .empty;
var default_override: ?[]u8 = null;
var config_initialized = false;
var cached_config: ?config_mod.OwnedConfig = null;
var cached_config_error: ?anyerror = null;
var cached_config_diagnostic: config_mod.Diagnostic = .{};
extern "c" fn getenv(name: [*:0]const u8) ?[*:0]const u8;
fn environmentGet(_: ?*anyopaque, name: []const u8) ?[]const u8 {
    var buffer: [256]u8 = undefined;
    if (name.len >= buffer.len) return null;
    @memcpy(buffer[0..name.len], name);
    buffer[name.len] = 0;
    const p = getenv(buffer[0..name.len :0]) orelse return null;
    const value = std.mem.span(p);
    return if (std.unicode.utf8ValidateSlice(value)) value else null;
}
pub const environment: api.settings_mod.Environment = .{ .context = null, .get = environmentGet };
fn settingsFor(name: ?[]const u8, diagnostic: *?[]u8) !*HegelSettings {
    profiles_mutex.lock();
    defer profiles_mutex.unlock();
    if (!config_initialized) {
        cached_config = config_mod.loadDetailed(gpa, api.io(), environment, null, &cached_config_diagnostic) catch |err| blk: {
            cached_config_error = err;
            break :blk null;
        };
        config_initialized = true;
    }
    if (cached_config_error) |err| return err;
    const settings = profiles.settingsFor(gpa, name, cached_config.?.view(), registry.items, default_override, environment) catch |err| {
        if (err != error.OutOfMemory) diagnostic.* = try diagnoseProfiles(cached_config.?.view(), name);
        return err;
    };
    return HegelSettings.create(settings);
}
fn newSettings(ctx: ?*HegelContext, name: ?[]const u8, out: [*c]?*HegelSettings, comptime function: []const u8) c_int {
    api.clearLastError(ctx);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": out parameter is null", .{});
    var diagnostic: ?[]u8 = null;
    defer if (diagnostic) |message| gpa.free(message);
    out.* = settingsFor(name, &diagnostic) catch |err| {
        if (diagnostic) |message| return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}", .{message});
        if (cached_config_error != null) {
            const d = &cached_config_diagnostic;
            if (d.message) |message| {
                if (d.path) |path| {
                    if (d.line > 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}:{d}: {s}", .{ path, d.line, message });
                    return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}: {s}", .{ path, message });
                }
                return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}", .{message});
            }
        }
        return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}", .{@errorName(err)});
    };
    return t.HEGEL_OK;
}
pub export fn hegel_settings_new(ctx: ?*HegelContext, out_settings: [*c]?*HegelSettings) c_int {
    return newSettings(ctx, null, out_settings, "hegel_settings_new");
}
pub export fn hegel_settings_new_for_profile(ctx: ?*HegelContext, name: [*c]const u8, out_settings: [*c]?*HegelSettings) c_int {
    api.clearLastError(ctx);
    const text = requiredString(ctx, "hegel_settings_new_for_profile", "name", name) orelse return t.HEGEL_E_INVALID_ARG;
    return newSettings(ctx, text, out_settings, "hegel_settings_new_for_profile");
}
pub export fn hegel_settings_register_profile(ctx: ?*HegelContext, name: [*c]const u8, settings: ?*const HegelSettings) c_int {
    api.clearLastError(ctx);
    const text = requiredString(ctx, "hegel_settings_register_profile", "name", name) orelse return t.HEGEL_E_INVALID_ARG;
    const h = handle(ctx, settings, "hegel_settings_register_profile") orelse return t.HEGEL_E_INVALID_HANDLE;
    if (!profiles.validName(text)) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_register_profile: invalid profile name \"{s}\": profile names use only ASCII letters, digits, '-' and '_'", .{text});
    if (std.mem.eql(u8, text, "base") or std.mem.eql(u8, text, "default")) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_settings_register_profile: cannot register reserved profile name \"{s}\"", .{text});
    registerProfile(text, h.inner) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
fn registerProfile(name: []const u8, settings: api.settings_mod.Settings) !void {
    profiles_mutex.lock();
    defer profiles_mutex.unlock();
    var copy = try settings.deepClone(gpa);
    errdefer copy.deinitOwned(gpa);
    for (registry.items, 0..) |*entry, i| if (std.mem.eql(u8, entry.name, name)) {
        registry_settings.items[i].deinitOwned(gpa);
        registry_settings.items[i] = copy;
        entry.delta = profiles.ProfileDelta.snapshot(copy);
        return;
    };
    const owned = try gpa.dupe(u8, name);
    errdefer gpa.free(owned);
    try registry.ensureUnusedCapacity(gpa, 1);
    try registry_settings.ensureUnusedCapacity(gpa, 1);
    registry.appendAssumeCapacity(.{ .name = owned, .delta = profiles.ProfileDelta.snapshot(copy) });
    registry_settings.appendAssumeCapacity(copy);
}
pub export fn hegel_set_default_profile(ctx: ?*HegelContext, name: [*c]const u8) c_int {
    api.clearLastError(ctx);
    const text = if (name != null) requiredString(ctx, "hegel_set_default_profile", "name", name) orelse return t.HEGEL_E_INVALID_ARG else null;
    if (text) |value| {
        if (!profiles.validName(value)) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_set_default_profile: invalid profile name \"{s}\": profile names use only ASCII letters, digits, '-' and '_'", .{value});
        if (std.mem.eql(u8, value, "default")) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_set_default_profile: hegel_set_default_profile cannot name the \"default\" alias it resolves", .{});
    }
    const owned = if (text) |value| gpa.dupe(u8, value) catch |err| return api.internal(ctx, err) else null;
    profiles_mutex.lock();
    defer profiles_mutex.unlock();
    if (default_override) |old| gpa.free(old);
    default_override = owned;
    return t.HEGEL_OK;
}
fn hasName(names: []const []const u8, name: []const u8) bool {
    for (names) |n| if (std.mem.eql(u8, n, name)) return true;
    return false;
}
fn profileLookup(entries: []const profiles.NamedProfile, name: []const u8) ?*const profiles.ProfileDelta {
    for (entries) |*entry| if (std.mem.eql(u8, entry.name, name)) return &entry.delta;
    return null;
}
fn joinNames(names: []const []const u8, separator: []const u8) ![]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(gpa);
    for (names, 0..) |name, i| {
        if (i > 0) try out.appendSlice(gpa, separator);
        try out.appendSlice(gpa, name);
    }
    return out.toOwnedSlice(gpa);
}
fn knownNames(config: profiles.Config) ![]u8 {
    var names: std.ArrayList([]const u8) = .empty;
    defer names.deinit(gpa);
    try names.appendSlice(gpa, &.{ "base", "ci", "development", "workload" });
    for (config.profiles) |profile| if (!hasName(names.items, profile.name)) try names.append(gpa, profile.name);
    for (registry.items) |profile| if (!hasName(names.items, profile.name)) try names.append(gpa, profile.name);
    std.mem.sort([]const u8, names.items, {}, struct {
        fn less(_: void, a: []const u8, b: []const u8) bool {
            return std.mem.order(u8, a, b) == .lt;
        }
    }.less);
    return joinNames(names.items, ", ");
}
const Arrival = union(enum) { requested, default: []const u8, extends: []const u8 };
fn diagnoseChain(config: profiles.Config, candidates: profiles.Candidates, name: []const u8, initial_arrival: Arrival) !?[]u8 {
    var chain: std.ArrayList([]const u8) = .empty;
    defer chain.deinit(gpa);
    var current = name;
    var arrival = initial_arrival;
    while (true) {
        if (std.mem.eql(u8, current, "default")) {
            const source: []const u8 = if (candidates.overridden != null) "hegel_set_default_profile" else if (candidates.env != null) "HEGEL_DEFAULT_PROFILE" else "the default entry in hegel.toml";
            const named = candidates.overridden orelse candidates.env orelse candidates.toml;
            if (named) |value| {
                if (std.mem.eql(u8, value, "default")) return try std.fmt.allocPrint(gpa, "{s} cannot name the \"default\" alias it resolves", .{source});
                if (!hasName(chain.items, value)) {
                    current = value;
                    arrival = .{ .default = source };
                    continue;
                }
            }
            current = if (!hasName(chain.items, candidates.environment)) candidates.environment else "base";
            continue;
        }
        if (std.mem.eql(u8, current, "base")) return null;
        if (hasName(chain.items, current)) {
            try chain.append(gpa, current);
            const joined = try joinNames(chain.items, " -> ");
            defer gpa.free(joined);
            return try std.fmt.allocPrint(gpa, "profile extends cycle: {s}", .{joined});
        }
        try chain.append(gpa, current);
        const cfg = profileLookup(config.profiles, current);
        const registered = profileLookup(registry.items, current);
        const shipped = hasName(&.{ "ci", "development", "workload" }, current);
        if (cfg == null and registered == null and !shipped) {
            const quoted = try @import("../draws/text.zig").debugString(gpa, current);
            defer gpa.free(quoted);
            switch (arrival) {
                .extends => |parent| {
                    const qparent = try @import("../draws/text.zig").debugString(gpa, parent);
                    defer gpa.free(qparent);
                    return try std.fmt.allocPrint(gpa, "profile {s} extends unknown profile {s}", .{ qparent, quoted });
                },
                else => {
                    const known = try knownNames(config);
                    defer gpa.free(known);
                    return if (arrival == .default) try std.fmt.allocPrint(gpa, "unknown settings profile {s} (named by {s}); known profiles: {s}", .{ quoted, arrival.default, known }) else try std.fmt.allocPrint(gpa, "unknown settings profile {s}; known profiles: {s}", .{ quoted, known });
                },
            }
        }
        if (registered != null) {
            if (cfg != null and cfg.?.extends != null) {
                const quoted = try @import("../draws/text.zig").debugString(gpa, current);
                defer gpa.free(quoted);
                return try std.fmt.allocPrint(gpa, "cannot set extends on registered profile {s}: a registered profile is a complete snapshot", .{quoted});
            }
            return null;
        }
        if (cfg != null and cfg.?.extends != null) {
            arrival = .{ .extends = current };
            current = cfg.?.extends.?;
        } else current = if (shipped) "base" else "default";
    }
}
fn parsedU64(value: []const u8) ?u64 {
    if (value.len == 0) return null;
    const digits = if (value[0] == '+') value[1..] else value;
    if (digits.len == 0) return null;
    for (digits) |digit| if (digit < '0' or digit > '9') return null;
    return std.fmt.parseInt(u64, digits, 10) catch null;
}
fn diagnoseProfiles(config: profiles.Config, name: ?[]const u8) !?[]u8 {
    const candidates = profiles.Candidates.gather(config, default_override, environment);
    const structural: profiles.Candidates = .{ .toml = candidates.toml, .environment = candidates.environment };
    for (config.profiles) |profile| if (try diagnoseChain(config, structural, profile.name, .requested)) |message| return message;
    if (config.default) |value| if (try diagnoseChain(config, structural, value, .{ .default = "the default entry in hegel.toml" })) |message| return message;
    if (try diagnoseChain(config, candidates, name orelse "default", .requested)) |message| return message;
    const keys = [_][]const u8{ "HEGEL_TEST_CASES", "HEGEL_SEED", "HEGEL_DERANDOMIZE", "HEGEL_PRINT_BLOB", "HEGEL_NONDETERMINISM_STRICTNESS" };
    for (keys, 0..) |key, i| if (environment.value(key)) |value| {
        const reason: ?[]const u8 = switch (i) {
            0 => if (parsedU64(value) == null or parsedU64(value).? == 0) "a positive integer" else null,
            1 => if (!std.mem.eql(u8, value, "none") and parsedU64(value) == null) "an integer or 'none'" else null,
            2, 3 => if (api.settings_mod.parseBool(value) == null) "true or false" else null,
            4 => if (api.settings_mod.NondeterminismStrictness.parse(value) == null) "quiet, warn or error" else null,
            else => unreachable,
        };
        if (reason) |text| {
            const quoted = try @import("../draws/text.zig").debugString(gpa, value);
            defer gpa.free(quoted);
            return try std.fmt.allocPrint(gpa, "{s} must be {s}, got {s}", .{ key, text, quoted });
        }
    };
    return null;
}

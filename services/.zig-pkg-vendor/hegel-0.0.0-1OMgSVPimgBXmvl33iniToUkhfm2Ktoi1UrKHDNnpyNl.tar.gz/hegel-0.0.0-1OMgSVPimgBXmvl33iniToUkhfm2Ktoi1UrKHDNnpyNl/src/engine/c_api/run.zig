// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("../c_api.zig");
const t = api.types;
const gpa = api.gpa;
const Ctx = api.HegelContext;
const Tc = api.HegelTestCase;
const native_runner = @import("../test_runner.zig");
const blob_mod = @import("../blob.zig");
pub const HegelFailure = struct {
    origin: [:0]u8,
    reproduce_blob: ?[:0]u8,
    caveat: ?[:0]u8,
    fn copy(source: HegelFailure) !HegelFailure {
        return fromSlices(source.origin, source.reproduce_blob, source.caveat);
    }
    fn fromSlices(origin: []const u8, blob: ?[]const u8, caveat: ?[]const u8) !HegelFailure {
        const o = try api.cstringLossy(origin);
        errdefer gpa.free(o);
        const b = if (blob) |s| try api.cstringLossy(s) else null;
        errdefer if (b) |s| gpa.free(s);
        return .{ .origin = o, .reproduce_blob = b, .caveat = if (caveat) |s| try api.cstringLossy(s) else null };
    }
    fn deinit(self: *HegelFailure) void {
        gpa.free(self.origin);
        if (self.reproduce_blob) |s| gpa.free(s);
        if (self.caveat) |s| gpa.free(s);
    }
};
pub const HegelRunResult = struct {
    failures: []HegelFailure,
    message: ?[:0]u8 = null,
    fn fromNative(source: native_runner.TestRunResult) !HegelRunResult {
        const failures = try gpa.alloc(HegelFailure, source.failures.len);
        var count: usize = 0;
        errdefer {
            for (failures[0..count]) |*f| f.deinit();
            gpa.free(failures);
        }
        for (source.failures, failures) |failure, *dest| {
            dest.* = try HegelFailure.fromSlices(failure.origin, failure.reproduce_blob, failure.caveat);
            count += 1;
        }
        return .{ .failures = failures };
    }
    fn fromError(message: []const u8) !HegelRunResult {
        return .{ .failures = &.{}, .message = try api.cstringLossy(message) };
    }
    fn copy(self: *const HegelRunResult) !HegelRunResult {
        const failures = try gpa.alloc(HegelFailure, self.failures.len);
        var count: usize = 0;
        errdefer {
            for (failures[0..count]) |*f| f.deinit();
            gpa.free(failures);
        }
        for (self.failures, failures) |failure, *dest| {
            dest.* = try failure.copy();
            count += 1;
        }
        return .{ .failures = failures, .message = if (self.message) |s| try gpa.dupeSentinel(u8, s, 0) else null };
    }
    fn deinit(self: *HegelRunResult) void {
        for (self.failures) |*failure| failure.deinit();
        gpa.free(self.failures);
        if (self.message) |m| gpa.free(m);
    }
    fn status(self: *const HegelRunResult) c_uint {
        return if (self.message != null) t.HEGEL_RUN_STATUS_ERROR else if (self.failures.len == 0) t.HEGEL_RUN_STATUS_PASSED else t.HEGEL_RUN_STATUS_FAILED;
    }
};
pub const HegelRun = struct {
    settings: api.settings_mod.Settings,
    key: ?[]u8,
    location: ?api.TestLocation = null,
    blob: ?[]u8,
    callback: t.hegel_output_callback_t,
    user_data: ?*anyopaque,
    thread: ?std.Thread = null,
    output_mutex: api.Mutex = .{},
    output_lines: std.ArrayList([:0]u8) = .empty,
    stage: std.atomic.Value(Stage) = .init(.idle),
    cancelled: std.atomic.Value(bool) = .init(false),
    offered: ?*api.state.NativeTestCaseHandle = null,
    current_family: ?*api.FamilyShared = null,
    result: ?HegelRunResult = null,
    const Stage = enum(u8) { idle, offered, resumed, finished };
    fn emit(ctx: ?*anyopaque, line: []const u8) void {
        const self: *HegelRun = @ptrCast(@alignCast(ctx.?));
        if (self.cancelled.load(.acquire)) return;
        const text = api.cstringLossy(line) catch return;
        self.output_mutex.lock();
        defer self.output_mutex.unlock();
        self.output_lines.append(gpa, text) catch gpa.free(text);
    }
    fn flushOutput(self: *HegelRun) void {
        self.output_mutex.lock();
        const lines = self.output_lines;
        self.output_lines = .empty;
        self.output_mutex.unlock();
        var owned = lines;
        defer owned.deinit(gpa);
        for (owned.items) |line| {
            defer gpa.free(line);
            if (self.callback) |callback| callback(self.user_data, @ptrCast(line.ptr), line.len) else (api.settings_mod.Output{}).line(api.io(), line);
        }
    }
    fn executor(ctx: *anyopaque, handle: *api.state.NativeTestCaseHandle) anyerror!void {
        const self: *HegelRun = @ptrCast(@alignCast(ctx));
        if (self.cancelled.load(.acquire)) return error.Cancelled;
        self.offered = handle;
        self.stage.store(.offered, .release);
        while (self.stage.load(.acquire) == .offered) {
            if (self.cancelled.load(.acquire)) return error.Cancelled;
            std.Thread.yield() catch {};
        }
        if (self.cancelled.load(.acquire)) return error.Cancelled;
    }
    fn work(self: *HegelRun) void {
        self.workFallible() catch |err| {
            if (!self.cancelled.load(.acquire)) self.result = HegelRunResult.fromError(@errorName(err)) catch null;
        };
        if (!self.cancelled.load(.acquire)) if (self.location) |location| {
            const passed = if (self.result) |*result| result.status() == t.HEGEL_RUN_STATUS_PASSED else false;
            @import("../antithesis.zig").report(gpa, api.io(), api.settings_api.environment, location.view(), passed, .{ .context = self, .callback = emit }) catch {};
        };
        self.stage.store(.finished, .release);
    }
    fn workFallible(self: *HegelRun) !void {
        const engine = try native_runner.Engine.create(gpa, api.io(), self.settings, self.key, .{ .context = self, .call = executor });
        defer engine.deinit();
        var result = (if (self.blob) |blob| engine.runBlob(blob) else engine.run()) catch |err| {
            if (self.cancelled.load(.acquire)) return;
            self.result = try HegelRunResult.fromError(engine.diagnostic orelse @errorName(err));
            return;
        };
        defer result.deinit(gpa);
        self.result = try HegelRunResult.fromNative(result);
    }
    fn destroy(self: *HegelRun) void {
        if (self.current_family) |family| family.complete(.valid, null) catch {};
        self.cancelled.store(true, .release);
        self.stage.store(.resumed, .release);
        if (self.thread) |thread| thread.join();
        if (self.current_family) |family| family.release();
        if (self.result) |*r| r.deinit();
        for (self.output_lines.items) |line| gpa.free(line);
        self.output_lines.deinit(gpa);
        self.settings.deinitOwned(gpa);
        if (self.location) |*location| location.deinit();
        if (self.key) |key| gpa.free(key);
        if (self.blob) |blob| gpa.free(blob);
        gpa.destroy(self);
    }
};
fn createRun(settings: *const api.HegelSettings, blob: ?[]const u8, callback: t.hegel_output_callback_t, user_data: ?*anyopaque) !*HegelRun {
    var owned = try settings.inner.deepClone(gpa);
    errdefer owned.deinitOwned(gpa);
    const key = if (settings.database_key) |key| try gpa.dupe(u8, key) else null;
    errdefer if (key) |k| gpa.free(k);
    const raw = if (blob) |b| try gpa.dupe(u8, b) else null;
    errdefer if (raw) |b| gpa.free(b);
    var location = if (settings.test_location) |loc| try loc.deepClone() else null;
    errdefer if (location) |*loc| loc.deinit();
    const run = try gpa.create(HegelRun);
    run.* = .{ .settings = owned, .key = key, .blob = raw, .callback = callback, .user_data = user_data, .location = location };
    run.settings.output = .{ .context = run, .callback = HegelRun.emit };
    return run;
}
pub export fn hegel_run_start(ctx: ?*Ctx, settings: ?*const api.HegelSettings, callback: t.hegel_output_callback_t, user_data: ?*anyopaque, out_run: [*c]?*HegelRun) c_int {
    api.clearLastError(ctx);
    if (out_run == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_start: out parameter is null", .{});
    if (checkEnvironment(ctx, "hegel_run_start")) |rc| return rc;
    const h = settings orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_start: settings pointer is null", .{});
    out_run.* = createRun(h, null, callback, user_data) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_run_start_blob(ctx: ?*Ctx, settings: ?*const api.HegelSettings, blob: [*c]const u8, callback: t.hegel_output_callback_t, user_data: ?*anyopaque, out_run: [*c]?*HegelRun) c_int {
    api.clearLastError(ctx);
    if (out_run == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_start_blob: out parameter is null", .{});
    const h = settings orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_start_blob: settings pointer is null", .{});
    if (blob == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_start_blob: blob pointer is null", .{});
    const text = api.utf8(blob) orelse return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_start_blob: blob is not valid UTF-8", .{});
    if (checkEnvironment(ctx, "hegel_run_start_blob")) |rc| return rc;
    var decoded = blob_mod.decodeBlob(gpa, text) catch |err| return api.internal(ctx, err);
    if (decoded) |*d| d.deinit(gpa) else return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_start_blob: the supplied failure blob could not be decoded. It may be corrupt or from an incompatible Hegel version.", .{});
    out_run.* = createRun(h, text, callback, user_data) catch |err| return api.internal(ctx, err);
    return t.HEGEL_OK;
}
pub export fn hegel_next_test_case(ctx: ?*Ctx, run: ?*HegelRun, out_test_case: [*c]?*Tc) c_int {
    api.clearLastError(ctx);
    const self = run orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_next_test_case: run pointer is null", .{});
    if (out_test_case == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_next_test_case: out parameter is null", .{});
    out_test_case.* = null;
    if (self.current_family) |family| {
        if (!family.completed.load(.acquire)) return api.fail(ctx, t.HEGEL_E_NOT_COMPLETE, "hegel_next_test_case: previous test case was not marked complete (call hegel_mark_complete before requesting the next case)", .{});
        family.release();
        self.current_family = null;
        self.stage.store(.resumed, .release);
    }
    if (self.thread == null) self.thread = std.Thread.spawn(.{}, HegelRun.work, .{self}) catch |err| return api.internal(ctx, err);
    while (true) {
        self.flushOutput();
        switch (self.stage.load(.acquire)) {
            .finished => {
                self.flushOutput();
                return t.HEGEL_OK;
            },
            .offered => {
                const offered = self.offered.?;
                var source = api.data_source.NativeDataSource.fromHandle(offered.retain());
                const shared = api.SourceShared.create(source) catch |err| {
                    source.deinit();
                    return api.internal(ctx, err);
                };
                defer shared.release();
                const family = api.FamilyShared.create(shared) catch |err| return api.internal(ctx, err);
                const tc = Tc.create(family, shared, .main, -1) catch |err| {
                    family.release();
                    return api.internal(ctx, err);
                };
                self.current_family = family;
                self.offered = null;
                out_test_case.* = tc;
                return t.HEGEL_OK;
            },
            else => std.Thread.yield() catch {},
        }
    }
}
pub export fn hegel_run_free(ctx: ?*Ctx, run: ?*HegelRun) c_int {
    api.clearLastError(ctx);
    if (run) |h| h.destroy();
    return t.HEGEL_OK;
}
pub export fn hegel_run_result(ctx: ?*Ctx, run: ?*HegelRun, out_result: [*c]?*HegelRunResult) c_int {
    api.clearLastError(ctx);
    const h = run orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_result: run pointer is null", .{});
    if (out_result == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result: out parameter is null", .{});
    out_result.* = null;
    if (h.stage.load(.acquire) != .finished) return api.fail(ctx, t.HEGEL_E_NOT_COMPLETE, "hegel_run_result: run has not finished yet", .{});
    const r = if (h.result) |*r| r else return api.internal(ctx, error.OutOfMemory);
    const result = gpa.create(HegelRunResult) catch |err| return api.internal(ctx, err);
    result.* = r.copy() catch |err| {
        gpa.destroy(result);
        return api.internal(ctx, err);
    };
    out_result.* = result;
    return t.HEGEL_OK;
}
pub export fn hegel_run_result_free(ctx: ?*Ctx, result: ?*HegelRunResult) c_int {
    api.clearLastError(ctx);
    if (result) |r| {
        r.deinit();
        gpa.destroy(r);
    }
    return t.HEGEL_OK;
}
pub export fn hegel_failure_free(ctx: ?*Ctx, failure: ?*HegelFailure) c_int {
    api.clearLastError(ctx);
    if (failure) |f| {
        f.deinit();
        gpa.destroy(f);
    }
    return t.HEGEL_OK;
}
pub export fn hegel_run_result_status(ctx: ?*Ctx, r: ?*const HegelRunResult, out_status: [*c]c_uint) c_int {
    api.clearLastError(ctx);
    const h = r orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_result_status: result pointer is null", .{});
    if (out_status == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result_status: out parameter is null", .{});
    out_status.* = h.status();
    return t.HEGEL_OK;
}
pub export fn hegel_run_result_error(ctx: ?*Ctx, r: ?*const HegelRunResult, out_error: [*c][*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = r orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_result_error: result pointer is null", .{});
    if (out_error == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result_error: out parameter is null", .{});
    out_error.* = if (h.message) |m| m.ptr else null;
    return t.HEGEL_OK;
}
pub export fn hegel_run_result_failure_count(ctx: ?*Ctx, r: ?*const HegelRunResult, out_count: [*c]usize) c_int {
    api.clearLastError(ctx);
    const h = r orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_result_failure_count: result pointer is null", .{});
    if (out_count == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result_failure_count: out parameter is null", .{});
    out_count.* = h.failures.len;
    return t.HEGEL_OK;
}
pub export fn hegel_run_result_failure(ctx: ?*Ctx, r: ?*const HegelRunResult, index: usize, out_failure: [*c]?*HegelFailure) c_int {
    api.clearLastError(ctx);
    const h = r orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_run_result_failure: result pointer is null", .{});
    if (out_failure == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result_failure: out parameter is null", .{});
    out_failure.* = null;
    if (index >= h.failures.len) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_run_result_failure: index {d} is out of range (the result has {d} failures)", .{ index, h.failures.len });
    const f = gpa.create(HegelFailure) catch |err| return api.internal(ctx, err);
    f.* = h.failures[index].copy() catch |err| {
        gpa.destroy(f);
        return api.internal(ctx, err);
    };
    out_failure.* = f;
    return t.HEGEL_OK;
}
pub export fn hegel_failure_origin(ctx: ?*Ctx, f: ?*const HegelFailure, out_value: [*c][*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = f orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_failure_origin: failure pointer is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_failure_origin: out parameter is null", .{});
    out_value.* = h.origin.ptr;
    return t.HEGEL_OK;
}
pub export fn hegel_failure_reproduction_blob(ctx: ?*Ctx, f: ?*const HegelFailure, out_value: [*c][*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = f orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_failure_reproduction_blob: failure pointer is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_failure_reproduction_blob: out parameter is null", .{});
    out_value.* = if (h.reproduce_blob) |text| text.ptr else null;
    return t.HEGEL_OK;
}
pub export fn hegel_failure_caveat(ctx: ?*Ctx, f: ?*const HegelFailure, out_value: [*c][*c]const u8) c_int {
    api.clearLastError(ctx);
    const h = f orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_failure_caveat: failure pointer is null", .{});
    if (out_value == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_failure_caveat: out parameter is null", .{});
    out_value.* = if (h.caveat) |text| text.ptr else null;
    return t.HEGEL_OK;
}

fn checkEnvironment(ctx: ?*Ctx, comptime function: []const u8) ?c_int {
    const message = @import("../antithesis.zig").checkEnvironment(gpa, api.io(), api.settings_api.environment) catch |err| return api.internal(ctx, err);
    if (message) |text| {
        defer gpa.free(text);
        return api.fail(ctx, t.HEGEL_E_INVALID_ARG, function ++ ": {s}", .{text});
    }
    return null;
}

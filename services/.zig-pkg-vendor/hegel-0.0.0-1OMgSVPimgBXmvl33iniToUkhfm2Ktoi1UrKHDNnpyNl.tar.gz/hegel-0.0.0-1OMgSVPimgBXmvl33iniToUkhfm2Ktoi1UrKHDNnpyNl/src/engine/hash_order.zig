// SPDX-License-Identifier: MIT
// Insertion/iteration compatibility for hashbrown 0.17.1 and rustc-hash 2.1.2.
// Copyright (c) 2016 Amanieu d'Antras. See LICENSES/{Hashbrown,Rustc-Hash}-MIT.txt.
const std = @import("std");
const builtin = @import("builtin");
const Allocator = std.mem.Allocator;
const native_group_width: usize = if ((builtin.cpu.arch == .x86_64 or builtin.cpu.arch == .x86) and std.Target.x86.featureSetHas(builtin.cpu.features, .sse2)) 16 else @sizeOf(usize);
pub fn hashU64(value: u64) usize {
    if (@sizeOf(usize) == 8) return std.math.rotl(usize, @as(usize, @intCast(value)) *% 0xf1357aea2e62a9c5, 26);
    var result: usize = @as(usize, @truncate(value)) *% 0x93d765dd;
    result = (result +% @as(usize, @truncate(value >> 32))) *% 0x93d765dd;
    return std.math.rotl(usize, result, 15);
}
const Table = struct {
    slots: []?usize,
    control: []bool,
    group_width: usize,
    fn init(gpa: Allocator, count: usize, group_width: usize) !Table {
        const slots = try gpa.alloc(?usize, count);
        errdefer gpa.free(slots);
        @memset(slots, null);
        const control = try gpa.alloc(bool, count + group_width);
        @memset(control, false);
        return .{ .slots = slots, .control = control, .group_width = group_width };
    }
    fn deinit(self: Table, gpa: Allocator) void {
        gpa.free(self.slots);
        gpa.free(self.control);
    }
    fn insert(self: *Table, index: usize, hash: usize) void {
        const mask = self.slots.len - 1;
        const group_width = self.group_width;
        var position = hash & mask;
        var stride: usize = 0;
        while (true) {
            for (0..group_width) |offset| if (!self.control[position + offset]) {
                var slot = (position + offset) & mask;
                if (self.slots[slot] != null) {
                    slot = 0;
                    while (self.slots[slot] != null) slot += 1;
                }
                self.slots[slot] = index;
                self.control[slot] = true;
                self.control[((slot -% group_width) & mask) + group_width] = true;
                return;
            };
            stride += group_width;
            position = (position + stride) & mask;
        }
    }
};
pub fn u64MapOrder(gpa: Allocator, keys: []const u64) ![]usize {
    return u64MapOrderWithGroup(gpa, keys, native_group_width);
}
pub fn u64MapOrderWithGroup(gpa: Allocator, keys: []const u64, group_width: usize) ![]usize {
    var table = try Table.init(gpa, 4, group_width);
    defer table.deinit(gpa);
    var count: usize = 0;
    for (keys, 0..) |key, index| {
        const capacity = if (table.slots.len < 8) table.slots.len - 1 else table.slots.len / 8 * 7;
        if (count == capacity) {
            var grown = try Table.init(gpa, table.slots.len * 2, group_width);
            for (table.slots) |slot| if (slot) |old| grown.insert(old, hashU64(keys[old]));
            table.deinit(gpa);
            table = grown;
        }
        table.insert(index, hashU64(key));
        count += 1;
    }
    const order = try gpa.alloc(usize, keys.len);
    var next: usize = 0;
    for (table.slots) |slot| if (slot) |index| {
        order[next] = index;
        next += 1;
    };
    return order;
}

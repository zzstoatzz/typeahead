// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
pub const Category = enum {
    Lu,
    Ll,
    Lt,
    Lm,
    Lo,
    Mn,
    Mc,
    Me,
    Nd,
    Nl,
    No,
    Pc,
    Pd,
    Ps,
    Pe,
    Pi,
    Pf,
    Po,
    Sm,
    Sc,
    Sk,
    So,
    Zs,
    Zl,
    Zp,
    Cc,
    Cf,
    Cs,
    Co,
    Cn,
    pub fn asStr(self: Category) []const u8 {
        return @tagName(self);
    }
    pub fn fromCode(code: []const u8) ?Category {
        return std.meta.stringToEnum(Category, code);
    }
};
const CategoryRun = struct { end: u32, category: Category };
const Base = struct { cp: u32, base: u32 };
fn lineCount(comptime data: []const u8) usize {
    @setEvalBranchQuota(3000000);
    return std.mem.count(u8, data, "\n");
}
fn categoryTable(comptime data: []const u8) [lineCount(data)]CategoryRun {
    @setEvalBranchQuota(3000000);
    var result: [lineCount(data)]CategoryRun = undefined;
    var lines = std.mem.splitScalar(u8, data, '\n');
    var i: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        const space = std.mem.indexOfScalar(u8, line, ' ').?;
        result[i] = .{ .end = std.fmt.parseInt(u32, line[0..space], 16) catch unreachable, .category = Category.fromCode(line[space + 1 ..]).? };
        i += 1;
    }
    return result;
}
fn baseTable(comptime data: []const u8) [lineCount(data)]Base {
    @setEvalBranchQuota(3000000);
    var result: [lineCount(data)]Base = undefined;
    var lines = std.mem.splitScalar(u8, data, '\n');
    var i: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        const space = std.mem.indexOfScalar(u8, line, ' ').?;
        result[i] = .{ .cp = std.fmt.parseInt(u32, line[0..space], 16) catch unreachable, .base = std.fmt.parseInt(u32, line[space + 1 ..], 16) catch unreachable };
        i += 1;
    }
    return result;
}
pub const ranges = categoryTable(@embedFile("unicode/categories.txt"));
pub const nfd_bases = baseTable(@embedFile("unicode/nfd_bases.txt"));
pub fn generalCategory(cp: u32) error{InternalError}!Category {
    if (cp > 0x10ffff) return error.InternalError;
    return categoryLookup(cp);
}
pub fn generalCategoryChar(cp: u21) Category {
    return categoryLookup(cp);
}
fn categoryLookup(cp: u32) Category {
    var lo: usize = 0;
    var hi: usize = ranges.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (ranges[mid].end < cp) lo = mid + 1 else hi = mid;
    }
    return ranges[lo].category;
}
pub fn groupMatches(category: []const u8, group: []const u8) bool {
    return switch (group.len) {
        2 => std.mem.eql(u8, category, group),
        1 => category[0] == group[0] and std.mem.indexOfScalar(u8, "LMNPSZC", group[0]) != null,
        else => false,
    };
}
pub fn isInGroup(cp: u32, group: []const u8) error{InternalError}!bool {
    return groupMatches((try generalCategory(cp)).asStr(), group);
}
pub fn isInGroupChar(cp: u21, group: []const u8) bool {
    return groupMatches(generalCategoryChar(cp).asStr(), group);
}
pub fn nfdBase(cp: u32) ?u32 {
    var lo: usize = 0;
    var hi: usize = nfd_bases.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (nfd_bases[mid].cp < cp) lo = mid + 1 else hi = mid;
    }
    return if (lo < nfd_bases.len and nfd_bases[lo].cp == cp) nfd_bases[lo].base else null;
}
test "Unicode source tables" {
    try std.testing.expectEqual(Category.Lu, try generalCategory('A'));
    try std.testing.expectEqual(Category.Cs, try generalCategory(0xd800));
    try std.testing.expectEqual(@as(?u32, 'A'), nfdBase(0x1fa));
    try std.testing.expectError(error.InternalError, generalCategory(0x110000));
}

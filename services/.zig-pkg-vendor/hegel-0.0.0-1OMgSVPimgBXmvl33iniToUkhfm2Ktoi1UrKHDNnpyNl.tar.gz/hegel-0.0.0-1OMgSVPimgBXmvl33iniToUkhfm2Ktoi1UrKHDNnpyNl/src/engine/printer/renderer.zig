// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/printer.rs; see provenance.
const std = @import("std");
const e = @import("engine.zig");
const Cmd = e.Cmd;
const Allocator = std.mem.Allocator;
const Group = struct { depth: usize, indent: usize, pending: usize = 0, want_break: bool = false, comment: bool = false };
const Token = union(enum) {
    text: struct { content: []const u8, width: usize },
    breakable: struct { sep: []const u8, width: usize, indent: isize, group: usize },
    if_break: struct { content: []const u8, group: usize },
    comment: []const u8,
    fn width(self: Token) usize {
        return switch (self) {
            .text => |v| v.width,
            .breakable => |v| v.width,
            else => 0,
        };
    }
};
fn width(s: []const u8) usize {
    return std.unicode.utf8CountCodepoints(s) catch unreachable;
}
fn trimStart(s: []const u8) []const u8 {
    var start: usize = 0;
    while (start < s.len) {
        const n = std.unicode.utf8ByteSequenceLength(s[start]) catch unreachable;
        const cp = std.unicode.utf8Decode(s[start .. start + n]) catch unreachable;
        if (!@import("../unicode_char.zig").isWhitespace(cp)) break;
        start += n;
    }
    return s[start..];
}
fn markCommentGroups(a: Allocator, slots: []const e.Slot, cmds: []const Cmd, force: *std.ArrayList(bool), stack: *std.ArrayList(usize)) Allocator.Error!void {
    for (cmds) |cmd| {
        switch (cmd) {
            .begin_group => {
                try force.append(a, false);
                try stack.append(a, force.items.len - 1);
            },
            .end_group => {
                _ = stack.pop();
            },
            .comment => {
                for (stack.items) |id| force.items[id] = true;
            },
            .splice => |id| try markCommentGroups(a, slots, slots[id].commands.items, force, stack),
            else => {},
        }
    }
}
pub fn render(printer: *e.Printer) e.Error![]u8 {
    const a = printer.arena.allocator();
    var force: std.ArrayList(bool) = .empty;
    try force.append(a, false);
    var stack: std.ArrayList(usize) = .empty;
    try markCommentGroups(a, printer.slots.items, printer.main.items, &force, &stack);
    var r = try Renderer.init(a, printer.max_width, printer.slots.items, force.items);
    try r.run(printer.main.items);
    try r.flush();
    try r.emitPendingPad();
    try r.out.appendSlice(a, r.pending_comments.items);
    return printer.allocator.dupe(u8, r.out.items);
}
const Renderer = struct {
    a: Allocator,
    max_width: usize,
    slots: []const e.Slot,
    force_break: []const bool,
    out: std.ArrayList(u8) = .empty,
    output_width: usize = 0,
    at_line_start: bool = true,
    pending_pad: ?isize = 0,
    block_indent: usize = 0,
    buffer: std.ArrayList(Token) = .empty,
    head: usize = 0,
    buffer_width: usize = 0,
    pending_comments: std.ArrayList(u8) = .empty,
    indentation: isize = 0,
    groups: std.ArrayList(Group) = .empty,
    group_stack: std.ArrayList(usize) = .empty,
    group_queue: std.ArrayList(std.ArrayList(usize)) = .empty,
    const Self = @This();
    fn init(a: Allocator, max_width: usize, slots: []const e.Slot, force: []const bool) !Self {
        var r = Self{ .a = a, .max_width = max_width, .slots = slots, .force_break = force };
        try r.groups.append(a, .{ .depth = 0, .indent = 0 });
        try r.group_stack.append(a, 0);
        var level: std.ArrayList(usize) = .empty;
        try level.append(a, 0);
        try r.group_queue.append(a, level);
        return r;
    }
    fn empty(self: *const Self) bool {
        return self.head == self.buffer.items.len;
    }
    fn pop(self: *Self) ?Token {
        if (self.empty()) return null;
        const token = self.buffer.items[self.head];
        self.head += 1;
        if (self.empty()) {
            self.buffer.clearRetainingCapacity();
            self.head = 0;
        }
        return token;
    }
    fn run(self: *Self, cmds: []const Cmd) e.Error!void {
        for (cmds) |cmd| try self.execute(cmd);
    }
    fn execute(self: *Self, cmd: Cmd) e.Error!void {
        switch (cmd) {
            .text => |s| try self.text(s),
            .breakable => |s| try self.breakable(s),
            .if_break => |s| try self.ifBreak(s),
            .hard_break => try self.newline(),
            .begin_group => |g| try self.beginGroup(g.indent, g.open),
            .end_group => |s| try self.endGroup(s),
            .shift_indent => |delta| self.indentation += delta,
            .comment => |s| try self.comment(s),
            .splice => |id| {
                const slot = &self.slots[id];
                self.block_indent += slot.block_indent;
                try self.run(slot.commands.items);
                self.block_indent -= slot.block_indent;
            },
            .line_prefix => |s| try self.linePrefix(s),
        }
    }
    fn emitPendingPad(self: *Self) !void {
        if (self.pending_pad) |indent| {
            self.pending_pad = null;
            const pad = self.block_indent + @as(usize, @intCast(@max(indent, 0)));
            try self.out.appendNTimes(self.a, ' ', pad);
            self.output_width = pad;
        }
    }
    fn pushContent(self: *Self, s: []const u8, w: usize) !void {
        if (w > 0) {
            try self.emitPendingPad();
            self.at_line_start = false;
        }
        try self.out.appendSlice(self.a, s);
        self.output_width += w;
    }
    fn emitPendingComments(self: *Self) !void {
        try self.out.appendSlice(self.a, self.pending_comments.items);
        self.pending_comments.clearRetainingCapacity();
    }
    fn startLine(self: *Self, indent: isize) !void {
        try self.emitPendingPad();
        try self.emitPendingComments();
        try self.out.append(self.a, '\n');
        self.pending_pad = indent;
        self.output_width = self.block_indent + @as(usize, @intCast(@max(indent, 0)));
        self.at_line_start = true;
    }
    fn linePrefix(self: *Self, s: []const u8) !void {
        if (self.empty() and self.pending_pad != null) {
            const w = width(s);
            try self.out.appendSlice(self.a, s);
            try self.emitPendingPad();
            self.output_width += w;
            if (w > 0) self.at_line_start = false;
        } else try self.text(s);
    }
    fn text(self: *Self, s: []const u8) Allocator.Error!void {
        const w = width(s);
        if (self.empty()) {
            try self.pushContent(s, w);
        } else {
            const last = &self.buffer.items[self.buffer.items.len - 1];
            if (last.* == .text) {
                last.text.content = try std.mem.concat(self.a, u8, &.{ last.text.content, s });
                last.text.width += w;
            } else try self.buffer.append(self.a, .{ .text = .{ .content = s, .width = w } });
            self.buffer_width += w;
            try self.breakOuterGroups();
        }
    }
    fn breakable(self: *Self, sep: []const u8) Allocator.Error!void {
        const group = self.group_stack.items[self.group_stack.items.len - 1];
        if (self.groups.items[group].want_break) {
            try self.newline();
        } else {
            const w = width(sep);
            try self.buffer.append(self.a, .{ .breakable = .{ .sep = sep, .width = w, .indent = self.indentation, .group = group } });
            self.groups.items[group].pending += 1;
            self.buffer_width += w;
            try self.breakOuterGroups();
        }
    }
    fn ifBreak(self: *Self, s: []const u8) !void {
        const group = self.group_stack.items[self.group_stack.items.len - 1];
        if (self.groups.items[group].want_break) {
            try self.text(s);
        } else try self.buffer.append(self.a, .{ .if_break = .{ .content = s, .group = group } });
    }
    fn comment(self: *Self, s: []const u8) !void {
        if (self.empty()) {
            try self.pending_comments.appendSlice(self.a, s);
        } else try self.buffer.append(self.a, .{ .comment = s });
    }
    fn newline(self: *Self) Allocator.Error!void {
        try self.flush();
        try self.startLine(self.indentation);
    }
    fn beginGroup(self: *Self, indent: usize, open: []const u8) !void {
        if (open.len > 0) try self.text(open);
        const depth = self.groups.items[self.group_stack.items[self.group_stack.items.len - 1]].depth + 1;
        const id = self.groups.items.len;
        const has_comment = self.force_break[id];
        try self.groups.append(self.a, .{ .depth = depth, .indent = indent, .want_break = has_comment, .comment = has_comment });
        try self.group_stack.append(self.a, id);
        while (self.group_queue.items.len <= depth) try self.group_queue.append(self.a, .empty);
        try self.group_queue.items[depth].append(self.a, id);
        self.indentation += @intCast(indent);
    }
    fn endGroup(self: *Self, closing: []const u8) e.Error!void {
        if (self.group_stack.items.len == 1) return error.UnbalancedGroup;
        const id = self.group_stack.pop().?;
        self.indentation -= @intCast(self.groups.items[id].indent);
        var close = closing;
        if (self.groups.items[id].comment) {
            if (!(self.empty() and self.at_line_start)) try self.newline();
            close = trimStart(close);
        }
        if (self.groups.items[id].pending == 0) self.queueRemove(id);
        if (close.len > 0) try self.text(close);
    }
    fn queueRemove(self: *Self, id: usize) void {
        const level = &self.group_queue.items[self.groups.items[id].depth];
        for (level.items, 0..) |g, i| {
            if (g == id) {
                _ = level.orderedRemove(i);
                return;
            }
        }
    }
    fn breakOuterGroups(self: *Self) Allocator.Error!void {
        while (self.output_width + self.buffer_width > self.max_width) {
            const id = self.deq() orelse return;
            while (self.groups.items[id].pending > 0) {
                const token = self.pop().?;
                self.buffer_width -= token.width();
                try self.outputToken(token);
            }
            while (!self.empty()) {
                const token = self.buffer.items[self.head];
                if (token == .breakable) break;
                _ = self.pop();
                self.buffer_width -= token.width();
                try self.outputToken(token);
            }
        }
    }
    fn deq(self: *Self) ?usize {
        for (self.group_queue.items) |*level| {
            for (level.items, 0..) |group, i| {
                if (self.groups.items[group].pending > 0) {
                    const id = level.orderedRemove(i);
                    self.groups.items[id].want_break = true;
                    return id;
                }
            }
            for (level.items) |group| self.groups.items[group].want_break = true;
            level.clearRetainingCapacity();
        }
        return null;
    }
    fn outputToken(self: *Self, token: Token) Allocator.Error!void {
        switch (token) {
            .text => |t| try self.pushContent(t.content, t.width),
            .if_break => |t| {
                if (self.groups.items[t.group].want_break) try self.pushContent(t.content, width(t.content));
            },
            .comment => |s| try self.pending_comments.appendSlice(self.a, s),
            .breakable => |t| {
                self.groups.items[t.group].pending -= 1;
                if (self.groups.items[t.group].want_break) {
                    try self.startLine(t.indent);
                } else {
                    if (self.groups.items[t.group].pending == 0) self.queueRemove(t.group);
                    try self.pushContent(t.sep, t.width);
                }
            },
        }
    }
    fn flush(self: *Self) Allocator.Error!void {
        while (self.pop()) |token| try self.outputToken(token);
        self.buffer_width = 0;
    }
};

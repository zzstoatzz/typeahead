// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/printer.rs; see provenance.
const std = @import("std");
const Allocator = std.mem.Allocator;
pub const Error = Allocator.Error || error{ DeadSlot, UnbalancedGroup, NoSpeculation, UnresolvedDeferred, NothingToResolve };
pub fn errorMessage(err: anyerror) []const u8 {
    return switch (err) {
        error.DeadSlot => "print region used after its printing session ended",
        error.UnbalancedGroup => "end_group without a matching begin_group",
        error.NoSpeculation => "commit or abort without an open speculative region",
        error.UnresolvedDeferred => "printer has unresolved deferred slots",
        error.NothingToResolve => "resolve called with no outstanding deferred slots",
        else => @errorName(err),
    };
}
pub const SlotId = usize;
pub const Target = union(enum) { main, slot: SlotId };
pub const Cmd = union(enum) { text: []const u8, breakable: []const u8, if_break: []const u8, hard_break, begin_group: struct { indent: usize, open: []const u8 }, end_group: []const u8, shift_indent: isize, comment: []const u8, splice: SlotId, line_prefix: []const u8 };
const Commands = std.ArrayList(Cmd);
const Buffers = std.ArrayList(Commands);
pub const Slot = struct { commands: Commands = .empty, speculation: Buffers = .empty, pending_notes: Buffers = .empty, dead: bool = false, block_indent: usize = 0, starts_line: bool = true };
pub const Printer = struct {
    allocator: Allocator,
    arena: std.heap.ArenaAllocator,
    max_width: usize,
    main: Commands = .empty,
    open_groups: isize = 0,
    speculation: Buffers = .empty,
    pending_notes: Buffers = .empty,
    slots: std.ArrayList(Slot) = .empty,
    pending_resolve: bool = false,
    sealed: bool = false,
    rendered: ?[]u8 = null,
    const Self = @This();
    pub fn init(gpa: Allocator, width: usize) Self {
        return .{ .allocator = gpa, .arena = .init(gpa), .max_width = width };
    }
    pub fn deinit(self: *Self) void {
        if (self.rendered) |v| self.allocator.free(v);
        self.arena.deinit();
    }
    fn arenaAllocator(self: *Self) Allocator {
        return self.arena.allocator();
    }
    pub fn maxWidth(self: *const Self) usize {
        return self.max_width;
    }
    pub fn setMaxWidth(self: *Self, width: usize) void {
        self.max_width = width;
        if (self.rendered) |v| self.allocator.free(v);
        self.rendered = null;
    }
    pub fn text(self: *Self, target: Target, s: []const u8) Error!void {
        return self.dispatch(target, .{ .text = try self.arenaAllocator().dupe(u8, s) });
    }
    pub fn ifBreak(self: *Self, target: Target, s: []const u8) Error!void {
        return self.dispatch(target, .{ .if_break = try self.arenaAllocator().dupe(u8, s) });
    }
    pub fn breakable(self: *Self, target: Target, s: []const u8) Error!void {
        return self.dispatch(target, .{ .breakable = try self.arenaAllocator().dupe(u8, s) });
    }
    pub fn hardBreak(self: *Self, target: Target) Error!void {
        return self.dispatch(target, .hard_break);
    }
    pub fn beginGroup(self: *Self, target: Target, indent: usize, open: []const u8) Error!void {
        return self.dispatch(target, .{ .begin_group = .{ .indent = indent, .open = try self.arenaAllocator().dupe(u8, open) } });
    }
    pub fn endGroup(self: *Self, target: Target, close: []const u8) Error!void {
        return self.dispatch(target, .{ .end_group = try self.arenaAllocator().dupe(u8, close) });
    }
    pub fn shiftIndent(self: *Self, target: Target, delta: isize) Error!void {
        return self.dispatch(target, .{ .shift_indent = delta });
    }
    pub fn comment(self: *Self, target: Target, s: []const u8) Error!void {
        return self.dispatch(target, .{ .comment = try self.arenaAllocator().dupe(u8, s) });
    }
    pub fn linePrefix(self: *Self, target: Target, s: []const u8) Error!void {
        return self.dispatch(target, .{ .line_prefix = try self.arenaAllocator().dupe(u8, s) });
    }
    pub fn deferred(self: *Self, target: Target) Error!SlotId {
        return self.openSlot(target, 0);
    }
    pub fn block(self: *Self, target: Target, indent: usize) Error!SlotId {
        return self.openSlot(target, indent);
    }
    fn live(self: *const Self, target: Target) bool {
        return !self.sealed and switch (target) {
            .main => true,
            .slot => |i| i < self.slots.items.len and !self.slots.items[i].dead,
        };
    }
    fn openSlot(self: *Self, target: Target, indent: usize) Error!SlotId {
        if (!self.live(target)) return error.DeadSlot;
        const id = self.slots.items.len;
        const starts = self.atLineStart(target);
        try self.slots.append(self.arenaAllocator(), .{ .block_indent = indent, .starts_line = starts });
        try self.dispatch(target, .{ .splice = id });
        return id;
    }
    pub fn atLineStart(self: *const Self, target: Target) bool {
        const cmds = switch (target) {
            .main => &self.main,
            .slot => |i| &self.slots.items[i].commands,
        };
        const spec = switch (target) {
            .main => &self.speculation,
            .slot => |i| &self.slots.items[i].speculation,
        };
        var i = spec.items.len;
        while (i > 0) {
            i -= 1;
            var j = spec.items[i].items.len;
            while (j > 0) {
                j -= 1;
                const cmd = spec.items[i].items[j];
                if (cmd != .shift_indent) return self.endsLine(cmd);
            }
        }
        i = cmds.items.len;
        while (i > 0) {
            i -= 1;
            if (cmds.items[i] != .shift_indent) return self.endsLine(cmds.items[i]);
        }
        return switch (target) {
            .main => true,
            .slot => |id| self.slots.items[id].starts_line,
        };
    }
    fn endsLine(self: *const Self, cmd: Cmd) bool {
        return switch (cmd) {
            .hard_break => true,
            .splice => |id| blk: {
                const slot = &self.slots.items[id];
                var i = slot.commands.items.len;
                while (i > 0) {
                    i -= 1;
                    if (slot.commands.items[i] != .shift_indent) break :blk self.endsLine(slot.commands.items[i]);
                }
                break :blk slot.starts_line;
            },
            else => false,
        };
    }
    pub fn beginSpeculative(self: *Self, target: Target) Error!void {
        if (!self.live(target)) return error.DeadSlot;
        const spec = switch (target) {
            .main => &self.speculation,
            .slot => |id| &self.slots.items[id].speculation,
        };
        try spec.append(self.arenaAllocator(), .empty);
    }
    pub fn commitSpeculative(self: *Self, target: Target) Error!void {
        if (!self.live(target)) return error.DeadSlot;
        const a = self.arenaAllocator();
        switch (target) {
            .main => {
                if (self.speculation.items.len == 0) return error.NoSpeculation;
                if (self.speculation.items.len > 1) {
                    const buf = self.speculation.pop().?;
                    try self.speculation.items[self.speculation.items.len - 1].appendSlice(a, buf.items);
                    return;
                }
                const sound = self.slots.items.len == 0;
                var balance = self.open_groups;
                for (self.speculation.items[self.speculation.items.len - 1].items) |cmd| {
                    switch (cmd) {
                        .begin_group => balance += 1,
                        .end_group => {
                            balance -= 1;
                            if (sound and balance < 0) return error.UnbalancedGroup;
                        },
                        else => {},
                    }
                }
                const buf = self.speculation.pop().?;
                for (buf.items) |cmd| {
                    if (cmd == .splice) self.pending_resolve = true;
                }
                self.open_groups = balance;
                try self.main.appendSlice(a, buf.items);
            },
            .slot => |id| {
                const slot = &self.slots.items[id];
                const buf = slot.speculation.pop() orelse return error.NoSpeculation;
                if (slot.speculation.items.len > 0) {
                    try slot.speculation.items[slot.speculation.items.len - 1].appendSlice(a, buf.items);
                    return;
                }
                try slot.commands.appendSlice(a, buf.items);
            },
        }
        try self.releaseHeldNotes(target);
    }
    pub fn abortSpeculative(self: *Self, target: Target) Error!void {
        if (!self.live(target)) return error.DeadSlot;
        const spec = switch (target) {
            .main => &self.speculation,
            .slot => |id| &self.slots.items[id].speculation,
        };
        const buf = spec.pop() orelse return error.NoSpeculation;
        try self.killSplices(buf.items);
        if (spec.items.len == 0) try self.releaseHeldNotes(target);
    }
    fn releaseHeldNotes(self: *Self, target: Target) Error!void {
        const a = self.arenaAllocator();
        const notes = switch (target) {
            .main => &self.pending_notes,
            .slot => |id| &self.slots.items[id].pending_notes,
        };
        const commands = switch (target) {
            .main => &self.main,
            .slot => |id| &self.slots.items[id].commands,
        };
        for (notes.items) |n| try commands.appendSlice(a, n.items);
        notes.clearRetainingCapacity();
    }
    pub fn resolve(self: *Self) Error!void {
        if (!self.pending_resolve) return error.NothingToResolve;
        self.seal();
        self.pending_resolve = false;
        _ = try self.renderedOutput();
    }
    pub fn value(self: *Self) Error![]const u8 {
        if (self.pending_resolve) return error.UnresolvedDeferred;
        self.seal();
        return self.renderedOutput();
    }
    fn renderedOutput(self: *Self) Error![]const u8 {
        if (self.rendered == null) self.rendered = try self.render();
        return self.rendered.?;
    }
    fn seal(self: *Self) void {
        self.speculation.clearRetainingCapacity();
        for (self.slots.items) |*s| {
            s.speculation.clearRetainingCapacity();
            s.dead = true;
        }
        self.sealed = true;
    }
    pub fn slotIsLive(self: *const Self, id: SlotId) bool {
        return id < self.slots.items.len and !self.slots.items[id].dead;
    }
    pub fn mainIsLive(self: *const Self) bool {
        return !self.sealed;
    }
    pub fn note(self: *Self, target: Target, s: []const u8, prefix: ?[]const u8) Error!void {
        if (!self.live(target)) return error.DeadSlot;
        const a = self.arenaAllocator();
        const spec = switch (target) {
            .main => &self.speculation,
            .slot => |id| &self.slots.items[id].speculation,
        };
        const held = switch (target) {
            .main => &self.pending_notes,
            .slot => |id| &self.slots.items[id].pending_notes,
        };
        var cmds: Commands = .empty;
        var segments = std.mem.splitScalar(u8, s, '\n');
        while (segments.next()) |segment| {
            if (prefix) |p| try cmds.append(a, .{ .line_prefix = try a.dupe(u8, p) });
            if (segment.len != 0) try cmds.append(a, .{ .text = try a.dupe(u8, segment) });
            try cmds.append(a, .hard_break);
        }
        if (spec.items.len > 0) {
            try held.append(a, cmds);
            return;
        }
        for (cmds.items) |cmd| try self.dispatch(target, cmd);
    }
    fn dispatch(self: *Self, target: Target, cmd: Cmd) Error!void {
        if (!self.live(target)) return error.DeadSlot;
        const a = self.arenaAllocator();
        switch (target) {
            .main => {
                if (self.speculation.items.len > 0) {
                    try self.speculation.items[self.speculation.items.len - 1].append(a, cmd);
                    return;
                }
                switch (cmd) {
                    .begin_group => self.open_groups += 1,
                    .end_group => {
                        if (self.slots.items.len == 0 and self.open_groups == 0) return error.UnbalancedGroup;
                        self.open_groups -= 1;
                    },
                    .splice => self.pending_resolve = true,
                    else => {},
                }
                try self.main.append(a, cmd);
            },
            .slot => |id| {
                const slot = &self.slots.items[id];
                if (slot.speculation.items.len > 0) {
                    try slot.speculation.items[slot.speculation.items.len - 1].append(a, cmd);
                } else try slot.commands.append(a, cmd);
            },
        }
    }
    fn killSplices(self: *Self, cmds: []const Cmd) Error!void {
        var work: std.ArrayList(usize) = .empty;
        for (cmds) |cmd| {
            if (cmd == .splice) try work.append(self.arenaAllocator(), cmd.splice);
        }
        while (work.pop()) |id| {
            const slot = &self.slots.items[id];
            slot.dead = true;
            for (slot.commands.items) |cmd| {
                if (cmd == .splice) try work.append(self.arenaAllocator(), cmd.splice);
            }
            for (slot.speculation.items) |buf| {
                for (buf.items) |cmd| {
                    if (cmd == .splice) try work.append(self.arenaAllocator(), cmd.splice);
                }
            }
        }
    }
    fn render(self: *Self) Error![]u8 {
        return @import("renderer.zig").render(self);
    }
};
pub const Mutex = struct {
    value: std.atomic.Mutex = .unlocked,
    pub fn lock(self: *@This()) void {
        while (!self.value.tryLock()) std.atomic.spinLoopHint();
    }
    pub fn unlock(self: *@This()) void {
        self.value.unlock();
    }
};
pub const PrinterShared = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize) = .init(1),
    mutex: Mutex = .{},
    value: Printer,
    width_configured: bool = false,
    pub fn create(a: Allocator, width: usize) !*@This() {
        const p = try a.create(@This());
        p.* = .{ .allocator = a, .value = .init(a, width) };
        return p;
    }
    pub fn retain(self: *@This()) *@This() {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *@This()) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            const a = self.allocator;
            self.value.deinit();
            a.destroy(self);
        }
    }
};

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/profiles.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const s = @import("settings.zig");
const Allocator = std.mem.Allocator;
pub const Environment = s.Environment;
pub const ProfileDelta = struct {
    extends: ?[]const u8 = null,
    test_cases: ?u64 = null,
    verbosity: ?s.Verbosity = null,
    seed: ??u64 = null,
    derandomize: ?bool = null,
    database: ?s.Database = null,
    suppress_health_check: ?[]const s.HealthCheck = null,
    phases: ?[]const s.Phase = null,
    report_multiple_failures: ?bool = null,
    show_statistics: ?bool = null,
    print_blob: ?bool = null,
    backend: ?s.Backend = null,
    nondeterminism_strictness: ?s.NondeterminismStrictness = null,
    unbounded_choices: ?bool = null,
    pub fn apply(self: ProfileDelta, settings: *s.Settings) void {
        if (self.test_cases) |v| settings.test_cases = v;
        if (self.verbosity) |v| settings.verbosity = v;
        if (self.seed) |v| settings.seed = v;
        if (self.derandomize) |v| settings.derandomize = v;
        if (self.database) |v| settings.database = v;
        if (self.suppress_health_check) |v| settings.suppress_health_check = v;
        if (self.phases) |v| settings.phases = v;
        if (self.report_multiple_failures) |v| settings.report_multiple_failures = v;
        if (self.show_statistics) |v| settings.show_statistics = v;
        if (self.print_blob) |v| settings.print_blob = v;
        if (self.backend) |v| settings.backend = v;
        if (self.nondeterminism_strictness) |v| settings.nondeterminism_strictness = v;
        if (self.unbounded_choices) |v| settings.unbounded_choices = v;
    }
    pub fn snapshot(settings: s.Settings) ProfileDelta {
        return .{
            .test_cases = settings.test_cases,
            .verbosity = settings.verbosity,
            .seed = settings.seed,
            .derandomize = settings.derandomize,
            .database = settings.database,
            .suppress_health_check = settings.suppress_health_check,
            .phases = settings.phases,
            .report_multiple_failures = settings.report_multiple_failures,
            .show_statistics = settings.show_statistics,
            .print_blob = settings.print_blob,
            .backend = settings.backend,
            .nondeterminism_strictness = settings.nondeterminism_strictness,
            .unbounded_choices = settings.unbounded_choices,
        };
    }
};
pub const NamedProfile = struct { name: []const u8, delta: ProfileDelta };
pub const Config = struct { default: ?[]const u8 = null, profiles: []const NamedProfile = &.{}, path: ?[]const u8 = null };
pub const Error = error{ ReservedName, InvalidName, CircularDefault, UnknownProfile, UnknownExtends, ExtendsCycle, ExtendsOnRegistered, InvalidEnvironment } || Allocator.Error;
pub fn validName(name: []const u8) bool {
    if (name.len == 0) return false;
    for (name) |c| if (!std.ascii.isAlphanumeric(c) and c != '-' and c != '_') return false;
    return true;
}
fn eq(a: []const u8, b: []const u8) bool {
    return std.mem.eql(u8, a, b);
}
const shipped = [_]NamedProfile{
    .{ .name = "development", .delta = .{} },
    .{ .name = "ci", .delta = .{ .derandomize = true, .database = .disabled, .suppress_health_check = &.{.too_slow} } },
    .{ .name = "workload", .delta = .{ .backend = .urandom, .database = .disabled, .suppress_health_check = &.{ .filter_too_much, .too_slow, .test_cases_too_large, .large_initial_test_case } } },
};
fn lookup(entries: []const NamedProfile, name: []const u8) ?*const ProfileDelta {
    for (entries) |*entry| if (eq(entry.name, name)) return &entry.delta;
    return null;
}
pub const Candidates = struct {
    overridden: ?[]const u8 = null,
    env: ?[]const u8 = null,
    toml: ?[]const u8 = null,
    environment: []const u8 = "development",
    pub fn gather(config: Config, overridden: ?[]const u8, env: s.Environment) Candidates {
        return .{ .overridden = overridden, .env = env.value("HEGEL_DEFAULT_PROFILE"), .toml = config.default, .environment = if (s.inAntithesis(env)) "workload" else if (s.isInCi(env)) "ci" else "development" };
    }
    fn resolve(self: Candidates, chain: []const []const u8) Error![]const u8 {
        if (self.overridden orelse self.env orelse self.toml) |named| {
            if (eq(named, "default")) return error.CircularDefault;
            if (!contains(chain, named)) return named;
        }
        return if (!contains(chain, self.environment)) self.environment else "base";
    }
};
fn contains(chain: []const []const u8, name: []const u8) bool {
    for (chain) |entry| if (eq(entry, name)) return true;
    return false;
}
fn deltaChain(gpa: Allocator, name: []const u8, config: Config, registry: []const NamedProfile, candidates: Candidates) Error!std.ArrayList(*const ProfileDelta) {
    var deltas: std.ArrayList(*const ProfileDelta) = .empty;
    errdefer deltas.deinit(gpa);
    var chain: std.ArrayList([]const u8) = .empty;
    defer chain.deinit(gpa);
    var current = name;
    var via_extends = false;
    while (true) {
        if (eq(current, "default")) {
            current = try candidates.resolve(chain.items);
            via_extends = false;
            continue;
        }
        if (eq(current, "base")) return deltas;
        if (contains(chain.items, current)) return error.ExtendsCycle;
        try chain.append(gpa, current);
        const cfg = lookup(config.profiles, current);
        const registered = lookup(registry, current);
        const ship = lookup(&shipped, current);
        if (cfg == null and registered == null and ship == null) return if (via_extends) error.UnknownExtends else error.UnknownProfile;
        if (cfg) |delta| try deltas.append(gpa, delta);
        if (registered) |delta| {
            if (cfg != null and cfg.?.extends != null) return error.ExtendsOnRegistered;
            try deltas.append(gpa, delta);
            return deltas;
        }
        if (ship) |delta| try deltas.append(gpa, delta);
        if (cfg != null and cfg.?.extends != null) {
            current = cfg.?.extends.?;
            via_extends = true;
        } else {
            current = if (ship != null) "base" else "default";
            via_extends = false;
        }
    }
}
pub fn resolve(gpa: Allocator, name: []const u8, config: Config, registry: []const NamedProfile, base: s.Settings, candidates: Candidates) Error!s.Settings {
    var deltas = try deltaChain(gpa, name, config, registry, candidates);
    defer deltas.deinit(gpa);
    var result = base;
    var index = deltas.items.len;
    while (index > 0) {
        index -= 1;
        deltas.items[index].apply(&result);
    }
    return result;
}
pub fn validate(gpa: Allocator, config: Config, registry: []const NamedProfile, candidates: Candidates) Error!void {
    const structural: Candidates = .{ .toml = candidates.toml, .environment = candidates.environment };
    for (config.profiles) |profile| {
        var deltas = try deltaChain(gpa, profile.name, config, registry, structural);
        deltas.deinit(gpa);
    }
    if (config.default) |name| {
        var deltas = try deltaChain(gpa, name, config, registry, structural);
        deltas.deinit(gpa);
    }
}
pub fn settingsFor(gpa: Allocator, name: ?[]const u8, config: Config, registry: []const NamedProfile, overridden: ?[]const u8, env: s.Environment) Error!s.Settings {
    const candidates = Candidates.gather(config, overridden, env);
    try validate(gpa, config, registry, candidates);
    var settings = try resolve(gpa, name orelse "default", config, registry, .{ .in_antithesis = s.inAntithesis(env) }, candidates);
    settings = try settings.withEnvOverrides(env);
    settings.config_path = config.path;
    return settings;
}

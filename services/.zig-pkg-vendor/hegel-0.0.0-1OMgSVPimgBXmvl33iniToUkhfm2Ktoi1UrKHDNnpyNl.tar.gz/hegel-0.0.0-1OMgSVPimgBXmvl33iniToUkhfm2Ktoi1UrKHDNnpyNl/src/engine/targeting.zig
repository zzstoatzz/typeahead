// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/targeting.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const state = @import("state.zig");
const RunResult = @import("execution.zig").RunResult;
const cache = @import("exec_cache.zig");
const Allocator = std.mem.Allocator;
pub const TargetingSchedule = @import("runner_policy.zig").TargetingSchedule;
pub const BestTarget = struct { label: []u8, score: f64, choices: []c.ChoiceValue };
pub const NdTarget = struct {
    nodes: []c.ChoiceNode,
    reference: f64,
    dead: bool,
    pub fn timeline(self: NdTarget, gpa: Allocator) ![]c.ChoiceValue {
        const values = try gpa.alloc(c.ChoiceValue, self.nodes.len);
        var count: usize = 0;
        errdefer {
            for (values[0..count]) |*v| v.deinit(gpa);
            gpa.free(values);
        }
        for (self.nodes, values) |node, *value| {
            value.* = try node.value(gpa);
            count += 1;
        }
        return values;
    }
    pub fn deinit(self: *NdTarget, gpa: Allocator) void {
        c.deinitNodes(gpa, self.nodes);
        self.* = undefined;
    }
};
pub const TargetingState = struct {
    allocator: Allocator,
    best_targets: std.ArrayList(BestTarget) = .empty,
    nd_targets: std.StringHashMapUnmanaged(NdTarget) = .empty,
    pub fn init(gpa: Allocator) TargetingState {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *TargetingState) void {
        for (self.best_targets.items) |entry| {
            self.allocator.free(entry.label);
            c.deinitValues(self.allocator, entry.choices);
        }
        self.best_targets.deinit(self.allocator);
        var iter = self.nd_targets.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            entry.value_ptr.deinit(self.allocator);
        }
        self.nd_targets.deinit(self.allocator);
    }
    pub fn best(self: *const TargetingState, label: []const u8) ?*const BestTarget {
        for (self.best_targets.items) |*entry| if (std.mem.eql(u8, entry.label, label)) return entry;
        return null;
    }
    pub fn record(self: *TargetingState, choices: []const c.ChoiceValue, observations: *const std.StringHashMapUnmanaged(f64)) !void {
        var iter = observations.iterator();
        while (iter.next()) |entry| {
            const label = entry.key_ptr.*;
            const score = entry.value_ptr.*;
            var index: ?usize = null;
            for (self.best_targets.items, 0..) |old, i| if (std.mem.eql(u8, old.label, label)) {
                index = i;
                break;
            };
            if (index != null and !(score > self.best_targets.items[index.?].score)) continue;
            const owned_choices = try cloneValues(self.allocator, choices);
            errdefer c.deinitValues(self.allocator, owned_choices);
            if (index) |i| {
                c.deinitValues(self.allocator, self.best_targets.items[i].choices);
                self.best_targets.items[i].choices = owned_choices;
                self.best_targets.items[i].score = score;
            } else {
                const owned_label = try self.allocator.dupe(u8, label);
                errdefer self.allocator.free(owned_label);
                try self.best_targets.append(self.allocator, .{ .label = owned_label, .score = score, .choices = owned_choices });
            }
        }
    }
    pub fn isEmpty(self: *const TargetingState) bool {
        return self.best_targets.items.len == 0;
    }
    pub fn seeds(self: *const TargetingState, gpa: Allocator) ![]BestTarget {
        const entries = try gpa.alloc(BestTarget, self.best_targets.items.len);
        var count: usize = 0;
        errdefer {
            for (entries[0..count]) |entry| {
                gpa.free(entry.label);
                c.deinitValues(gpa, entry.choices);
            }
            gpa.free(entries);
        }
        for (self.best_targets.items, entries) |source, *dest| {
            const label = try gpa.dupe(u8, source.label);
            errdefer gpa.free(label);
            dest.* = .{ .label = label, .score = source.score, .choices = try cloneValues(gpa, source.choices) };
            count += 1;
        }
        std.mem.sort(BestTarget, entries, {}, struct {
            fn less(_: void, a: BestTarget, b: BestTarget) bool {
                return std.mem.order(u8, a.label, b.label) == .lt;
            }
        }.less);
        return entries;
    }
    pub fn ndTarget(self: *TargetingState, label: []const u8) ?*NdTarget {
        return self.nd_targets.getPtr(label);
    }
    pub fn setNdTarget(self: *TargetingState, label: []const u8, target: NdTarget) !void {
        if (self.nd_targets.getPtr(label)) |old| {
            old.deinit(self.allocator);
            old.* = target;
        } else {
            const owned = try self.allocator.dupe(u8, label);
            errdefer self.allocator.free(owned);
            try self.nd_targets.put(self.allocator, owned, target);
        }
    }
    pub fn adoptNd(self: *TargetingState, label: []const u8, nodes: []const c.ChoiceNode, median: f64) !void {
        const reference = if (self.ndTarget(label)) |old| @max(old.reference, median) else @max(-std.math.inf(f64), median);
        var copied = try cache.CachedRun.init(self.allocator, .valid, null, nodes, &.{});
        errdefer copied.deinit(self.allocator);
        try self.setNdTarget(label, .{ .nodes = copied.nodes, .reference = reference, .dead = false });
        self.allocator.free(copied.spans);
    }
};
pub fn cloneValues(gpa: Allocator, source: []const c.ChoiceValue) ![]c.ChoiceValue {
    const result = try gpa.alloc(c.ChoiceValue, source.len);
    var count: usize = 0;
    errdefer {
        for (result[0..count]) |*v| v.deinit(gpa);
        gpa.free(result);
    }
    for (source, result) |*v, *dest| {
        dest.* = try v.deepClone(gpa);
        count += 1;
    }
    return result;
}
pub fn isClimbable(data: *const c.ChoiceData) bool {
    return switch (data.*) {
        .integer, .float, .boolean, .bytes => true,
        else => false,
    };
}
pub fn stepChoice(gpa: Allocator, node: *const c.ChoiceNode, delta: i128) !?c.ChoiceValue {
    return switch (node.data) {
        .integer => |v| blk: {
            var value = try v.value.addInt(gpa, delta);
            defer value.deinit();
            if (!v.constraint.validate(value)) break :blk null;
            break :blk .{ .integer = try value.clone(gpa) };
        },
        .float => |v| blk: {
            const value = v.value + @as(f64, @floatFromInt(delta));
            break :blk if (v.constraint.validate(value)) .{ .float = value } else null;
        },
        .boolean => |v| if (delta < -1 or delta > 1) null else .{ .boolean = if (delta == -1) false else if (delta == 1) true else v.value },
        .bytes => |v| blk: {
            var value = try c.BigInt.fromBytesBe(gpa, .plus, v.value);
            defer value.deinit();
            var next = try value.addInt(gpa, delta);
            defer next.deinit();
            if (next.sign() == .minus) break :blk null;
            const encoded = try next.toBytesBe(gpa);
            defer gpa.free(encoded[1]);
            const bytes = try gpa.alloc(u8, @max(@max(encoded[1].len, 1), v.value.len));
            @memset(bytes, 0);
            @memcpy(bytes[bytes.len - encoded[1].len ..], encoded[1]);
            if (!v.constraint.validate(bytes)) {
                gpa.free(bytes);
                break :blk null;
            }
            break :blk .{ .bytes = bytes };
        },
        else => null,
    };
}
pub fn Optimiser(comptime Engine: type) type {
    return struct {
        engine: *Engine,
        max_valid: u64,
        max_calls: u64,
        const Self = @This();
        fn exhausted(self: Self) bool {
            return self.engine.origins.anyLive() or self.engine.nd_active or self.engine.valid_test_cases >= self.max_valid or self.engine.calls >= self.max_calls;
        }
        fn trial(self: *Self, choices: []const c.ChoiceValue) !?RunResult {
            if (self.exhausted()) return null;
            const ntc = try state.NativeTestCase.forProbe(self.engine.allocator, choices, self.engine.rngSpawn(), self.engine.choiceBound());
            return try self.engine.testFunction(ntc);
        }
        pub fn optimiseTargets(self: *Self) !void {
            const gpa = self.engine.allocator;
            const seeds = try self.engine.targeting.seeds(gpa);
            defer {
                for (seeds) |seed| {
                    gpa.free(seed.label);
                    c.deinitValues(gpa, seed.choices);
                }
                gpa.free(seeds);
            }
            var max_improvements: usize = 10;
            while (true) {
                const previous = self.engine.calls;
                var any_improvements = false;
                for (seeds) |seed| if (try self.hillClimb(seed.label, max_improvements) > 0) {
                    any_improvements = true;
                };
                max_improvements *|= 2;
                if (!any_improvements or previous == self.engine.calls) return;
            }
        }
        fn hillClimb(self: *Self, label: []const u8, max_improvements: usize) !usize {
            const gpa = self.engine.allocator;
            const best_target = self.engine.targeting.best(label) orelse return error.InternalError;
            const start = try cloneValues(gpa, best_target.choices);
            defer c.deinitValues(gpa, start);
            var current = (try self.trial(start)) orelse return 0;
            defer current.deinit(gpa);
            if (@backingInt(current.status) < @backingInt(c.Status.valid)) return 0;
            var improvements: usize = 0;
            var examined: std.AutoHashMapUnmanaged(usize, void) = .empty;
            defer examined.deinit(gpa);
            var i: isize = @as(isize, @intCast(current.nodes.len)) - 1;
            var previous_len = current.nodes.len;
            while (i >= 0 and improvements <= max_improvements) {
                if (current.nodes.len != previous_len) {
                    i = @as(isize, @intCast(current.nodes.len)) - 1;
                    previous_len = current.nodes.len;
                    continue;
                }
                const index: usize = @intCast(i);
                if (examined.contains(index)) {
                    i -= 1;
                    continue;
                }
                try examined.put(gpa, index, {});
                if (!current.nodes[index].was_forced and isClimbable(&current.nodes[index].data)) {
                    const len_before = current.nodes.len;
                    var search = @import("shrinker/search.zig").FindInteger.init();
                    while (search.probe()) |k| search.record(try self.tryReplace(label, &current, &improvements, index, @intCast(k)));
                    if (index < current.nodes.len and current.nodes.len == len_before) {
                        search = .init();
                        while (search.probe()) |k| search.record(try self.tryReplace(label, &current, &improvements, index, -@as(i128, @intCast(k))));
                    }
                }
                i -= 1;
            }
            return improvements;
        }
        fn tryReplace(self: *Self, label: []const u8, current: *RunResult, improvements: *usize, index: usize, delta: i128) !bool {
            if (delta < -(1 << 20) or delta > 1 << 20) return false;
            const gpa = self.engine.allocator;
            var new_value = (try stepChoice(gpa, &current.nodes[index], delta)) orelse return false;
            const values = current.realizedValues(gpa) catch |err| {
                new_value.deinit(gpa);
                return err;
            };
            defer c.deinitValues(gpa, values);
            values[index].deinit(gpa);
            values[index] = new_value;
            var proposed = (try self.trial(values)) orelse return false;
            errdefer proposed.deinit(gpa);
            if (@backingInt(proposed.status) < @backingInt(c.Status.valid)) {
                proposed.deinit(gpa);
                return false;
            }
            const old_score = current.target_observations.get(label) orelse -std.math.inf(f64);
            const new_score = proposed.target_observations.get(label) orelse -std.math.inf(f64);
            if (new_score < old_score or (!(new_score > old_score) and proposed.nodes.len > current.nodes.len)) {
                proposed.deinit(gpa);
                return false;
            }
            if (new_score > old_score) improvements.* += 1;
            current.deinit(gpa);
            current.* = proposed;
            return true;
        }
    };
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const offset: u64 = 0xcbf29ce484222325;
const prime: u64 = 0x100000001b3;

fn append(hash: u64, bytes: []const u8) u64 {
    var result = hash;
    for (bytes) |byte| result = (result ^ byte) *% prime;
    return result;
}

pub fn labelFromBytes(name: []const u8) u64 {
    return append(offset, name);
}

pub fn labelFromName(name: []const u8) u64 {
    return labelFromBytes(name);
}

pub fn combineLabels(labels: []const u64) u64 {
    var hash = offset;
    for (labels) |label| {
        var remaining = label;
        for (0..8) |_| {
            hash = (hash ^ @as(u8, @truncate(remaining))) *% prime;
            remaining >>= 8;
        }
    }
    return hash;
}

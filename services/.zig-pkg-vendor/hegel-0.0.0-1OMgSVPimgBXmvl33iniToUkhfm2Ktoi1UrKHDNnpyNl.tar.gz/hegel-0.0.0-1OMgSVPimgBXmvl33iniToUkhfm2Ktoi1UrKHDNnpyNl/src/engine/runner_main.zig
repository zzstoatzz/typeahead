// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const state = @import("state.zig");
const db = @import("database.zig");
const blob = @import("blob.zig");
const cache = @import("exec_cache.zig");
const policy = @import("runner_policy.zig");
const target = @import("targeting.zig");
const persistence = @import("persistence.zig");
const types = @import("runner_types.zig");
const runner = @import("test_runner.zig");
const nd = @import("nd.zig");
pub fn run(engine: anytype) anyerror!runner.TestRunResult {
    const settings = engine.settings;
    const max_cases = settings.test_cases;
    if (settings.verbosity == .debug) {
        if (settings.config_path) |path| try engine.log("loaded config: {s}", .{path}) else try engine.log("no config file loaded", .{});
    }
    var schedule = policy.TargetingSchedule.init(max_cases);
    const invalid_budget = policy.invalidThresholds(0.01, 0.99);
    const replay_aligned = try reuse(engine);
    const found_in_reuse = engine.origins.anyLive();
    const actually_generate = settings.hasPhase(.generate) and !found_in_reuse and !engine.test_is_trivial;
    if (actually_generate) try logPhase(engine, "Generate", "Start");
    engine.collect_statistics = true;
    if (settings.hasPhase(.generate) and !engine.test_is_trivial and withinBudget(engine, invalid_budget) and !found_in_reuse and max_cases > 1) {
        var initial = try engine.testFunction(try state.NativeTestCase.forSimplest(engine.allocator, engine.choiceBound()));
        defer initial.deinit(engine.allocator);
        if (policy.largeInitial(initial.status == .early_stop, initial.status, c.flattenedLen(initial.nodes), engine.choiceBound(), settings.healthCheckSuppressed(.large_initial_test_case))) return engine.fail(error.HealthCheck, "FailedHealthCheck: LargeInitialTestCase — the smallest natural input for this test is very large, which makes it hard to generate and shrink good inputs. Consider reducing the amount of data generated, or introducing small alternatives (e.g. `gs::one_of` with an empty option). If this is expected, suppress the check with suppress_health_check = [HealthCheck::LargeInitialTestCase].", .{});
    }
    engine.capture_discoveries = true;
    while (settings.hasPhase(.generate) and !found_in_reuse and canGenerate(engine, invalid_budget)) {
        for (0..10) |_| {
            if (!canGenerate(engine, invalid_budget)) break;
            var rng = engine.rngSpawn();
            const params = try state.GenerationParameters.draw(&rng);
            const tc = try state.NativeTestCase.newRandomWithParams(engine.allocator, rng, params, engine.choiceBound());
            if (settings.verbosity == .verbose) try engine.log("Running test case", .{});
            var result = try engine.testFunction(tc);
            defer result.deinit(engine.allocator);
            if (settings.verbosity == .debug) try engine.log("test case #{d}: status = {s}, choices = {d}", .{ engine.calls, statusName(result.status), c.flattenedLen(result.nodes) });
            if (!engine.origins.anyLive()) {
                if (result.status == .invalid and engine.invalid_test_cases >= 50 and engine.valid_test_cases < 10 and !settings.healthCheckSuppressed(.filter_too_much)) return engine.fail(error.HealthCheck, "FailedHealthCheck: FilterTooMuch — it looks like this test is filtering out too many inputs. {d} inputs were filtered out by assume() while only {d} valid inputs were generated. If this is expected, suppress the check with suppress_health_check = [HealthCheck::FilterTooMuch].", .{ engine.invalid_test_cases, engine.valid_test_cases });
                if (policy.tooLarge(engine.valid_test_cases, engine.overrun_test_cases, settings.healthCheckSuppressed(.test_cases_too_large))) return engine.fail(error.HealthCheck, "FailedHealthCheck: TestCasesTooLarge — generated inputs routinely exceeded the maximum size: {d} inputs were generated successfully, while {d} inputs overran the choice limit during generation. Testing with inputs this large is slow and shrinks poorly. Try reducing the amount of data generated, e.g. a smaller min_size on collections like gs::vecs(). If this is expected, suppress the check with suppress_health_check = [HealthCheck::TestCasesTooLarge], which also removes the limit on the size of a test case.", .{ engine.valid_test_cases, engine.overrun_test_cases });
                if (policy.tooSlow(engine.valid_test_cases, engine.total_test_time, engine.too_slow_threshold_ns, settings.healthCheckSuppressed(.too_slow))) {
                    const elapsed = try policy.formatDuration(engine.allocator, engine.total_test_time);
                    defer engine.allocator.free(elapsed);
                    const threshold = try policy.formatDuration(engine.allocator, engine.too_slow_threshold_ns);
                    defer engine.allocator.free(threshold);
                    return engine.fail(error.HealthCheck, "FailedHealthCheck: TooSlow — input generation is slow: only {d} valid inputs after {s} (threshold {s}). Slow generation makes property testing much less effective. If this is expected, suppress the check with suppress_health_check = [HealthCheck::TooSlow].", .{ engine.valid_test_cases, elapsed, threshold });
                }
            }
            if (settings.hasPhase(.target) and !engine.origins.anyLive() and !engine.targeting.isEmpty() and schedule.shouldFire(engine.valid_test_cases)) {
                if (engine.nd_active) try engine.optimiseTargetsNd() else {
                    var optimiser: target.Optimiser(@TypeOf(engine.*)) = .{ .engine = engine, .max_valid = max_cases, .max_calls = max_cases * 10 };
                    try optimiser.optimiseTargets();
                }
            }
            if (result.status == .valid and (engine.valid_test_cases >= 10 or engine.origins.anyLive())) try spanMutation(engine, result.nodes, result.spans);
            try engine.firstCheckSweep();
            try engine.ndDiscoverySweep();
        }
    }
    try engine.firstCheckSweep();
    try engine.ndDiscoverySweep();
    engine.capture_discoveries = false;
    if (engine.test_is_trivial and engine.valid_test_cases == 0 and !engine.origins.anyLive() and engine.invalid_test_cases > 0) return engine.fail(error.Unsatisfiable, "Unsatisfiable: unable to satisfy the test's assumptions. The test draws no data, and assume() rejected its only possible input.", .{});
    if (engine.consecutive_duplicates >= 10 and engine.valid_test_cases == 0 and !engine.origins.anyLive() and !engine.test_is_trivial and !settings.healthCheckSuppressed(.filter_too_much) and engine.invalid_test_cases > 0) return engine.fail(error.HealthCheck, "FailedHealthCheck: FilterTooMuch — every reachable input was filtered out by assume() before any valid input was generated. {d} inputs were filtered out across the full search space. If this is expected, suppress the check with suppress_health_check = [HealthCheck::FilterTooMuch].", .{engine.invalid_test_cases});
    if (actually_generate) try logPhase(engine, "Generate", "End");
    engine.collect_statistics = false;
    var deadline: ?i128 = null;
    if (engine.origins.anyLive() and !replay_aligned and settings.hasPhase(.shrink)) {
        try logPhase(engine, "Shrink", "Start");
        if (settings.verbosity == .debug) {
            const totals = liveTotals(engine);
            try engine.log("Shrinking: {d} origin(s), initial total length = {d}", .{ totals[0], totals[1] });
        }
        if (!engine.nd_active) try secondaryShrinkReplay(engine);
        deadline = engine.now() + @as(i128, @intCast(engine.shrink_budget_ns));
        var shrunk: std.StringHashMapUnmanaged(void) = .empty;
        defer {
            var keys = shrunk.keyIterator();
            while (keys.next()) |key| engine.allocator.free(key.*);
            shrunk.deinit(engine.allocator);
        }
        var timed_out = false;
        while (true) {
            var pending: ?[]u8 = null;
            for (engine.origins.iter()) |entry| if (entry.record.incumbent() != null and !shrunk.contains(entry.origin)) {
                pending = try engine.allocator.dupe(u8, entry.origin);
                break;
            };
            const origin = pending orelse break;
            defer engine.allocator.free(origin);
            const counter = engine.origins.get(origin).?;
            var initial = try cache.CachedRun.init(engine.allocator, .interesting, null, counter.incumbent().?, counter.incumbentSpans());
            defer initial.deinit(engine.allocator);
            timed_out = (try engine.shrinkOrigin(origin, initial.nodes, initial.spans, deadline, &shrunk)) or timed_out;
        }
        if (timed_out and settings.verbosity != .quiet) try engine.log("WARNING: Shrinking has been running for more than 300 seconds and is making very slow progress, so it has been stopped. The smallest failing example found so far will be reported. Re-running the test will resume shrinking from there, and may take this long again before stopping.", .{});
        if (settings.verbosity == .debug) {
            const totals = liveTotals(engine);
            try engine.log("Shrinking complete: {d} origin(s), final total length = {d}", .{ totals[0], totals[1] });
        }
        try logPhase(engine, "Shrink", "End");
    } else if (replay_aligned and settings.verbosity == .debug) try engine.log("Skipping shrink: reused aligned database replay", .{});
    const final_deadline = deadline orelse engine.now() + @as(i128, @intCast(engine.shrink_budget_ns));
    try engine.finalReplay(final_deadline, settings.hasPhase(.shrink));
    try reconcile(engine);
    if (settings.verbosity == .debug) try engine.log("Test done. interesting_test_cases={d}", .{liveTotals(engine)[0]});
    if (settings.show_statistics) {
        const lines = try engine.statistics.render();
        defer @import("events.zig").deinitLines(engine.allocator, lines);
        for (lines) |line| settings.output.line(engine.io, line);
    }
    return buildReport(engine);
}
fn statusName(status: c.Status) []const u8 {
    return switch (status) {
        .early_stop => "EarlyStop",
        .invalid => "Invalid",
        .valid => "Valid",
        .interesting => "Interesting",
    };
}
fn liveTotals(engine: anytype) [2]usize {
    var count: usize = 0;
    var nodes: usize = 0;
    for (engine.origins.iter()) |entry| if (entry.record.incumbent()) |incumbent| {
        count += 1;
        nodes += incumbent.len;
    };
    return .{ count, nodes };
}
fn logPhase(engine: anytype, name: []const u8, edge: []const u8) !void {
    if (engine.settings.verbosity == .verbose or engine.settings.verbosity == .debug) try engine.log("{s}ing phase: {s}", .{ edge, name });
}
fn withinBudget(engine: anytype, budget: policy.InvalidBudget) bool {
    return policy.withinInvalidBudget(engine.invalid_test_cases, engine.overrun_test_cases, engine.valid_test_cases, budget);
}
fn canGenerate(engine: anytype, budget: policy.InvalidBudget) bool {
    return !engine.test_is_trivial and engine.valid_test_cases < engine.settings.test_cases and withinBudget(engine, budget) and !(engine.valid_test_cases == 0 and engine.consecutive_duplicates >= 10) and policy.shouldGenerateMore(!engine.origins.anyLive(), engine.calls, engine.first_bug_at, engine.last_bug_at, engine.settings.hasPhase(.shrink), engine.settings.report_multiple_failures, if (engine.first_bug_time) |time| @intCast(@max(0, engine.now() - time)) else null);
}
fn usizeFromFloat(value: f64) usize {
    return if (std.math.isNan(value) or value <= 0) 0 else if (value >= @as(f64, @floatFromInt(std.math.maxInt(usize)))) std.math.maxInt(usize) else @intFromFloat(value);
}
fn reuse(engine: anytype) anyerror!bool {
    if (!engine.settings.hasPhase(.reuse) or engine.database == null or engine.database_key == null) return false;
    const database = &engine.database.?;
    const key = engine.database_key.?;
    const gpa = engine.allocator;
    try logPhase(engine, "Reuse", "Start");
    const secondary = try db.subKey(gpa, key, "secondary");
    defer gpa.free(secondary);
    const primary = try database.fetch(gpa, key);
    defer persistence.freeEntries(gpa, primary);
    std.mem.sort([]u8, primary, {}, lessBytes);
    var aligned = primary.len > 0;
    var values: std.ArrayList([]const u8) = .empty;
    defer values.deinit(gpa);
    try values.appendSlice(gpa, primary);
    const desired = @max(usizeFromFloat(@ceil(@as(f64, @floatFromInt(engine.settings.test_cases)) * @as(f64, if (engine.settings.hasPhase(.generate)) 0.1 else 1.0))), 2);
    const extra = if (values.items.len < desired) try database.fetch(gpa, secondary) else try gpa.alloc([]u8, 0);
    defer persistence.freeEntries(gpa, extra);
    if (values.items.len < desired) {
        var available: std.ArrayList([]u8) = .empty;
        defer available.deinit(gpa);
        for (extra) |bytes| if (!containsBytes(primary, bytes)) try available.append(gpa, bytes);
        const shortfall = desired - values.items.len;
        if (available.items.len > shortfall) {
            for (0..shortfall) |i| {
                const j = engine.rng.range(usize, i, available.items.len);
                std.mem.swap([]u8, &available.items[i], &available.items[j]);
            }
            available.shrinkRetainingCapacity(shortfall);
        }
        std.mem.sort([]u8, available.items, {}, lessBytes);
        try values.appendSlice(gpa, available.items);
    }
    var primary_interesting = false;
    for (values.items, 0..) |raw, index| {
        if (index >= primary.len and primary_interesting) break;
        const parsed_choices = try db.deserializeChoices(gpa, raw);
        defer if (parsed_choices) |choices| c.deinitValues(gpa, choices);
        var stored: ?blob.NdReproState = null;
        defer if (stored) |*value| value.deinit();
        if (parsed_choices == null) {
            stored = try blob.decodeNdState(gpa, raw);
            if (stored == null) {
                database.delete(key, raw);
                database.delete(secondary, raw);
                continue;
            }
            if (engine.settings.nondeterminism_strictness != .@"error") engine.ndFlip();
        }
        const nd_entry = stored != null or engine.nd_active;
        var witness: ?runner.RunResult = null;
        defer if (witness) |*value| value.deinit(gpa);
        var evidence: nd.Evidence = .{};
        var entry_aligned = false;
        if (parsed_choices != null and !nd_entry) {
            var executed = try engine.testFunction(try state.NativeTestCase.forProbe(gpa, parsed_choices.?, engine.rngSpawn(), engine.choiceBound()));
            var owns_executed = true;
            defer if (owns_executed) executed.deinit(gpa);
            const realized = try executed.realizedValues(gpa);
            defer c.deinitValues(gpa, realized);
            entry_aligned = runner.valuesEqual(realized, parsed_choices.?);
            evidence.record(executed.status == .interesting);
            if (executed.status == .interesting) {
                witness = executed;
                owns_executed = false;
            }
        } else {
            const source: types.ReproSource = if (stored) |*value| .{ .graph = .{ .source = &value.graph, .longest = @min(value.longest, engine.choiceBound()) } } else .{ .sequence = parsed_choices.? };
            const result = try reuseReproduce(engine, source);
            witness = result.witness;
            evidence = result.evidence;
            if (witness) |*run_result| {
                entry_aligned = if (parsed_choices) |choices| blk: {
                    const realized = try run_result.realizedValues(gpa);
                    defer c.deinitValues(gpa, realized);
                    break :blk runner.valuesEqual(realized, choices);
                } else blk: {
                    var observed = try @import("graph.zig").Run.fromNodes(gpa, run_result.nodes, run_result.spans);
                    defer observed.deinit();
                    break :blk stored.?.graph.walkVerdict(&observed) == .whole;
                };
            }
        }
        if (witness) |*run_result| {
            if (run_result.origin) |origin| {
                const counter = try engine.origins.entry(origin);
                try counter.trust(if (stored) |*value| .{ .graph = &value.graph, .longest = @min(value.longest, engine.choiceBound()) } else null, .{ .fails = evidence.fails(), .replays = evidence.runs() });
                counter.markFirstChecked();
            }
            if (index < primary.len) {
                primary_interesting = true;
                if (!entry_aligned) aligned = false;
            } else aligned = false;
            if (!engine.settings.report_multiple_failures) break;
        } else {
            if (!nd_entry) {
                database.delete(key, raw);
                database.delete(secondary, raw);
            } else if (index < primary.len) database.moveValue(key, secondary, raw) else database.delete(secondary, raw);
        }
    }
    if (!engine.origins.anyLive()) aligned = false;
    try logPhase(engine, "Reuse", "End");
    return aligned;
}
fn reuseReproduce(engine: anytype, source: types.ReproSource) anyerror!types.Reproduction {
    engine.capture_replays = true;
    engine.reuse_replays = true;
    defer {
        engine.capture_replays = false;
        engine.reuse_replays = false;
    }
    return engine.ndReproduce(null, source, nd.reuseReplayBudget(), 0);
}
fn containsBytes(entries: []const []const u8, bytes: []const u8) bool {
    for (entries) |entry| if (std.mem.eql(u8, entry, bytes)) return true;
    return false;
}
fn lessBytes(_: void, a: []const u8, b: []const u8) bool {
    return policy.shortlex(a, b) == .lt;
}
fn secondaryShrinkReplay(engine: anytype) anyerror!void {
    if (engine.database == null or engine.database_key == null) return;
    const database = &engine.database.?;
    const key = engine.database_key.?;
    const gpa = engine.allocator;
    const secondary = try db.subKey(gpa, key, "secondary");
    defer gpa.free(secondary);
    const entries = try database.fetch(gpa, secondary);
    defer persistence.freeEntries(gpa, entries);
    std.mem.sort([]u8, entries, {}, lessBytes);
    var max_primary: ?[]u8 = null;
    defer if (max_primary) |bytes| gpa.free(bytes);
    for (engine.origins.iter()) |entry| if (entry.record.incumbent()) |nodes| {
        const bytes = (try db.serializeNodes(gpa, nodes)) orelse return error.InternalError;
        if (max_primary == null or policy.shortlex(bytes, max_primary.?) == .gt) {
            if (max_primary) |old| gpa.free(old);
            max_primary = bytes;
        } else gpa.free(bytes);
    };
    for (entries) |raw| {
        if (max_primary != null and policy.shortlex(raw, max_primary.?) == .gt) break;
        if (try db.deserializeChoices(gpa, raw)) |choices| {
            defer c.deinitValues(gpa, choices);
            var observed = try engine.testFunction(try state.NativeTestCase.forChoices(gpa, choices, null, null));
            observed.deinit(gpa);
            database.delete(secondary, raw);
            if (engine.nd_active) break;
        } else if (try blob.decodeNdState(gpa, raw)) |value| {
            var decoded = value;
            decoded.deinit();
            continue;
        } else database.delete(secondary, raw);
    }
}
fn reconcile(engine: anytype) anyerror!void {
    const gpa = engine.allocator;
    var entries: std.ArrayList([]u8) = .empty;
    defer {
        for (entries.items) |bytes| gpa.free(bytes);
        entries.deinit(gpa);
    }
    for (engine.origins.iter()) |entry| {
        if (engine.nd_active and entry.record.needsConfirmation()) continue;
        const nodes = entry.record.incumbent() orelse continue;
        const bytes = if (engine.nd_active) blk: {
            var repro = try entry.record.reproState();
            defer repro.deinit();
            break :blk (try blob.encodeNdState(gpa, &repro)) orelse return error.InternalError;
        } else (try db.serializeNodes(gpa, nodes)) orelse return error.InternalError;
        entries.append(gpa, bytes) catch |err| {
            gpa.free(bytes);
            return err;
        };
    }
    try engine.persister.reconcile(entries.items);
}
const ReportEntry = struct {
    origin: []u8,
    nodes: []c.ChoiceNode,
    repro: ?blob.NdReproState,
    fn deinit(self: *ReportEntry, gpa: std.mem.Allocator) void {
        gpa.free(self.origin);
        c.deinitNodes(gpa, self.nodes);
        if (self.repro) |*value| value.deinit();
    }
};
fn buildReport(engine: anytype) anyerror!runner.TestRunResult {
    const gpa = engine.allocator;
    var entries: std.ArrayList(ReportEntry) = .empty;
    defer {
        for (entries.items) |*entry| entry.deinit(gpa);
        entries.deinit(gpa);
    }
    for (engine.origins.iterMut()) |*entry| {
        if (engine.nd_active and entry.record.needsConfirmation()) continue;
        if (entry.record.incumbent() == null) continue;
        const origin = try gpa.dupe(u8, entry.origin);
        errdefer gpa.free(origin);
        var repro: ?blob.NdReproState = if (engine.nd_active) try entry.record.reproState() else null;
        errdefer if (repro) |*value| value.deinit();
        const nodes = entry.record.evict().?;
        errdefer c.deinitNodes(gpa, nodes);
        try entries.append(gpa, .{ .origin = origin, .nodes = nodes, .repro = repro });
    }
    var i: usize = 1;
    while (i < entries.items.len) : (i += 1) {
        var j = i;
        while (j > 0 and try c.nodesOrder(gpa, entries.items[j - 1].nodes, entries.items[j].nodes) == .lt) : (j -= 1) std.mem.swap(ReportEntry, &entries.items[j - 1], &entries.items[j]);
    }
    var failures: std.ArrayList(runner.Failure) = .empty;
    errdefer {
        for (failures.items) |*failure| failure.deinit(gpa);
        failures.deinit(gpa);
    }
    const selected = if (!engine.settings.report_multiple_failures and entries.items.len > 0) entries.items[entries.items.len - 1 ..] else entries.items;
    for (selected) |*entry| {
        const origin = try gpa.dupe(u8, entry.origin);
        errdefer gpa.free(origin);
        const encoded = if (engine.nd_active) (try blob.encodeNdFailure(gpa, &entry.repro.?)) orelse return error.InternalError else blk: {
            const snapshot = try cache.CachedRun.init(gpa, .interesting, null, entry.nodes, &.{});
            var view = runner.RunResult.fromCached(snapshot);
            defer view.deinit(gpa);
            const values = try view.realizedValues(gpa);
            defer c.deinitValues(gpa, values);
            break :blk (try blob.encodeFailure(gpa, values)) orelse return error.InternalError;
        };
        errdefer gpa.free(encoded);
        const caveat = if (engine.nd_active) try engine.origins.caveat(entry.origin) else null;
        errdefer if (caveat) |value| gpa.free(value);
        try failures.append(gpa, .{ .origin = origin, .reproduce_blob = encoded, .caveat = caveat });
    }
    if (failures.items.len == 0 and engine.nd_active) {
        const unconfirmed = try engine.origins.unconfirmed(gpa);
        defer {
            for (unconfirmed) |origin| gpa.free(origin);
            gpa.free(unconfirmed);
        }
        const names = if (!engine.settings.report_multiple_failures and unconfirmed.len > 0) unconfirmed[0..1] else unconfirmed;
        for (names) |name| {
            const origin = try gpa.dupe(u8, name);
            errdefer gpa.free(origin);
            const caveat = try engine.origins.caveat(name);
            errdefer if (caveat) |value| gpa.free(value);
            try failures.append(gpa, .{ .origin = origin, .reproduce_blob = null, .caveat = caveat });
        }
    }
    return .{ .failures = try failures.toOwnedSlice(gpa) };
}
const Range = struct { start: usize, end: usize };
const Group = struct { label: u64, ranges: std.ArrayList(Range) = .empty };
fn spanMutation(engine: anytype, nodes: []const c.ChoiceNode, spans: []const c.Span) anyerror!void {
    const gpa = engine.allocator;
    var groups: std.ArrayList(Group) = .empty;
    defer {
        for (groups.items) |*group| group.ranges.deinit(gpa);
        groups.deinit(gpa);
    }
    for (spans) |span| {
        var index: ?usize = null;
        for (groups.items, 0..) |group, i| if (group.label == span.label) {
            index = i;
            break;
        };
        if (index == null) {
            try groups.append(gpa, .{ .label = span.label });
            index = groups.items.len - 1;
        }
        const group = &groups.items[index.?];
        var seen = false;
        for (group.ranges.items) |range| if (range.start == span.start and range.end == span.end) {
            seen = true;
            break;
        };
        if (!seen) try group.ranges.append(gpa, .{ .start = span.start, .end = span.end });
    }
    var multiple: std.ArrayList(usize) = .empty;
    defer multiple.deinit(gpa);
    const labels = try gpa.alloc(u64, groups.items.len);
    defer gpa.free(labels);
    for (groups.items, labels) |group, *label| label.* = group.label;
    const group_order = try @import("hash_order.zig").u64MapOrder(gpa, labels);
    defer gpa.free(group_order);
    for (group_order) |index| {
        const group = &groups.items[index];
        if (group.ranges.items.len < 2) continue;
        std.mem.sort(Range, group.ranges.items, {}, struct {
            fn less(_: void, a: Range, b: Range) bool {
                return if (a.start == b.start) a.end < b.end else a.start < b.start;
            }
        }.less);
        try multiple.append(gpa, index);
    }
    if (multiple.items.len == 0) return;
    var source = runner.RunResult.fromCached(try cache.CachedRun.init(gpa, .valid, null, nodes, &.{}));
    defer source.deinit(gpa);
    const values = try source.realizedValues(gpa);
    defer c.deinitValues(gpa, values);
    for (0..5) |_| {
        if (engine.valid_test_cases >= engine.settings.test_cases) break;
        const group = groups.items[multiple.items[engine.rng.range(usize, 0, multiple.items.len)]].ranges.items;
        const ia = engine.rng.range(usize, 0, group.len);
        var ib = engine.rng.range(usize, 0, group.len - 1);
        if (ib >= ia) ib += 1;
        var a = group[ia];
        var b = group[ib];
        if (a.start > b.start) std.mem.swap(Range, &a, &b);
        var proposal: std.ArrayList(c.ChoiceValueRef) = .empty;
        defer proposal.deinit(gpa);
        if (a.start <= b.start and b.end <= a.end) {
            try appendValues(gpa, &proposal, values[0..b.start]);
            try appendValues(gpa, &proposal, values[a.start..]);
        } else {
            const donor = if (engine.rng.random(bool)) a else b;
            try appendValues(gpa, &proposal, values[0..a.start]);
            try appendValues(gpa, &proposal, values[donor.start..donor.end]);
            if (a.end <= b.start) try appendValues(gpa, &proposal, values[a.end..b.start]);
            try appendValues(gpa, &proposal, values[donor.start..donor.end]);
            try appendValues(gpa, &proposal, values[b.end..]);
        }
        const owned = try gpa.alloc(c.ChoiceValue, proposal.items.len);
        var count: usize = 0;
        defer {
            for (owned[0..count]) |*value| value.deinit(gpa);
            gpa.free(owned);
        }
        for (proposal.items, owned) |value, *dest| {
            dest.* = try value.toOwned(gpa);
            count += 1;
        }
        var result = try engine.cachedTestFunction(owned, null, engine.choiceBound() -| c.flattenedValuesLen(owned));
        defer result.deinit(gpa);
        if (result.status == .interesting) return;
    }
}
fn appendValues(gpa: std.mem.Allocator, out: *std.ArrayList(c.ChoiceValueRef), values: []const c.ChoiceValue) !void {
    for (values) |*value| try out.append(gpa, value.valueRef());
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const draws = @import("../draws.zig");
const IntervalSet = @import("../intervalsets.zig").IntervalSet;
const Allocator = std.mem.Allocator;
pub const Error = draws.Error;
pub const DomainData = struct {
    allocator: Allocator,
    raw: []u8,
    top_level_domains: [][]const u8,
    pub fn init(allocator: Allocator, source: []const u8) Error!DomainData {
        const raw = try allocator.dupe(u8, source);
        errdefer allocator.free(raw);
        var domains: std.ArrayList([]const u8) = .empty;
        defer domains.deinit(allocator);
        var lines = std.mem.splitScalar(u8, raw, '\n');
        while (lines.next()) |line| {
            if (line.len == 0 and lines.index == null) break;
            const value = if (line.len > 0 and line[line.len - 1] == '\r' and lines.index != null) line[0 .. line.len - 1] else line;
            if (std.mem.startsWith(u8, value, "#") or std.mem.eql(u8, value, "ARPA")) continue;
            try domains.append(allocator, value);
        }
        std.mem.sort([]const u8, domains.items, {}, struct {
            fn less(_: void, a: []const u8, b: []const u8) bool {
                return a.len < b.len;
            }
        }.less);
        const result = try allocator.alloc([]const u8, domains.items.len + 1);
        result[0] = "COM";
        @memcpy(result[1..], domains.items);
        return .{ .allocator = allocator, .raw = raw, .top_level_domains = result };
    }
    pub fn deinit(self: *DomainData) void {
        self.allocator.free(self.top_level_domains);
        self.allocator.free(self.raw);
        self.* = undefined;
    }
};
pub const DomainSpec = struct {
    allocator: Allocator,
    max_length: usize,
    eligible_tlds: [][]const u8,
    tld_storage: []u8,
    pub fn init(allocator: Allocator, max_length: usize, top_level_domains: []const []const u8) Error!DomainSpec {
        if (max_length > 255) return error.InvalidArgument;
        var count: usize = 0;
        var bytes: usize = 0;
        for (top_level_domains) |tld| if (tld.len + 2 <= max_length) {
            count += 1;
            bytes += tld.len;
        };
        if (count == 0) return error.InvalidArgument;
        const storage = try allocator.alloc(u8, bytes);
        errdefer allocator.free(storage);
        const eligible = try allocator.alloc([]const u8, count);
        var offset: usize = 0;
        var index: usize = 0;
        for (top_level_domains) |tld| if (tld.len + 2 <= max_length) {
            @memcpy(storage[offset..][0..tld.len], tld);
            eligible[index] = storage[offset..][0..tld.len];
            offset += tld.len;
            index += 1;
        };
        return .{ .allocator = allocator, .max_length = max_length, .eligible_tlds = eligible, .tld_storage = storage };
    }
    pub fn deinit(self: *DomainSpec) void {
        self.allocator.free(self.eligible_tlds);
        self.allocator.free(self.tld_storage);
        self.* = undefined;
    }
};
pub const Context = struct {
    domain: DomainSpec,
    email_alphabet: IntervalSet,
    printable_alphabet: IntervalSet,
    fragment_alphabet: IntervalSet,
    pub fn init(allocator: Allocator, domains: []const []const u8) Error!Context {
        var domain = try DomainSpec.init(allocator, 255, domains);
        errdefer domain.deinit();
        var email = try IntervalSet.init(allocator, &.{ .{ .start = '!', .end = '!' }, .{ .start = '#', .end = '\'' }, .{ .start = '*', .end = '+' }, .{ .start = '-', .end = '-' }, .{ .start = '/', .end = '9' }, .{ .start = '=', .end = '=' }, .{ .start = 'A', .end = 'Z' }, .{ .start = '^', .end = '`' }, .{ .start = 'a', .end = 'z' }, .{ .start = '{', .end = '~' } });
        errdefer email.deinit();
        var printable = try IntervalSet.init(allocator, &.{ .{ .start = 9, .end = 13 }, .{ .start = 32, .end = 126 } });
        errdefer printable.deinit();
        return .{ .domain = domain, .email_alphabet = email, .printable_alphabet = printable, .fragment_alphabet = try IntervalSet.init(allocator, &.{.{ .start = 0, .end = 255 }}) };
    }
    pub fn deinit(self: *Context) void {
        self.domain.deinit();
        self.email_alphabet.deinit();
        self.printable_alphabet.deinit();
        self.fragment_alphabet.deinit();
        self.* = undefined;
    }
};
pub fn drawAsciiLetter(ntc: anytype) Error!u8 {
    const i: u8 = @intCast(try draws.drawInt(i128, ntc, 0, 51));
    return if (i < 26) 'a' + i else 'A' + (i - 26);
}
pub fn drawAsciiAlnum(ntc: anytype) Error!u8 {
    const i: u8 = @intCast(try draws.drawInt(i128, ntc, 0, 61));
    return if (i < 26) 'a' + i else if (i < 52) 'A' + (i - 26) else '0' + (i - 52);
}
pub fn drawAsciiAlnumOrHyphen(ntc: anytype) Error!u8 {
    const i: u8 = @intCast(try draws.drawInt(i128, ntc, 0, 62));
    return if (i < 26) 'a' + i else if (i < 52) 'A' + (i - 26) else if (i < 62) '0' + (i - 52) else '-';
}
pub fn drawDnsLabel(ntc: anytype, max_len: usize) Error![]u8 {
    const len: usize = @intCast(try draws.drawInt(i128, ntc, 1, @intCast(max_len)));
    if (len == 0) return error.InternalError;
    const label = try ntc.allocator.alloc(u8, len);
    errdefer ntc.allocator.free(label);
    label[0] = try drawAsciiLetter(ntc);
    if (len > 1) {
        for (1..len - 1) |i| label[i] = if (i == 3 and label[2] == '-') try drawAsciiAlnum(ntc) else try drawAsciiAlnumOrHyphen(ntc);
        label[len - 1] = try drawAsciiAlnum(ntc);
    }
    return label;
}
pub fn generateDomain(ntc: anytype, spec: *const DomainSpec) Error![]u8 {
    const allocator = ntc.allocator;
    const index: usize = @intCast(try draws.drawInt(i128, ntc, 0, @intCast(spec.eligible_tlds.len - 1)));
    const tld = spec.eligible_tlds[index];
    var domain: std.ArrayList(u8) = .empty;
    errdefer domain.deinit(allocator);
    for (tld) |ch| try domain.append(allocator, if (try ntc.weighted(0.5, null)) std.ascii.toLower(ch) else ch);
    var state = draws.ManyState.init(1, 126);
    while (try draws.manyMore(ntc, &state)) {
        const label = try drawDnsLabel(ntc, 63);
        defer allocator.free(label);
        if (domain.items.len + 1 + label.len > spec.max_length) continue;
        try domain.insert(allocator, 0, '.');
        try domain.insertSlice(allocator, 0, label);
    }
    return domain.toOwnedSlice(allocator);
}
fn markInvalid(ntc: anytype) Error {
    ntc.conclude(.invalid, null) catch |err| return err;
    return error.InvalidTestCase;
}
pub fn generateEmail(ntc: anytype, context: *const Context) Error![]u8 {
    const allocator = ntc.allocator;
    const local = try ntc.drawString(&context.email_alphabet, 1, 64);
    defer allocator.free(local);
    const domain = try generateDomain(ntc, &context.domain);
    defer allocator.free(domain);
    const address = try std.fmt.allocPrint(allocator, "{s}@{s}", .{ local, domain });
    errdefer allocator.free(address);
    if (address.len > 254) return markInvalid(ntc);
    return address;
}
pub fn isUrlSafe(cp: u32) bool {
    return (cp < 128 and std.ascii.isAlphanumeric(@intCast(cp))) or switch (cp) {
        '$', '-', '_', '.', '+', '!', '*', '\'', '(', ')', ',', '~' => true,
        else => false,
    };
}
pub fn isFragmentSafe(cp: u32) bool {
    return isUrlSafe(cp) or cp == '?' or cp == '/';
}
pub fn pushPercentEncoded(allocator: Allocator, out: *std.ArrayList(u8), cp: u32) Error!void {
    if (cp > 255) return error.InternalError;
    const hex = "0123456789ABCDEF";
    try out.appendSlice(allocator, &.{ '%', hex[cp >> 4], hex[cp & 15] });
}
pub fn urlEncodePath(allocator: Allocator, text: []const u8) Error![]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    const view = std.unicode.Utf8View.init(text) catch return error.InternalError;
    var it = view.iterator();
    while (it.nextCodepoint()) |cp| {
        if (isUrlSafe(cp)) try out.append(allocator, @intCast(cp)) else try pushPercentEncoded(allocator, &out, cp);
    }
    return out.toOwnedSlice(allocator);
}
pub fn urlEncodeFragment(ntc: anytype, text: []const u8) Error![]u8 {
    const allocator = ntc.allocator;
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    const view = std.unicode.Utf8View.init(text) catch return error.InternalError;
    var it = view.iterator();
    while (it.nextCodepoint()) |cp| {
        const force = try ntc.weighted(0.5, null);
        if (force or !isFragmentSafe(cp)) try pushPercentEncoded(allocator, &out, cp) else try out.append(allocator, @intCast(cp));
    }
    return out.toOwnedSlice(allocator);
}
pub fn generateUrl(ntc: anytype, context: *const Context) Error![]u8 {
    const allocator = ntc.allocator;
    const scheme: []const u8 = if (try ntc.weighted(0.5, null)) "https" else "http";
    const domain = try generateDomain(ntc, &context.domain);
    defer allocator.free(domain);
    const port = if (try ntc.weighted(0.5, null)) try std.fmt.allocPrint(allocator, ":{}", .{try draws.drawInt(i128, ntc, 1, 65535)}) else try allocator.alloc(u8, 0);
    defer allocator.free(port);
    var state = draws.ManyState.init(0, null);
    var path: std.ArrayList(u8) = .empty;
    defer path.deinit(allocator);
    var count: usize = 0;
    while (try draws.manyMore(ntc, &state)) {
        const raw = try ntc.drawString(&context.printable_alphabet, 0, 100);
        defer allocator.free(raw);
        const encoded = try urlEncodePath(allocator, raw);
        defer allocator.free(encoded);
        if (count > 0) try path.append(allocator, '/');
        try path.appendSlice(allocator, encoded);
        count += 1;
    }
    var fragment: std.ArrayList(u8) = .empty;
    defer fragment.deinit(allocator);
    if (try ntc.weighted(0.5, null)) {
        const raw = try ntc.drawString(&context.fragment_alphabet, 1, 100);
        defer allocator.free(raw);
        const encoded = try urlEncodeFragment(ntc, raw);
        defer allocator.free(encoded);
        try fragment.append(allocator, '#');
        try fragment.appendSlice(allocator, encoded);
    }
    return std.fmt.allocPrint(allocator, "{s}://{s}{s}/{s}{s}", .{ scheme, domain, port, path.items, fragment.items });
}
test "domain ordering retains duplicate COM and stable equal-length order" {
    var data = try DomainData.init(std.testing.allocator, "# fixture\nARPA\nCOM\nAA\nBB\nLONG\n");
    defer data.deinit();
    try std.testing.expectEqualStrings("COM", data.top_level_domains[0]);
    try std.testing.expectEqualStrings("AA", data.top_level_domains[1]);
    try std.testing.expectEqualStrings("BB", data.top_level_domains[2]);
    try std.testing.expectEqualStrings("COM", data.top_level_domains[3]);
    const encoded = try urlEncodePath(std.testing.allocator, "a b/$é");
    defer std.testing.allocator.free(encoded);
    try std.testing.expectEqualStrings("a%20b%2F$%E9", encoded);
}

pub fn defaultDomains(allocator: Allocator) Error!DomainData {
    return DomainData.init(allocator, @embedFile("tlds.txt"));
}

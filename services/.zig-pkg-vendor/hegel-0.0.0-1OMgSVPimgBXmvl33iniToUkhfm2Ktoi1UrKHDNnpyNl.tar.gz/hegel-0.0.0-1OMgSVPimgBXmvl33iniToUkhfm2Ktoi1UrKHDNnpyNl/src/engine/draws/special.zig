// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const draws = @import("../draws.zig");
const Error = draws.Error;
pub const Date = struct {
    year: i32,
    month: u8,
    day: u8,
    pub fn format(self: Date, writer: *std.Io.Writer) std.Io.Writer.Error!void {
        try writer.print("Date {{ year: {}, month: {}, day: {} }}", .{ self.year, self.month, self.day });
    }
};
pub const Time = struct {
    hour: u8,
    minute: u8,
    second: u8,
    nanosecond: u32,
    pub fn format(self: Time, writer: *std.Io.Writer) std.Io.Writer.Error!void {
        try writer.print("Time {{ hour: {}, minute: {}, second: {}, nanosecond: {} }}", .{ self.hour, self.minute, self.second, self.nanosecond });
    }
};
pub const DateTime = struct {
    date: Date,
    time: Time,
    pub fn format(self: DateTime, writer: *std.Io.Writer) std.Io.Writer.Error!void {
        try writer.print("DateTime {{ date: {f}, time: {f} }}", .{ self.date, self.time });
    }
};
const pad = @import("../rust_fmt.zig").paddedDecimal;
pub const MIN_YEAR: i32 = -999999;
pub const MAX_YEAR: i32 = 999999;
pub const LAST_NS_OF_DAY: i64 = 86400000000000 - 1;
pub fn daysInMonth(year: i32, month: u8) i64 {
    return switch (month) {
        1, 3, 5, 7, 8, 10, 12 => 31,
        4, 6, 9, 11 => 30,
        2 => if (@rem(year, 4) == 0 and (@rem(year, 100) != 0 or @rem(year, 400) == 0)) 29 else 28,
        else => unreachable,
    };
}
pub fn daysFromCivil(d: Date) i64 {
    const y = @as(i64, d.year) - @intFromBool(d.month <= 2);
    const era = @divFloor(y, 400);
    const yoe = y - era * 400;
    const mp = @as(i64, d.month) + @as(i64, if (d.month > 2) -3 else 9);
    const doy = @divTrunc(153 * mp + 2, 5) + d.day - 1;
    const doe = yoe * 365 + @divTrunc(yoe, 4) - @divTrunc(yoe, 100) + doy;
    return era * 146097 + doe - 719468;
}
pub fn civilFromDays(input: i64) Date {
    const z = input + 719468;
    const era = @divFloor(z, 146097);
    const doe = z - era * 146097;
    const yoe = @divTrunc(doe - @divTrunc(doe, 1460) + @divTrunc(doe, 36524) - @divTrunc(doe, 146096), 365);
    const y = yoe + era * 400;
    const doy = doe - (365 * yoe + @divTrunc(yoe, 4) - @divTrunc(yoe, 100));
    const mp = @divTrunc(5 * doy + 2, 153);
    const day: u8 = @intCast(doy - @divTrunc(153 * mp + 2, 5) + 1);
    const month: u8 = @intCast(if (mp < 10) mp + 3 else mp - 9);
    return .{ .year = @intCast(y + @intFromBool(month <= 2)), .month = month, .day = day };
}
pub fn validateDate(ntc: anytype, what: []const u8, d: Date) Error!void {
    const valid = d.year >= MIN_YEAR and d.year <= MAX_YEAR and d.month >= 1 and d.month <= 12 and d.day >= 1 and d.day <= daysInMonth(d.year, d.month);
    if (!valid) return draws.invalid(ntc, "{s} is not a valid date (year in [{}, {}]): {f}-{f}-{f}", .{ what, MIN_YEAR, MAX_YEAR, pad(d.year, 5), pad(d.month, 2), pad(d.day, 2) });
}
pub fn validateTime(ntc: anytype, what: []const u8, t: Time) Error!void {
    if (!(t.hour <= 23 and t.minute <= 59 and t.second <= 59 and t.nanosecond <= 999999999)) return draws.invalid(ntc, "{s} is not a valid time: {f}:{f}:{f}.{f}", .{ what, pad(t.hour, 2), pad(t.minute, 2), pad(t.second, 2), pad(t.nanosecond, 9) });
}
pub fn timeToNs(t: Time) i64 {
    return ((@as(i64, t.hour) * 60 + t.minute) * 60 + t.second) * 1000000000 + t.nanosecond;
}
pub fn timeFromNs(ns: i64) Time {
    return .{ .hour = @intCast(@divTrunc(ns, 3600000000000)), .minute = @intCast(@rem(@divTrunc(ns, 60000000000), 60)), .second = @intCast(@rem(@divTrunc(ns, 1000000000), 60)), .nanosecond = @intCast(@rem(ns, 1000000000)) };
}
pub fn drawDateIn(ntc: anytype, min: i64, max: i64) Error!Date {
    const center = std.math.clamp(daysFromCivil(.{ .year = 2000, .month = 1, .day = 1 }), min, max);
    const offset = try draws.drawInt(i64, ntc, min - center, max - center);
    return civilFromDays(center + offset);
}
pub fn drawTimeIn(ntc: anytype, min: i64, max: i64) Error!Time {
    return timeFromNs(min + try draws.drawInt(i64, ntc, 0, max - min));
}
pub fn generateDate(ntc: anytype, min: Date, max: Date) Error!Date {
    try validateDate(ntc, "min_value", min);
    try validateDate(ntc, "max_value", max);
    const lo = daysFromCivil(min);
    const hi = daysFromCivil(max);
    if (lo > hi) return draws.invalid(ntc, "generate_date requires min_value <= max_value, got [{f}, {f}]", .{ min, max });
    try draws.begin(ntc, draws.LABEL_DATE);
    defer ntc.stopSpan(false);
    return drawDateIn(ntc, lo, hi);
}
pub fn generateTime(ntc: anytype, min: Time, max: Time) Error!Time {
    try validateTime(ntc, "min_value", min);
    try validateTime(ntc, "max_value", max);
    const lo = timeToNs(min);
    const hi = timeToNs(max);
    if (lo > hi) return draws.invalid(ntc, "generate_time requires min_value <= max_value, got [{f}, {f}]", .{ min, max });
    try draws.begin(ntc, draws.LABEL_TIME);
    defer ntc.stopSpan(false);
    return drawTimeIn(ntc, lo, hi);
}
pub fn generateDatetime(ntc: anytype, min: DateTime, max: DateTime) Error!DateTime {
    try validateDate(ntc, "min_value.date", min.date);
    try validateDate(ntc, "max_value.date", max.date);
    try validateTime(ntc, "min_value.time", min.time);
    try validateTime(ntc, "max_value.time", max.time);
    const min_days = daysFromCivil(min.date);
    const max_days = daysFromCivil(max.date);
    const min_ns = timeToNs(min.time);
    const max_ns = timeToNs(max.time);
    if (min_days > max_days or (min_days == max_days and min_ns > max_ns)) return draws.invalid(ntc, "generate_datetime requires min_value <= max_value, got [{f}, {f}]", .{ min, max });
    try draws.begin(ntc, draws.LABEL_DATETIME);
    defer ntc.stopSpan(false);
    const date = try drawDateIn(ntc, min_days, max_days);
    const day = daysFromCivil(date);
    return .{ .date = date, .time = try drawTimeIn(ntc, if (day == min_days) min_ns else 0, if (day == max_days) max_ns else LAST_NS_OF_DAY) };
}
pub fn generateUuid(ntc: anytype, version: ?u8) Error![16]u8 {
    if (version) |v| if (v > 15) return draws.invalid(ntc, "uuid version must be a single hex nibble (0..=15), got {}", .{v});
    try draws.begin(ntc, draws.LABEL_UUID);
    defer ntc.stopSpan(false);
    const hi = try draws.drawInt(u64, ntc, 0, std.math.maxInt(u64));
    const lo = try draws.drawInt(u64, ntc, 0, std.math.maxInt(u64));
    var n = (@as(u128, hi) << 64) | lo;
    if (version) |v| {
        n &= ~(@as(u128, 0xc000) << 48);
        n |= @as(u128, 0x8000) << 48;
        n &= ~(@as(u128, 0xf000) << 64);
        n |= @as(u128, v) << 76;
    } else if (n == 0) {
        n = 1;
    }
    var bytes: [16]u8 = undefined;
    std.mem.writeInt(u128, &bytes, n, .big);
    return bytes;
}
pub const V4Network = struct { base: u32, size_minus_1: u32 };
pub const V6Network = struct { base: u128, size_minus_1: u128 };
pub fn parseV4Cidr(value: []const u8) Error!V4Network {
    const slash = std.mem.indexOfScalar(u8, value, '/') orelse return error.InternalError;
    const address = std.Io.net.Ip4Address.parse(value[0..slash], 0) catch return error.InternalError;
    const prefix = std.fmt.parseInt(u6, value[slash + 1 ..], 10) catch return error.InternalError;
    if (prefix < 1 or prefix > 32) return error.InternalError;
    const mask = @as(u32, std.math.maxInt(u32)) << @as(u5, @intCast(32 - prefix));
    return .{ .base = std.mem.readInt(u32, &address.bytes, .big) & mask, .size_minus_1 = ~mask };
}
pub fn parseV6Cidr(value: []const u8) Error!V6Network {
    const slash = std.mem.indexOfScalar(u8, value, '/') orelse return error.InternalError;
    const address = try parseIpv6(value[0..slash]);
    const prefix = std.fmt.parseInt(u8, value[slash + 1 ..], 10) catch return error.InternalError;
    if (prefix < 1 or prefix > 128) return error.InternalError;
    const mask = @as(u128, std.math.maxInt(u128)) << @as(u7, @intCast(128 - prefix));
    if (~mask > @as(u128, std.math.maxInt(i128))) return error.InternalError;
    return .{ .base = address & mask, .size_minus_1 = ~mask };
}
pub const SPECIAL_IPV4_CIDRS = [_][]const u8{
    "0.0.0.0/8",
    "10.0.0.0/8",
    "100.64.0.0/10",
    "127.0.0.0/8",
    "169.254.0.0/16",
    "172.16.0.0/12",
    "192.0.0.0/24",
    "192.0.0.0/29",
    "192.0.0.8/32",
    "192.0.0.9/32",
    "192.0.0.10/32",
    "192.0.0.170/32",
    "192.0.0.171/32",
    "192.0.2.0/24",
    "192.31.196.0/24",
    "192.52.193.0/24",
    "192.88.99.0/24",
    "192.168.0.0/16",
    "192.175.48.0/24",
    "198.18.0.0/15",
    "198.51.100.0/24",
    "203.0.113.0/24",
    "240.0.0.0/4",
    "255.255.255.255/32",
};
pub const SPECIAL_IPV4_NETWORKS = blk: {
    @setEvalBranchQuota(100000);
    var result: [SPECIAL_IPV4_CIDRS.len]V4Network = undefined;
    for (SPECIAL_IPV4_CIDRS, 0..) |cidr, i| result[i] = parseV4Cidr(cidr) catch unreachable;
    break :blk result;
};
pub const SPECIAL_IPV6_CIDRS = [_][]const u8{
    "::1/128",
    "::/128",
    "::ffff:0:0/96",
    "64:ff9b::/96",
    "64:ff9b:1::/48",
    "100::/64",
    "2001::/23",
    "2001::/32",
    "2001:1::1/128",
    "2001:1::2/128",
    "2001:2::/48",
    "2001:3::/32",
    "2001:4:112::/48",
    "2001:10::/28",
    "2001:20::/28",
    "2001:db8::/32",
    "2002::/16",
    "2620:4f:8000::/48",
    "fc00::/7",
    "fe80::/10",
};
pub const SPECIAL_IPV6_NETWORKS = blk: {
    @setEvalBranchQuota(100000);
    var result: [SPECIAL_IPV6_CIDRS.len]V6Network = undefined;
    for (SPECIAL_IPV6_CIDRS, 0..) |cidr, i| result[i] = parseV6Cidr(cidr) catch unreachable;
    break :blk result;
};
pub fn generateIpv4(ntc: anytype) Error![4]u8 {
    try draws.begin(ntc, draws.LABEL_IP_ADDRESS);
    defer ntc.stopSpan(false);
    return drawIpv4(ntc);
}
pub fn generateIpv6(ntc: anytype) Error![16]u8 {
    try draws.begin(ntc, draws.LABEL_IP_ADDRESS);
    defer ntc.stopSpan(false);
    return drawIpv6(ntc);
}
pub fn drawIpv4(ntc: anytype) Error![4]u8 {
    const address: u32 = if (try draws.drawInt(i64, ntc, 0, 1) == 0) blk: {
        const a: u32 = @intCast(try draws.drawInt(i64, ntc, 0, 255));
        const b: u32 = @intCast(try draws.drawInt(i64, ntc, 0, 255));
        const c: u32 = @intCast(try draws.drawInt(i64, ntc, 0, 255));
        const d: u32 = @intCast(try draws.drawInt(i64, ntc, 0, 255));
        break :blk (a << 24) | (b << 16) | (c << 8) | d;
    } else blk: {
        const index: usize = @intCast(try draws.drawInt(i64, ntc, 0, SPECIAL_IPV4_NETWORKS.len - 1));
        const net = SPECIAL_IPV4_NETWORKS[index];
        const offset: u32 = @intCast(try draws.drawInt(i64, ntc, 0, net.size_minus_1));
        break :blk net.base + offset;
    };
    var bytes: [4]u8 = undefined;
    std.mem.writeInt(u32, &bytes, address, .big);
    return bytes;
}
pub fn drawIpv6(ntc: anytype) Error![16]u8 {
    const address: u128 = if (try draws.drawInt(i64, ntc, 0, 1) == 0) blk: {
        const hi = try draws.drawInt(u64, ntc, 0, std.math.maxInt(u64));
        const lo = try draws.drawInt(u64, ntc, 0, std.math.maxInt(u64));
        break :blk (@as(u128, hi) << 64) | lo;
    } else blk: {
        const index: usize = @intCast(try draws.drawInt(i64, ntc, 0, SPECIAL_IPV6_NETWORKS.len - 1));
        const net = SPECIAL_IPV6_NETWORKS[index];
        break :blk net.base + try draws.drawInt(u128, ntc, 0, net.size_minus_1);
    };
    var bytes: [16]u8 = undefined;
    std.mem.writeInt(u128, &bytes, address, .big);
    return bytes;
}
test "Gregorian conversion over the full supported year envelope" {
    try std.testing.expectEqual(@as(i64, 0), daysFromCivil(.{ .year = 1970, .month = 1, .day = 1 }));
    for ([_]i32{ -999999, -400, -100, -1, 0, 1, 1900, 2000, 2024, 999999 }) |year| {
        for (1..13) |month| {
            const d: Date = .{ .year = year, .month = @intCast(month), .day = @intCast(daysInMonth(year, @intCast(month))) };
            try std.testing.expectEqual(d, civilFromDays(daysFromCivil(d)));
        }
    }
}

fn ipv6Parts(text: []const u8, parts: *[8]u16) Error!usize {
    if (text.len == 0) return 0;
    var count: usize = 0;
    var tokens = std.mem.splitScalar(u8, text, ':');
    while (tokens.next()) |token| {
        if (token.len == 0 or count >= 8) return error.InternalError;
        if (std.mem.indexOfScalar(u8, token, '.') != null) {
            if (count >= 7 or tokens.next() != null) return error.InternalError;
            const v4 = std.Io.net.Ip4Address.parse(token, 0) catch return error.InternalError;
            parts[count] = std.mem.readInt(u16, v4.bytes[0..2], .big);
            parts[count + 1] = std.mem.readInt(u16, v4.bytes[2..4], .big);
            count += 2;
        } else {
            if (token.len > 4) return error.InternalError;
            parts[count] = std.fmt.parseInt(u16, token, 16) catch return error.InternalError;
            count += 1;
        }
    }
    return count;
}
pub fn parseIpv6(text: []const u8) Error!u128 {
    var parts: [8]u16 = @splat(0);
    if (std.mem.indexOf(u8, text, "::")) |compression| {
        if (std.mem.indexOf(u8, text[compression + 2 ..], "::") != null) return error.InternalError;
        const left = try ipv6Parts(text[0..compression], &parts);
        var right: [8]u16 = undefined;
        const n = try ipv6Parts(text[compression + 2 ..], &right);
        if (left + n >= 8) return error.InternalError;
        @memcpy(parts[8 - n ..], right[0..n]);
    } else if (try ipv6Parts(text, &parts) != 8) return error.InternalError;
    var result: u128 = 0;
    for (parts) |part| result = (result << 16) | part;
    return result;
}

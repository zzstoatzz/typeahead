// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const unicode = @import("../unicodedata.zig");
const sets = @import("../intervalsets.zig");
const IntervalSet = sets.IntervalSet;
const Interval = sets.Interval;
const Allocator = std.mem.Allocator;
pub const Error = Allocator.Error || error{ InvalidArgument, InternalError };
pub const TextAlphabet = struct {
    codec: ?[]const u8 = null,
    min_codepoint: u32 = 0,
    max_codepoint: u32 = std.math.maxInt(u32),
    categories: ?[]const []const u8 = null,
    exclude_categories: ?[]const []const u8 = null,
    include_characters: ?[]const u8 = null,
    exclude_characters: ?[]const u8 = null,
};
pub fn isValidCategory(category: []const u8) bool {
    return if (category.len == 1) std.mem.indexOfScalar(u8, "LMNPSZC", category[0]) != null else unicode.Category.fromCode(category) != null;
}
pub fn rangeMinusSurrogates(allocator: Allocator, min: u32, max: u32) Error!IntervalSet {
    if (min > max) return IntervalSet.init(allocator, &.{});
    var intervals: [2]Interval = undefined;
    var count: usize = 0;
    if (max < 0xd800 or min > 0xdfff) {
        intervals[0] = .{ .start = min, .end = max };
        count = 1;
    } else {
        if (min < 0xd800) {
            intervals[count] = .{ .start = min, .end = 0xd7ff };
            count += 1;
        }
        if (max > 0xdfff) {
            intervals[count] = .{ .start = 0xe000, .end = max };
            count += 1;
        }
    }
    return IntervalSet.init(allocator, intervals[0..count]);
}
pub fn charsToIntervals(allocator: Allocator, chars: []const u8) Error!IntervalSet {
    var points: std.ArrayList(u32) = .empty;
    defer points.deinit(allocator);
    const view = std.unicode.Utf8View.init(chars) catch return error.InvalidArgument;
    var it = view.iterator();
    while (it.nextCodepoint()) |cp| try points.append(allocator, cp);
    std.mem.sort(u32, points.items, {}, std.sort.asc(u32));
    var ranges: std.ArrayList(Interval) = .empty;
    defer ranges.deinit(allocator);
    for (points.items) |cp| {
        if (ranges.items.len > 0) {
            const last = &ranges.items[ranges.items.len - 1];
            if (cp <= last.end) continue;
            if (cp == last.end + 1) {
                last.end = cp;
                continue;
            }
        }
        try ranges.append(allocator, .{ .start = cp, .end = cp });
    }
    return IntervalSet.init(allocator, ranges.items);
}
pub fn categoryIntervalset(allocator: Allocator, category: []const u8) Error!IntervalSet {
    var ranges: std.ArrayList(Interval) = .empty;
    defer ranges.deinit(allocator);
    var start: u32 = 0;
    for (unicode.ranges) |run| {
        if (unicode.groupMatches(run.category.asStr(), category)) {
            var segment = try rangeMinusSurrogates(allocator, start, run.end);
            defer segment.deinit();
            for (segment.intervals) |range| {
                if (ranges.items.len > 0 and ranges.items[ranges.items.len - 1].end + 1 == range.start) {
                    ranges.items[ranges.items.len - 1].end = range.end;
                } else try ranges.append(allocator, range);
            }
        }
        start = run.end + 1;
    }
    return IntervalSet.init(allocator, ranges.items);
}
pub fn categoriesUnion(allocator: Allocator, categories: []const []const u8) Error!IntervalSet {
    var result = try IntervalSet.init(allocator, &.{});
    errdefer result.deinit();
    for (categories) |category| {
        var single = try categoryIntervalset(allocator, category);
        defer single.deinit();
        const combined = try result.unionWith(&single);
        result.deinit();
        result = combined;
    }
    return result;
}
pub fn buildIntervals(allocator: Allocator, alphabet: TextAlphabet) Error!IntervalSet {
    const codec_max: u32 = if (alphabet.codec) |codec| blk: {
        if (std.mem.eql(u8, codec, "ascii")) break :blk 127;
        if (std.mem.eql(u8, codec, "latin-1") or std.mem.eql(u8, codec, "iso-8859-1")) break :blk 255;
        if (std.mem.eql(u8, codec, "utf-8")) break :blk 0x10ffff;
        return error.InvalidArgument;
    } else 0x10ffff;
    const category_lists = [_]?[]const []const u8{ alphabet.categories, alphabet.exclude_categories };
    for (category_lists) |list| if (list) |categories| {
        for (categories) |category| if (!isValidCategory(category)) return error.InvalidArgument;
    };
    var included = try charsToIntervals(allocator, alphabet.include_characters orelse "");
    defer included.deinit();
    var excluded = try charsToIntervals(allocator, alphabet.exclude_characters orelse "");
    defer excluded.deinit();
    if (alphabet.codec != null) {
        for (included.intervals) |range| if (range.end > codec_max) return error.InvalidArgument;
    }
    var overlap = try included.intersection(&excluded);
    defer overlap.deinit();
    if (!overlap.isEmpty()) return error.InvalidArgument;
    var result = try rangeMinusSurrogates(allocator, alphabet.min_codepoint, @min(codec_max, alphabet.max_codepoint));
    errdefer result.deinit();
    if (alphabet.categories) |categories| {
        var union_set = try categoriesUnion(allocator, categories);
        defer union_set.deinit();
        const next = try result.intersection(&union_set);
        result.deinit();
        result = next;
    } else if (alphabet.exclude_categories) |categories| {
        var union_set = try categoriesUnion(allocator, categories);
        defer union_set.deinit();
        const next = try result.difference(&union_set);
        result.deinit();
        result = next;
    }
    if (!excluded.isEmpty()) {
        const next = try result.difference(&excluded);
        result.deinit();
        result = next;
    }
    if (!included.isEmpty()) {
        const next = try result.unionWith(&included);
        result.deinit();
        result = next;
    }
    return result;
}
test "category alphabet composition" {
    var letters = try buildIntervals(std.testing.allocator, .{ .codec = "ascii", .categories = &.{"L"}, .include_characters = "0", .exclude_characters = "A" });
    defer letters.deinit();
    try std.testing.expect(letters.contains('a'));
    try std.testing.expect(!letters.contains('A'));
    try std.testing.expect(letters.contains('0'));
    try std.testing.expect(!letters.contains('1'));
    try std.testing.expectError(error.InvalidArgument, buildIntervals(std.testing.allocator, .{ .include_characters = "x", .exclude_characters = "x" }));
}

pub const AlphabetCache = struct {
    allocator: Allocator,
    entries: std.ArrayList(Entry) = .empty,
    pub const limit = 64;
    const Entry = struct { arena: std.heap.ArenaAllocator, alphabet: TextAlphabet, intervals: IntervalSet };

    pub fn deinit(self: *AlphabetCache) void {
        self.clear();
        self.entries.deinit(self.allocator);
        self.* = undefined;
    }

    pub fn clear(self: *AlphabetCache) void {
        for (self.entries.items) |*entry| entry.arena.deinit();
        self.entries.clearRetainingCapacity();
    }

    pub fn build(self: *AlphabetCache, allocator: Allocator, alphabet: TextAlphabet) Error!IntervalSet {
        for (self.entries.items) |entry| if (alphabetEql(entry.alphabet, alphabet)) return entry.intervals.cloneWithAllocator(allocator);
        var arena: std.heap.ArenaAllocator = .init(self.allocator);
        errdefer arena.deinit();
        const owned = try ownAlphabet(arena.allocator(), alphabet);
        const intervals = try buildIntervals(arena.allocator(), owned);
        const result = try intervals.cloneWithAllocator(allocator);
        errdefer {
            var mutable = result;
            mutable.deinit();
        }
        if (self.entries.items.len >= limit) self.clear();
        try self.entries.append(self.allocator, .{ .arena = arena, .alphabet = owned, .intervals = intervals });
        return result;
    }
};

fn optionalEql(a: ?[]const u8, b: ?[]const u8) bool {
    if (a) |av| return if (b) |bv| std.mem.eql(u8, av, bv) else false;
    return b == null;
}
fn listEql(a: ?[]const []const u8, b: ?[]const []const u8) bool {
    const av = a orelse return b == null;
    const bv = b orelse return false;
    if (av.len != bv.len) return false;
    for (av, bv) |aa, bb| if (!std.mem.eql(u8, aa, bb)) return false;
    return true;
}
fn alphabetEql(a: TextAlphabet, b: TextAlphabet) bool {
    return a.min_codepoint == b.min_codepoint and a.max_codepoint == b.max_codepoint and optionalEql(a.codec, b.codec) and listEql(a.categories, b.categories) and listEql(a.exclude_categories, b.exclude_categories) and optionalEql(a.include_characters, b.include_characters) and optionalEql(a.exclude_characters, b.exclude_characters);
}
fn ownOptional(allocator: Allocator, value: ?[]const u8) Allocator.Error!?[]const u8 {
    return if (value) |text| try allocator.dupe(u8, text) else null;
}
fn ownList(allocator: Allocator, value: ?[]const []const u8) Allocator.Error!?[]const []const u8 {
    const list = value orelse return null;
    const result = try allocator.alloc([]const u8, list.len);
    for (list, 0..) |item, i| result[i] = try allocator.dupe(u8, item);
    return result;
}
fn ownAlphabet(allocator: Allocator, alphabet: TextAlphabet) Allocator.Error!TextAlphabet {
    return .{ .codec = try ownOptional(allocator, alphabet.codec), .min_codepoint = alphabet.min_codepoint, .max_codepoint = alphabet.max_codepoint, .categories = try ownList(allocator, alphabet.categories), .exclude_categories = try ownList(allocator, alphabet.exclude_categories), .include_characters = try ownOptional(allocator, alphabet.include_characters), .exclude_characters = try ownOptional(allocator, alphabet.exclude_characters) };
}
fn cacheAllocationPaths(allocator: Allocator) !void {
    var cache: AlphabetCache = .{ .allocator = allocator };
    defer cache.deinit();
    const alphabet: TextAlphabet = .{ .codec = "ascii", .categories = &.{"L"}, .include_characters = "0", .exclude_characters = "A" };
    var first = try cache.build(allocator, alphabet);
    defer first.deinit();
    var second = try cache.build(allocator, alphabet);
    defer second.deinit();
    try std.testing.expect(first.eql(&second));
    try std.testing.expectEqual(@as(usize, 1), cache.entries.items.len);
}
test "alphabet cache owns keys and survives allocation failures" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, cacheAllocationPaths, .{});
}

fn writeDebugCharacter(allocator: Allocator, out: *std.ArrayList(u8), cp: u21, string: bool) Allocator.Error!void {
    const escaped: ?[]const u8 = switch (cp) {
        0 => "\\0",
        9 => "\\t",
        10 => "\\n",
        13 => "\\r",
        '\\' => "\\\\",
        '\'' => if (string) null else "\\'",
        '"' => if (string) "\\\"" else null,
        else => null,
    };
    if (escaped) |text| {
        try out.appendSlice(allocator, text);
        return;
    }
    if (cp != '\'' and cp != '"' and @import("../unicode_char.zig").needsDebugEscape(cp)) {
        const text = try std.fmt.allocPrint(allocator, "\\u{{{x}}}", .{cp});
        defer allocator.free(text);
        try out.appendSlice(allocator, text);
        return;
    }
    var bytes: [4]u8 = undefined;
    const n = std.unicode.utf8Encode(cp, &bytes) catch unreachable;
    try out.appendSlice(allocator, bytes[0..n]);
}
pub fn debugString(allocator: Allocator, text: []const u8) Error![]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    try out.append(allocator, '"');
    const view = std.unicode.Utf8View.init(text) catch return error.InvalidArgument;
    var it = view.iterator();
    while (it.nextCodepoint()) |cp| try writeDebugCharacter(allocator, &out, cp, true);
    try out.append(allocator, '"');
    return out.toOwnedSlice(allocator);
}
fn debugChars(allocator: Allocator, points: []const u21) Allocator.Error![]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    try out.append(allocator, '[');
    for (points, 0..) |cp, i| {
        if (i > 0) try out.appendSlice(allocator, ", ");
        try out.append(allocator, '\'');
        try writeDebugCharacter(allocator, &out, cp, false);
        try out.append(allocator, '\'');
    }
    try out.append(allocator, ']');
    return out.toOwnedSlice(allocator);
}
fn detailedError(allocator: Allocator, diagnostic: ?*?[]u8, comptime format: []const u8, args: anytype) Error {
    if (diagnostic) |out| out.* = std.fmt.allocPrint(allocator, format, args) catch return error.OutOfMemory;
    return error.InvalidArgument;
}
pub fn buildIntervalsDetailed(allocator: Allocator, alphabet: TextAlphabet, diagnostic: ?*?[]u8) Error!IntervalSet {
    const codec_max: u32 = if (alphabet.codec) |codec| blk: {
        if (std.mem.eql(u8, codec, "ascii")) break :blk 127;
        if (std.mem.eql(u8, codec, "latin-1") or std.mem.eql(u8, codec, "iso-8859-1")) break :blk 255;
        if (std.mem.eql(u8, codec, "utf-8")) break :blk 0x10ffff;
        return detailedError(allocator, diagnostic, "invalid codec: {s}", .{codec});
    } else 0x10ffff;
    for ([_]?[]const []const u8{ alphabet.categories, alphabet.exclude_categories }) |list| if (list) |categories| {
        for (categories) |category| if (!isValidCategory(category)) {
            const quoted = try debugString(allocator, category);
            defer allocator.free(quoted);
            return detailedError(allocator, diagnostic, "{s} is not a valid Unicode category", .{quoted});
        };
    };
    const include = alphabet.include_characters orelse "";
    const exclude = alphabet.exclude_characters orelse "";
    const include_view = std.unicode.Utf8View.init(include) catch return error.InvalidArgument;
    const exclude_view = std.unicode.Utf8View.init(exclude) catch return error.InvalidArgument;
    if (alphabet.codec) |codec| {
        var bad: std.ArrayList(u21) = .empty;
        defer bad.deinit(allocator);
        var it = include_view.iterator();
        while (it.nextCodepoint()) |cp| if (cp > codec_max) try bad.append(allocator, cp);
        if (bad.items.len > 0) {
            const chars_debug = try debugChars(allocator, bad.items);
            defer allocator.free(chars_debug);
            const codec_debug = try debugString(allocator, codec);
            defer allocator.free(codec_debug);
            return detailedError(allocator, diagnostic, "include_characters {s} cannot be encoded by codec {s}", .{ chars_debug, codec_debug });
        }
    }
    if (alphabet.include_characters != null and alphabet.exclude_characters != null) {
        var overlap: std.ArrayList(u21) = .empty;
        defer overlap.deinit(allocator);
        var it = include_view.iterator();
        while (it.nextCodepoint()) |cp| {
            var excluded = exclude_view.iterator();
            while (excluded.nextCodepoint()) |other| if (cp == other) {
                try overlap.append(allocator, cp);
                break;
            };
        }
        if (overlap.items.len > 0) {
            const chars_debug = try debugChars(allocator, overlap.items);
            defer allocator.free(chars_debug);
            const incl_debug = try debugString(allocator, include);
            defer allocator.free(incl_debug);
            const excl_debug = try debugString(allocator, exclude);
            defer allocator.free(excl_debug);
            return detailedError(allocator, diagnostic, "characters {s} are present in both include_characters={s} and exclude_characters={s} (overlap)", .{ chars_debug, incl_debug, excl_debug });
        }
    }
    return buildIntervals(allocator, alphabet);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const draws = @import("../draws.zig");
const p = @import("../re/parser.zig");
const c = @import("../re/constants.zig");
const fold = @import("../re/casefold.zig");
const unicode = @import("../unicodedata.zig");
const IntervalSet = @import("../intervalsets.zig").IntervalSet;
const Mutex = @import("../sync.zig").Mutex;
const Allocator = std.mem.Allocator;
pub const Error = draws.Error;
const InKey = struct { ptr: usize, len: usize, flags: u32 };
const CharKey = struct { cp: u32, flags: u32 };
const ProducibleKey = struct { ptr: usize, flags: u32 };
const CASE_FLAGS = c.SRE_FLAG_IGNORECASE | c.SRE_FLAG_ASCII;
pub const Caches = struct {
    in_cache: std.AutoHashMapUnmanaged(InKey, []const u32) = .empty,
    char_cache: std.AutoHashMapUnmanaged(CharKey, []const u32) = .empty,
    producible: std.AutoHashMapUnmanaged(ProducibleKey, bool) = .empty,
    fn deinit(self: *Caches, allocator: Allocator) void {
        var ins = self.in_cache.valueIterator();
        while (ins.next()) |value| allocator.free(value.*);
        var chars = self.char_cache.valueIterator();
        while (chars.next()) |value| allocator.free(value.*);
        self.in_cache.deinit(allocator);
        self.char_cache.deinit(allocator);
        self.producible.deinit(allocator);
    }
};
const SharedCache = struct { caches: Caches = .{}, mutex: Mutex = .{} };
pub const CompiledRegex = struct {
    allocator: Allocator,
    parsed: p.Result,
    alphabet: ?IntervalSet,
    shared: *SharedCache,
    pub fn compile(allocator: Allocator, pattern: []const u8, alphabet: ?*const IntervalSet, diagnostic: ?*?[]u8) Error!CompiledRegex {
        var parsed = try p.parsePattern(allocator, pattern, 0);
        errdefer parsed.deinit();
        if (parsed.failure) |failure| {
            if (diagnostic) |out| {
                const quoted = try @import("text.zig").debugString(allocator, pattern);
                defer allocator.free(quoted);
                out.* = try std.fmt.allocPrint(allocator, "invalid regex pattern {s}: {s} at position {}", .{ quoted, failure.msg, failure.pos });
            }
            return error.InvalidArgument;
        }
        const shared = try allocator.create(SharedCache);
        errdefer allocator.destroy(shared);
        shared.* = .{};
        return .{ .allocator = allocator, .parsed = parsed, .alphabet = if (alphabet) |set| try set.cloneWithAllocator(allocator) else null, .shared = shared };
    }
    pub fn deinit(self: *CompiledRegex) void {
        self.shared.caches.deinit(self.allocator);
        self.allocator.destroy(self.shared);
        self.parsed.deinit();
        if (self.alphabet) |*set| set.deinit();
        self.* = undefined;
    }
    fn alphabetPtr(self: *const CompiledRegex) ?*const IntervalSet {
        return if (self.alphabet) |*set| set else null;
    }
};
fn scalar(cp: u32) bool {
    return cp <= 0x10ffff and !(cp >= 0xd800 and cp <= 0xdfff);
}
pub fn alphabetAllows(alphabet: ?*const IntervalSet, cp: u32) bool {
    return if (alphabet) |set| set.contains(cp) else scalar(cp);
}
pub fn isWord(cp: u32, ascii: bool) bool {
    return if (ascii) cp == '_' or (cp < 128 and std.ascii.isAlphanumeric(@intCast(cp))) else cp == '_' or unicode.isInGroupChar(@intCast(cp), "L") or unicode.isInGroupChar(@intCast(cp), "N");
}
pub fn isUniSpace(cp: u32) bool {
    return switch (cp) {
        ' ', 9...13, 0x1c...0x1f, 0x85 => true,
        else => unicode.isInGroupChar(@intCast(cp), "Z"),
    };
}
pub fn inCategory(cp: u32, category: c.ChCode, ascii: bool) bool {
    return switch (category) {
        .Digit => if (ascii) cp >= '0' and cp <= '9' else unicode.isInGroupChar(@intCast(cp), "Nd"),
        .NotDigit => !inCategory(cp, .Digit, ascii),
        .Space => if (ascii) switch (cp) {
            ' ', 9...13 => true,
            else => false,
        } else isUniSpace(cp),
        .NotSpace => !inCategory(cp, .Space, ascii),
        .Word => isWord(cp, ascii),
        .NotWord => !isWord(cp, ascii),
    };
}
pub fn charMatchesSet(items: []const p.SetItem, cp: u32, flags: u32) bool {
    const negate = items.len > 0 and items[0] == .Negate;
    var matches = false;
    for (items) |item| switch (item) {
        .Negate => {},
        .Literal => |want| {
            if (fold.literalMatches(want, cp, flags)) matches = true;
        },
        .Range => |r| {
            if (fold.rangeMatches(r.lo, r.hi, cp, flags)) matches = true;
        },
        .Category => |category| {
            if (inCategory(cp, category, flags & c.SRE_FLAG_ASCII != 0)) matches = true;
        },
    };
    return if (negate) !matches else matches;
}
fn appendUnique(allocator: Allocator, out: *std.ArrayList(u32), seen: *std.AutoHashMapUnmanaged(u32, void), cp: u32) Error!void {
    const entry = try seen.getOrPut(allocator, cp);
    if (!entry.found_existing) try out.append(allocator, cp);
}
pub fn literalCandidates(allocator: Allocator, cp: u32, flags: u32, alphabet: ?*const IntervalSet) Error![]u32 {
    if (!scalar(cp)) return error.InternalError;
    var values: std.ArrayList(u32) = .empty;
    defer values.deinit(allocator);
    try fold.pushEquivalents(allocator, &values, cp, flags);
    var out: std.ArrayList(u32) = .empty;
    errdefer out.deinit(allocator);
    var seen: std.AutoHashMapUnmanaged(u32, void) = .empty;
    defer seen.deinit(allocator);
    for (values.items) |candidate| if (alphabetAllows(alphabet, candidate)) try appendUnique(allocator, &out, &seen, candidate);
    return out.toOwnedSlice(allocator);
}
const Gather = union(enum) { any: bool, not_literal: struct { cp: u32, flags: u32 }, class: struct { items: []const p.SetItem, flags: u32 }, categories: struct { items: []const c.ChCode, ascii: bool } };
fn predicate(kind: Gather, cp: u32) bool {
    return switch (kind) {
        .any => |newline| newline or cp != '\n',
        .not_literal => |value| !fold.literalMatches(value.cp, cp, value.flags),
        .class => |value| charMatchesSet(value.items, cp, value.flags),
        .categories => |value| for (value.items) |category| {
            if (inCategory(cp, category, value.ascii)) break true;
        } else false,
    };
}
fn gatherChars(allocator: Allocator, alphabet: ?*const IntervalSet, kind: Gather) Error![]u32 {
    var out: std.ArrayList(u32) = .empty;
    errdefer out.deinit(allocator);
    const ranges: []const @import("../intervalsets.zig").Interval = if (alphabet) |set| set.intervals else &.{.{ .start = 0, .end = 0xffff }};
    for (ranges) |range| {
        var cp: u32 = range.start;
        while (true) {
            if (scalar(cp) and predicate(kind, cp)) try out.append(allocator, cp);
            if (cp == range.end) break;
            cp += 1;
        }
    }
    return out.toOwnedSlice(allocator);
}
pub fn buildInSet(allocator: Allocator, items: []const p.SetItem, flags: u32, alphabet: ?*const IntervalSet) Error![]u32 {
    var out: std.ArrayList(u32) = .empty;
    defer out.deinit(allocator);
    var seen: std.AutoHashMapUnmanaged(u32, void) = .empty;
    defer seen.deinit(allocator);
    var categories: std.ArrayList(c.ChCode) = .empty;
    defer categories.deinit(allocator);
    for (items) |item| switch (item) {
        .Negate => {
            return gatherChars(allocator, alphabet, .{ .class = .{ .items = items, .flags = flags } });
        },
        .Category => |category| try categories.append(allocator, category),
        .Literal => |cp| {
            const values = try literalCandidates(allocator, cp, flags, alphabet);
            defer allocator.free(values);
            for (values) |value| try appendUnique(allocator, &out, &seen, value);
        },
        .Range => |range| {
            var cp = range.lo;
            while (true) {
                if (scalar(cp)) {
                    const values = try literalCandidates(allocator, cp, flags, alphabet);
                    defer allocator.free(values);
                    for (values) |value| try appendUnique(allocator, &out, &seen, value);
                }
                if (cp == range.hi) break;
                cp += 1;
            }
        },
    };
    if (categories.items.len > 0) {
        const values = try gatherChars(allocator, alphabet, .{ .categories = .{ .items = categories.items, .ascii = flags & c.SRE_FLAG_ASCII != 0 } });
        defer allocator.free(values);
        for (values) |value| try appendUnique(allocator, &out, &seen, value);
    }
    return out.toOwnedSlice(allocator);
}
fn inChars(re: *const CompiledRegex, items: []const p.SetItem, flags: u32) Error![]const u32 {
    re.shared.mutex.lock();
    defer re.shared.mutex.unlock();
    const key: InKey = .{ .ptr = @intFromPtr(items.ptr), .len = items.len, .flags = flags & CASE_FLAGS };
    if (re.shared.caches.in_cache.get(key)) |value| return value;
    const computed = try buildInSet(re.allocator, items, flags, re.alphabetPtr());
    errdefer re.allocator.free(computed);
    try re.shared.caches.in_cache.put(re.allocator, key, computed);
    return computed;
}
fn cachedChars(re: *const CompiledRegex, key: CharKey, kind: Gather) Error![]const u32 {
    re.shared.mutex.lock();
    defer re.shared.mutex.unlock();
    if (re.shared.caches.char_cache.get(key)) |value| return value;
    const computed = try gatherChars(re.allocator, re.alphabetPtr(), kind);
    errdefer re.allocator.free(computed);
    try re.shared.caches.char_cache.put(re.allocator, key, computed);
    return computed;
}
fn notLiteralChars(re: *const CompiledRegex, cp: u32, flags: u32) Error![]const u32 {
    if (!scalar(cp)) return error.InternalError;
    return cachedChars(re, .{ .cp = cp, .flags = flags & CASE_FLAGS }, .{ .not_literal = .{ .cp = cp, .flags = flags } });
}
fn anyChars(re: *const CompiledRegex, flags: u32) Error![]const u32 {
    return cachedChars(re, .{ .cp = std.math.maxInt(u32), .flags = flags & c.SRE_FLAG_DOTALL }, .{ .any = flags & c.SRE_FLAG_DOTALL != 0 });
}
fn producibleSub(re: *const CompiledRegex, pattern: p.SubPattern, flags: u32) Error!bool {
    if (pattern.isEmpty()) return true;
    const key: ProducibleKey = .{ .ptr = @intFromPtr(pattern.data.items.ptr), .flags = flags };
    re.shared.mutex.lock();
    const cached = re.shared.caches.producible.get(key);
    re.shared.mutex.unlock();
    if (cached) |value| return value;
    const result = for (pattern.data.items) |op| {
        if (!try producibleOp(re, op, flags)) break false;
    } else true;
    re.shared.mutex.lock();
    defer re.shared.mutex.unlock();
    try re.shared.caches.producible.put(re.allocator, key, result);
    return result;
}
fn producibleOp(re: *const CompiledRegex, op: p.OpCode, flags: u32) Error!bool {
    return switch (op) {
        .Literal => |cp| blk: {
            const values = try literalCandidates(re.allocator, cp, flags, re.alphabetPtr());
            defer re.allocator.free(values);
            break :blk values.len > 0;
        },
        .NotLiteral => |cp| (try notLiteralChars(re, cp, flags)).len > 0,
        .Any => (try anyChars(re, flags)).len > 0,
        .In => |items| (try inChars(re, items, flags)).len > 0,
        .At, .GroupRef, .AssertNot => true,
        .Failure => false,
        .Branch => |items| for (items) |item| {
            if (try producibleSub(re, item, flags)) break true;
        } else false,
        .Subpattern => |value| try producibleSub(re, value.p, (flags | value.add_flags) & ~value.del_flags),
        .GroupRefExists => |value| try producibleSub(re, value.yes, flags) or (if (value.no) |no| try producibleSub(re, no, flags) else true),
        .Assert => |value| try producibleSub(re, value.p, flags),
        .AtomicGroup => |value| try producibleSub(re, value, flags),
        .MaxRepeat => |value| value.min == 0 or try producibleSub(re, value.item, flags),
        .MinRepeat => |value| value.min == 0 or try producibleSub(re, value.item, flags),
        .PossessiveRepeat => |value| value.min == 0 or try producibleSub(re, value.item, flags),
    };
}
pub fn isWordBoundary(text: []const u32, pos: usize, ascii: bool) bool {
    const before = pos > 0 and isWord(text[pos - 1], ascii);
    const after = pos < text.len and isWord(text[pos], ascii);
    return before != after;
}
pub fn atMatches(at: c.AtCode, text: []const u32, pos: usize, flags: u32) bool {
    return switch (at) {
        .Beginning => pos == 0 or (flags & c.SRE_FLAG_MULTILINE != 0 and pos > 0 and text[pos - 1] == '\n'),
        .BeginningString => pos == 0,
        .End => pos == text.len or (pos < text.len and text[pos] == '\n' and (flags & c.SRE_FLAG_MULTILINE != 0 or pos + 1 == text.len)),
        .EndString => pos == text.len,
        .Boundary => isWordBoundary(text, pos, flags & c.SRE_FLAG_ASCII != 0),
        .NonBoundary => !isWordBoundary(text, pos, flags & c.SRE_FLAG_ASCII != 0),
    };
}
const Groups = std.AutoHashMapUnmanaged(u32, []const u32);
fn combine(allocator: Allocator, a: []const p.OpCode, b: []const p.OpCode) Allocator.Error![]const p.OpCode {
    const out = try allocator.alloc(p.OpCode, a.len + b.len);
    @memcpy(out[0..a.len], a);
    @memcpy(out[a.len..], b);
    return out;
}
pub fn matchSeq(allocator: Allocator, ops: []const p.OpCode, pos: usize, text: []const u32, flags: u32, groups: *const Groups) Error!?usize {
    if (ops.len == 0) return pos;
    const first = ops[0];
    const rest = ops[1..];
    switch (first) {
        .Literal => |want| {
            if (!scalar(want) or pos >= text.len or !fold.literalMatches(want, text[pos], flags)) return null;
            return matchSeq(allocator, rest, pos + 1, text, flags, groups);
        },
        .NotLiteral => |banned| {
            if (!scalar(banned) or pos >= text.len or fold.literalMatches(banned, text[pos], flags)) return null;
            return matchSeq(allocator, rest, pos + 1, text, flags, groups);
        },
        .Any => {
            if (pos >= text.len or (text[pos] == '\n' and flags & c.SRE_FLAG_DOTALL == 0)) return null;
            return matchSeq(allocator, rest, pos + 1, text, flags, groups);
        },
        .In => |items| {
            if (pos >= text.len or !charMatchesSet(items, text[pos], flags)) return null;
            return matchSeq(allocator, rest, pos + 1, text, flags, groups);
        },
        .At => |at| return if (atMatches(at, text, pos, flags)) matchSeq(allocator, rest, pos, text, flags, groups) else null,
        .Branch => |branches| {
            for (branches) |branch| {
                const joined = try combine(allocator, branch.data.items, rest);
                defer allocator.free(joined);
                if (try matchSeq(allocator, joined, pos, text, flags, groups)) |end| return end;
            }
            return null;
        },
        .Subpattern => |value| {
            const end = (try matchSeq(allocator, value.p.data.items, pos, text, (flags | value.add_flags) & ~value.del_flags, groups)) orelse return null;
            return matchSeq(allocator, rest, end, text, flags, groups);
        },
        .AtomicGroup => |value| {
            const end = (try matchSeq(allocator, value.data.items, pos, text, flags, groups)) orelse return null;
            return matchSeq(allocator, rest, end, text, flags, groups);
        },
        .GroupRef => |gid| {
            const value = groups.get(gid) orelse return null;
            if (pos + value.len > text.len) return null;
            for (value, 0..) |cp, i| if (!fold.grouprefEq(text[pos + i], cp, flags)) return null;
            return matchSeq(allocator, rest, pos + value.len, text, flags, groups);
        },
        .GroupRefExists => |value| {
            const branch = if (groups.contains(value.cond_group)) value.yes.data.items else if (value.no) |no| no.data.items else &.{};
            const joined = try combine(allocator, branch, rest);
            defer allocator.free(joined);
            return matchSeq(allocator, joined, pos, text, flags, groups);
        },
        .Assert => |value| return if (try matchSeq(allocator, value.p.data.items, pos, text, flags, groups) != null) matchSeq(allocator, rest, pos, text, flags, groups) else null,
        .AssertNot => |value| return if (try matchSeq(allocator, value.p.data.items, pos, text, flags, groups) == null) matchSeq(allocator, rest, pos, text, flags, groups) else null,
        .Failure => return null,
        .MaxRepeat => |value| {
            var positions: std.ArrayList(usize) = .empty;
            defer positions.deinit(allocator);
            try positions.append(allocator, pos);
            var cur = pos;
            var zero_width = false;
            while (true) {
                if (value.max != c.MAXREPEAT and positions.items.len > value.max) break;
                const next = (try matchSeq(allocator, value.item.data.items, cur, text, flags, groups)) orelse break;
                if (next > cur) {
                    cur = next;
                    try positions.append(allocator, cur);
                } else {
                    zero_width = true;
                    break;
                }
            }
            const minimum = if (zero_width) 0 else value.min;
            if (positions.items.len - 1 < minimum) return null;
            var i = positions.items.len;
            while (i > minimum) {
                i -= 1;
                if (try matchSeq(allocator, rest, positions.items[i], text, flags, groups)) |end| return end;
            }
            return null;
        },
        .MinRepeat => |value| {
            var cur = pos;
            var count: usize = 0;
            while (count < value.min) {
                const next = (try matchSeq(allocator, value.item.data.items, cur, text, flags, groups)) orelse return null;
                if (next <= cur) {
                    count = value.min;
                    break;
                }
                cur = next;
                count += 1;
            }
            while (true) {
                if (try matchSeq(allocator, rest, cur, text, flags, groups)) |end| return end;
                if (value.max != c.MAXREPEAT and count >= value.max) return null;
                const next = (try matchSeq(allocator, value.item.data.items, cur, text, flags, groups)) orelse return null;
                if (next <= cur) return null;
                cur = next;
                count += 1;
            }
        },
        .PossessiveRepeat => |value| {
            var cur = pos;
            var count: usize = 0;
            var zero_width = false;
            while (true) {
                if (value.max != c.MAXREPEAT and count >= value.max) break;
                const next = (try matchSeq(allocator, value.item.data.items, cur, text, flags, groups)) orelse break;
                if (next > cur) {
                    cur = next;
                    count += 1;
                } else {
                    zero_width = true;
                    break;
                }
            }
            if (count < value.min and !zero_width) return null;
            return matchSeq(allocator, rest, cur, text, flags, groups);
        },
    }
}
const PendingAnchor = struct { char_pos: usize, at: c.AtCode, flags: u32 };
const PendingAssert = struct { char_pos: usize, direction: i32, pattern: p.SubPattern, flags: u32, groups: Groups };
const GenState = struct {
    allocator: Allocator,
    groups: Groups = .empty,
    flags: u32,
    fullmatch: bool,
    pending_anchors: std.ArrayList(PendingAnchor) = .empty,
    pending_asserts: std.ArrayList(PendingAssert) = .empty,
    pending_lookaheads: std.ArrayList(PendingAssert) = .empty,
    needs_whole_match: bool = false,
    fn pending(self: *GenState, pos: usize, direction: i32, pattern: p.SubPattern) Error!PendingAssert {
        return .{ .char_pos = pos, .direction = direction, .pattern = pattern, .flags = self.flags, .groups = try self.groups.clone(self.allocator) };
    }
};
fn markInvalid(ntc: anytype) Error {
    ntc.conclude(.invalid, null) catch |err| return err;
    return error.InvalidTestCase;
}
fn pickIndex(ntc: anytype, n: usize) Error!usize {
    if (n == 0) return error.InternalError;
    return if (n == 1) 0 else @intCast(try draws.drawInt(i64, ntc, 0, @intCast(n - 1)));
}
fn drawAnyChar(ntc: anytype, alphabet: ?*const IntervalSet) Error!u32 {
    if (alphabet) |set| {
        if (set.isEmpty()) return markInvalid(ntc);
        const index = try draws.drawInt(i64, ntc, 0, @intCast(set.len() - 1));
        const cp = set.get(@intCast(index)) orelse return error.InternalError;
        if (!scalar(cp)) return error.InternalError;
        return cp;
    }
    return @intCast(try draws.drawInt(i128, ntc, 32, 126));
}
fn drawPad(ntc: anytype, alphabet: ?*const IntervalSet, allocator: Allocator, out: *std.ArrayList(u32)) Error!void {
    const n = try draws.drawInt(i128, ntc, 0, 10);
    var i: i128 = 0;
    while (i < n) : (i += 1) try out.append(allocator, try drawAnyChar(ntc, alphabet));
}
fn effectiveFirst(pattern: p.SubPattern) ?p.OpCode {
    if (pattern.isEmpty()) return null;
    const op = pattern.data.items[0];
    return switch (op) {
        .Subpattern => |v| effectiveFirst(v.p),
        .AtomicGroup => |v| effectiveFirst(v),
        else => op,
    };
}
fn effectiveLast(pattern: p.SubPattern) ?p.OpCode {
    if (pattern.isEmpty()) return null;
    const op = pattern.data.items[pattern.len() - 1];
    return switch (op) {
        .Subpattern => |v| effectiveLast(v.p),
        .AtomicGroup => |v| effectiveLast(v),
        else => op,
    };
}
fn drawPrefix(ntc: anytype, parsed: p.ParsedPattern, alphabet: ?*const IntervalSet, allocator: Allocator, out: *std.ArrayList(u32)) Error!void {
    if (effectiveFirst(parsed.pattern)) |op| if (op == .At) switch (op.At) {
        .BeginningString => return,
        .Beginning => {
            if (parsed.flags & c.SRE_FLAG_MULTILINE != 0 and alphabetAllows(alphabet, '\n')) {
                try drawPad(ntc, alphabet, allocator, out);
                if (out.items.len > 0) try out.append(allocator, '\n');
            }
            return;
        },
        else => {},
    };
    try drawPad(ntc, alphabet, allocator, out);
}
fn drawSuffix(ntc: anytype, parsed: p.ParsedPattern, alphabet: ?*const IntervalSet, allocator: Allocator, out: *std.ArrayList(u32)) Error!void {
    if (effectiveLast(parsed.pattern)) |op| if (op == .At) switch (op.At) {
        .EndString => return,
        .End => {
            if (!alphabetAllows(alphabet, '\n')) return;
            if (parsed.flags & c.SRE_FLAG_MULTILINE != 0) {
                if (try ntc.weighted(0.5, null)) {
                    try out.append(allocator, '\n');
                    try drawPad(ntc, alphabet, allocator, out);
                }
            } else if (try ntc.weighted(0.5, null)) try out.append(allocator, '\n');
            return;
        },
        else => {},
    };
    try drawPad(ntc, alphabet, allocator, out);
}
fn emitFromChars(ntc: anytype, values: []const u32, allocator: Allocator, out: *std.ArrayList(u32)) Error!void {
    if (values.len == 0) return markInvalid(ntc);
    const index: usize = if (values.len > 256 and try ntc.weighted(0.8, null)) @intCast(try draws.drawInt(i128, ntc, 0, 255)) else if (values.len > 256) @intCast(try draws.drawInt(i128, ntc, 256, @intCast(values.len - 1))) else @intCast(try draws.drawInt(i128, ntc, 0, @intCast(values.len - 1)));
    try out.append(allocator, values[index]);
}
fn generateSubpattern(ntc: anytype, re: *const CompiledRegex, pattern: p.SubPattern, state: *GenState, out: *std.ArrayList(u32)) Error!void {
    for (pattern.data.items) |op| try generateOp(ntc, re, op, state, out);
}
fn generateRepeat(ntc: anytype, re: *const CompiledRegex, value: p.OpCode.Repeat, state: *GenState, out: *std.ArrayList(u32), possessive: bool) Error!void {
    if (value.min == 0 and !try producibleSub(re, value.item, state.flags)) return;
    if (possessive) state.needs_whole_match = true;
    var many = draws.ManyState.init(value.min, if (value.max == c.MAXREPEAT) null else value.max);
    while (try draws.manyMore(ntc, &many)) try generateSubpattern(ntc, re, value.item, state, out);
}
fn generateOp(ntc: anytype, re: *const CompiledRegex, op: p.OpCode, state: *GenState, out: *std.ArrayList(u32)) Error!void {
    const allocator = state.allocator;
    switch (op) {
        .Literal => |cp| {
            const values = try literalCandidates(allocator, cp, state.flags, re.alphabetPtr());
            if (values.len == 0) return markInvalid(ntc);
            try out.append(allocator, values[try pickIndex(ntc, values.len)]);
        },
        .NotLiteral => |cp| try emitFromChars(ntc, try notLiteralChars(re, cp, state.flags), allocator, out),
        .Any => try emitFromChars(ntc, try anyChars(re, state.flags), allocator, out),
        .At => |at| switch (at) {
            .BeginningString => {
                if (out.items.len > 0) return markInvalid(ntc);
            },
            .Beginning => {
                if (state.flags & c.SRE_FLAG_MULTILINE != 0) {
                    if (out.items.len > 0 and out.items[out.items.len - 1] != '\n') return markInvalid(ntc);
                } else if (out.items.len > 0) return markInvalid(ntc);
            },
            .End, .EndString, .Boundary, .NonBoundary => try state.pending_anchors.append(allocator, .{ .char_pos = out.items.len, .at = at, .flags = state.flags }),
        },
        .In => |items| try emitFromChars(ntc, try inChars(re, items, state.flags), allocator, out),
        .Branch => |items| {
            var live: std.ArrayList(p.SubPattern) = .empty;
            for (items) |item| if (try producibleSub(re, item, state.flags)) try live.append(allocator, item);
            if (live.items.len == 0) return markInvalid(ntc);
            try generateSubpattern(ntc, re, live.items[try pickIndex(ntc, live.items.len)], state, out);
        },
        .Subpattern => |value| {
            const saved = state.flags;
            state.flags = (state.flags | value.add_flags) & ~value.del_flags;
            const before = out.items.len;
            try generateSubpattern(ntc, re, value.p, state, out);
            state.flags = saved;
            if (value.group) |gid| try state.groups.put(allocator, gid, try allocator.dupe(u32, out.items[before..]));
        },
        .GroupRef => |gid| {
            const value = state.groups.get(gid) orelse return markInvalid(ntc);
            try out.appendSlice(allocator, value);
        },
        .GroupRefExists => |value| {
            if (state.groups.contains(value.cond_group)) try generateSubpattern(ntc, re, value.yes, state, out) else if (value.no) |no| try generateSubpattern(ntc, re, no, state, out);
        },
        .Assert => |value| {
            if (state.fullmatch) try state.pending_asserts.append(allocator, try state.pending(out.items.len, value.direction, value.p)) else try generateSubpattern(ntc, re, value.p, state, out);
        },
        .AssertNot => |value| {
            if (value.direction < 0) {
                for (0..out.items.len + 1) |start| if (try matchSeq(allocator, value.p.data.items, start, out.items, state.flags, &state.groups) == out.items.len) return markInvalid(ntc);
            } else try state.pending_lookaheads.append(allocator, try state.pending(out.items.len, value.direction, value.p));
        },
        .Failure => return markInvalid(ntc),
        .AtomicGroup => |value| {
            state.needs_whole_match = true;
            try generateSubpattern(ntc, re, value, state, out);
        },
        .MaxRepeat => |value| try generateRepeat(ntc, re, value, state, out, false),
        .MinRepeat => |value| try generateRepeat(ntc, re, value, state, out, false),
        .PossessiveRepeat => |value| try generateRepeat(ntc, re, value, state, out, true),
    }
}
fn wholeMatch(allocator: Allocator, parsed: p.ParsedPattern, fullmatch: bool, text: []const u32, groups: *const Groups) Error!bool {
    if (fullmatch) {
        const anchored = try combine(allocator, parsed.pattern.data.items, &.{.{ .At = .EndString }});
        defer allocator.free(anchored);
        return try matchSeq(allocator, anchored, 0, text, parsed.flags, groups) != null;
    }
    for (0..text.len + 1) |start| if (try matchSeq(allocator, parsed.pattern.data.items, start, text, parsed.flags, groups) != null) return true;
    return false;
}
fn generateRegexAttempt(ntc: anytype, re: *const CompiledRegex, fullmatch: bool) Error!?[]u8 {
    var arena: std.heap.ArenaAllocator = .init(ntc.allocator);
    defer arena.deinit();
    const allocator = arena.allocator();
    const parsed = re.parsed.parsed.?;
    var state: GenState = .{ .allocator = allocator, .flags = parsed.flags, .fullmatch = fullmatch };
    var out: std.ArrayList(u32) = .empty;
    if (parsed.pattern.isEmpty()) {
        if (!fullmatch) try drawPad(ntc, re.alphabetPtr(), allocator, &out);
        return try @import("../sampling.zig").codepointsToString(ntc.allocator, out.items);
    }
    if (!fullmatch) try drawPrefix(ntc, parsed, re.alphabetPtr(), allocator, &out);
    try generateSubpattern(ntc, re, parsed.pattern, &state, &out);
    if (!fullmatch) try drawSuffix(ntc, parsed, re.alphabetPtr(), allocator, &out);
    for (state.pending_anchors.items) |anchor| if (!atMatches(anchor.at, out.items, anchor.char_pos, anchor.flags)) return null;
    for (state.pending_asserts.items) |pending| {
        const holds = if (pending.direction >= 0) try matchSeq(allocator, pending.pattern.data.items, pending.char_pos, out.items, pending.flags, &pending.groups) != null else blk: {
            for (0..pending.char_pos + 1) |start| if (try matchSeq(allocator, pending.pattern.data.items, start, out.items, pending.flags, &pending.groups) == pending.char_pos) break :blk true;
            break :blk false;
        };
        if (!holds) return null;
    }
    for (state.pending_lookaheads.items) |pending| if (try matchSeq(allocator, pending.pattern.data.items, pending.char_pos, out.items, pending.flags, &pending.groups) != null) return null;
    if (state.needs_whole_match and !try wholeMatch(allocator, parsed, fullmatch, out.items, &state.groups)) return null;
    return try @import("../sampling.zig").codepointsToString(ntc.allocator, out.items);
}
pub fn generateRegex(ntc: anytype, re: *const CompiledRegex, fullmatch: bool) Error![]u8 {
    for (0..5) |_| if (try generateRegexAttempt(ntc, re, fullmatch)) |value| return value;
    return markInvalid(ntc);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");
const math = @import("math_compat.zig");
pub const Error = error{InternalError};

pub fn stdtr(df: i32, t: f64) Error!f64 {
    if (df < 1) return error.InternalError;
    if (t == 0) return 0.5;
    const abs_t = @abs(t);
    const degrees: f64 = @floatFromInt(df);
    const z = 1 + abs_t * abs_t / degrees;
    const p = if (@mod(df, 2) == 1) blk: {
        const u = abs_t / math.sqrt(degrees);
        var p = math.atan(u);
        if (df > 1) {
            var f: f64 = 1;
            var tz: f64 = 1;
            var j: i32 = 3;
            while (j <= df - 2) : (j += 2) {
                tz *= (@as(f64, @floatFromInt(j)) - 1) / (z * @as(f64, @floatFromInt(j)));
                f += tz;
            }
            p += f * u / z;
        }
        break :blk p * 2 / std.math.pi;
    } else blk: {
        var f: f64 = 1;
        var tz: f64 = 1;
        var j: i32 = 2;
        while (j <= df - 2) : (j += 2) {
            tz *= (@as(f64, @floatFromInt(j)) - 1) / (z * @as(f64, @floatFromInt(j)));
            f += tz;
        }
        break :blk f * abs_t / math.sqrt(z * degrees);
    };
    return if (t < 0) 0.5 - 0.5 * p else 0.5 + 0.5 * p;
}

pub fn stdtrit(df: i32, p: f64) Error!f64 {
    if (df < 1) return error.InternalError;
    if (p == 0.5) return 0;
    if (!(p > 0 and p < 1)) return error.InternalError;
    if (df == 1) {
        return if (p > 0.5) math.cos(std.math.pi * (1 - p)) / math.sin(std.math.pi * (1 - p)) else -math.cos(std.math.pi * p) / math.sin(std.math.pi * p);
    }
    if (df == 2) return (2 * p - 1) / math.sqrt(2 * p * (1 - p));
    const sign: f64 = if (p > 0.5) 1 else -1;
    const q = if (p > 0.5) p else 1 - p;
    const degrees: f64 = @floatFromInt(df);
    var lo: f64 = 0;
    var hi: f64 = 1;
    while (try stdtr(df, hi) < q) hi *= 2;
    const log_norm = lnGamma(0.5 * (degrees + 1)) - 0.5 * math.log(degrees * std.math.pi) - lnGamma(0.5 * degrees);
    var t = 0.5 * (lo + hi);
    for (0..50) |_| {
        const f_val = try stdtr(df, t);
        if (f_val < q) lo = t else hi = t;
        const log_f = log_norm - 0.5 * (degrees + 1) * math.log1p(t * t / degrees);
        const f = math.exp(log_f);
        const t_newton = t - (f_val - q) / f;
        t = if (lo <= t_newton and t_newton <= hi) t_newton else 0.5 * (lo + hi);
        if (hi - lo < 1e-10 * (1 + @abs(t))) break;
    }
    return sign * t;
}

pub fn lnGamma(x: f64) f64 {
    const coefficients = [_]f64{ 0.9999999999998099, 676.5203681218851, -1259.1392167224028, 771.3234287776531, -176.6150291621406, 12.507343278686905, -0.13857109526572012, 9.984369578019572e-6, 1.5056327351493116e-7 };
    const z = x - 1;
    var sum = coefficients[0];
    for (coefficients[1..], 1..) |c, i| sum += c / (z + @as(f64, @floatFromInt(i)));
    const t = z + 7.5;
    return 0.5 * math.log(2 * std.math.pi) + (z + 0.5) * math.log(t) - t + math.log(sum);
}

pub fn gamma(x: f64) f64 {
    return math.exp(lnGamma(x));
}

pub const UniformDistribution = struct {
    half_width: f64,

    pub fn init(half_width: f64) UniformDistribution {
        return .{ .half_width = half_width };
    }

    pub fn cdf(self: UniformDistribution, x: f64) Error!f64 {
        if (x < -self.half_width) return 0;
        if (x > self.half_width) return 1;
        return (x + self.half_width) / (2 * self.half_width);
    }

    pub fn inverseCdf(self: UniformDistribution, u: f64) Error!f64 {
        return -self.half_width + 2 * self.half_width * u;
    }

    pub fn pdf(self: UniformDistribution, x: f64) f64 {
        return if (-self.half_width <= x and x <= self.half_width) 1 / (2 * self.half_width) else 0;
    }
};

pub const LogStudentTDistribution = struct {
    scale_bits: f64,
    df: i32,
    t_coef: f64,

    pub fn init(scale_bits: f64, df: i32) LogStudentTDistribution {
        const degrees: f64 = @floatFromInt(df);
        return .{ .scale_bits = scale_bits, .df = df, .t_coef = gamma((degrees + 1) / 2) / (math.sqrt(degrees * std.math.pi) * gamma(degrees / 2)) };
    }

    pub fn cdf(self: LogStudentTDistribution, x: f64) Error!f64 {
        return stdtr(self.df, std.math.copysign(math.log2(1 + @abs(x)), x) / self.scale_bits);
    }

    pub fn inverseCdf(self: LogStudentTDistribution, u: f64) Error!f64 {
        const y = std.math.clamp(self.scale_bits * try stdtrit(self.df, u), -1023, 1023);
        return std.math.copysign(math.expm1(@abs(y) * std.math.ln2), y);
    }

    pub fn pdf(self: LogStudentTDistribution, x: f64) f64 {
        const y = std.math.copysign(math.log2(1 + @abs(x)), x) / self.scale_bits;
        const degrees: f64 = @floatFromInt(self.df);
        const f_t = self.t_coef * math.pow(1 + y * y / degrees, -((degrees + 1) / 2));
        return f_t / (self.scale_bits * (1 + @abs(x)) * std.math.ln2);
    }
};

pub fn PiecewiseDistribution(comptime I: type, comptime O: type) type {
    return struct {
        const Self = @This();
        inner: I,
        outer: O,
        switchover: f64,
        alpha: f64,
        beta: f64,
        inner_g_neg: f64,
        outer_g_pos: f64,
        inner_mass: f64,
        left_mass: f64,

        pub fn init(inner: I, outer: O, switchover: f64) Error!Self {
            const inner_g_neg = try inner.cdf(-switchover);
            const inner_g_pos = try inner.cdf(switchover);
            const outer_g_neg = try outer.cdf(-switchover);
            const outer_g_pos = try outer.cdf(switchover);
            const outer_outer_mass = 1 - (outer_g_pos - outer_g_neg);
            const inner_inner_mass = inner_g_pos - inner_g_neg;
            const inner_pdf = inner.pdf(switchover);
            const outer_pdf = outer.pdf(switchover);
            if (inner_pdf == 0) return error.InternalError;
            const alpha = 1 / (outer_pdf * inner_inner_mass / inner_pdf + outer_outer_mass);
            const beta = alpha * outer_pdf / inner_pdf;
            return .{
                .inner = inner,
                .outer = outer,
                .switchover = switchover,
                .alpha = alpha,
                .beta = beta,
                .inner_g_neg = inner_g_neg,
                .outer_g_pos = outer_g_pos,
                .inner_mass = beta * inner_inner_mass,
                .left_mass = alpha * outer_g_neg,
            };
        }

        pub fn cdf(self: Self, x: f64) Error!f64 {
            if (x <= -self.switchover) return self.alpha * try self.outer.cdf(x);
            if (x < self.switchover) return self.left_mass + self.beta * (try self.inner.cdf(x) - self.inner_g_neg);
            return self.left_mass + self.inner_mass + self.alpha * (try self.outer.cdf(x) - self.outer_g_pos);
        }

        pub fn inverseCdf(self: Self, u: f64) Error!f64 {
            if (u <= self.left_mass) return self.outer.inverseCdf(u / self.alpha);
            if (u < self.left_mass + self.inner_mass) return self.inner.inverseCdf(self.inner_g_neg + (u - self.left_mass) / self.beta);
            return self.outer.inverseCdf((u - self.left_mass - self.inner_mass) / self.alpha + self.outer_g_pos);
        }

        pub fn pdf(self: Self, x: f64) f64 {
            return if (@abs(x) < self.switchover) self.beta * self.inner.pdf(x) else self.alpha * self.outer.pdf(x);
        }
    };
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
pub const log = @import("math_compat/log.zig").log;
pub const exp = @import("math_compat/exp.zig").exp;
pub const scalbn = @import("math_compat/scalbn.zig").scalbn;
pub const log2 = @import("math_compat/log2.zig").log2;
pub const log1p = @import("math_compat/log1p.zig").log1p;
pub const expm1 = @import("math_compat/expm1.zig").expm1;
pub const pow = @import("math_compat/pow.zig").pow;
pub const sqrt = @import("math_compat/sqrt.zig").sqrt;
pub const atan = @import("math_compat/atan.zig").atan;
pub const sin = @import("math_compat/sin.zig").sin;
pub const cos = @import("math_compat/cos.zig").cos;
pub fn floor(x: f64) f64 {
    @setFloatMode(.strict);
    if ((@as(u64, @bitCast(x)) & 0x7ff0000000000000) == 0x7ff0000000000000) return x;
    return @floor(x);
}
pub fn ceil(x: f64) f64 {
    @setFloatMode(.strict);
    if ((@as(u64, @bitCast(x)) & 0x7ff0000000000000) == 0x7ff0000000000000) return x;
    return @ceil(x);
}
pub fn round(x: f64) f64 {
    @setFloatMode(.strict);
    return @round(x);
}
pub fn copysign(x: f64, sign: f64) f64 {
    return @bitCast((@as(u64, @bitCast(x)) & 0x7fffffffffffffff) | (@as(u64, @bitCast(sign)) & 0x8000000000000000));
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-provenance/state.json.
const std = @import("std");
const state = @import("state.zig");
const c = @import("choices.zig");
const draws = @import("draws.zig");
const machine_mod = @import("state_machine.zig");
const execution = @import("execution.zig");
const Allocator = std.mem.Allocator;
pub const NativeDataSource = struct {
    allocator: Allocator,
    inner: *state.NativeTestCaseHandle,
    aborted: std.atomic.Value(bool) = .init(false),
    diagnostic: ?[]u8 = null,
    pub const Created = struct { source: NativeDataSource, handle: *state.NativeTestCaseHandle };
    pub fn init(gpa: Allocator, ntc: state.NativeTestCase) Allocator.Error!Created {
        const handle = try state.NativeTestCaseHandle.create(gpa, ntc);
        return .{ .source = fromHandle(handle.retain()), .handle = handle };
    }
    pub fn fromHandle(handle: *state.NativeTestCaseHandle) NativeDataSource {
        return .{ .allocator = handle.allocator, .inner = handle };
    }
    pub fn deinit(self: *NativeDataSource) void {
        if (self.diagnostic) |message| self.allocator.free(message);
        self.inner.release();
    }
    fn abortedError(self: *NativeDataSource) error{ Assume, StopTest } {
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        return if (ntc.status() == .invalid) error.Assume else error.StopTest;
    }
    fn call(self: *NativeDataSource, comptime function: anytype, args: anytype) anyerror!@typeInfo(@TypeOf(@call(.auto, function, .{@as(*state.NativeTestCase, undefined)} ++ args))).error_union.payload {
        if (self.aborted.load(.monotonic)) return self.abortedError();
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        return @call(.auto, function, .{ntc} ++ args) catch |err| switch (err) {
            error.Overrun => {
                self.aborted.store(true, .monotonic);
                return error.StopTest;
            },
            error.InvalidTestCase => {
                self.aborted.store(true, .monotonic);
                return error.Assume;
            },
            error.AssumeViolation => error.Assume,
            else => blk: {
                if (ntc.diagnostic) |message| try self.setDiagnostic(message);
                break :blk err;
            },
        };
    }
    pub fn setDiagnostic(self: *NativeDataSource, message: []const u8) Allocator.Error!void {
        const owned = try self.allocator.dupe(u8, message);
        if (self.diagnostic) |old| self.allocator.free(old);
        self.diagnostic = owned;
    }
    pub fn takeNodes(handle: *state.NativeTestCaseHandle, gpa: Allocator) ![]c.ChoiceNode {
        const ntc = handle.lock();
        defer handle.unlock();
        try ntc.reassemble();
        return c.cloneNodes(gpa, ntc.nodes.items);
    }
    pub fn takeSpans(handle: *state.NativeTestCaseHandle, gpa: Allocator) Allocator.Error![]c.Span {
        const ntc = handle.lock();
        defer handle.unlock();
        return gpa.dupe(c.Span, ntc.spans.asSlice());
    }
    pub fn takeDivergence(handle: *state.NativeTestCaseHandle, gpa: Allocator) !?@import("replay.zig").Divergence {
        const ntc = handle.lock();
        defer handle.unlock();
        return if (ntc.divergence()) |d| try d.deepClone(gpa) else null;
    }
    pub fn takeSettled(handle: *state.NativeTestCaseHandle, gpa: Allocator) ![]@import("graph.zig").Settled {
        const ntc = handle.lock();
        defer handle.unlock();
        return ntc.settledEdges(gpa);
    }
    pub fn takeEnded(handle: *state.NativeTestCaseHandle) bool {
        const ntc = handle.lock();
        defer handle.unlock();
        return ntc.endedOnEnd();
    }
    pub fn takeTargetObservations(handle: *state.NativeTestCaseHandle, gpa: Allocator) !std.StringHashMapUnmanaged(f64) {
        const ntc = handle.lock();
        defer handle.unlock();
        const family = ntc.family;
        family.mutex.lock();
        defer family.mutex.unlock();
        var out: std.StringHashMapUnmanaged(f64) = .empty;
        errdefer {
            var keys = out.keyIterator();
            while (keys.next()) |key| gpa.free(key.*);
            out.deinit(gpa);
        }
        var it = family.target_observations.iterator();
        while (it.next()) |entry| {
            const label = try gpa.dupe(u8, entry.key_ptr.*);
            errdefer gpa.free(label);
            try out.put(gpa, label, entry.value_ptr.*);
        }
        return out;
    }
    pub fn takeEvents(handle: *state.NativeTestCaseHandle, gpa: Allocator) ![]execution.Event {
        const ntc = handle.lock();
        defer handle.unlock();
        const family = ntc.family;
        family.mutex.lock();
        defer family.mutex.unlock();
        const out = try gpa.alloc(execution.Event, family.events.items.len);
        var count: usize = 0;
        errdefer {
            for (out[0..count]) |event| gpa.free(event.label);
            gpa.free(out);
        }
        for (out, family.events.items) |*dest, source| {
            dest.* = .{ .label = try gpa.dupe(u8, source.label), .value = source.value };
            count += 1;
        }
        return out;
    }
    pub const Outcome = struct { status: c.Status, origin: ?[]u8 };
    pub fn takeOutcome(handle: *state.NativeTestCaseHandle, gpa: Allocator) !Outcome {
        const ntc = handle.lock();
        defer handle.unlock();
        const conclusion = ntc.family.conclusion() orelse return error.UsageError;
        return .{ .status = conclusion.status, .origin = if (conclusion.origin) |o| try gpa.dupe(u8, o) else null };
    }
    pub fn shouldCapture(self: *NativeDataSource) bool {
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        return ntc.shouldCapture();
    }
    pub fn markComplete(self: *NativeDataSource, status: c.Status, origin: ?[]const u8) !void {
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        try ntc.conclude(status, origin);
    }
    pub fn cloneStream(self: *NativeDataSource) !NativeDataSource {
        return fromHandle(try self.call(state.NativeTestCase.cloneStream, .{}));
    }
    pub fn startSpan(self: *NativeDataSource, label: u64) !void {
        _ = try self.call(state.NativeTestCase.startSpan, .{label});
    }
    pub fn stopSpan(self: *NativeDataSource, discard: bool) !void {
        try self.call(stopSpanImpl, .{discard});
    }
    fn stopSpanImpl(ntc: *state.NativeTestCase, discard: bool) state.Error!void {
        ntc.stopSpan(discard);
    }
    pub fn newCollection(self: *NativeDataSource, min: u64, max: ?u64) !state.ManyState {
        return self.call(newCollectionImpl, .{ min, max });
    }
    fn newCollectionImpl(_: *state.NativeTestCase, min: u64, max: ?u64) state.Error!state.ManyState {
        return .init(std.math.cast(usize, min) orelse std.math.maxInt(usize), if (max) |n| std.math.cast(usize, n) orelse std.math.maxInt(usize) else null);
    }
    pub fn recursionLeaf(self: *NativeDataSource, s: *state.RecursionState) !bool {
        return self.call(recursionLeafImpl, .{s});
    }
    fn recursionLeafImpl(_: *state.NativeTestCase, s: *state.RecursionState) state.Error!bool {
        return s.countLeaf();
    }
    pub fn newPool(self: *NativeDataSource) !state.NativeVariables {
        return self.call(newPoolImpl, .{});
    }
    fn newPoolImpl(ntc: *state.NativeTestCase) state.Error!state.NativeVariables {
        return .init(ntc.allocator);
    }
    pub fn poolAdd(self: *NativeDataSource, pool: *state.NativeVariables) !i64 {
        return self.call(poolAddImpl, .{pool});
    }
    fn poolAddImpl(ntc: *state.NativeTestCase, pool: *state.NativeVariables) !i64 {
        const id = try draws.freshId(ntc);
        try pool.add(id);
        return id;
    }
    pub fn poolGenerate(self: *NativeDataSource, pool: *state.NativeVariables, consume: bool) !i64 {
        return self.call(poolGenerateImpl, .{ pool, consume });
    }
    fn poolGenerateImpl(ntc: *state.NativeTestCase, pool: *state.NativeVariables, consume: bool) !i64 {
        const active = try pool.active(ntc.allocator);
        defer ntc.allocator.free(active);
        if (active.len == 0) return error.AssumeViolation;
        const id = try draws.chooseFrom(ntc, active);
        if (consume) try pool.consume(id);
        return id;
    }
    pub fn targetObservation(self: *NativeDataSource, score: f64, label: []const u8) !void {
        if (!std.math.isFinite(score)) {
            const quoted = try draws.text.debugString(self.allocator, label);
            defer self.allocator.free(quoted);
            const number = try floatDisplay(self.allocator, score);
            defer self.allocator.free(number);
            const msg = try std.fmt.allocPrint(self.allocator, "tc.target({s}, label={s}) requires a finite score; got non-finite value", .{ number, quoted });
            defer self.allocator.free(msg);
            try self.setDiagnostic(msg);
            return error.InvalidArgument;
        }
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        ntc.family.target(label, score) catch |err| {
            if (err == error.InvalidArgument) {
                const quoted = try draws.text.debugString(self.allocator, label);
                defer self.allocator.free(quoted);
                const number = try floatDisplay(self.allocator, score);
                defer self.allocator.free(number);
                const msg = try std.fmt.allocPrint(self.allocator, "tc.target({s}, label={s}) would overwrite previous tc.target(_, label={s}); each label can be observed at most once per test case", .{ number, quoted, quoted });
                defer self.allocator.free(msg);
                try self.setDiagnostic(msg);
            }
            return err;
        };
    }
    pub fn eventObservation(self: *NativeDataSource, label: []const u8, value: ?f64) !void {
        if (value) |v| if (!std.math.isFinite(v)) {
            const quoted = try draws.text.debugString(self.allocator, label);
            defer self.allocator.free(quoted);
            const number = try floatDisplay(self.allocator, v);
            defer self.allocator.free(number);
            const msg = try std.fmt.allocPrint(self.allocator, "tc.event_value({s}, {s}) requires a finite value; got non-finite value", .{ quoted, number });
            defer self.allocator.free(msg);
            try self.setDiagnostic(msg);
            return error.InvalidArgument;
        };
        const ntc = self.inner.lock();
        defer self.inner.unlock();
        try ntc.family.event(label, value);
    }
    pub fn generateInteger(self: *NativeDataSource, min: c.BigInt, max: c.BigInt) !c.BigInt {
        return self.call(draws.generateInteger, .{ min, max });
    }
    pub fn generateFloat(self: *NativeDataSource, spec: draws.FloatSpec) !f64 {
        return self.call(draws.generateFloat, .{spec});
    }
    pub fn generateBytes(self: *NativeDataSource, min: usize, max: usize) ![]u8 {
        return self.call(draws.generateBytes, .{ min, max });
    }
    pub fn generateBoolean(self: *NativeDataSource, p: f64, forced: ?bool) !bool {
        return self.call(draws.generateBoolean, .{ p, forced });
    }
    pub fn generateDate(self: *NativeDataSource, min: draws.special.Date, max: draws.special.Date) !draws.special.Date {
        return self.call(draws.special.generateDate, .{ min, max });
    }
    pub fn generateTime(self: *NativeDataSource, min: draws.special.Time, max: draws.special.Time) !draws.special.Time {
        return self.call(draws.special.generateTime, .{ min, max });
    }
    pub fn generateDatetime(self: *NativeDataSource, min: draws.special.DateTime, max: draws.special.DateTime) !draws.special.DateTime {
        return self.call(draws.special.generateDatetime, .{ min, max });
    }
    pub fn generateUuid(self: *NativeDataSource, version: ?u8) ![16]u8 {
        return self.call(draws.special.generateUuid, .{version});
    }
    pub fn generateIpv4(self: *NativeDataSource) ![4]u8 {
        return self.call(draws.special.generateIpv4, .{});
    }
    pub fn generateIpv6(self: *NativeDataSource) ![16]u8 {
        return self.call(draws.special.generateIpv6, .{});
    }
    pub fn collectionMore(self: *NativeDataSource, s: *state.ManyState) !bool {
        return self.call(draws.manyMore, .{s});
    }
    pub fn collectionReject(self: *NativeDataSource, s: *state.ManyState) !void {
        return self.call(draws.manyReject, .{s});
    }
    pub fn newRecursion(self: *NativeDataSource, depth: u64, leaves: u64) !state.RecursionState {
        return self.call(draws.newRecursionState, .{ depth, leaves });
    }
    pub fn recursionBranch(self: *NativeDataSource, s: *state.RecursionState, depth: u64) !bool {
        return self.call(draws.recursionBranch, .{ s, depth });
    }
    pub fn recursionRetry(self: *NativeDataSource, s: *state.RecursionState) !void {
        return self.call(draws.recursionRetry, .{s});
    }
    pub fn recursionFinish(self: *NativeDataSource, s: *state.RecursionState) !bool {
        return self.call(draws.recursionFinish, .{s});
    }
    fn invalid(self: *NativeDataSource, comptime fmt: []const u8, args: anytype) anyerror {
        const message = try std.fmt.allocPrint(self.allocator, fmt, args);
        defer self.allocator.free(message);
        try self.setDiagnostic(message);
        return error.InvalidArgument;
    }
    pub fn newStateMachine(self: *NativeDataSource, names: []const []const u8, groups: []const i64, weights: []const f64, invariant_names: []const []const u8, always: []const bool, min: i64, max: i64, steps: i64) !machine_mod.NativeStateMachine {
        if (names.len == 0) return self.invalid("cannot run a state machine with no rules", .{});
        if (groups.len != names.len) return self.invalid("rule_groups must be parallel to rule_names: got {d} group assignments for {d} rules", .{ groups.len, names.len });
        if (weights.len != names.len) return self.invalid("rule_weights must be parallel to rule_names: got {d} weights for {d} rules", .{ weights.len, names.len });
        for (weights, 0..) |weight, rule| if (!std.math.isFinite(weight) or weight <= 0) return self.invalid("rule weights must be finite and positive, but rule {d} ({s}) has weight {f}", .{ rule, names[rule], @import("rust_fmt.zig").floatDisplay(weight) });
        if (always.len != invariant_names.len) return self.invalid("invariant_always_check must be parallel to invariant_names: got {d} flags for {d} invariants", .{ always.len, invariant_names.len });
        if (min < 1 or max < min) return self.invalid("state machine concurrency bounds must satisfy 1 <= min <= max, got [{d}, {d}]", .{ min, max });
        if (@import("builtin").target.cpu.arch.isWasm() and max > 1) return self.invalid("concurrent state machines are not supported in the WebAssembly build", .{});
        if (steps < 1) return self.invalid("state machine step count must be at least 1, got {d}", .{steps});
        return self.call(newMachineImpl, .{ groups, weights, always, min, max, steps });
    }
    fn newMachineImpl(ntc: *state.NativeTestCase, groups: []const i64, weights: []const f64, always: []const bool, min: i64, max: i64, steps: i64) !machine_mod.NativeStateMachine {
        return machine_mod.NativeStateMachine.init(ntc, groups, weights, always, min, max, steps);
    }
    pub fn stateMachineNextGroup(self: *NativeDataSource, machine: *machine_mod.NativeStateMachine) !?i64 {
        return self.call(machineNextGroup, .{machine}) catch |err| {
            if (err == error.InvalidArgument) if (machine.diagnostic) |message| try self.setDiagnostic(message);
            return err;
        };
    }
    fn machineNextGroup(ntc: *state.NativeTestCase, machine: *machine_mod.NativeStateMachine) !?i64 {
        return machine.nextGroup(ntc);
    }
    pub fn stateMachineNextRule(self: *NativeDataSource, machine: *machine_mod.NativeStateMachine, worker: i64) !?i64 {
        return self.call(machineNextRule, .{ machine, worker }) catch |err| {
            if (err == error.InvalidArgument) if (machine.diagnostic) |message| try self.setDiagnostic(message);
            return err;
        };
    }
    fn machineNextRule(ntc: *state.NativeTestCase, machine: *machine_mod.NativeStateMachine, worker: i64) !?i64 {
        return machine.nextRule(ntc, worker);
    }
    pub fn stateMachineRuleRejected(self: *NativeDataSource, machine: *machine_mod.NativeStateMachine, worker: i64) !void {
        return self.call(machineRuleRejected, .{ machine, worker }) catch |err| {
            if (err == error.InvalidArgument) if (machine.diagnostic) |message| try self.setDiagnostic(message);
            return err;
        };
    }
    fn machineRuleRejected(_: *state.NativeTestCase, machine: *machine_mod.NativeStateMachine, worker: i64) !void {
        return machine.ruleRejected(worker);
    }
    pub fn stateMachineShouldCheckInvariant(self: *NativeDataSource, machine: *machine_mod.NativeStateMachine, index: i64) !bool {
        return self.call(machineInvariant, .{ machine, index }) catch |err| {
            if (err == error.InvalidArgument) if (machine.diagnostic) |message| try self.setDiagnostic(message);
            return err;
        };
    }
    fn machineInvariant(ntc: *state.NativeTestCase, machine: *machine_mod.NativeStateMachine, index: i64) !bool {
        return machine.shouldCheckInvariant(ntc, index);
    }
    pub fn generateString(self: *NativeDataSource, spec: *const draws.StringSpec) ![]u8 {
        return self.call(draws.generateString, .{spec});
    }
};

fn floatDisplay(allocator: Allocator, value: f64) ![]u8 {
    return std.fmt.allocPrint(allocator, "{f}", .{@import("rust_fmt.zig").floatDisplay(value)});
}

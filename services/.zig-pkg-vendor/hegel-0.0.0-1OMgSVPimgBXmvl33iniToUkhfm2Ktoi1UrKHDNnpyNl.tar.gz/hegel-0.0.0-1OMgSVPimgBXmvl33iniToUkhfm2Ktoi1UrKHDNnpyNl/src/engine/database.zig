// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const choices = @import("choices.zig");
const Allocator = std.mem.Allocator;
const Value = choices.ChoiceValue;
const ValueRef = choices.ChoiceValueRef;
const BigInt = choices.BigInt;
pub const max_clone_depth = 100;
pub const metakeys_name = ".hegel-keys";
const Error = choices.Error || error{MalformedData};

pub fn fnv1a(bytes: []const u8) u64 {
    var value: u64 = 0xcbf29ce484222325;
    for (bytes) |byte| value = (value ^ byte) *% 0x100000001b3;
    return value;
}

pub fn fnvHex(bytes: []const u8) [16]u8 {
    var result: [16]u8 = undefined;
    _ = std.fmt.bufPrint(&result, "{x:0>16}", .{fnv1a(bytes)}) catch unreachable;
    return result;
}

pub fn subKey(allocator: Allocator, key: []const u8, sub: []const u8) Allocator.Error![]u8 {
    return std.fmt.allocPrint(allocator, "{s}.{s}", .{ key, sub });
}

pub fn serializeChoices(allocator: Allocator, values: []const Value) Error!?[]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    writeChoices(allocator, &out, values, 0) catch |err| {
        if (err != error.MalformedData) return err;
        out.deinit(allocator);
        return null;
    };
    return try out.toOwnedSlice(allocator);
}

pub fn serializeNodes(allocator: Allocator, nodes: []const choices.ChoiceNode) Error!?[]u8 {
    var out: std.ArrayList(u8) = .empty;
    errdefer out.deinit(allocator);
    writeLength(allocator, &out, nodes.len) catch |err| {
        if (err != error.MalformedData) return err;
        out.deinit(allocator);
        return null;
    };
    for (nodes) |*node| writeOne(allocator, &out, node.data.valueRef(), 0) catch |err| {
        if (err != error.MalformedData) return err;
        out.deinit(allocator);
        return null;
    };
    return try out.toOwnedSlice(allocator);
}

pub fn serializeOneChoice(allocator: Allocator, out: *std.ArrayList(u8), value: ValueRef) Error!bool {
    const start = out.items.len;
    writeOne(allocator, out, value, 0) catch |err| {
        out.shrinkRetainingCapacity(start);
        if (err == error.MalformedData) return false;
        return err;
    };
    return true;
}

fn writeLength(allocator: Allocator, out: *std.ArrayList(u8), len: usize) Error!void {
    const value = std.math.cast(u32, len) orelse return error.MalformedData;
    try out.appendSlice(allocator, &std.mem.toBytes(std.mem.nativeToLittle(u32, value)));
}

fn writeChoices(allocator: Allocator, out: *std.ArrayList(u8), values: []const Value, depth: usize) Error!void {
    if (depth > max_clone_depth) return error.MalformedData;
    try writeLength(allocator, out, values.len);
    for (values) |*value| try writeOne(allocator, out, value.valueRef(), depth);
}

fn writeOne(allocator: Allocator, out: *std.ArrayList(u8), value: ValueRef, depth: usize) Error!void {
    switch (value) {
        .integer => |v| {
            try out.appendSlice(allocator, &.{ 0, 10 });
            const bytes = try v.toSignedBytesLe(allocator);
            defer allocator.free(bytes);
            try writeLength(allocator, out, bytes.len);
            try out.appendSlice(allocator, bytes);
        },
        .boolean => |v| try out.appendSlice(allocator, &.{ 1, @intFromBool(v) }),
        .float => |v| {
            try out.append(allocator, 2);
            try out.appendSlice(allocator, &std.mem.toBytes(std.mem.nativeToLittle(u64, @bitCast(v))));
        },
        .bytes => |v| {
            try out.append(allocator, 3);
            try writeLength(allocator, out, v.len);
            try out.appendSlice(allocator, v);
        },
        .string => |v| {
            try out.append(allocator, 4);
            try writeLength(allocator, out, v.len);
            for (v) |codepoint| try out.appendSlice(allocator, &std.mem.toBytes(std.mem.nativeToLittle(u32, codepoint)));
        },
        .clone => |v| {
            if (depth + 1 > max_clone_depth) return error.MalformedData;
            try out.append(allocator, 5);
            try writeLength(allocator, out, v.len());
            for (0..v.len()) |i| try writeOne(allocator, out, v.valueAt(i), depth + 1);
        },
    }
}

pub fn deserializeChoices(allocator: Allocator, bytes: []const u8) Error!?[]Value {
    return decode(allocator, bytes, false);
}

pub fn deserializeChoicesExact(allocator: Allocator, bytes: []const u8) Error!?[]Value {
    return decode(allocator, bytes, true);
}

fn decode(allocator: Allocator, bytes: []const u8, exact: bool) Error!?[]Value {
    var parser: Parser = .{ .allocator = allocator, .bytes = bytes };
    const result = parser.readList(0) catch |err| {
        if (err == error.MalformedData) return null;
        return err;
    };
    if (exact and parser.position != bytes.len) {
        deinitValues(allocator, result);
        return null;
    }
    return result;
}

pub fn deinitValues(allocator: Allocator, values: []Value) void {
    for (values) |*value| value.deinit(allocator);
    allocator.free(values);
}

const Parser = struct {
    allocator: Allocator,
    bytes: []const u8,
    position: usize = 0,

    fn take(self: *Parser, count: usize) error{MalformedData}![]const u8 {
        if (count > self.bytes.len - self.position) return error.MalformedData;
        const bytes = self.bytes[self.position..][0..count];
        self.position += count;
        return bytes;
    }

    fn number(self: *Parser, comptime T: type) error{MalformedData}!T {
        return std.mem.readInt(T, (try self.take(@sizeOf(T)))[0..@sizeOf(T)], .little);
    }

    fn readList(self: *Parser, depth: usize) Error![]Value {
        if (depth > max_clone_depth) return error.MalformedData;
        const count = try self.number(u32);
        if (count > self.bytes.len - self.position) return error.MalformedData;
        var values: std.ArrayList(Value) = .empty;
        errdefer {
            for (values.items) |*value| value.deinit(self.allocator);
            values.deinit(self.allocator);
        }
        for (0..count) |_| {
            var value = try self.readOne(depth);
            errdefer value.deinit(self.allocator);
            try values.append(self.allocator, value);
        }
        return values.toOwnedSlice(self.allocator);
    }

    fn readOne(self: *Parser, depth: usize) Error!Value {
        return switch (try self.number(u8)) {
            0 => .{ .integer = try self.readInteger() },
            1 => .{ .boolean = try self.number(u8) != 0 },
            2 => .{ .float = @bitCast(try self.number(u64)) },
            3 => .{ .bytes = try self.allocator.dupe(u8, try self.take(try self.number(u32))) },
            4 => result: {
                const count = try self.number(u32);
                if (count > (self.bytes.len - self.position) / 4) return error.MalformedData;
                const points = try self.allocator.alloc(u32, count);
                errdefer self.allocator.free(points);
                for (points) |*point| point.* = try self.number(u32);
                break :result .{ .string = points };
            },
            5 => result: {
                const values = try self.readList(depth + 1);
                errdefer deinitValues(self.allocator, values);
                break :result .{ .clone = try choices.CloneRecord.fromValues(self.allocator, values) };
            },
            else => error.MalformedData,
        };
    }

    fn readInteger(self: *Parser) Error!BigInt {
        return switch (try self.number(u8)) {
            0 => try BigInt.fromInt(self.allocator, try self.number(i8)),
            1 => try BigInt.fromInt(self.allocator, try self.number(i16)),
            2 => try BigInt.fromInt(self.allocator, try self.number(i32)),
            3 => try BigInt.fromInt(self.allocator, try self.number(i64)),
            4 => try BigInt.fromInt(self.allocator, try self.number(i128)),
            5 => try BigInt.fromInt(self.allocator, try self.number(u8)),
            6 => try BigInt.fromInt(self.allocator, try self.number(u16)),
            7 => try BigInt.fromInt(self.allocator, try self.number(u32)),
            8 => try BigInt.fromInt(self.allocator, try self.number(u64)),
            9 => try BigInt.fromInt(self.allocator, try self.number(u128)),
            10 => try BigInt.fromSignedBytesLe(self.allocator, try self.take(try self.number(u32))),
            else => error.MalformedData,
        };
    }
};

var temporary_counter: std.atomic.Value(u64) = .init(0);

pub const DirectoryDatabase = struct {
    allocator: Allocator,
    io: std.Io,
    root: []u8,

    pub fn init(allocator: Allocator, io: std.Io, root: []const u8) Allocator.Error!DirectoryDatabase {
        return .{ .allocator = allocator, .io = io, .root = try allocator.dupe(u8, root) };
    }

    pub fn deinit(self: *DirectoryDatabase) void {
        self.allocator.free(self.root);
        self.* = undefined;
    }

    pub fn keyPath(self: *const DirectoryDatabase, allocator: Allocator, key: []const u8) Allocator.Error![]u8 {
        return std.fmt.allocPrint(allocator, "{s}/{s}", .{ self.root, keyHash(key) });
    }

    pub fn fetch(self: *const DirectoryDatabase, allocator: Allocator, key: []const u8) Allocator.Error![][]u8 {
        var values: std.ArrayList([]u8) = .empty;
        errdefer {
            for (values.items) |value| allocator.free(value);
            values.deinit(allocator);
        }
        const path = try self.keyPath(allocator, key);
        defer allocator.free(path);
        const dir = std.Io.Dir.cwd().openDir(self.io, path, .{ .iterate = true }) catch return values.toOwnedSlice(allocator);
        defer dir.close(self.io);
        var iterator = dir.iterate();
        while (iterator.next(self.io) catch null) |entry| {
            const bytes = dir.readFileAlloc(self.io, entry.name, allocator, .unlimited) catch continue;
            errdefer allocator.free(bytes);
            try values.append(allocator, bytes);
        }
        return values.toOwnedSlice(allocator);
    }

    pub fn save(self: *const DirectoryDatabase, key: []const u8, value: []const u8) void {
        var arena = std.heap.ArenaAllocator.init(self.allocator);
        defer arena.deinit();
        const allocator = arena.allocator();
        const path = self.keyPath(allocator, key) catch return;
        const cwd = std.Io.Dir.cwd();
        const existed = exists(self.io, path);
        if (!std.mem.eql(u8, key, metakeys_name) and !existed) self.save(metakeys_name, key);
        cwd.createDirPath(self.io, path) catch return;
        const file = std.fmt.allocPrint(allocator, "{s}/{s}", .{ path, fnvHex(value) }) catch return;
        if (exists(self.io, file)) return;
        const temporary = std.fmt.allocPrint(allocator, "{s}.tmp.{d}.{d}", .{ file, std.c.getpid(), temporary_counter.fetchAdd(1, .monotonic) }) catch return;
        cwd.writeFile(self.io, .{ .sub_path = temporary, .data = value }) catch {
            cwd.deleteFile(self.io, temporary) catch {};
            return;
        };
        cwd.rename(temporary, cwd, file, self.io) catch cwd.deleteFile(self.io, temporary) catch {};
    }

    pub fn delete(self: *const DirectoryDatabase, key: []const u8, value: []const u8) void {
        var arena = std.heap.ArenaAllocator.init(self.allocator);
        defer arena.deinit();
        const path = self.keyPath(arena.allocator(), key) catch return;
        const file = std.fmt.allocPrint(arena.allocator(), "{s}/{s}", .{ path, fnvHex(value) }) catch return;
        const cwd = std.Io.Dir.cwd();
        cwd.deleteFile(self.io, file) catch return;
        cwd.deleteDir(self.io, path) catch return;
        if (!std.mem.eql(u8, key, metakeys_name)) self.delete(metakeys_name, key);
    }

    pub fn moveValue(self: *const DirectoryDatabase, src: []const u8, dst: []const u8, value: []const u8) void {
        if (std.mem.eql(u8, src, dst)) return self.save(src, value);
        var arena = std.heap.ArenaAllocator.init(self.allocator);
        defer arena.deinit();
        const allocator = arena.allocator();
        const dst_path = self.keyPath(allocator, dst) catch return;
        if (!exists(self.io, dst_path)) self.save(metakeys_name, dst);
        const cwd = std.Io.Dir.cwd();
        cwd.createDirPath(self.io, dst_path) catch {
            self.delete(src, value);
            self.save(dst, value);
            return;
        };
        const src_path = self.keyPath(allocator, src) catch return;
        const src_file = std.fmt.allocPrint(allocator, "{s}/{s}", .{ src_path, fnvHex(value) }) catch return;
        const dst_file = std.fmt.allocPrint(allocator, "{s}/{s}", .{ dst_path, fnvHex(value) }) catch return;
        cwd.rename(src_file, cwd, dst_file, self.io) catch {
            self.delete(src, value);
            self.save(dst, value);
            return;
        };
        cwd.deleteDir(self.io, src_path) catch return;
        if (!std.mem.eql(u8, src, metakeys_name)) self.delete(metakeys_name, src);
    }
};

fn keyHash(key: []const u8) [16]u8 {
    var value = fnv1a("native:");
    for (key) |byte| value = (value ^ byte) *% 0x100000001b3;
    var result: [16]u8 = undefined;
    _ = std.fmt.bufPrint(&result, "{x:0>16}", .{value}) catch unreachable;
    return result;
}

fn exists(io: std.Io, path: []const u8) bool {
    _ = std.Io.Dir.cwd().statFile(io, path, .{}) catch return false;
    return true;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/lib.rs printer ABI block; see provenance.
const std = @import("std");
const api = @import("c_api.zig");
const p = @import("printer.zig");
const gpa = api.gpa;
const t = api.types;
const C = api.HegelContext;
pub const HegelPrinterOptions = struct { max_width: ?u64 = null };
pub const HegelReflowOptions = struct { inner: p.reflow.ReflowOptions = .{} };
pub const HegelPrinter = struct {
    inner: *p.PrinterShared,
    target: p.Target,
    busy: std.atomic.Value(bool) = .init(false),
    worker: ?*api.WorkerCell = null,
    started: ?i128 = null,
    fn create(inner: *p.PrinterShared, target: p.Target, worker: ?*api.WorkerCell, started: ?i128) !*@This() {
        const self = try gpa.create(@This());
        self.* = .{ .inner = inner.retain(), .target = target, .worker = if (worker) |w| w.retain() else null, .started = started };
        return self;
    }
    fn destroy(self: *@This()) void {
        self.inner.release();
        if (self.worker) |w| w.release();
        gpa.destroy(self);
    }
    fn linePrefixBuffer(self: *const @This()) !?[]u8 {
        return attributionPrefix(self.worker, self.started);
    }
    fn stamp(self: *@This()) !void {
        if (self.inner.value.atLineStart(self.target)) {
            if (try self.linePrefixBuffer()) |prefix| {
                defer gpa.free(prefix);
                try self.inner.value.linePrefix(self.target, prefix);
            }
        }
    }
};
fn attributionPrefix(worker: ?*api.WorkerCell, started: ?i128) !?[]u8 {
    @setFloatMode(.strict);
    const cell = worker orelse return null;
    const id = cell.value.load(.acquire);
    if (id == -1) return null;
    const elapsed = if (started) |start| @max(@as(i128, 0), @as(i128, @intCast(std.Io.Clock.awake.now(api.io()).nanoseconds)) - start) else 0;
    const secs = @divTrunc(elapsed, 1000000000);
    const nanos = @mod(elapsed, 1000000000);
    const ms = (@as(f64, @floatFromInt(secs)) + @as(f64, @floatFromInt(nanos)) / 1e9) * 1000.0;
    return try std.fmt.allocPrint(gpa, "[worker {d} +{d:.3}ms] ", .{ id, ms });
}
fn translate(ctx: ?*C, comptime name: []const u8, err: anyerror) c_int {
    return api.fail(ctx, if (err == error.DeadSlot) t.HEGEL_E_INVALID_HANDLE else if (err == error.OutOfMemory) t.HEGEL_E_INTERNAL else t.HEGEL_E_INVALID_ARG, name ++ ": {s}", .{p.errorMessage(err)});
}
fn guard(ctx: ?*C, comptime name: []const u8, printer: ?*HegelPrinter) ?*HegelPrinter {
    const handle = printer orelse {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, name ++ ": printer handle is null", .{});
        return null;
    };
    if (handle.busy.cmpxchgStrong(false, true, .acq_rel, .acquire) != null) {
        _ = api.fail(ctx, t.HEGEL_E_CONCURRENT_USE, name ++ ": printer handle is in use by another thread", .{});
        return null;
    }
    return handle;
}
fn guardError(printer: ?*HegelPrinter) c_int {
    return if (printer == null) t.HEGEL_E_INVALID_HANDLE else t.HEGEL_E_CONCURRENT_USE;
}
fn releaseGuard(handle: *HegelPrinter) void {
    handle.busy.store(false, .release);
}
fn textArg(ctx: ?*C, comptime name: []const u8, comptime arg: []const u8, ptr: [*c]const u8, len: usize) ?[]const u8 {
    const text = api.optionalUtf8Buffer(ctx, name, arg, ptr, len) orelse return null;
    if (std.mem.indexOfScalar(u8, text, '\n') != null) {
        _ = api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": " ++ arg ++ " must not contain newlines", .{});
        return null;
    }
    return text;
}
pub export fn hegel_printer_options_new(ctx: ?*C, out: [*c]?*HegelPrinterOptions) c_int {
    api.clearLastError(ctx);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_printer_options_new: out parameter is null", .{});
    const value = gpa.create(HegelPrinterOptions) catch return translate(ctx, "hegel_printer_options_new", error.OutOfMemory);
    value.* = .{};
    out.* = value;
    return t.HEGEL_OK;
}
pub export fn hegel_printer_options_free(ctx: ?*C, options: ?*HegelPrinterOptions) c_int {
    api.clearLastError(ctx);
    if (options) |v| gpa.destroy(v);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_options_set_max_width(ctx: ?*C, options: ?*HegelPrinterOptions, max_width: u64) c_int {
    api.clearLastError(ctx);
    const value = options orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, "hegel_printer_options_set_max_width: options pointer is null", .{});
    if (max_width == 0) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_printer_options_set_max_width: max_width must be positive", .{});
    value.max_width = max_width;
    return t.HEGEL_OK;
}
pub export fn hegel_printer_new(ctx: ?*C, options: ?*const HegelPrinterOptions, out: [*c]?*HegelPrinter) c_int {
    api.clearLastError(ctx);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_printer_new: out parameter is null", .{});
    const width = if (options) |o| o.max_width orelse 79 else 79;
    const shared = p.PrinterShared.create(gpa, api.sizeArg(width)) catch |err| return translate(ctx, "hegel_printer_new", err);
    defer shared.release();
    out.* = HegelPrinter.create(shared, .main, null, null) catch |err| return translate(ctx, "hegel_printer_new", err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_free(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    api.clearLastError(ctx);
    if (printer) |v| v.destroy();
    return t.HEGEL_OK;
}
const TextOp = enum { text, if_break, breakable, comment, end_group };
fn textOp(ctx: ?*C, comptime name: []const u8, printer: ?*HegelPrinter, comptime op: TextOp, comptime arg: []const u8, ptr: [*c]const u8, len: usize) c_int {
    api.clearLastError(ctx);
    const handle = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(handle);
    const text = textArg(ctx, name, arg, ptr, len) orelse return t.HEGEL_E_INVALID_ARG;
    handle.inner.mutex.lock();
    defer handle.inner.mutex.unlock();
    if (op == .text or op == .if_break or op == .end_group) handle.stamp() catch |err| return translate(ctx, name, err);
    const result = switch (op) {
        .text => handle.inner.value.text(handle.target, text),
        .if_break => handle.inner.value.ifBreak(handle.target, text),
        .breakable => handle.inner.value.breakable(handle.target, text),
        .comment => handle.inner.value.comment(handle.target, text),
        .end_group => handle.inner.value.endGroup(handle.target, text),
    };
    result catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_text(ctx: ?*C, printer: ?*HegelPrinter, text: [*c]const u8, len: usize) c_int {
    return textOp(ctx, "hegel_printer_text", printer, .text, "text", text, len);
}
pub export fn hegel_printer_if_break(ctx: ?*C, printer: ?*HegelPrinter, text: [*c]const u8, len: usize) c_int {
    return textOp(ctx, "hegel_printer_if_break", printer, .if_break, "text", text, len);
}
pub export fn hegel_printer_breakable(ctx: ?*C, printer: ?*HegelPrinter, sep: [*c]const u8, len: usize) c_int {
    return textOp(ctx, "hegel_printer_breakable", printer, .breakable, "sep", sep, len);
}
pub export fn hegel_printer_comment(ctx: ?*C, printer: ?*HegelPrinter, text: [*c]const u8, len: usize) c_int {
    return textOp(ctx, "hegel_printer_comment", printer, .comment, "text", text, len);
}
pub export fn hegel_printer_end_group(ctx: ?*C, printer: ?*HegelPrinter, close: [*c]const u8, len: usize) c_int {
    return textOp(ctx, "hegel_printer_end_group", printer, .end_group, "close", close, len);
}
pub export fn hegel_printer_begin_group(ctx: ?*C, printer: ?*HegelPrinter, indent: u64, open: [*c]const u8, len: usize) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_begin_group";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    const text = textArg(ctx, name, "open", open, len) orelse return t.HEGEL_E_INVALID_ARG;
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    h.stamp() catch |err| return translate(ctx, name, err);
    h.inner.value.beginGroup(h.target, api.sizeArg(indent), text) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
const SimpleOp = enum { hard_break, begin_speculative, commit_speculative, abort_speculative };
fn simpleOp(ctx: ?*C, comptime name: []const u8, printer: ?*HegelPrinter, comptime op: SimpleOp) c_int {
    api.clearLastError(ctx);
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    const result = switch (op) {
        .hard_break => h.inner.value.hardBreak(h.target),
        .begin_speculative => h.inner.value.beginSpeculative(h.target),
        .commit_speculative => h.inner.value.commitSpeculative(h.target),
        .abort_speculative => h.inner.value.abortSpeculative(h.target),
    };
    result catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_hard_break(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    return simpleOp(ctx, "hegel_printer_hard_break", printer, .hard_break);
}
pub export fn hegel_printer_begin_speculative(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    return simpleOp(ctx, "hegel_printer_begin_speculative", printer, .begin_speculative);
}
pub export fn hegel_printer_commit_speculative(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    return simpleOp(ctx, "hegel_printer_commit_speculative", printer, .commit_speculative);
}
pub export fn hegel_printer_abort_speculative(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    return simpleOp(ctx, "hegel_printer_abort_speculative", printer, .abort_speculative);
}
pub export fn hegel_printer_shift_indent(ctx: ?*C, printer: ?*HegelPrinter, delta: i64) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_shift_indent";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    h.inner.value.shiftIndent(h.target, @intCast(std.math.clamp(delta, std.math.minInt(isize), std.math.maxInt(isize)))) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_deferred(ctx: ?*C, printer: ?*HegelPrinter, out: [*c]?*HegelPrinter) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_deferred";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": out parameter is null", .{});
    out.* = null;
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    const slot = h.inner.value.deferred(h.target) catch |err| return translate(ctx, name, err);
    out.* = HegelPrinter.create(h.inner, .{ .slot = slot }, h.worker, h.started) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_resolve(ctx: ?*C, printer: ?*HegelPrinter) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_resolve";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    if (h.target != .main) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": not the document's root handle", .{});
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    h.inner.value.resolve() catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_is_live(ctx: ?*C, printer: ?*HegelPrinter, out: [*c]bool) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_is_live";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": out parameter is null", .{});
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    out.* = switch (h.target) {
        .main => h.inner.value.mainIsLive(),
        .slot => |id| h.inner.value.slotIsLive(id),
    };
    return t.HEGEL_OK;
}
pub export fn hegel_printer_value(ctx: ?*C, printer: ?*HegelPrinter, out: [*c]t.hegel_printer_value_result_t) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_value";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": out parameter is null", .{});
    if (h.target != .main) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": not the document's root handle", .{});
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    const value = h.inner.value.value() catch |err| return translate(ctx, name, err);
    const bytes = gpa.dupe(u8, value) catch |err| return translate(ctx, name, err);
    out.* = .{ .data = bytes.ptr, .len = bytes.len };
    return t.HEGEL_OK;
}
pub export fn hegel_printer_value_result_free(ctx: ?*C, result: [*c]t.hegel_printer_value_result_t) c_int {
    api.clearLastError(ctx);
    if (result == null) return t.HEGEL_OK;
    if (result.*.data != null) gpa.free(result.*.data[0..result.*.len]);
    result.* = .{};
    return t.HEGEL_OK;
}
pub export fn hegel_reflow_options_new(ctx: ?*C, out: [*c]?*HegelReflowOptions) c_int {
    api.clearLastError(ctx);
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, "hegel_reflow_options_new: out parameter is null", .{});
    const value = gpa.create(HegelReflowOptions) catch |err| return translate(ctx, "hegel_reflow_options_new", err);
    value.* = .{};
    out.* = value;
    return t.HEGEL_OK;
}
pub export fn hegel_reflow_options_free(ctx: ?*C, options: ?*HegelReflowOptions) c_int {
    api.clearLastError(ctx);
    if (options) |value| gpa.destroy(value);
    return t.HEGEL_OK;
}
pub export fn hegel_printer_reflow(ctx: ?*C, printer: ?*HegelPrinter, options: ?*const HegelReflowOptions, text: [*c]const u8, len: usize) c_int {
    api.clearLastError(ctx);
    const name = "hegel_printer_reflow";
    const h = guard(ctx, name, printer) orelse return guardError(printer);
    defer releaseGuard(h);
    const repr = api.optionalUtf8Buffer(ctx, name, "text", text, len) orelse return t.HEGEL_E_INVALID_ARG;
    h.inner.mutex.lock();
    defer h.inner.mutex.unlock();
    h.stamp() catch |err| return translate(ctx, name, err);
    p.reflow.reflow(&h.inner.value, h.target, repr, if (options) |o| o.inner else .{}) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_test_case_printer(ctx: ?*C, tc: ?*api.HegelTestCase, options: ?*const HegelPrinterOptions, out: [*c]?*HegelPrinter) c_int {
    api.clearLastError(ctx);
    const name = "hegel_test_case_printer";
    const case = tc orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, name ++ ": test case pointer is null", .{});
    if (out == null) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": out parameter is null", .{});
    const shared = case.family.printer;
    if (options) |o| {
        if (o.max_width) |requested| {
            shared.mutex.lock();
            defer shared.mutex.unlock();
            if (!shared.width_configured) {
                shared.value.setMaxWidth(api.sizeArg(requested));
                shared.width_configured = true;
            } else if (shared.value.maxWidth() != api.sizeArg(requested)) return api.fail(ctx, t.HEGEL_E_INVALID_ARG, name ++ ": the family's document is laid out to max_width {d} and cannot change to {d}", .{ shared.value.maxWidth(), requested });
        }
    }
    out.* = HegelPrinter.create(shared, case.print_target, case.worker, case.family.started) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}
pub export fn hegel_note(ctx: ?*C, tc: ?*api.HegelTestCase, text: [*c]const u8, len: usize) c_int {
    api.clearLastError(ctx);
    const name = "hegel_note";
    const case = tc orelse return api.fail(ctx, t.HEGEL_E_INVALID_HANDLE, name ++ ": test case pointer is null", .{});
    const content = api.optionalUtf8Buffer(ctx, name, "text", text, len) orelse return t.HEGEL_E_INVALID_ARG;
    const prefix = attributionPrefix(case.worker, case.family.started) catch |err| return translate(ctx, name, err);
    defer if (prefix) |v| gpa.free(v);
    const shared = case.family.printer;
    shared.mutex.lock();
    defer shared.mutex.unlock();
    shared.value.note(case.print_target, content, prefix) catch |err| return translate(ctx, name, err);
    return t.HEGEL_OK;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const choices = @import("choices.zig");
const database = @import("database.zig");
const Allocator = std.mem.Allocator;
pub const ChoiceValue = choices.ChoiceValue;
pub const Frame = struct { label: u64, ordinal: usize };
pub const Addr = []Frame;
pub const DRAW_LABEL = @import("labels.zig").labelFromName("hegel.draw");
pub const START: usize = 0;
pub const END: usize = 1;
pub const MAX_NODES: usize = 1 << 20;
pub const MAX_EDGES: usize = 1 << 20;
pub const MAX_FRAMES: usize = 1 << 12;

pub fn framesEql(a: []const Frame, b: []const Frame) bool {
    if (a.len != b.len) return false;
    for (a, b) |left, right| if (left.label != right.label or left.ordinal != right.ordinal) return false;
    return true;
}

pub const Ident = union(enum) {
    start,
    at: Addr,
    end,

    pub fn eql(self: Ident, other: Ident) bool {
        if (std.meta.activeTag(self) != std.meta.activeTag(other)) return false;
        return switch (self) {
            .at => |a| framesEql(a, other.at),
            else => true,
        };
    }

    pub fn deepClone(self: Ident, gpa: Allocator) Allocator.Error!Ident {
        return switch (self) {
            .at => |a| .{ .at = try gpa.dupe(Frame, a) },
            else => self,
        };
    }

    pub fn deinit(self: *Ident, gpa: Allocator) void {
        if (self.* == .at) gpa.free(self.at);
        self.* = undefined;
    }
};

const IdentContext = struct {
    pub fn hash(_: @This(), ident: Ident) u64 {
        var h = std.hash.Wyhash.init(@backingInt(std.meta.activeTag(ident)));
        if (ident == .at) for (ident.at) |frame| {
            var bytes: [16]u8 = undefined;
            std.mem.writeInt(u64, bytes[0..8], frame.label, .little);
            std.mem.writeInt(u64, bytes[8..16], @intCast(frame.ordinal), .little);
            h.update(&bytes);
        };
        return h.final();
    }
    pub fn eql(_: @This(), a: Ident, b: Ident) bool {
        return a.eql(b);
    }
};

pub const Step = struct {
    addr: Addr,
    value: ChoiceValue,

    pub fn deepClone(self: *const Step, gpa: Allocator) choices.Error!Step {
        const addr = try gpa.dupe(Frame, self.addr);
        errdefer gpa.free(addr);
        return .{ .addr = addr, .value = try self.value.deepClone(gpa) };
    }

    pub fn deinit(self: *Step, gpa: Allocator) void {
        gpa.free(self.addr);
        self.value.deinit(gpa);
    }
};

pub fn drawAddresses(gpa: Allocator, spans: []const choices.Span, count: usize) Allocator.Error![]Addr {
    const Sibling = struct { parent: ?usize, label: u64 };
    var counts: std.AutoHashMapUnmanaged(Sibling, usize) = .empty;
    defer counts.deinit(gpa);
    const frames = try gpa.alloc(Frame, spans.len);
    defer gpa.free(frames);
    for (spans, frames) |span, *frame| {
        const entry = try counts.getOrPut(gpa, .{ .parent = span.parent, .label = span.label });
        if (!entry.found_existing) entry.value_ptr.* = 0;
        frame.* = .{ .label = span.label, .ordinal = entry.value_ptr.* };
        entry.value_ptr.* += 1;
    }
    var open: std.ArrayList(usize) = .empty;
    defer open.deinit(gpa);
    var direct: std.AutoHashMapUnmanaged(?usize, usize) = .empty;
    defer direct.deinit(gpa);
    const result = try gpa.alloc(Addr, count);
    var filled: usize = 0;
    errdefer {
        for (result[0..filled]) |addr| gpa.free(addr);
        gpa.free(result);
    }
    var next: usize = 0;
    for (0..count) |i| {
        while (next < spans.len and spans[next].start <= i) : (next += 1) {
            if (spans[next].end > i) try open.append(gpa, next);
        }
        var kept: usize = 0;
        for (open.items) |s| if (spans[s].end > i) {
            open.items[kept] = s;
            kept += 1;
        };
        open.items.len = kept;
        const parent: ?usize = if (kept == 0) null else open.items[kept - 1];
        const entry = try direct.getOrPut(gpa, parent);
        if (!entry.found_existing) entry.value_ptr.* = 0;
        const addr = try gpa.alloc(Frame, kept + 1);
        for (open.items, addr[0..kept]) |s, *frame| frame.* = frames[s];
        addr[kept] = .{ .label = DRAW_LABEL, .ordinal = entry.value_ptr.* };
        entry.value_ptr.* += 1;
        result[i] = addr;
        filled += 1;
    }
    return result;
}

pub fn deinitAddresses(gpa: Allocator, addresses: []Addr) void {
    for (addresses) |addr| gpa.free(addr);
    gpa.free(addresses);
}

pub const Run = struct {
    allocator: Allocator,
    steps: std.ArrayList(Step) = .empty,

    pub fn init(gpa: Allocator) Run {
        return .{ .allocator = gpa };
    }

    pub fn deinit(self: *Run) void {
        for (self.steps.items) |*step| step.deinit(self.allocator);
        self.steps.deinit(self.allocator);
    }

    pub fn append(self: *Run, addr: []const Frame, value: *const ChoiceValue) choices.Error!void {
        var step: Step = .{ .addr = try self.allocator.dupe(Frame, addr), .value = undefined };
        errdefer self.allocator.free(step.addr);
        step.value = try value.deepClone(self.allocator);
        errdefer step.value.deinit(self.allocator);
        try self.steps.append(self.allocator, step);
    }

    pub fn fromNodes(gpa: Allocator, nodes: []const choices.ChoiceNode, spans: []const choices.Span) choices.Error!Run {
        const addresses = try drawAddresses(gpa, spans, nodes.len);
        defer deinitAddresses(gpa, addresses);
        var run = Run.init(gpa);
        errdefer run.deinit();
        for (nodes, addresses) |*node, addr| {
            if (node.was_forced) continue;
            var value = try node.value(gpa);
            defer value.deinit(gpa);
            try run.append(addr, &value);
        }
        return run;
    }

    pub fn values(self: *const Run, gpa: Allocator) choices.Error![]ChoiceValue {
        const result = try gpa.alloc(ChoiceValue, self.steps.items.len);
        var filled: usize = 0;
        errdefer {
            for (result[0..filled]) |*value| value.deinit(gpa);
            gpa.free(result);
        }
        for (self.steps.items, result) |*step, *value| {
            value.* = try step.value.deepClone(gpa);
            filled += 1;
        }
        return result;
    }

    pub fn idents(self: *const Run, gpa: Allocator) Allocator.Error![]Ident {
        const result = try gpa.alloc(Ident, self.steps.items.len);
        var filled: usize = 0;
        errdefer {
            for (result[0..filled]) |*ident| ident.deinit(gpa);
            gpa.free(result);
        }
        for (self.steps.items, 0..) |step, i| {
            result[i] = if (i + 1 == self.steps.items.len) .end else try identAfter(gpa, step.addr, self.steps.items[i + 1].addr);
            filled += 1;
        }
        return result;
    }
};

pub fn identAfter(gpa: Allocator, prev: []const Frame, next: []const Frame) Allocator.Error!Ident {
    var shared: usize = 0;
    while (shared < @min(prev.len, next.len) and framesEql(prev[shared..][0..1], next[shared..][0..1])) : (shared += 1) {}
    return .{ .at = try gpa.dupe(Frame, next[0..@min(shared + 1, next.len)]) };
}

pub fn identBefore(gpa: Allocator, prev: ?[]const Frame, next: []const Frame) Allocator.Error!Ident {
    return if (prev) |p| identAfter(gpa, p, next) else .start;
}

pub const Edge = struct {
    addr: Addr,
    value: ChoiceValue,
    target: usize,

    pub fn eql(self: *const Edge, other: *const Edge) bool {
        return self.target == other.target and framesEql(self.addr, other.addr) and self.value.eql(&other.value);
    }

    pub fn deepClone(self: *const Edge, gpa: Allocator) choices.Error!Edge {
        const addr = try gpa.dupe(Frame, self.addr);
        errdefer gpa.free(addr);
        return .{ .addr = addr, .value = try self.value.deepClone(gpa), .target = self.target };
    }

    pub fn deinit(self: *Edge, gpa: Allocator) void {
        gpa.free(self.addr);
        self.value.deinit(gpa);
    }
};

pub const Node = struct {
    ident: Ident,
    edges: std.ArrayList(Edge) = .empty,

    fn deinit(self: *Node, gpa: Allocator) void {
        self.ident.deinit(gpa);
        for (self.edges.items) |*edge| edge.deinit(gpa);
        self.edges.deinit(gpa);
    }
};

pub const Walked = enum { whole, foreign, gap };

pub const Graph = struct {
    allocator: Allocator,
    nodes_list: std.ArrayList(Node) = .empty,
    index: std.HashMapUnmanaged(Ident, usize, IdentContext, std.hash_map.default_max_load_percentage) = .empty,

    pub fn init(gpa: Allocator) Allocator.Error!Graph {
        var graph: Graph = .{ .allocator = gpa };
        errdefer graph.deinit();
        _ = try graph.nodeFor(.start);
        _ = try graph.nodeFor(.end);
        return graph;
    }

    pub fn deinit(self: *Graph) void {
        for (self.nodes_list.items) |*n| n.deinit(self.allocator);
        self.nodes_list.deinit(self.allocator);
        self.index.deinit(self.allocator);
    }

    pub fn fromRun(gpa: Allocator, run: *const Run) choices.Error!Graph {
        var graph = try Graph.init(gpa);
        errdefer graph.deinit();
        _ = try graph.insert(run);
        return graph;
    }

    pub fn nodes(self: *const Graph) []const Node {
        return self.nodes_list.items;
    }
    pub fn node(self: *const Graph, ident: Ident) ?usize {
        return self.index.get(ident);
    }

    pub fn nodeFor(self: *Graph, ident: Ident) Allocator.Error!usize {
        if (self.node(ident)) |n| return n;
        try self.nodes_list.ensureUnusedCapacity(self.allocator, 1);
        try self.index.ensureUnusedCapacity(self.allocator, 1);
        const n = self.nodes_list.items.len;
        const copied = try ident.deepClone(self.allocator);
        self.nodes_list.appendAssumeCapacity(.{ .ident = copied });
        self.index.putAssumeCapacity(copied, n);
        return n;
    }

    fn edgeTo(self: *const Graph, n: usize, step: *const Step, want: usize) ?usize {
        for (self.nodes()[n].edges.items, 0..) |*edge, i| {
            if (edge.target == want and framesEql(edge.addr, step.addr) and edge.value.eql(&step.value)) return i;
        }
        return null;
    }

    pub fn insert(self: *Graph, run: *const Run) choices.Error!bool {
        const identities = try run.idents(self.allocator);
        defer {
            for (identities) |*ident| ident.deinit(self.allocator);
            self.allocator.free(identities);
        }
        var n = START;
        var added = false;
        for (run.steps.items, identities) |*step, ident| {
            const want = try self.nodeFor(ident);
            if (self.edgeTo(n, step, want) == null) {
                var edge: Edge = .{ .addr = try self.allocator.dupe(Frame, step.addr), .value = undefined, .target = want };
                errdefer self.allocator.free(edge.addr);
                edge.value = try step.value.deepClone(self.allocator);
                errdefer edge.value.deinit(self.allocator);
                try self.nodes_list.items[n].edges.append(self.allocator, edge);
                added = true;
            }
            n = want;
        }
        return added;
    }

    pub fn graft(self: *Graph, run: *const Run) choices.Error!bool {
        return self.walkVerdict(run) == .gap and try self.insert(run);
    }

    pub fn withRun(self: *const Graph, run: *const Run) choices.Error!Graph {
        if (self.walkVerdict(run) == .foreign) return Graph.fromRun(self.allocator, run);
        var graph = try self.deepClone();
        errdefer graph.deinit();
        _ = try graph.insert(run);
        return graph;
    }

    pub fn walkVerdict(self: *const Graph, run: *const Run) Walked {
        var n = START;
        for (run.steps.items, 0..) |*step, i| {
            var first: ?*const Edge = null;
            for (self.nodes()[n].edges.items) |*edge| if (framesEql(edge.addr, step.addr) and valueKind(&edge.value) == valueKind(&step.value)) {
                first = edge;
                break;
            };
            if (first == null) return .gap;
            if (!first.?.value.eql(&step.value)) return .foreign;
            const want: ?usize = if (i + 1 == run.steps.items.len) END else blk: {
                const next = run.steps.items[i + 1].addr;
                var shared: usize = 0;
                while (shared < @min(step.addr.len, next.len) and framesEql(step.addr[shared..][0..1], next[shared..][0..1])) : (shared += 1) {}
                break :blk self.node(.{ .at = @constCast(next[0..@min(shared + 1, next.len)]) });
            };
            if (want == null or self.edgeTo(n, step, want.?) == null) return .gap;
            n = want.?;
        }
        return if (n == END) .whole else .gap;
    }

    pub fn reachable(self: *const Graph, gpa: Allocator) Allocator.Error![]usize {
        var order: std.ArrayList(usize) = .empty;
        errdefer order.deinit(gpa);
        const seen = try gpa.alloc(bool, self.nodes_list.items.len);
        defer gpa.free(seen);
        @memset(seen, false);
        seen[START] = true;
        try order.append(gpa, START);
        var i: usize = 0;
        while (i < order.items.len) : (i += 1) for (self.nodes()[order.items[i]].edges.items) |edge| {
            if (!seen[edge.target]) {
                seen[edge.target] = true;
                try order.append(gpa, edge.target);
            }
        };
        return order.toOwnedSlice(gpa);
    }

    pub fn edgeCount(self: *const Graph) Allocator.Error!usize {
        const order = try self.reachable(self.allocator);
        defer self.allocator.free(order);
        var total: usize = 0;
        for (order) |n| total += self.nodes()[n].edges.items.len;
        return total;
    }

    pub fn key(self: *const Graph) choices.Error!GraphKey {
        const order = try self.reachable(self.allocator);
        defer self.allocator.free(order);
        var values: std.ArrayList(ValueRank) = .empty;
        errdefer {
            for (values.items) |*v| v.deinit(self.allocator);
            values.deinit(self.allocator);
        }
        for (order) |n| for (self.nodes()[n].edges.items) |*edge| {
            var rank = try shrinkRank(self.allocator, &edge.value);
            errdefer rank.deinit(self.allocator);
            try values.append(self.allocator, rank);
        };
        const count = values.items.len;
        return .{ .allocator = self.allocator, .edges = count, .nodes = order.len, .values = try values.toOwnedSlice(self.allocator) };
    }

    pub fn deepClone(self: *const Graph) choices.Error!Graph {
        return self.deepCloneWithAllocator(self.allocator);
    }

    pub fn deepCloneWithAllocator(self: *const Graph, gpa: Allocator) choices.Error!Graph {
        var graph: Graph = .{ .allocator = gpa };
        errdefer graph.deinit();
        for (self.nodes()) |n| {
            const index = try graph.nodeFor(n.ident);
            for (n.edges.items) |*edge| {
                var copied = try edge.deepClone(gpa);
                errdefer copied.deinit(gpa);
                try graph.nodes_list.items[index].edges.append(gpa, copied);
            }
        }
        return graph;
    }

    pub fn pruned(self: *const Graph) choices.Error!Graph {
        const reached = try self.reachable(self.allocator);
        defer self.allocator.free(reached);
        var order: std.ArrayList(usize) = .empty;
        defer order.deinit(self.allocator);
        try order.appendSlice(self.allocator, &.{ START, END });
        for (reached) |n| if (n != START and n != END) try order.append(self.allocator, n);
        const map = try self.allocator.alloc(usize, self.nodes().len);
        defer self.allocator.free(map);
        @memset(map, std.math.maxInt(usize));
        for (order.items, 0..) |n, i| map[n] = i;
        var graph: Graph = .{ .allocator = self.allocator };
        errdefer graph.deinit();
        for (order.items) |n| {
            const index = try graph.nodeFor(self.nodes()[n].ident);
            for (self.nodes()[n].edges.items) |*edge| {
                var copied = try edge.deepClone(self.allocator);
                errdefer copied.deinit(self.allocator);
                copied.target = map[edge.target];
                try graph.nodes_list.items[index].edges.append(self.allocator, copied);
            }
        }
        return graph;
    }

    pub fn deleteEdge(self: *const Graph, n: usize, i: usize) choices.Error!Graph {
        var graph = try self.deepClone();
        errdefer graph.deinit();
        var removed = graph.nodes_list.items[n].edges.orderedRemove(i);
        removed.deinit(self.allocator);
        if (graph.nodes()[n].edges.items.len == 0) for (graph.nodes_list.items) |*current| {
            var k: usize = 0;
            while (k < current.edges.items.len) {
                if (current.edges.items[k].target == n) current.edges.items[k].target = END;
                var duplicate = false;
                for (current.edges.items[0..k]) |*previous| if (previous.eql(&current.edges.items[k])) {
                    duplicate = true;
                    break;
                };
                if (duplicate) {
                    var edge = current.edges.orderedRemove(k);
                    edge.deinit(self.allocator);
                } else k += 1;
            }
        };
        return graph;
    }

    pub fn setValue(self: *const Graph, n: usize, addr: []const Frame, old: *const ChoiceValue, value: *const ChoiceValue) choices.Error!Graph {
        var graph = try self.deepClone();
        errdefer graph.deinit();
        for (graph.nodes_list.items[n].edges.items) |*edge| if (framesEql(edge.addr, addr) and edge.value.eql(old)) {
            const replacement = try value.deepClone(self.allocator);
            edge.value.deinit(self.allocator);
            edge.value = replacement;
        };
        return graph;
    }

    pub fn retainSettled(self: *Graph, settled: []const Settled) Allocator.Error!void {
        for (self.nodes_list.items, 0..) |*current, n| {
            const keep = try self.allocator.alloc(bool, current.edges.items.len);
            defer self.allocator.free(keep);
            for (current.edges.items, 0..) |*edge, i| {
                keep[i] = settledContains(settled, n, i);
                if (keep[i]) continue;
                keep[i] = true;
                for (current.edges.items, 0..) |*other, j| if (i != j and framesEql(edge.addr, other.addr) and edge.value.eql(&other.value) and settledContains(settled, n, j)) {
                    keep[i] = false;
                    break;
                };
            }
            var kept: usize = 0;
            for (current.edges.items, keep) |edge, yes| {
                if (yes) {
                    current.edges.items[kept] = edge;
                    kept += 1;
                } else {
                    var removed = edge;
                    removed.deinit(self.allocator);
                }
            }
            current.edges.items.len = kept;
        }
    }

    pub fn encode(self: *const Graph) !?[]u8 {
        var buf: std.ArrayList(u8) = .empty;
        defer buf.deinit(self.allocator);
        try putU32(self.allocator, &buf, self.nodes().len);
        for (self.nodes()) |n| {
            try buf.append(self.allocator, switch (n.ident) {
                .start => 0,
                .end => 1,
                .at => 2,
            });
            if (n.ident == .at) try putFrames(self.allocator, &buf, n.ident.at);
            try putU32(self.allocator, &buf, n.edges.items.len);
            for (n.edges.items) |*edge| {
                try putFrames(self.allocator, &buf, edge.addr);
                const body = try database.serializeChoices(self.allocator, @as([*]const ChoiceValue, @ptrCast(&edge.value))[0..1]) orelse return null;
                defer self.allocator.free(body);
                try putU32(self.allocator, &buf, body.len);
                try buf.appendSlice(self.allocator, body);
                try putU32(self.allocator, &buf, edge.target);
            }
        }
        return try buf.toOwnedSlice(self.allocator);
    }

    pub fn decode(gpa: Allocator, bytes: []const u8) !?Graph {
        var rest = bytes;
        const count = takeU32(&rest) orelse return null;
        if (count < 2 or count > MAX_NODES) return null;
        var graph = try Graph.init(gpa);
        var success = false;
        defer if (!success) graph.deinit();
        for (0..count) |n| {
            if (rest.len == 0) return null;
            const tag = rest[0];
            rest = rest[1..];
            var ident: Ident = switch (tag) {
                0 => .start,
                1 => .end,
                2 => .{ .at = try takeFrames(gpa, &rest) orelse return null },
                else => return null,
            };
            defer ident.deinit(gpa);
            if ((n == START) != (ident == .start) or (n == END) != (ident == .end)) return null;
            if (n > END and graph.node(ident) != null) return null;
            if (try graph.nodeFor(ident) != n) return null;
            const edges = takeU32(&rest) orelse return null;
            if (edges > MAX_EDGES) return null;
            for (0..edges) |_| {
                const addr = try takeFrames(gpa, &rest) orelse return null;
                var added = false;
                defer if (!added) gpa.free(addr);
                const len = takeU32(&rest) orelse return null;
                if (rest.len < len) return null;
                const body = rest[0..len];
                rest = rest[len..];
                const values = try database.deserializeChoicesExact(gpa, body) orelse return null;
                if (values.len != 1) {
                    choices.deinitValues(gpa, values);
                    return null;
                }
                var value = values[0];
                gpa.free(values);
                defer if (!added) value.deinit(gpa);
                const target = takeU32(&rest) orelse return null;
                if (target >= count) return null;
                try graph.nodes_list.items[n].edges.append(gpa, .{ .addr = addr, .value = value, .target = target });
                added = true;
            }
        }
        if (rest.len != 0) return null;
        success = true;
        return graph;
    }
};

pub const Settled = struct { node: usize, edge: usize };
fn settledContains(settled: []const Settled, node: usize, edge: usize) bool {
    for (settled) |pair| if (pair.node == node and pair.edge == edge) return true;
    return false;
}

fn putU32(gpa: Allocator, buf: *std.ArrayList(u8), n: usize) Allocator.Error!void {
    var bytes: [4]u8 = undefined;
    std.mem.writeInt(u32, &bytes, @truncate(n), .little);
    try buf.appendSlice(gpa, &bytes);
}
fn takeU32(rest: *[]const u8) ?usize {
    if (rest.len < 4) return null;
    const n = std.mem.readInt(u32, rest.*[0..4], .little);
    rest.* = rest.*[4..];
    return n;
}
fn putFrames(gpa: Allocator, buf: *std.ArrayList(u8), frames: []const Frame) Allocator.Error!void {
    try putU32(gpa, buf, frames.len);
    for (frames) |frame| {
        var bytes: [8]u8 = undefined;
        std.mem.writeInt(u64, &bytes, frame.label, .little);
        try buf.appendSlice(gpa, &bytes);
        try putU32(gpa, buf, frame.ordinal);
    }
}
fn takeFrames(gpa: Allocator, rest: *[]const u8) Allocator.Error!?Addr {
    const count = takeU32(rest) orelse return null;
    if (count > MAX_FRAMES) return null;
    const frames = try gpa.alloc(Frame, count);
    var success = false;
    defer if (!success) gpa.free(frames);
    for (frames) |*frame| {
        if (rest.len < 8) return null;
        const label = std.mem.readInt(u64, rest.*[0..8], .little);
        rest.* = rest.*[8..];
        frame.* = .{ .label = label, .ordinal = takeU32(rest) orelse return null };
    }
    success = true;
    return frames;
}

pub const ValueRank = struct {
    kind: u8,
    size: u64,
    elements: []u64,
    pub fn deinit(self: *ValueRank, gpa: Allocator) void {
        gpa.free(self.elements);
    }
    pub fn order(self: ValueRank, other: ValueRank) std.math.Order {
        const kind_order = std.math.order(self.kind, other.kind);
        if (kind_order != .eq) return kind_order;
        const size_order = std.math.order(self.size, other.size);
        return if (size_order != .eq) size_order else std.mem.order(u64, self.elements, other.elements);
    }
};
pub const GraphKey = struct {
    allocator: Allocator,
    edges: usize,
    nodes: usize,
    values: []ValueRank,
    pub fn deinit(self: *GraphKey) void {
        for (self.values) |*value| value.deinit(self.allocator);
        self.allocator.free(self.values);
    }
    pub fn order(self: GraphKey, other: GraphKey) std.math.Order {
        const edge_order = std.math.order(self.edges, other.edges);
        if (edge_order != .eq) return edge_order;
        const node_order = std.math.order(self.nodes, other.nodes);
        if (node_order != .eq) return node_order;
        for (self.values[0..@min(self.values.len, other.values.len)], other.values[0..@min(self.values.len, other.values.len)]) |a, b| {
            const ordering = a.order(b);
            if (ordering != .eq) return ordering;
        }
        return std.math.order(self.values.len, other.values.len);
    }
};
pub fn valueKind(value: *const ChoiceValue) u8 {
    return switch (value.*) {
        .boolean => 0,
        .integer => 1,
        .float => 2,
        .bytes => 3,
        .string => 4,
        .clone => 5,
    };
}
pub fn shrinkRank(gpa: Allocator, value: *const ChoiceValue) choices.Error!ValueRank {
    var kind: u8 = undefined;
    var size: u64 = undefined;
    var elements: []u64 = undefined;
    switch (value.*) {
        .boolean => |v| {
            kind = 0;
            size = @intFromBool(v);
            elements = try gpa.alloc(u64, 0);
        },
        .integer => |v| {
            var magnitude = try v.magnitude(gpa);
            defer magnitude.deinit();
            kind = 1;
            size = magnitude.toInt(u64) orelse std.math.maxInt(u64);
            elements = try gpa.alloc(u64, 0);
        },
        .float => |v| {
            kind = 2;
            size = @import("float_index.zig").floatToIndex(@abs(v));
            elements = try gpa.alloc(u64, 0);
        },
        .bytes => |v| {
            kind = 3;
            size = @intCast(v.len);
            elements = try gpa.alloc(u64, v.len);
            for (v, elements) |x, *out| out.* = x;
        },
        .string => |v| {
            kind = 3;
            size = @intCast(v.len);
            elements = try gpa.alloc(u64, v.len);
            for (v, elements) |x, *out| out.* = x;
        },
        .clone => |v| {
            kind = 4;
            size = @intCast(v.flatLen());
            elements = try gpa.alloc(u64, 0);
        },
    }
    return .{ .kind = kind, .size = size, .elements = elements };
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/events.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const Allocator = std.mem.Allocator;
pub const Event = struct { label: []const u8, value: ?f64 = null };
const Count = struct { label: []u8, cases: u64 };
const Values = struct { label: []u8, values: std.ArrayList(f64) = .empty };
pub const Summary = struct { count: usize, min: f64, max: f64, median: f64, mean: f64, p90: f64 };
pub const RunStatistics = struct {
    allocator: Allocator,
    cases: u64 = 0,
    counts: std.ArrayList(Count) = .empty,
    values: std.ArrayList(Values) = .empty,
    measurement_calls: u64 = 0,
    measurement_fails: u64 = 0,
    pub fn init(gpa: Allocator) RunStatistics {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *RunStatistics) void {
        for (self.counts.items) |entry| self.allocator.free(entry.label);
        for (self.values.items) |*entry| {
            self.allocator.free(entry.label);
            entry.values.deinit(self.allocator);
        }
        self.counts.deinit(self.allocator);
        self.values.deinit(self.allocator);
        self.* = undefined;
    }
    pub fn recordCase(self: *RunStatistics, events: []const Event) !void {
        self.cases += 1;
        for (events, 0..) |event, index| {
            if (event.value) |v| {
                var target: ?*Values = null;
                for (self.values.items) |*entry| if (std.mem.eql(u8, entry.label, event.label)) {
                    target = entry;
                    break;
                };
                if (target) |entry| {
                    try entry.values.append(self.allocator, v);
                } else {
                    const label = try self.allocator.dupe(u8, event.label);
                    errdefer self.allocator.free(label);
                    var entry: Values = .{ .label = label };
                    errdefer entry.values.deinit(self.allocator);
                    try entry.values.append(self.allocator, v);
                    try self.values.append(self.allocator, entry);
                }
            } else {
                var seen = false;
                for (events[0..index]) |previous| if (previous.value == null and std.mem.eql(u8, previous.label, event.label)) {
                    seen = true;
                    break;
                };
                if (seen) continue;
                var found = false;
                for (self.counts.items) |*entry| if (std.mem.eql(u8, entry.label, event.label)) {
                    entry.cases += 1;
                    found = true;
                    break;
                };
                if (!found) {
                    const label = try self.allocator.dupe(u8, event.label);
                    errdefer self.allocator.free(label);
                    try self.counts.append(self.allocator, .{ .label = label, .cases = 1 });
                }
            }
        }
    }
    pub fn recordMeasurement(self: *RunStatistics, failed: bool) void {
        self.measurement_calls += 1;
        self.measurement_fails += @intFromBool(failed);
    }
    pub fn summary(self: *const RunStatistics, label: []const u8) !?Summary {
        for (self.values.items) |entry| if (std.mem.eql(u8, entry.label, label)) {
            const sorted = try self.allocator.dupe(f64, entry.values.items);
            defer self.allocator.free(sorted);
            std.mem.sort(f64, sorted, {}, struct {
                fn less(_: void, a: f64, b: f64) bool {
                    return a < b;
                }
            }.less);
            const count = sorted.len;
            var sum: f64 = 0;
            for (sorted) |value| sum += value;
            return .{ .count = count, .min = sorted[0], .max = sorted[count - 1], .median = if (count % 2 == 1) sorted[count / 2] else (sorted[count / 2 - 1] + sorted[count / 2]) / 2.0, .mean = sum / @as(f64, @floatFromInt(count)), .p90 = sorted[nearestRankIndex(count, 0.9)] };
        };
        return null;
    }
    pub fn render(self: *const RunStatistics) ![][]u8 {
        const gpa = self.allocator;
        var lines: std.ArrayList([]u8) = .empty;
        errdefer {
            for (lines.items) |line| gpa.free(line);
            lines.deinit(gpa);
        }
        if (self.counts.items.len == 0 and self.values.items.len == 0) {
            try appendLine(gpa, &lines, "Statistics (over {d} test cases): no events were recorded; record them with tc.event(..) or tc.event_value(..)", .{self.cases});
        } else {
            try appendLine(gpa, &lines, "Statistics (over {d} test cases):", .{self.cases});
            const counts = try gpa.dupe(Count, self.counts.items);
            defer gpa.free(counts);
            std.mem.sort(Count, counts, {}, struct {
                fn less(_: void, a: Count, b: Count) bool {
                    return std.mem.order(u8, a.label, b.label) == .lt;
                }
            }.less);
            for (counts) |entry| try appendLine(gpa, &lines, "  * {s}: {d:.1}% of test cases", .{ entry.label, 100.0 * @as(f64, @floatFromInt(entry.cases)) / @as(f64, @floatFromInt(@max(self.cases, 1))) });
            const values = try gpa.dupe(Values, self.values.items);
            defer gpa.free(values);
            std.mem.sort(Values, values, {}, struct {
                fn less(_: void, a: Values, b: Values) bool {
                    return std.mem.order(u8, a.label, b.label) == .lt;
                }
            }.less);
            for (values) |entry| {
                const stats = (try self.summary(entry.label)).?;
                try appendLine(gpa, &lines, "  * {s}: count {d}, min {d}, median {d}, mean {d:.2}, p90 {d}, max {d}", .{ entry.label, stats.count, stats.min, stats.median, stats.mean, stats.p90, stats.max });
            }
        }
        if (self.measurement_calls > 0) try appendLine(gpa, &lines, "  * nondeterministic handling: measurement replays {d}, failing {d}", .{ self.measurement_calls, self.measurement_fails });
        return lines.toOwnedSlice(gpa);
    }
};
fn appendLine(gpa: Allocator, lines: *std.ArrayList([]u8), comptime format: []const u8, args: anytype) !void {
    const line = try std.fmt.allocPrint(gpa, format, args);
    errdefer gpa.free(line);
    try lines.append(gpa, line);
}
pub fn deinitLines(gpa: Allocator, lines: [][]u8) void {
    for (lines) |line| gpa.free(line);
    gpa.free(lines);
}
pub fn nearestRankIndex(count: usize, q: f64) usize {
    return @max(@as(usize, @intFromFloat(@ceil(@as(f64, @floatFromInt(count)) * q))), 1) - 1;
}

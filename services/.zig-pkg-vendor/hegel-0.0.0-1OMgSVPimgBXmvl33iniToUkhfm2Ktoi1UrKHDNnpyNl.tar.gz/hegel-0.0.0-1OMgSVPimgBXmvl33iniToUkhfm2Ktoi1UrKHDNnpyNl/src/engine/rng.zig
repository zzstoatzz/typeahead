// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
// Copyright 2018 Developers of the Rand project.
// Copyright 2018-2020 Developers of the Rand project.
// Copyright 2017 The Rust Project Developers.
// Copyright (c) 2014 The Rust Project Developers.
// Copyright (c) 2018–2026 The Rand Project Developers.

const std = @import("std");
const builtin = @import("builtin");

pub fn Xoshiro(comptime Word: type) type {
    return struct {
        state: [4]Word,

        pub fn seeded(seed: u64) @This() {
            var state = seed;
            var result: @This() = undefined;
            if (Word == u64) {
                for (&result.state) |*word| word.* = splitMix(&state);
            } else {
                for (0..2) |i| {
                    const value = splitMix(&state);
                    result.state[i * 2] = @truncate(value);
                    result.state[i * 2 + 1] = @truncate(value >> 32);
                }
            }
            return result;
        }

        pub fn fromSeed(seed: [32]u8) @This() {
            var result: @This() = undefined;
            const bytes_per_word = @sizeOf(Word);
            var nonzero = false;
            for (&result.state, 0..) |*word, i| {
                word.* = std.mem.readInt(Word, seed[i * bytes_per_word ..][0..bytes_per_word], .little);
                nonzero = nonzero or word.* != 0;
            }
            return if (nonzero) result else seeded(0);
        }

        fn nextWord(self: *@This()) Word {
            const sum = self.state[0] +% self.state[3];
            const result = std.math.rotl(Word, sum, if (Word == u64) 23 else 7) +% self.state[0];
            const temporary = self.state[1] << (if (Word == u64) 17 else 9);
            self.state[2] ^= self.state[0];
            self.state[3] ^= self.state[1];
            self.state[1] ^= self.state[2];
            self.state[0] ^= self.state[3];
            self.state[2] ^= temporary;
            self.state[3] = std.math.rotl(Word, self.state[3], if (Word == u64) 45 else 11);
            return result;
        }

        pub fn nextU32(self: *@This()) u32 {
            if (Word == u32) return self.nextWord();
            return @truncate(self.nextWord() >> 32);
        }

        pub fn nextU64(self: *@This()) u64 {
            if (Word == u64) return self.nextWord();
            const lo: u64 = self.nextWord();
            const hi: u64 = self.nextWord();
            return (hi << 32) | lo;
        }

        pub fn fillBytes(self: *@This(), destination: []u8) void {
            var i: usize = 0;
            while (i < destination.len) {
                var buffer: [@sizeOf(Word)]u8 = undefined;
                std.mem.writeInt(Word, &buffer, self.nextWord(), .little);
                const len = @min(buffer.len, destination.len - i);
                @memcpy(destination[i..][0..len], buffer[0..len]);
                i += len;
            }
        }

        pub fn spawn(self: *@This()) @This() {
            var seed: [32]u8 = undefined;
            self.fillBytes(&seed);
            return fromSeed(seed);
        }
    };
}

fn splitMix(state: *u64) u64 {
    state.* +%= 0x9e3779b97f4a7c15;
    var z = state.*;
    z = (z ^ (z >> 30)) *% 0xbf58476d1ce4e5b9;
    z = (z ^ (z >> 27)) *% 0x94d049bb133111eb;
    return z ^ (z >> 31);
}

pub const SmallRng = Xoshiro(if (@bitSizeOf(usize) >= 64) u64 else u32);

pub const EngineRng = union(enum) {
    prng: SmallRng,
    urandom: std.Io,

    pub fn seeded(seed: u64) EngineRng {
        return .{ .prng = .seeded(seed) };
    }

    pub fn fromOs(io: std.Io) EngineRng {
        var seed: [8]u8 = undefined;
        io.randomSecure(&seed) catch {
            std.debug.print("warning: reading entropy from the OS failed; falling back to a fixed zero seed, so every run will generate the same sequence.\n", .{});
            return seeded(0);
        };
        return seeded(std.mem.readInt(u64, &seed, .little));
    }

    pub fn fromOsOrZero(seed: u64, entropy_ok: bool) EngineRng {
        if (!entropy_ok) std.debug.print("warning: reading entropy from the OS failed; falling back to a fixed zero seed, so every run will generate the same sequence.\n", .{});
        return seeded(if (entropy_ok) seed else 0);
    }

    pub fn urandomSource(io: std.Io) EngineRng {
        return urandomOrFallback(io, switch (builtin.os.tag) {
            .windows, .wasi, .freestanding => false,
            else => true,
        });
    }

    pub fn urandomOrFallback(io: std.Io, available: bool) EngineRng {
        if (available) return .{ .urandom = io };
        std.debug.print("warning: the urandom backend reads the OS random device, which is not available on this platform; falling back to an OS-seeded PRNG (equivalent to the default backend).\n", .{});
        return fromOs(io);
    }

    pub fn spawn(self: *EngineRng) EngineRng {
        return switch (self.*) {
            .prng => |*prng| .{ .prng = prng.spawn() },
            .urandom => |io| .{ .urandom = io },
        };
    }

    pub fn nextU32(self: *EngineRng) u32 {
        return switch (self.*) {
            .prng => |*prng| prng.nextU32(),
            .urandom => |io| blk: {
                var buffer: [4]u8 = undefined;
                readUrandom(io, &buffer);
                break :blk std.mem.readInt(u32, &buffer, .little);
            },
        };
    }

    pub fn nextU64(self: *EngineRng) u64 {
        return switch (self.*) {
            .prng => |*prng| prng.nextU64(),
            .urandom => |io| blk: {
                var buffer: [8]u8 = undefined;
                readUrandom(io, &buffer);
                break :blk std.mem.readInt(u64, &buffer, .little);
            },
        };
    }

    pub fn fillBytes(self: *EngineRng, destination: []u8) void {
        switch (self.*) {
            .prng => |*prng| prng.fillBytes(destination),
            .urandom => |io| readUrandom(io, destination),
        }
    }

    pub fn random(self: *EngineRng, comptime T: type) T {
        if (T == bool) return self.nextU32() >> 31 != 0;
        if (T == f64) return @as(f64, @floatFromInt(self.nextU64() >> 11)) * (1.0 / 9007199254740992.0);
        if (T == f32) return @as(f32, @floatFromInt(self.nextU32() >> 8)) * (1.0 / 16777216.0);
        const info = @typeInfo(T).int;
        const U = @Int(.unsigned, info.bits);
        const raw: U = if (info.bits <= 32) @truncate(self.nextU32()) else if (info.bits <= 64) @truncate(self.nextU64()) else blk: {
            const lo: u128 = self.nextU64();
            const hi: u128 = self.nextU64();
            break :blk @truncate((hi << 64) | lo);
        };
        return @bitCast(raw);
    }

    pub fn range(self: *EngineRng, comptime T: type, low: T, high: T) T {
        std.debug.assert(low < high);
        if (T == usize and high <= std.math.maxInt(u32)) return @intCast(self.rangeInclusive(u32, @intCast(low), @intCast(high - 1)));
        if (T == usize) return @intCast(self.rangeInclusive(u64, @intCast(low), @intCast(high - 1)));
        return self.rangeInclusive(T, low, high - 1);
    }

    pub fn rangeInclusive(self: *EngineRng, comptime T: type, low: T, high: T) T {
        std.debug.assert(low <= high);
        if (T == usize and high <= std.math.maxInt(u32)) return @intCast(self.rangeInclusive(u32, @intCast(low), @intCast(high)));
        const bits = @typeInfo(T).int.bits;
        const U = @Int(.unsigned, bits);
        const S = @Int(.unsigned, @max(32, bits));
        const W = @Int(.unsigned, @bitSizeOf(S) * 2);
        const low_unsigned: U = @bitCast(low);
        const high_unsigned: U = @bitCast(high);
        const span: U = high_unsigned -% low_unsigned +% 1;
        const width: S = span;
        if (width == 0) return self.random(T);
        const product: W = @as(W, self.random(S)) * width;
        var result: S = @intCast(product >> @bitSizeOf(S));
        const remainder: S = @truncate(product);
        if (remainder > 0 -% width) {
            const next_product: W = @as(W, self.random(S)) * width;
            const next_hi: S = @intCast(next_product >> @bitSizeOf(S));
            result += @addWithOverflow(remainder, next_hi)[1];
        }
        return @bitCast(low_unsigned +% @as(U, @truncate(result)));
    }

    pub fn randomBool(self: *EngineRng, probability: f64) bool {
        std.debug.assert(probability >= 0 and probability <= 1);
        if (probability == 1) return true;
        const threshold: u64 = @intFromFloat(probability * 18446744073709551616.0);
        return self.nextU64() < threshold;
    }
};

fn readUrandom(io: std.Io, destination: []u8) void {
    const file = std.Io.Dir.openFileAbsolute(io, "/dev/urandom", .{}) catch @panic("failed to read from the OS random device");
    defer file.close(io);
    var reader = file.readerStreaming(io, &.{});
    reader.interface.readSliceAll(destination) catch @panic("failed to read from the OS random device");
}

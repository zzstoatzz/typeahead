// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const c = @import("choices.zig");
const floatDisplay = @import("rust_fmt.zig").floatDisplay;
const sampling = @import("sampling.zig");
const labelFromName = @import("labels.zig").labelFromName;
pub const text = @import("draws/text.zig");
pub const internet = @import("draws/internet.zig");
pub const regex = @import("draws/regex.zig");
pub const special = @import("draws/special.zig");
pub const Error = c.Error || c.EngineError;
pub const TextAlphabet = text.TextAlphabet;
pub const ManyState = sampling.ManyState;
pub const RecursionState = sampling.RecursionState;
pub const FloatSpec = struct { width: u32, min_value: f64, max_value: f64, allow_nan: bool, allow_infinity: bool, exclude_min: bool, exclude_max: bool, smallest_nonzero_magnitude: f64 };
pub const LABEL_REGEX = labelFromName("hegel.regex");
pub const LABEL_EMAIL = labelFromName("hegel.email");
pub const LABEL_URL = labelFromName("hegel.url");
pub const LABEL_DOMAIN = labelFromName("hegel.domain");
pub const LABEL_DATE = labelFromName("hegel.date");
pub const LABEL_TIME = labelFromName("hegel.time");
pub const LABEL_DATETIME = labelFromName("hegel.datetime");
pub const LABEL_UUID = labelFromName("hegel.uuid");
pub const LABEL_IP_ADDRESS = labelFromName("hegel.ip_address");
pub const LABEL_INTEGER = labelFromName("hegel.integer");
pub const LABEL_FLOAT = labelFromName("hegel.float");
pub const LABEL_BOOLEAN = labelFromName("hegel.boolean");
pub const LABEL_BYTES = labelFromName("hegel.bytes");
pub const LABEL_STRING = labelFromName("hegel.string");
pub const LABEL_FRESH_ID = labelFromName("hegel.fresh_id");
pub const LABEL_SET_CHOICE = labelFromName("hegel.set_choice");
pub const LABEL_CONCURRENCY = labelFromName("hegel.concurrency");
pub const LABEL_FEATURE_FLAG = labelFromName("hegel.feature_flag");
pub fn invalid(ntc: anytype, comptime format: []const u8, args: anytype) Error {
    const message = std.fmt.allocPrint(ntc.allocator, format, args) catch return error.OutOfMemory;
    defer ntc.allocator.free(message);
    ntc.setDiagnostic(message) catch return error.OutOfMemory;
    return error.InvalidArgument;
}
pub fn begin(ntc: anytype, label: u64) Error!void {
    _ = try ntc.startSpan(label);
}
pub fn generateInteger(ntc: anytype, min: c.BigInt, max: c.BigInt) Error!c.BigInt {
    if (min.order(max) == .gt) {
        const lower = min.toString(ntc.allocator, 10) catch |err| return if (err == error.OutOfMemory) error.OutOfMemory else error.InternalError;
        defer ntc.allocator.free(lower);
        const upper = max.toString(ntc.allocator, 10) catch |err| return if (err == error.OutOfMemory) error.OutOfMemory else error.InternalError;
        defer ntc.allocator.free(upper);
        return invalid(ntc, "generate_integer requires min_value <= max_value, got [{s}, {s}]", .{ lower, upper });
    }
    try begin(ntc, LABEL_INTEGER);
    defer ntc.stopSpan(false);
    return ntc.drawInteger(min, max);
}
pub fn freshId(ntc: anytype) Error!i64 {
    try begin(ntc, LABEL_FRESH_ID);
    defer ntc.stopSpan(false);
    return ntc.drawFreshId();
}
pub fn chooseFrom(ntc: anytype, members: []const i64) Error!i64 {
    try begin(ntc, LABEL_SET_CHOICE);
    defer ntc.stopSpan(false);
    return ntc.drawFromSet(members);
}
pub fn generateBytes(ntc: anytype, min: usize, max: usize) Error![]u8 {
    if (min > max) return invalid(ntc, "generate_bytes requires min_size <= max_size, got [{}, {}]", .{ min, max });
    try begin(ntc, LABEL_BYTES);
    defer ntc.stopSpan(false);
    return ntc.drawBytes(min, max);
}
pub fn generateBoolean(ntc: anytype, p: f64, forced: ?bool) Error!bool {
    if (!(p >= 0 and p <= 1)) return invalid(ntc, "generate_boolean(p = {f}) requires a probability in [0.0, 1.0]", .{floatDisplay(p)});
    if (forced == true and p == 0) return invalid(ntc, "generate_boolean: cannot force true when p = 0.0", .{});
    if (forced == false and p == 1) return invalid(ntc, "generate_boolean: cannot force false when p = 1.0", .{});
    try begin(ntc, LABEL_BOOLEAN);
    defer ntc.stopSpan(false);
    return ntc.weightedPrecise(p, forced);
}
fn ieeeNext(comptime F: type, value: F, up: bool) F {
    const U = @Int(.unsigned, @bitSizeOf(F));
    if (std.math.isNan(value) or value == (if (up) std.math.inf(F) else -std.math.inf(F))) return value;
    if (value == 0) return @bitCast(if (up) @as(U, 1) else (@as(U, 1) << (@bitSizeOf(F) - 1)) | 1);
    const bits: U = @bitCast(value);
    return @bitCast(if ((value > 0) == up) bits + 1 else bits - 1);
}
pub fn narrowToF32(min: f64, max: f64, snm: f64, value: f64) f64 {
    const narrowed: f64 = @as(f32, @floatCast(value));
    if (std.math.isFinite(narrowed)) return narrowed;
    return @as(f32, @floatCast(sampling.floatRestrictAndRedraw(.{ .min_value = @max(min, -@as(f64, std.math.floatMax(f32))), .max_value = @min(max, @as(f64, std.math.floatMax(f32))), .allow_nan = false, .allow_infinity = false, .smallest_nonzero_magnitude = snm }, value)));
}
pub fn generateFloat(ntc: anytype, spec: FloatSpec) Error!f64 {
    if (spec.width != 32 and spec.width != 64) return invalid(ntc, "unsupported float width: {} — Hegel supports widths 32 and 64", .{spec.width});
    const snm = spec.smallest_nonzero_magnitude;
    if (!(std.math.isFinite(snm) and snm > 0)) return invalid(ntc, "smallest_nonzero_magnitude must be a positive finite float, got {f}", .{floatDisplay(snm)});
    if (std.math.isNan(spec.min_value) or std.math.isNan(spec.max_value)) return invalid(ntc, "float bounds must not be NaN", .{});
    if (spec.allow_nan and (std.math.isFinite(spec.min_value) or std.math.isFinite(spec.max_value))) return invalid(ntc, "Cannot have allow_nan=true with min_value or max_value", .{});
    if (spec.allow_infinity and std.math.isFinite(spec.min_value) and std.math.isFinite(spec.max_value)) return invalid(ntc, "Cannot have allow_infinity=true with both min_value and max_value", .{});
    if (spec.width == 32) {
        for ([_]f64{ spec.min_value, spec.max_value }, [_][]const u8{ "min_value", "max_value" }) |bound, name| {
            if (@as(f64, @as(f32, @floatCast(bound))) != bound) return invalid(ntc, "{s} ({f}) cannot be exactly represented as a float of width 32", .{ name, floatDisplay(bound) });
        }
    }
    var min = spec.min_value;
    var max = spec.max_value;
    if (spec.exclude_min) min = if (spec.width == 32) ieeeNext(f32, @floatCast(min), true) else ieeeNext(f64, min, true);
    if (spec.exclude_max) max = if (spec.width == 32) ieeeNext(f32, @floatCast(max), false) else ieeeNext(f64, max, false);
    if (spec.width == 32 and !spec.allow_infinity) {
        min = @max(min, -@as(f64, std.math.floatMax(f32)));
        max = @min(max, @as(f64, std.math.floatMax(f32)));
    }
    if (min > max) return invalid(ntc, "min_value ({f}) must be <= max_value ({f}) after exclusive-bound adjustment", .{ floatDisplay(min), floatDisplay(max) });
    try begin(ntc, LABEL_FLOAT);
    defer ntc.stopSpan(false);
    const value = try ntc.drawFloat(if (spec.width == 32) .F32 else .F64, min, max, spec.allow_nan, spec.allow_infinity, snm);
    return if (spec.width == 32 and std.math.isFinite(value)) narrowToF32(min, max, snm, value) else value;
}
pub fn manyMore(ntc: anytype, state: *ManyState) Error!bool {
    const more = if (@as(f64, @floatFromInt(state.min_size)) == state.max_size) state.count < state.min_size else blk: {
        const forced: ?bool = if (state.force_stop) false else if (state.count < state.min_size) true else if (@as(f64, @floatFromInt(state.count)) >= state.max_size) false else null;
        break :blk try ntc.weighted(state.p_continue, forced);
    };
    if (more) state.count += 1;
    return more;
}
pub fn manyReject(ntc: anytype, state: *ManyState) Error!void {
    if (state.count == 0) return error.InternalError;
    state.count -= 1;
    state.rejections += 1;
    if (state.rejections > @max(3, 2 * state.count)) {
        if (state.count < state.min_size) {
            try ntc.conclude(.invalid, null);
            return error.InvalidTestCase;
        }
        state.force_stop = true;
    }
}
pub const RECURSION_MAX_ATTEMPTS: u64 = 9;
pub const RECURSION_MAX_REPRICES: u64 = 2;
const RECURSION_MAX_BRANCH_PROBABILITY: f64 = 0.95;
pub fn recursionBranchProbability(mean_arity: f64, max_leaves: u64) f64 {
    const k = @max(mean_arity, 1);
    const budget: f64 = @floatFromInt(std.math.clamp(max_leaves, 2, @as(u64, 1) << 32));
    return @min((budget - 1) / (budget * k - 1), RECURSION_MAX_BRANCH_PROBABILITY);
}
pub fn recursionArityEstimate(state: *const RecursionState) f64 {
    return (2 * 0.25 + @as(f64, @floatFromInt(state.closed_children))) / (0.25 + @as(f64, @floatFromInt(state.closed_branches)));
}
pub fn recursionEffectiveTarget(state: *const RecursionState) u64 {
    return @max(1, if (state.attempt >= 64) 0 else state.target >> @as(u6, @intCast(state.attempt)));
}
pub fn recursionPricedProbability(state: *const RecursionState) f64 {
    return recursionBranchProbability(recursionArityEstimate(state) + @as(f64, @floatFromInt(state.attempt)), recursionEffectiveTarget(state));
}
pub fn recursionTailProbability(state: *const RecursionState) f64 {
    return recursionBranchProbability(recursionArityEstimate(state) + @as(f64, @floatFromInt(state.attempt)), 2);
}
pub const RecursionProfile = struct { boundary_depth: u64, boundary_probability: f64, expected_leaves: f64 };
pub fn recursionProfile(target: f64, arity: f64, tail: f64, max_depth: u64) RecursionProfile {
    const grow = RECURSION_MAX_BRANCH_PROBABILITY;
    if (max_depth == 0) return .{ .boundary_depth = 0, .boundary_probability = tail, .expected_leaves = 1 };
    var lo = (1 - tail) / (1 - tail * arity);
    var hi = (1 - grow) + grow * arity * lo;
    var boundary: u64 = 0;
    const horizon = @min(max_depth, 4096);
    while (hi < target and boundary < horizon) {
        const next = (1 - grow) + grow * arity * hi;
        if (next - hi < 1e-9) break;
        lo = (1 - grow) + grow * arity * lo;
        hi = next;
        boundary += 1;
    }
    if (hi <= target) return .{ .boundary_depth = boundary, .boundary_probability = grow, .expected_leaves = hi };
    if (lo >= target) return .{ .boundary_depth = boundary, .boundary_probability = tail, .expected_leaves = lo };
    const fraction = (target - lo) / (hi - lo);
    return .{ .boundary_depth = boundary, .boundary_probability = tail + (grow - tail) * fraction, .expected_leaves = target };
}
pub fn recursionDecisionProbability(state: *const RecursionState, depth: u64) f64 {
    const target = recursionEffectiveTarget(state);
    if (target == 1) return recursionPricedProbability(state);
    const tail = recursionTailProbability(state);
    const profile = recursionProfile(@floatFromInt(target), recursionArityEstimate(state), tail, state.max_depth);
    return if (depth < profile.boundary_depth) RECURSION_MAX_BRANCH_PROBABILITY else if (depth == profile.boundary_depth) profile.boundary_probability else tail;
}
pub fn newRecursionState(ntc: anytype, max_depth: u64, max_leaves: u64) Error!RecursionState {
    const base = ntc.spanDepth();
    const target: u64 = if (max_leaves < 2) 1 else blk: {
        try begin(ntc, LABEL_BOOLEAN);
        const large = ntc.weightedPrecise(0.75, null) catch |err| {
            ntc.stopSpan(false);
            return err;
        };
        ntc.stopSpan(false);
        if (large) {
            try begin(ntc, LABEL_INTEGER);
            defer ntc.stopSpan(false);
            break :blk try ntc.drawIntegerUniform(2, max_leaves);
        }
        break :blk 1;
    };
    var state: RecursionState = .{ .allocator = ntc.allocator, .max_depth = max_depth, .max_leaves = max_leaves, .base_span_depth = base, .target = target, .branch_probability = 0 };
    state.branch_probability = recursionPricedProbability(&state);
    return state;
}
pub fn recursionBranch(ntc: anytype, state: *RecursionState, depth: u64) Error!bool {
    state.observeDecision(depth);
    const p = if (depth >= state.max_depth) 0 else recursionDecisionProbability(state, depth);
    try begin(ntc, LABEL_BOOLEAN);
    const branch = ntc.weightedPrecise(p, null) catch |err| {
        ntc.stopSpan(false);
        return err;
    };
    ntc.stopSpan(false);
    if (branch) try state.observeBranch(depth);
    return branch;
}
pub fn recursionRetry(ntc: anytype, state: *RecursionState) Error!void {
    while (ntc.spanDepth() > state.base_span_depth) ntc.stopSpan(true);
    state.discardOpenBranches();
    state.leaves = 0;
    state.attempt += 1;
    if (state.attempt >= RECURSION_MAX_ATTEMPTS) {
        try ntc.conclude(.invalid, null);
        return error.InvalidTestCase;
    }
    state.branch_probability = recursionPricedProbability(state);
}
pub fn recursionFinish(ntc: anytype, state: *RecursionState) Error!bool {
    state.closeRemainingBranches();
    if (state.reprices >= RECURSION_MAX_REPRICES) return true;
    const target = recursionEffectiveTarget(state);
    const mispriced = if (target == 1) recursionPricedProbability(state) - state.branch_probability > 0.05 else blk: {
        const reachable = recursionProfile(@floatFromInt(target), recursionArityEstimate(state), 0, state.max_depth).expected_leaves;
        break :blk state.leaves *| 2 < target and 2 * reachable >= @as(f64, @floatFromInt(target));
    };
    if (!mispriced) return true;
    while (ntc.spanDepth() > state.base_span_depth) ntc.stopSpan(true);
    state.leaves = 0;
    state.reprices += 1;
    state.branch_probability = recursionPricedProbability(state);
    return false;
}

pub fn drawInt(comptime T: type, ntc: anytype, min: T, max: T) Error!T {
    var lower = try c.BigInt.fromInt(ntc.allocator, min);
    defer lower.deinit();
    var upper = try c.BigInt.fromInt(ntc.allocator, max);
    defer upper.deinit();
    var drawn = try ntc.drawInteger(lower, upper);
    defer drawn.deinit();
    return drawn.toInt(T) orelse error.InternalError;
}

pub const StringSpec = union(enum) {
    Text: struct { intervals: c.IntervalSet, min_size: usize, max_size: usize },
    Regex: struct { compiled: regex.CompiledRegex, fullmatch: bool },
    Email: internet.Context,
    Url: internet.Context,
    Domain: internet.DomainSpec,
    pub fn deinit(self: *StringSpec) void {
        switch (self.*) {
            .Text => |*value| value.intervals.deinit(),
            .Regex => |*value| value.compiled.deinit(),
            .Email, .Url => |*value| value.deinit(),
            .Domain => |*value| value.deinit(),
        }
        self.* = undefined;
    }
    pub fn initText(allocator: std.mem.Allocator, alphabet: TextAlphabet, min_size: usize, max_size: usize) Error!StringSpec {
        return initTextDetailed(allocator, alphabet, min_size, max_size, null);
    }
    pub fn initTextDetailed(allocator: std.mem.Allocator, alphabet: TextAlphabet, min_size: usize, max_size: usize, diagnostic: ?*?[]u8) Error!StringSpec {
        if (min_size > max_size) {
            if (diagnostic) |out| out.* = try std.fmt.allocPrint(allocator, "text requires min_size <= max_size, got [{}, {}]", .{ min_size, max_size });
            return error.InvalidArgument;
        }
        var intervals = try text.buildIntervalsDetailed(allocator, alphabet, diagnostic);
        errdefer intervals.deinit();
        if (intervals.isEmpty() and max_size > 0) {
            if (diagnostic) |out| out.* = try allocator.dupe(u8, "InvalidArgument: No valid characters in the specified range. The alphabet's codec/codepoint/category/include/exclude constraints leave no characters available.");
            return error.InvalidArgument;
        }
        return .{ .Text = .{ .intervals = intervals, .min_size = min_size, .max_size = max_size } };
    }

    pub fn initRegex(allocator: std.mem.Allocator, pattern: []const u8, fullmatch: bool, alphabet: ?*const StringSpec, diagnostic: ?*?[]u8) Error!StringSpec {
        const intervals: ?*const c.IntervalSet = if (alphabet) |spec| switch (spec.*) {
            .Text => |*value| &value.intervals,
            else => {
                if (diagnostic) |out| out.* = try allocator.dupe(u8, "regex alphabet must be a text string generator");
                return error.InvalidArgument;
            },
        } else null;
        return .{ .Regex = .{ .compiled = try regex.CompiledRegex.compile(allocator, pattern, intervals, diagnostic), .fullmatch = fullmatch } };
    }
    pub fn initEmail(allocator: std.mem.Allocator, domains: []const []const u8) Error!StringSpec {
        return .{ .Email = try internet.Context.init(allocator, domains) };
    }
    pub fn initUrl(allocator: std.mem.Allocator, domains: []const []const u8) Error!StringSpec {
        return .{ .Url = try internet.Context.init(allocator, domains) };
    }
    pub fn initDomain(allocator: std.mem.Allocator, max_length: usize, domains: []const []const u8) Error!StringSpec {
        return initDomainDetailed(allocator, max_length, domains, null);
    }
    pub fn initDomainDetailed(allocator: std.mem.Allocator, max_length: usize, domains: []const []const u8, diagnostic: ?*?[]u8) Error!StringSpec {
        if (max_length > 255) {
            if (diagnostic) |out| out.* = try std.fmt.allocPrint(allocator, "domain max_length={} exceeds the RFC 1035 limit of 255", .{max_length});
            return error.InvalidArgument;
        }
        const spec = internet.DomainSpec.init(allocator, max_length, domains) catch |err| {
            if (err == error.InvalidArgument) {
                if (diagnostic) |out| out.* = try std.fmt.allocPrint(allocator, "domain max_length={} leaves no eligible TLDs", .{max_length});
            }
            return err;
        };
        return .{ .Domain = spec };
    }
};
pub fn generateString(ntc: anytype, spec: *const StringSpec) Error![]u8 {
    const label = switch (spec.*) {
        .Text => LABEL_STRING,
        .Regex => LABEL_REGEX,
        .Email => LABEL_EMAIL,
        .Url => LABEL_URL,
        .Domain => LABEL_DOMAIN,
    };
    try begin(ntc, label);
    defer ntc.stopSpan(false);
    return switch (spec.*) {
        .Text => |*value| ntc.drawString(&value.intervals, value.min_size, value.max_size),
        .Regex => |*value| regex.generateRegex(ntc, &value.compiled, value.fullmatch),
        .Email => |*value| internet.generateEmail(ntc, value),
        .Url => |*value| internet.generateUrl(ntc, value),
        .Domain => |*value| internet.generateDomain(ntc, value),
    };
}

pub const defaultDomains = internet.defaultDomains;

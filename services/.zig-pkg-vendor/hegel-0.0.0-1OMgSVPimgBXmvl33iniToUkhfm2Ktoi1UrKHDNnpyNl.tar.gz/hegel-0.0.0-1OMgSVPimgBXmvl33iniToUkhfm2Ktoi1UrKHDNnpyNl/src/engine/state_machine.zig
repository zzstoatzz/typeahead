// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-provenance/state.json.
const std = @import("std");
const state = @import("state.zig");
const Allocator = std.mem.Allocator;
const Ntc = state.NativeTestCase;
const Error = state.Error;
const BigInt = state.BigInt;
const labels = @import("labels.zig");
pub const P_CONTINUE: f64 = 1.0 - 1.0 / 4_294_967_296.0;
pub const ATTEMPT_MULTIPLIER: i64 = 10;
pub const MIN_ATTEMPTS_WITHOUT_SUCCESS: i64 = 1000;
pub const MAX_ROUND_RULES: i64 = 5;
pub const P_MAX_CONCURRENCY: f64 = 0.75;
const Group = std.ArrayList(usize);
fn drawIndex(ntc: *Ntc, n: usize) Error!usize {
    var lo = try BigInt.fromInt(ntc.allocator, @as(u8, 0));
    defer lo.deinit();
    var hi = try BigInt.fromInt(ntc.allocator, n - 1);
    defer hi.deinit();
    var value = try ntc.drawInteger(lo, hi);
    defer value.deinit();
    return value.toInt(usize) orelse error.InternalError;
}
fn drawConcurrency(ntc: *Ntc, min: i64, max: i64) Error!i64 {
    if (min == max) return max;
    _ = try ntc.startSpan(labels.labelFromName("hegel.concurrency"));
    const result = if (try ntc.weighted(P_MAX_CONCURRENCY, null)) max else blk: {
        var lo = try BigInt.fromInt(ntc.allocator, min);
        defer lo.deinit();
        var hi = try BigInt.fromInt(ntc.allocator, max);
        defer hi.deinit();
        var value = try ntc.drawInteger(lo, hi);
        defer value.deinit();
        break :blk value.toInt(i64) orelse return error.InternalError;
    };
    ntc.stopSpan(false);
    return result;
}
pub const FeatureFlags = struct {
    allocator: Allocator,
    p_disabled: f64,
    is_disabled: []?bool,
    at_least_one_of: []std.AutoHashMapUnmanaged(usize, void),
    pub fn init(ntc: *Ntc, groups: []const Group, num_rules: usize) Error!FeatureFlags {
        const gpa = ntc.allocator;
        var lo = try BigInt.fromInt(gpa, @as(u8, 0));
        defer lo.deinit();
        var hi = try BigInt.fromInt(gpa, @as(u16, 254));
        defer hi.deinit();
        var raw = try ntc.drawInteger(lo, hi);
        defer raw.deinit();
        const flags = try gpa.alloc(?bool, num_rules);
        errdefer gpa.free(flags);
        @memset(flags, null);
        const candidates = try gpa.alloc(std.AutoHashMapUnmanaged(usize, void), groups.len);
        @memset(candidates, .empty);
        errdefer {
            for (candidates) |*set| set.deinit(gpa);
            gpa.free(candidates);
        }
        for (groups, candidates) |group, *set| for (group.items) |rule| try set.put(gpa, rule, {});
        return .{ .allocator = gpa, .p_disabled = @as(f64, @floatFromInt(raw.toInt(i128) orelse return error.InternalError)) / 255.0, .is_disabled = flags, .at_least_one_of = candidates };
    }
    pub fn deinit(self: *FeatureFlags) void {
        self.allocator.free(self.is_disabled);
        for (self.at_least_one_of) |*set| set.deinit(self.allocator);
        self.allocator.free(self.at_least_one_of);
    }
    pub fn isEnabled(self: *FeatureFlags, ntc: *Ntc, group: usize, i: usize) Error!bool {
        _ = try ntc.startSpan(labels.labelFromName("hegel.feature_flag"));
        const candidates = &self.at_least_one_of[group];
        const forced: ?bool = if (candidates.count() == 1 and candidates.contains(i)) false else self.is_disabled[i];
        const disabled = try ntc.weighted(self.p_disabled, forced);
        self.is_disabled[i] = disabled;
        if (!disabled) candidates.clearRetainingCapacity();
        _ = candidates.remove(i);
        ntc.stopSpan(false);
        return !disabled;
    }
};
pub const WorkerState = struct {
    flags: FeatureFlags,
    steps_drawn: i64 = 0,
    steps_rejected: i64 = 0,
    rule_outstanding: bool = false,
    retry_pending: bool = false,
};
pub const NativeStateMachine = struct {
    allocator: Allocator,
    groups: std.ArrayList(Group) = .empty,
    group_ids: std.ArrayList(i64) = .empty,
    rule_weights: []f64 = &.{},
    concurrency_level: i64 = 0,
    current_group: usize = 0,
    rounds_started: i64 = 0,
    rounds_rejected: i64 = 0,
    step_count: i64,
    invariant_always_check: []bool = &.{},
    workers: std.ArrayList(WorkerState) = .empty,
    diagnostic: ?[]u8 = null,
    pub fn init(ntc: *Ntc, rule_groups: []const i64, rule_weights: []const f64, invariants: []const bool, min_concurrency: i64, max_concurrency: i64, step_count: i64) Error!NativeStateMachine {
        if (rule_groups.len == 0 or rule_groups.len != rule_weights.len or min_concurrency < 1 or min_concurrency > max_concurrency or step_count < 1) return error.InternalError;
        for (rule_weights) |w| if (!std.math.isFinite(w) or w <= 0) return error.InternalError;
        const gpa = ntc.allocator;
        var self: NativeStateMachine = .{ .allocator = gpa, .step_count = step_count };
        errdefer self.deinit();
        self.rule_weights = try gpa.dupe(f64, rule_weights);
        self.invariant_always_check = try gpa.dupe(bool, invariants);
        for (rule_groups, 0..) |id, rule| {
            var group: ?usize = null;
            for (self.group_ids.items, 0..) |existing, i| if (existing == id) {
                group = i;
                break;
            };
            if (group == null) {
                try self.groups.append(gpa, .empty);
                try self.group_ids.append(gpa, id);
                group = self.groups.items.len - 1;
            }
            try self.groups.items[group.?].append(gpa, rule);
        }
        self.concurrency_level = try drawConcurrency(ntc, min_concurrency, max_concurrency);
        for (0..@intCast(self.concurrency_level)) |_| {
            var flags = try FeatureFlags.init(ntc, self.groups.items, rule_groups.len);
            errdefer flags.deinit();
            try self.workers.append(gpa, .{ .flags = flags });
        }
        return self;
    }
    pub fn deinit(self: *NativeStateMachine) void {
        const gpa = self.allocator;
        for (self.groups.items) |*group| group.deinit(gpa);
        self.groups.deinit(gpa);
        self.group_ids.deinit(gpa);
        gpa.free(self.rule_weights);
        gpa.free(self.invariant_always_check);
        for (self.workers.items) |*worker| worker.flags.deinit();
        self.workers.deinit(gpa);
        if (self.diagnostic) |message| gpa.free(message);
    }
    pub fn concurrency(self: *const NativeStateMachine) i64 {
        return self.concurrency_level;
    }
    fn invalid(self: *NativeStateMachine, comptime fmt: []const u8, args: anytype) Error {
        const message = std.fmt.allocPrint(self.allocator, fmt, args) catch return error.OutOfMemory;
        if (self.diagnostic) |old| self.allocator.free(old);
        self.diagnostic = message;
        return error.InvalidArgument;
    }
    fn checkedWorker(self: *NativeStateMachine, idx: i64) Error!usize {
        if (idx < 0 or idx >= self.concurrency_level) return self.invalid("worker_index must be in [0, {d}), got {d}", .{ self.concurrency_level, idx });
        return @intCast(idx);
    }
    pub fn nextGroup(self: *NativeStateMachine, ntc: *Ntc) Error!?i64 {
        const counted = self.rounds_started - self.rounds_rejected;
        const scaled = self.step_count *| ATTEMPT_MULTIPLIER;
        const cap = if (counted == 0) @max(scaled, MIN_ATTEMPTS_WITHOUT_SUCCESS) else scaled;
        const forced: ?bool = if (counted >= self.step_count or self.rounds_started >= cap) false else if (self.rounds_started == 0) true else null;
        if (!(try ntc.weightedPrecise(P_CONTINUE, forced))) return null;
        const group = if (self.groups.items.len == 1) 0 else try drawIndex(ntc, self.groups.items.len);
        for (self.workers.items) |*worker| {
            worker.steps_drawn = 0;
            worker.steps_rejected = 0;
            worker.rule_outstanding = false;
            worker.retry_pending = false;
        }
        self.current_group = group;
        self.rounds_started += 1;
        return self.group_ids.items[group];
    }
    pub fn nextRule(self: *NativeStateMachine, ntc: *Ntc, worker_index: i64) Error!?i64 {
        const idx = try self.checkedWorker(worker_index);
        if (self.rounds_started == 0) return self.invalid("state machine rule requested before the first next_group call", .{});
        const worker = &self.workers.items[idx];
        if (self.concurrency_level == 1) {
            if (worker.steps_drawn >= 1) return null;
        } else {
            const completed = worker.steps_drawn - worker.steps_rejected;
            const p: f64 = if (worker.steps_drawn >= MAX_ROUND_RULES * ATTEMPT_MULTIPLIER or completed >= MAX_ROUND_RULES) 0 else if (worker.retry_pending) 1 else @as(f64, @floatFromInt(MAX_ROUND_RULES - completed)) / @as(f64, @floatFromInt(MAX_ROUND_RULES - completed + 1));
            if (!(try ntc.weighted(p, null))) return null;
        }
        const index = try self.selectRule(ntc, idx, self.current_group);
        worker.steps_drawn += 1;
        worker.rule_outstanding = true;
        worker.retry_pending = false;
        return index;
    }
    pub fn ruleRejected(self: *NativeStateMachine, worker_index: i64) Error!void {
        const idx = try self.checkedWorker(worker_index);
        const worker = &self.workers.items[idx];
        if (!worker.rule_outstanding) return self.invalid("rule_rejected called with no outstanding rule", .{});
        worker.rule_outstanding = false;
        worker.steps_rejected += 1;
        worker.retry_pending = true;
        if (self.concurrency_level == 1) self.rounds_rejected += 1;
    }
    pub fn shouldCheckInvariant(self: *NativeStateMachine, ntc: *Ntc, index: i64) Error!bool {
        if (index < 0 or index >= self.invariant_always_check.len) return self.invalid("invariant_index must be in [0, {d}), got {d}", .{ self.invariant_always_check.len, index });
        if (self.invariant_always_check[@intCast(index)]) return true;
        return ntc.weightedPrecise(1.0 / @as(f64, @floatFromInt(self.step_count)), null);
    }
    fn selectRule(self: *NativeStateMachine, ntc: *Ntc, worker: usize, group: usize) Error!i64 {
        const gpa = self.allocator;
        const members = self.groups.items[group].items;
        const flags = &self.workers.items[worker].flags;
        const weights = try gpa.alloc(f64, members.len);
        defer gpa.free(weights);
        for (members, weights) |rule, *w| w.* = self.rule_weights[rule];
        for (0..3) |_| {
            const k = try ntc.drawIndexWeighted(weights);
            if (weights[k] > 0) {
                if (try flags.isEnabled(ntc, group, members[k])) return @intCast(members[k]);
                weights[k] = 0;
            }
        }
        var allowed: std.ArrayList(usize) = .empty;
        defer allowed.deinit(gpa);
        var allowed_weights: std.ArrayList(f64) = .empty;
        defer allowed_weights.deinit(gpa);
        for (members, 0..) |rule, k| if (weights[k] > 0 and try flags.isEnabled(ntc, group, rule)) {
            try allowed.append(gpa, k);
            try allowed_weights.append(gpa, weights[k]);
        };
        if (allowed.items.len == 0) return error.InternalError;
        const j = try ntc.drawIndexWeighted(allowed_weights.items);
        const k = allowed.items[j];
        var lo = try BigInt.fromInt(gpa, @as(u8, 0));
        defer lo.deinit();
        var hi = try BigInt.fromInt(gpa, members.len - 1);
        defer hi.deinit();
        var value = try BigInt.fromInt(gpa, k);
        defer value.deinit();
        try ntc.drawIntegerForced(lo, hi, value);
        return @intCast(members[k]);
    }
};

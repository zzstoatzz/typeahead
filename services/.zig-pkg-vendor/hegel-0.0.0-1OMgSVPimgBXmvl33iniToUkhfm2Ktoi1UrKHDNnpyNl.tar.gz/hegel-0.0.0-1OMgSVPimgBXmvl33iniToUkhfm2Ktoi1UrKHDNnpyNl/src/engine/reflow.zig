// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/reflow.rs; see provenance.
const std = @import("std");
const p = @import("printer.zig");
const Allocator = std.mem.Allocator;
pub const ReflowOptions = struct {};
pub const MAX_DEPTH: usize = 64;
const Node = union(enum) { leaf: []const u8, group: *Group };
const Group = struct {
    prefix: []const u8,
    open: u8,
    close: u8,
    padded: bool,
    items: [][]Node,
    separators: []u8,
    fn openText(self: *const @This(), a: Allocator) ![]u8 {
        return std.mem.concat(a, u8, &.{ self.prefix, &.{self.open} });
    }
    fn closeText(self: *const @This(), a: Allocator) ![]u8 {
        return std.mem.concat(a, u8, &.{ if (self.padded) " " else "", &.{self.close} });
    }
    fn shallow(self: *const @This()) bool {
        for (self.items) |item| {
            for (item) |node| {
                if (node == .group) return false;
            }
        }
        return true;
    }
    fn flatText(self: *const @This(), a: Allocator) ![]u8 {
        var out: std.ArrayList(u8) = .empty;
        try out.appendSlice(a, try self.openText(a));
        if (self.padded and self.items.len > 0) try out.append(a, ' ');
        for (self.items, 0..) |item, i| {
            if (i > 0) {
                try out.append(a, self.separators[i - 1]);
                try out.append(a, ' ');
            }
            for (item) |node| {
                if (node == .leaf) try out.appendSlice(a, node.leaf);
            }
        }
        if (self.padded and self.items.len > 0) try out.append(a, ' ');
        try out.append(a, self.close);
        return out.toOwnedSlice(a);
    }
};
const ParseError = Allocator.Error || error{InvalidRepr};
const Parser = struct {
    a: Allocator,
    text: []const u8,
    pos: usize = 0,
    depth: usize = 0,
    fn peek(self: *const @This()) ?u8 {
        return if (self.pos < self.text.len) self.text[self.pos] else null;
    }
    fn next(self: *const @This()) ?u8 {
        return if (self.pos + 1 < self.text.len) self.text[self.pos + 1] else null;
    }
    fn bump(self: *@This()) ParseError!u8 {
        const ch = self.peek() orelse return error.InvalidRepr;
        self.pos += 1;
        return ch;
    }
    fn separator(self: *const @This()) bool {
        return (self.peek() == ',' or self.peek() == ';') and self.next() == ' ';
    }
    fn flush(self: *@This(), text: *std.ArrayList(u8), nodes: *std.ArrayList(Node)) ParseError!void {
        if (text.items.len > 0) {
            const owned = try text.toOwnedSlice(self.a);
            try nodes.append(self.a, .{ .leaf = owned });
        }
    }
    fn parse(self: *@This()) ParseError![]Node {
        if (std.mem.indexOfScalar(u8, self.text, '\n') != null) return error.InvalidRepr;
        const nodes = try self.item();
        if (self.pos != self.text.len) return error.InvalidRepr;
        return nodes;
    }
    fn item(self: *@This()) ParseError![]Node {
        var nodes: std.ArrayList(Node) = .empty;
        var text: std.ArrayList(u8) = .empty;
        while (self.peek()) |ch| {
            if (ch == ']' or ch == ')' or ch == '}' or self.separator() or (ch == ' ' and (self.next() == ']' or self.next() == ')' or self.next() == '}'))) break;
            if (ch == '"' or ch == '\'') {
                try self.flush(&text, &nodes);
                try nodes.append(self.a, .{ .leaf = try self.quoted() });
            } else if (ch == '[' or ch == '(' or ch == '{') {
                const prefix = try self.takePrefix(&text, &nodes);
                try self.flush(&text, &nodes);
                try nodes.append(self.a, .{ .group = try self.group(prefix, ch) });
            } else {
                try text.append(self.a, ch);
                _ = try self.bump();
            }
        }
        try self.flush(&text, &nodes);
        return nodes.toOwnedSlice(self.a);
    }
    fn group(self: *@This(), prefix: []const u8, open: u8) ParseError!*Group {
        if (self.depth == MAX_DEPTH) return error.InvalidRepr;
        self.depth += 1;
        _ = try self.bump();
        const close: u8 = switch (open) {
            '(' => ')',
            '[' => ']',
            else => '}',
        };
        const padded = self.peek() == ' ';
        if (padded) _ = try self.bump();
        var items: std.ArrayList([]Node) = .empty;
        var separators: std.ArrayList(u8) = .empty;
        if (self.peek() == close and !padded) {
            _ = try self.bump();
        } else {
            while (true) {
                try items.append(self.a, try self.item());
                const ch = self.peek() orelse return error.InvalidRepr;
                if (self.separator()) {
                    try separators.append(self.a, ch);
                    _ = try self.bump();
                    _ = try self.bump();
                } else if (ch == ' ' and padded and self.next() == close) {
                    _ = try self.bump();
                    _ = try self.bump();
                    break;
                } else if (!padded and ch == close) {
                    _ = try self.bump();
                    break;
                } else return error.InvalidRepr;
            }
        }
        self.depth -= 1;
        const g = try self.a.create(Group);
        g.* = .{ .prefix = prefix, .open = open, .close = close, .padded = padded, .items = try items.toOwnedSlice(self.a), .separators = try separators.toOwnedSlice(self.a) };
        return g;
    }
    fn quoted(self: *@This()) ParseError![]const u8 {
        const start = self.pos;
        const quote = try self.bump();
        while (true) {
            const ch = try self.bump();
            if (ch == '\\') {
                _ = try self.bump();
            } else if (ch == quote) return self.text[start..self.pos];
        }
    }
    fn takePrefix(self: *@This(), text: *std.ArrayList(u8), nodes: *std.ArrayList(Node)) ParseError![]const u8 {
        const joiner: []const u8 = if (text.items.len > 0 and text.items[text.items.len - 1] == ' ') blk: {
            _ = text.pop();
            break :blk " ";
        } else "";
        const start = if (std.mem.lastIndexOfScalar(u8, text.items, ' ')) |i| i + 1 else null;
        var prefix = try self.a.dupe(u8, text.items[start orelse 0 ..]);
        text.shrinkRetainingCapacity(start orelse 0);
        if (start == null) {
            while (nodes.pop()) |node| {
                switch (node) {
                    .leaf => |leaf| {
                        if (std.mem.lastIndexOfScalar(u8, leaf, ' ')) |i| {
                            prefix = try std.mem.concat(self.a, u8, &.{ leaf[i + 1 ..], prefix });
                            try nodes.append(self.a, .{ .leaf = leaf[0 .. i + 1] });
                            break;
                        } else prefix = try std.mem.concat(self.a, u8, &.{ leaf, prefix });
                    },
                    .group => |g| {
                        if (g.shallow()) {
                            prefix = try std.mem.concat(self.a, u8, &.{ try g.flatText(self.a), prefix });
                        } else {
                            try nodes.append(self.a, node);
                            break;
                        }
                    },
                }
            }
        }
        return std.mem.concat(self.a, u8, &.{ prefix, joiner });
    }
};
fn emitNodes(printer: *p.Printer, target: p.Target, a: Allocator, nodes: []const Node) p.PrinterError!void {
    for (nodes) |node| {
        switch (node) {
            .leaf => |text| try printer.text(target, text),
            .group => |g| {
                const open = try g.openText(a);
                const indent = if (g.padded) 4 else std.unicode.utf8CountCodepoints(open) catch unreachable;
                try printer.beginGroup(target, indent, open);
                if (g.padded) try printer.breakable(target, " ");
                for (g.items, 0..) |item, i| {
                    if (i > 0) {
                        try printer.text(target, &.{g.separators[i - 1]});
                        try printer.breakable(target, " ");
                    }
                    try emitNodes(printer, target, a, item);
                }
                try printer.endGroup(target, try g.closeText(a));
            },
        }
    }
}
pub fn reflow(printer: *p.Printer, target: p.Target, repr: []const u8, _: ReflowOptions) p.PrinterError!void {
    var arena = std.heap.ArenaAllocator.init(printer.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    var parser = Parser{ .a = a, .text = repr };
    const nodes = parser.parse() catch |err| {
        if (err == error.OutOfMemory) return error.OutOfMemory;
        var lines = std.mem.splitScalar(u8, repr, '\n');
        var i: usize = 0;
        while (lines.next()) |line| : (i += 1) {
            if (i > 0) try printer.hardBreak(target);
            if (line.len > 0) try printer.text(target, line);
        }
        return;
    };
    return emitNodes(printer, target, a, nodes);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const state = @import("state.zig");
const s = @import("settings.zig");
const execution = @import("execution.zig");
const cache = @import("exec_cache.zig");
const dbmod = @import("database.zig");
const persistence = @import("persistence.zig");
const counters = @import("counterexample.zig");
const events = @import("events.zig");
const targeting = @import("targeting.zig");
const policy = @import("runner_policy.zig");
const blob = @import("blob.zig");
const nd = @import("nd.zig");
const graph = @import("graph.zig");
const Allocator = std.mem.Allocator;
pub const RunResult = execution.RunResult;
pub const Failure = struct {
    origin: []u8,
    reproduce_blob: ?[]u8,
    caveat: ?[]u8,
    pub fn deinit(self: *Failure, gpa: Allocator) void {
        gpa.free(self.origin);
        if (self.reproduce_blob) |v| gpa.free(v);
        if (self.caveat) |v| gpa.free(v);
        self.* = undefined;
    }
};
pub const TestRunResult = struct {
    failures: []Failure,
    pub fn deinit(self: *TestRunResult, gpa: Allocator) void {
        for (self.failures) |*failure| failure.deinit(gpa);
        gpa.free(self.failures);
        self.* = undefined;
    }
};
pub const Engine = struct {
    allocator: Allocator,
    io: std.Io,
    settings: s.Settings,
    database_key: ?[]const u8,
    executor: execution.Executor,
    rng: state.EngineRng,
    database: ?dbmod.DirectoryDatabase,
    persister: persistence.Persister,
    exec_cache: cache.ExecCache,
    kind_ledger: cache.KindLedger,
    origins: counters.Counterexamples,
    targeting: targeting.TargetingState,
    statistics: events.RunStatistics,
    collect_statistics: bool = false,
    consecutive_duplicates: u64 = 0,
    calls: u64 = 0,
    valid_test_cases: u64 = 0,
    invalid_test_cases: u64 = 0,
    overrun_test_cases: u64 = 0,
    total_test_time: u128 = 0,
    too_slow_threshold_ns: u128 = 30 * std.time.ns_per_s,
    shrink_budget_ns: u128 = 300 * std.time.ns_per_s,
    test_is_trivial: bool = false,
    first_bug_at: ?u64 = null,
    last_bug_at: ?u64 = null,
    first_bug_time: ?i128 = null,
    nd_active: bool,
    check_window: bool = false,
    reuse_replays: bool = false,
    capture_replays: bool = false,
    capture_discoveries: bool = false,
    diagnostic: ?[]u8 = null,
    error_kind: enum { nondeterministic, flaky } = .nondeterministic,
    pub fn create(gpa: Allocator, io: std.Io, settings: s.Settings, key: ?[]const u8, executor: execution.Executor) !*Engine {
        const self = try gpa.create(Engine);
        errdefer gpa.destroy(self);
        const db: ?dbmod.DirectoryDatabase = switch (settings.database) {
            .disabled => null,
            .unset => try dbmod.DirectoryDatabase.init(gpa, io, ".hegel/examples"),
            .path => |path| try dbmod.DirectoryDatabase.init(gpa, io, path),
        };
        self.* = .{ .allocator = gpa, .io = io, .settings = settings, .database_key = key, .executor = executor, .rng = createRng(io, settings, key), .database = db, .persister = undefined, .exec_cache = .init(gpa), .kind_ledger = .init(gpa), .origins = .init(gpa), .targeting = .init(gpa), .statistics = .init(gpa), .nd_active = settings.nd_force };
        errdefer if (self.database) |*value| value.deinit();
        self.persister = try persistence.Persister.init(gpa, if (self.database) |*value| value else null, key);
        return self;
    }
    pub fn deinit(self: *Engine) void {
        const gpa = self.allocator;
        self.persister.deinit();
        if (self.database) |*value| value.deinit();
        self.exec_cache.deinit();
        self.kind_ledger.deinit();
        self.origins.deinit();
        self.targeting.deinit();
        self.statistics.deinit();
        if (self.diagnostic) |value| gpa.free(value);
        gpa.destroy(self);
    }
    pub fn now(self: *const Engine) i128 {
        return @intCast(std.Io.Clock.awake.now(self.io).nanoseconds);
    }
    pub fn choiceBound(self: *const Engine) usize {
        return self.settings.choiceBound();
    }
    pub fn rngSpawn(self: *Engine) state.EngineRng {
        return self.rng.spawn();
    }
    pub fn setDiagnostic(self: *Engine, text: []const u8) !void {
        const value = try self.allocator.dupe(u8, text);
        if (self.diagnostic) |old| self.allocator.free(old);
        self.diagnostic = value;
    }
    pub fn ndFlip(self: *Engine) void {
        if (self.nd_active) return;
        self.nd_active = true;
        self.exec_cache.clear();
        self.kind_ledger.clear();
        self.consecutive_duplicates = 0;
        if (self.settings.nondeterminism_strictness == .warn and self.settings.verbosity != .quiet and !self.settings.in_antithesis) self.settings.output.line(self.io, "Nondeterministic test behavior detected: failures are now confirmed by repeated replay before being shrunk or persisted, and unconfirmed failures are reported with a caveat. Set nondeterminism_strictness to quiet to silence this notice, or to error to abort instead.");
    }
    pub fn testFunction(self: *Engine, native_case: state.NativeTestCase) !RunResult {
        return self.testFunctionTagged(native_case, false);
    }
    pub fn measure(self: *Engine, native_case: state.NativeTestCase) !RunResult {
        return self.testFunctionTagged(native_case, true);
    }
    fn testFunctionTagged(self: *Engine, native_case: state.NativeTestCase, measurement: bool) !RunResult {
        var tc = native_case;
        if (self.capture_replays or (self.nd_active and self.capture_discoveries and !measurement)) tc.setShouldCapture();
        const start = self.now();
        var observed = try self.executor.execute(self.allocator, tc);
        errdefer observed.deinit(self.allocator);
        const mismatch = try self.recordRun(&observed, @intCast(@max(0, self.now() - start)), measurement);
        if (mismatch) {
            if (self.settings.nondeterminism_strictness == .@"error") return if (self.error_kind == .flaky) error.Flaky else error.Nondeterministic;
            self.ndFlip();
        }
        return observed;
    }
    fn recordRun(self: *Engine, observed: *const RunResult, elapsed: u128, measurement: bool) !bool {
        const mismatch = if (self.nd_active) false else try self.recordExecution(observed, measurement);
        if (measurement) {
            if (self.nd_active or self.check_window) self.statistics.recordMeasurement(observed.status == .interesting);
        } else {
            self.calls += 1;
            self.total_test_time += elapsed;
            if (observed.nodes.len == 0 and @backingInt(observed.status) >= @backingInt(c.Status.invalid)) self.test_is_trivial = true;
            if (@backingInt(observed.status) >= @backingInt(c.Status.valid) and observed.target_observations.count() != 0) {
                const values = try observed.realizedValues(self.allocator);
                defer c.deinitValues(self.allocator, values);
                try self.targeting.record(values, &observed.target_observations);
            }
            if (self.collect_statistics and (observed.status == .valid or observed.status == .interesting)) {
                const observations = try self.allocator.alloc(events.Event, observed.events.len);
                defer self.allocator.free(observations);
                for (observed.events, observations) |source, *dest| dest.* = .{ .label = source.label, .value = source.value };
                try self.statistics.recordCase(observations);
            }
            switch (observed.status) {
                .valid => self.valid_test_cases += 1,
                .invalid => self.invalid_test_cases += 1,
                .early_stop => self.overrun_test_cases += 1,
                .interesting => {
                    if (self.first_bug_at == null) {
                        self.first_bug_at = self.calls;
                        self.first_bug_time = self.now();
                    }
                    self.last_bug_at = self.calls;
                },
            }
        }
        if (observed.status == .interesting) {
            const origin = observed.origin orelse "";
            if (!self.nd_active) {
                if (!measurement or self.reuse_replays) {
                    try self.persister.record(origin, observed.nodes);
                    const counter = try self.origins.entry(origin);
                    const accepted = try counter.adopt(observed.nodes, observed.spans);
                    try counter.recordSighting(observed.nodes, observed.spans, accepted);
                }
            } else if (self.origins.incumbent(origin) == null) {
                _ = try (try self.origins.entry(origin)).adopt(observed.nodes, observed.spans);
            }
        }
        return mismatch;
    }
    fn recordExecution(self: *Engine, observed: *const RunResult, measurement: bool) !bool {
        if (self.settings.nondeterminism_strictness == .@"error") {
            if (try self.kind_ledger.observe(observed.nodes)) |mismatch| {
                self.error_kind = .nondeterministic;
                const expected = try @import("printer.zig").debugChoiceKind(self.allocator, mismatch.expected);
                defer self.allocator.free(expected);
                const actual = try @import("printer.zig").debugChoiceKind(self.allocator, mismatch.actual);
                defer self.allocator.free(actual);
                const message = try std.fmt.allocPrint(self.allocator, "Your data generation is non-deterministic: at the same choice position with the same prefix, the choice kind changed from {s} to {s}. This usually means a generator depends on global mutable state.", .{ expected, actual });
                defer self.allocator.free(message);
                try self.setDiagnostic(message);
                return true;
            }
        }
        if (observed.status == .early_stop) return false;
        const key = (try dbmod.serializeNodes(self.allocator, observed.nodes)) orelse return error.InternalError;
        defer self.allocator.free(key);
        var recorded = try self.exec_cache.record(key, observed.status, observed.origin, observed.nodes, observed.spans, !self.collect_statistics);
        defer recorded.deinit(self.allocator);
        if (self.collect_statistics and !measurement) {
            if (recorded.duplicate) self.consecutive_duplicates += 1 else self.consecutive_duplicates = 0;
        }
        if (recorded.verdict_mismatch) {
            self.error_kind = .flaky;
            const message = try flakyDiagnostic(self.allocator, recorded.mismatched_origin);
            defer self.allocator.free(message);
            try self.setDiagnostic(message);
        }
        return recorded.verdict_mismatch;
    }
    pub fn cachedTestFunction(self: *Engine, values: []const c.ChoiceValue, nodes: ?[]const c.ChoiceNode, extend: usize) !RunResult {
        if (!self.nd_active) {
            const key = (try dbmod.serializeChoices(self.allocator, values)) orelse return error.InternalError;
            defer self.allocator.free(key);
            if (try self.exec_cache.serve(key)) |hit| return RunResult.fromCached(hit);
        }
        const tc = if (extend == 0) try state.NativeTestCase.forChoices(self.allocator, values, nodes, null) else try state.NativeTestCase.forProbe(self.allocator, values, self.rngSpawn(), c.flattenedValuesLen(values) +| extend);
        return self.testFunction(tc);
    }
    pub fn firstCheckSweep(self: *Engine) !void {
        while (!self.nd_active) {
            var unchecked: ?cache.CachedRun = null;
            for (self.origins.iter()) |entry| if (entry.record.incumbent() != null and !entry.record.firstChecked()) {
                unchecked = try cache.CachedRun.init(self.allocator, .interesting, entry.origin, entry.record.incumbent().?, entry.record.incumbentSpans());
                break;
            };
            var initial = unchecked orelse return;
            defer initial.deinit(self.allocator);
            const origin = initial.origin.?;
            (try self.origins.entry(origin)).markFirstChecked();
            const previous_capture = self.capture_replays;
            self.capture_replays = true;
            self.check_window = true;
            const result = self.firstCheckReplays(origin, initial.nodes);
            self.capture_replays = previous_capture;
            self.check_window = false;
            const checked = try result;
            if (checked.miss) {
                if (self.settings.nondeterminism_strictness == .@"error") return if (self.error_kind == .flaky) error.Flaky else error.Nondeterministic;
                (try self.origins.entry(origin)).seedEvidence(checked.evidence);
                self.ndFlip();
            }
        }
    }
    fn firstCheckReplays(self: *Engine, origin: []const u8, nodes: []const c.ChoiceNode) !struct { miss: bool, evidence: nd.Evidence } {
        var initial = RunResult.fromCached(try cache.CachedRun.init(self.allocator, .interesting, null, nodes, &.{}));
        defer initial.deinit(self.allocator);
        const values = try initial.realizedValues(self.allocator);
        defer c.deinitValues(self.allocator, values);
        var evidence: nd.Evidence = .{};
        for (0..4) |_| {
            var observed = try self.measure(try state.NativeTestCase.forChoices(self.allocator, values, nodes, null));
            defer observed.deinit(self.allocator);
            const realized = try observed.realizedValues(self.allocator);
            defer c.deinitValues(self.allocator, realized);
            const failed = observed.status == .interesting and optionalStringEqual(observed.origin, origin);
            evidence.record(failed);
            const aligned = valuesEqual(values, realized);
            if (!failed or !aligned) {
                const message = if (aligned) try flakyDiagnostic(self.allocator, origin) else try firstCheckDiagnostic(self.allocator, values, realized);
                defer self.allocator.free(message);
                try self.setDiagnostic(message);
                self.error_kind = if (aligned) .flaky else .nondeterministic;
                return .{ .miss = true, .evidence = evidence };
            }
        }
        return .{ .miss = false, .evidence = evidence };
    }
    pub fn log(self: *Engine, comptime format: []const u8, args: anytype) !void {
        const text = try std.fmt.allocPrint(self.allocator, format, args);
        defer self.allocator.free(text);
        self.settings.output.line(self.io, text);
    }
    pub fn fail(self: *Engine, kind: anyerror, comptime format: []const u8, args: anytype) anyerror {
        const text = std.fmt.allocPrint(self.allocator, format, args) catch return error.OutOfMemory;
        defer self.allocator.free(text);
        self.setDiagnostic(text) catch return error.OutOfMemory;
        return kind;
    }
    pub fn replaySource(self: *Engine, origin: []const u8) !@import("runner_types.zig").ReplaySource {
        const counter = self.origins.get(origin) orelse return error.InternalError;
        return .{ .graph = (try counter.replayGraph()) orelse return error.InternalError, .longest = counter.longest() };
    }
    pub fn hasHistory(self: *Engine, origin: []const u8) bool {
        const counter = self.origins.get(origin) orelse return false;
        return !counter.history().isEmpty();
    }
    pub fn rejectOrigin(self: *Engine, origin: []const u8, evidence: counters.Counterexample.EvidenceCounts) !void {
        const counter = try self.origins.entry(origin);
        if (counter.reject(evidence)) |nodes| c.deinitNodes(self.allocator, nodes);
    }
    pub fn confirmBatch(self: *Engine, origin: []const u8, anchor: f64, source: *const graph.Graph, longest: usize, evidence: counters.Counterexample.EvidenceCounts) !void {
        try (try self.origins.entry(origin)).confirm(anchor, null, source, longest, evidence);
        try self.recordNdIncumbent(origin);
    }
    pub fn recordNdIncumbent(self: *Engine, origin: []const u8) !void {
        const counter = try self.origins.entry(origin);
        var repro = try counter.reproState();
        defer repro.deinit();
        try self.persister.recordNd(origin, counter.incumbent() orelse &.{}, &repro, false);
    }
    pub fn markShrunk(self: *Engine, origin: []const u8, shrunk: *std.StringHashMapUnmanaged(void)) !void {
        if (shrunk.contains(origin)) return;
        const owned = try self.allocator.dupe(u8, origin);
        errdefer self.allocator.free(owned);
        try shrunk.put(self.allocator, owned, {});
    }
    pub fn run(self: *Engine) anyerror!TestRunResult {
        return @import("runner_main.zig").run(self);
    }
    pub fn runBlob(self: *Engine, encoded: []const u8) anyerror!TestRunResult {
        return @import("runner_nd.zig").runBlob(self, encoded);
    }
    pub fn ndReproduce(self: *Engine, origin: ?[]const u8, source: @import("runner_types.zig").ReproSource, attempts: u64, fresh: u64) anyerror!@import("runner_types.zig").Reproduction {
        return @import("runner_nd.zig").ndReproduce(self, origin, source, attempts, fresh);
    }
    pub fn ndReplayGraph(self: *Engine, source: *const graph.Graph, max_size: usize, origin: ?[]const u8) anyerror!@import("runner_types.zig").NdReplay {
        return @import("runner_nd.zig").ndReplayGraph(self, source, max_size, origin);
    }
    pub fn ndReplayOnce(self: *Engine, values: []const c.ChoiceValue, origin: ?[]const u8) anyerror!@import("runner_types.zig").NdReplay {
        return @import("runner_nd.zig").ndReplayOnce(self, values, origin);
    }
    pub fn ndDiscoverySweep(self: *Engine) anyerror!void {
        return @import("runner_nd.zig").ndDiscoverySweep(self);
    }
    pub fn optimiseTargetsNd(self: *Engine) anyerror!void {
        return @import("runner_nd.zig").optimiseTargetsNd(self);
    }
    pub fn shrinkOrigin(self: *Engine, origin: []const u8, nodes: []const c.ChoiceNode, spans: []const c.Span, deadline: ?i128, shrunk: *std.StringHashMapUnmanaged(void)) anyerror!bool {
        return @import("runner_nd.zig").shrinkOrigin(self, origin, nodes, spans, deadline, shrunk);
    }
    pub fn finalReplay(self: *Engine, deadline: ?i128, shrink_enabled: bool) anyerror!void {
        return @import("runner_nd.zig").finalReplay(self, deadline, shrink_enabled);
    }
};
pub fn createRng(io: std.Io, settings: s.Settings, key: ?[]const u8) state.EngineRng {
    if (settings.backend == .urandom) return state.EngineRng.urandomSource(io);
    if (settings.seed) |seed| return state.EngineRng.seeded(seed);
    if (settings.derandomize) return state.EngineRng.seeded(dbmod.fnv1a(key orelse "unnamed-test"));
    return state.EngineRng.fromOs(io);
}
pub fn flakyDiagnostic(gpa: Allocator, origin: ?[]const u8) ![]u8 {
    const text = "Flaky test detected: Your test produced different outcomes when run with the same generated data — it failed when it previously succeeded, or succeeded when it previously failed. This usually means your test depends on external state such as global variables, system time, or external random number generators.";
    return if (origin) |value| std.fmt.allocPrint(gpa, "{s}\nThe failure that did not reproduce was: {s}", .{ text, value }) else gpa.dupe(u8, text);
}

pub fn valuesEqual(a: []const c.ChoiceValue, b: []const c.ChoiceValue) bool {
    if (a.len != b.len) return false;
    for (a, b) |*left, *right| if (!left.eql(right)) return false;
    return true;
}
pub fn optionalStringEqual(a: ?[]const u8, b: ?[]const u8) bool {
    if (a == null or b == null) return a == null and b == null;
    return std.mem.eql(u8, a.?, b.?);
}
pub fn firstCheckDiagnostic(gpa: Allocator, expected: []const c.ChoiceValue, realized: []const c.ChoiceValue) ![]u8 {
    var at: usize = 0;
    while (at < @min(expected.len, realized.len) and expected[at].eql(&realized[at])) : (at += 1) {}
    const detail = if (at == @min(expected.len, realized.len)) try std.fmt.allocPrint(gpa, "{d} choices were recorded but the replay realized {d}", .{ expected.len, realized.len }) else blk: {
        const before = try @import("printer.zig").debugChoiceValue(gpa, &expected[at]);
        defer gpa.free(before);
        const after = try @import("printer.zig").debugChoiceValue(gpa, &realized[at]);
        defer gpa.free(after);
        break :blk try std.fmt.allocPrint(gpa, "{s} became {s}", .{ before, after });
    };
    defer gpa.free(detail);
    return std.fmt.allocPrint(gpa, "Your test is non-deterministic: replaying the discovered failing example diverged from its recorded choices at position {d} ({s}). This usually means the test or a generator depends on global mutable state.", .{ at, detail });
}

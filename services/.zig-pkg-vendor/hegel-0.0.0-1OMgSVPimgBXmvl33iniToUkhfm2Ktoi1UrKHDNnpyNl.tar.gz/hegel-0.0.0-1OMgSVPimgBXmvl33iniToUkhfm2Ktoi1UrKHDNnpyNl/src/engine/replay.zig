// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const choices = @import("choices.zig");
const graph_mod = @import("graph.zig");
const Allocator = std.mem.Allocator;
const Value = choices.ChoiceValue;
const Mutex = @import("sync.zig").Mutex;

pub const Rescue = enum { pun, continue_replaying };
pub const Divergence = struct {
    stream: []usize,
    position: usize,
    pub fn deepClone(self: Divergence, gpa: Allocator) Allocator.Error!Divergence {
        return .{ .stream = try gpa.dupe(usize, self.stream), .position = self.position };
    }
    pub fn deinit(self: *Divergence, gpa: Allocator) void {
        gpa.free(self.stream);
    }
};
pub const Fits = struct {
    context: *anyopaque,
    call: *const fn (*anyopaque, *const Value) bool,
    pub fn accepts(self: Fits, value: *const Value) bool {
        return self.call(self.context, value);
    }
};
pub const Resolved = union(enum) {
    served: *const Value,
    misfit: struct { value: *const Value, timeline: usize },
    exhausted,
};
pub const ExternalReplay = struct {
    context: *anyopaque,
    vtable: *const VTable,
    pub const VTable = struct {
        resolve: *const fn (*anyopaque, Allocator, []const usize, usize, []const graph_mod.Frame, Fits) anyerror!?Value,
        divergence: *const fn (*anyopaque) ?Divergence,
        longest: *const fn (*anyopaque) usize,
        deinit: ?*const fn (*anyopaque, Allocator) void = null,
    };
};

pub const LiveSet = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize) = .init(1),
    mutex: Mutex = .{},
    live_flags: []bool,
    pruned: std.ArrayList([]usize) = .empty,
    first_divergence: ?Divergence = null,

    pub fn create(gpa: Allocator, count: usize) Allocator.Error!*LiveSet {
        const result = try gpa.create(LiveSet);
        errdefer gpa.destroy(result);
        const live = try gpa.alloc(bool, count);
        @memset(live, true);
        result.* = .{ .allocator = gpa, .live_flags = live };
        return result;
    }
    pub fn retain(self: *LiveSet) *LiveSet {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *LiveSet) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            const gpa = self.allocator;
            gpa.free(self.live_flags);
            for (self.pruned.items) |batch| gpa.free(batch);
            self.pruned.deinit(gpa);
            if (self.first_divergence) |*value| value.deinit(gpa);
            gpa.destroy(self);
        }
    }
    fn anyLive(self: *const LiveSet) bool {
        for (self.live_flags) |live| if (live) return true;
        return false;
    }
    fn prune(self: *LiveSet, batch: []usize) Allocator.Error!void {
        if (batch.len == 0) {
            self.allocator.free(batch);
            return;
        }
        errdefer self.allocator.free(batch);
        try self.pruned.append(self.allocator, batch);
        for (batch) |k| self.live_flags[k] = false;
    }
    fn diverge(self: *LiveSet, stream: []const usize, position: usize) Allocator.Error!void {
        if (self.first_divergence == null) self.first_divergence = .{ .stream = try self.allocator.dupe(usize, stream), .position = position };
    }
};

const ExternalShared = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize) = .init(1),
    mutex: Mutex = .{},
    resolver: ExternalReplay,
    fn create(gpa: Allocator, resolver: ExternalReplay) Allocator.Error!*ExternalShared {
        const result = try gpa.create(ExternalShared);
        result.* = .{ .allocator = gpa, .resolver = resolver };
        return result;
    }
    fn retain(self: *ExternalShared) *ExternalShared {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    fn release(self: *ExternalShared) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            if (self.resolver.vtable.deinit) |destroy| destroy(self.resolver.context, self.allocator);
            self.allocator.destroy(self);
        }
    }
};

const Pending = union(enum) {
    nodes: []usize,
    tie: struct { node: usize, edges: []usize },
    clone: struct { node: usize, edges: []usize, shared: *LiveSet },
    fn deinit(self: *Pending, gpa: Allocator) void {
        switch (self.*) {
            .nodes => |v| gpa.free(v),
            .tie => |v| gpa.free(v.edges),
            .clone => |v| {
                gpa.free(v.edges);
                v.shared.release();
            },
        }
    }
};
const Candidate = struct { edge: ?graph_mod.Settled, node: usize };

pub const GraphWalk = struct {
    allocator: Allocator,
    mutex: Mutex = .{},
    graph_value: graph_mod.Graph,
    prev: ?graph_mod.Addr = null,
    pending: Pending,
    settled_edges: std.ArrayList(graph_mod.Settled) = .empty,
    first_divergence: ?Divergence = null,
    children: std.ArrayList(*LiveSet) = .empty,

    fn create(gpa: Allocator, graph: *const graph_mod.Graph) choices.Error!*GraphWalk {
        const result = try gpa.create(GraphWalk);
        errdefer gpa.destroy(result);
        const start = try gpa.dupe(usize, &.{graph_mod.START});
        errdefer gpa.free(start);
        result.* = .{ .allocator = gpa, .graph_value = try graph.deepCloneWithAllocator(gpa), .pending = .{ .nodes = start } };
        return result;
    }
    fn destroy(self: *GraphWalk) void {
        self.graph_value.deinit();
        if (self.prev) |addr| self.allocator.free(addr);
        self.pending.deinit(self.allocator);
        self.settled_edges.deinit(self.allocator);
        if (self.first_divergence) |*value| value.deinit(self.allocator);
        for (self.children.items) |child| child.release();
        self.children.deinit(self.allocator);
        self.allocator.destroy(self);
    }
    fn candidate(self: *const GraphWalk, n: usize, edge: ?graph_mod.Settled, ident: ?graph_mod.Ident, ending: bool) ?Candidate {
        if ((ending and n == graph_mod.END) or (if (ident) |i| self.graph_value.nodes()[n].ident.eql(i) else false)) return .{ .edge = edge, .node = n };
        return null;
    }
    fn findCandidate(self: *const GraphWalk, ident: ?graph_mod.Ident, ending: bool) ?Candidate {
        switch (self.pending) {
            .nodes => |nodes| for (nodes) |n| {
                if (self.candidate(n, null, ident, ending)) |found| return found;
            },
            .tie => |tie| for (tie.edges) |i| {
                if (self.candidate(self.graph_value.nodes()[tie.node].edges.items[i].target, .{ .node = tie.node, .edge = i }, ident, ending)) |found| return found;
            },
            .clone => |clone| {
                clone.shared.mutex.lock();
                defer clone.shared.mutex.unlock();
                for (clone.edges, clone.shared.live_flags) |i, live| {
                    if (live) if (self.candidate(self.graph_value.nodes()[clone.node].edges.items[i].target, .{ .node = clone.node, .edge = i }, ident, ending)) |found| return found;
                }
            },
        }
        return null;
    }
    fn arrive(self: *GraphWalk, ident: graph_mod.Ident, stream: []const usize, position: usize) Allocator.Error!?usize {
        if (self.findCandidate(ident, false)) |found| {
            if (found.edge) |edge| try self.settled_edges.append(self.allocator, edge);
            return found.node;
        }
        try self.diverge(stream, position);
        return self.graph_value.node(ident);
    }
    fn identAt(self: *GraphWalk, addr: []const graph_mod.Frame) Allocator.Error!graph_mod.Ident {
        const next = try self.allocator.dupe(graph_mod.Frame, addr);
        errdefer self.allocator.free(next);
        const ident = try graph_mod.identBefore(self.allocator, self.prev, next);
        if (self.prev) |old| self.allocator.free(old);
        self.prev = next;
        return ident;
    }
    fn diverge(self: *GraphWalk, stream: []const usize, position: usize) Allocator.Error!void {
        if (self.divergence() == null) self.first_divergence = .{ .stream = try self.allocator.dupe(usize, stream), .position = position };
    }
    fn divergence(self: *const GraphWalk) ?Divergence {
        if (self.first_divergence) |found| return found;
        for (self.children.items) |child| {
            child.mutex.lock();
            defer child.mutex.unlock();
            if (child.first_divergence) |found| return found;
        }
        return null;
    }
    fn endedOnEnd(self: *const GraphWalk) bool {
        return self.findCandidate(null, true) != null;
    }
    fn settled(self: *const GraphWalk, gpa: Allocator) Allocator.Error![]graph_mod.Settled {
        var out: std.ArrayList(graph_mod.Settled) = .empty;
        errdefer out.deinit(gpa);
        try out.appendSlice(gpa, self.settled_edges.items);
        switch (self.pending) {
            .nodes => {},
            .tie => |tie| for (tie.edges) |i| {
                if (self.graph_value.nodes()[tie.node].edges.items[i].target == graph_mod.END) try out.append(gpa, .{ .node = tie.node, .edge = i });
            },
            .clone => |clone| {
                clone.shared.mutex.lock();
                defer clone.shared.mutex.unlock();
                for (clone.edges, clone.shared.live_flags) |i, live| if (live and self.graph_value.nodes()[clone.node].edges.items[i].target == graph_mod.END) try out.append(gpa, .{ .node = clone.node, .edge = i });
            },
        }
        return out.toOwnedSlice(gpa);
    }
    fn emptyPending(self: *GraphWalk) void {
        self.pending.deinit(self.allocator);
        self.pending = .{ .nodes = &.{} };
    }
};

pub const Replay = struct {
    allocator: Allocator,
    timelines: []?[]Value = &.{},
    nodes: []?[]choices.ChoiceNode = &.{},
    rescue: Rescue,
    shared: *LiveSet,
    external_shared: ?*ExternalShared = null,
    graph_walk: ?*GraphWalk = null,
    external_value: ?Value = null,

    pub fn deinit(self: *Replay) void {
        for (self.timelines) |timeline| if (timeline) |values| choices.deinitValues(self.allocator, values);
        self.allocator.free(self.timelines);
        for (self.nodes) |nodes| if (nodes) |values| choices.deinitNodes(self.allocator, values);
        self.allocator.free(self.nodes);
        if (self.external_value) |*value| value.deinit(self.allocator);
        if (self.external_shared) |external_ref| external_ref.release();
        if (self.graph_walk) |walk| walk.destroy();
        self.shared.release();
    }
    fn initSlots(gpa: Allocator, shared: *LiveSet, rescue: Rescue, count: usize) Allocator.Error!Replay {
        var replay: Replay = .{ .allocator = gpa, .rescue = rescue, .shared = shared };
        errdefer replay.deinit();
        replay.timelines = try gpa.alloc(?[]Value, count);
        @memset(replay.timelines, null);
        replay.nodes = try gpa.alloc(?[]choices.ChoiceNode, count);
        @memset(replay.nodes, null);
        return replay;
    }
    pub fn pun(gpa: Allocator, prefix: []const Value, nodes: ?[]const choices.ChoiceNode) choices.Error!Replay {
        var replay = try initSlots(gpa, try LiveSet.create(gpa, 1), .pun, 1);
        errdefer replay.deinit();
        replay.timelines[0] = try choices.cloneValues(gpa, prefix);
        if (nodes) |n| replay.nodes[0] = try choices.cloneNodes(gpa, n);
        return replay;
    }
    pub fn counterexample(gpa: Allocator, timelines: []const []const Value) choices.Error!Replay {
        var replay = try initSlots(gpa, try LiveSet.create(gpa, timelines.len), .continue_replaying, timelines.len);
        errdefer replay.deinit();
        for (timelines, replay.timelines) |timeline, *target| target.* = try choices.cloneValues(gpa, timeline);
        return replay;
    }
    pub fn graph(gpa: Allocator, source: *const graph_mod.Graph) choices.Error!Replay {
        var replay = try initSlots(gpa, try LiveSet.create(gpa, 0), .continue_replaying, 0);
        errdefer replay.deinit();
        replay.graph_walk = try GraphWalk.create(gpa, source);
        return replay;
    }
    pub fn external(gpa: Allocator, resolver: ExternalReplay) Allocator.Error!Replay {
        var replay = try initSlots(gpa, try LiveSet.create(gpa, 0), .continue_replaying, 0);
        errdefer replay.deinit();
        replay.external_shared = try ExternalShared.create(gpa, resolver);
        return replay;
    }
    pub fn needsFrames(self: *const Replay) bool {
        return self.graph_walk != null or self.external_shared != null;
    }
    pub fn proposalNode(self: *const Replay, timeline: usize, position: usize) ?*const choices.ChoiceNode {
        if (timeline >= self.nodes.len) return null;
        const nodes = self.nodes[timeline] orelse return null;
        return if (position < nodes.len) &nodes[position] else null;
    }
    fn valueAt(self: *const Replay, timeline: usize, position: usize) ?*const Value {
        const values = self.timelines[timeline] orelse return null;
        return if (position < values.len) &values[position] else null;
    }
    pub fn resolve(self: *Replay, stream: []const usize, position: usize, frames: []const graph_mod.Frame, fits: Fits) !Resolved {
        if (self.external_value) |*value| value.deinit(self.allocator);
        self.external_value = null;
        if (self.graph_walk) |walk| {
            walk.mutex.lock();
            defer walk.mutex.unlock();
            return self.resolveGraph(walk, stream, position, frames, fits);
        }
        if (self.external_shared) |external_ref| {
            external_ref.mutex.lock();
            defer external_ref.mutex.unlock();
            self.external_value = try external_ref.resolver.vtable.resolve(external_ref.resolver.context, self.allocator, stream, position, frames, fits);
            if (self.external_value) |*value| if (fits.accepts(value)) return .{ .served = value };
            return .exhausted;
        }
        return switch (self.rescue) {
            .pun => if (self.valueAt(0, position)) |value| if (fits.accepts(value)) .{ .served = value } else .{ .misfit = .{ .value = value, .timeline = 0 } } else .exhausted,
            .continue_replaying => self.resolveLive(stream, position, fits),
        };
    }
    fn resolveGraph(self: *Replay, walk: *GraphWalk, stream: []const usize, position: usize, addr: []const graph_mod.Frame, fits: Fits) Allocator.Error!Resolved {
        var ident = try walk.identAt(addr);
        defer ident.deinit(walk.allocator);
        const node = try walk.arrive(ident, stream, position) orelse {
            walk.emptyPending();
            return .exhausted;
        };
        const edges = walk.graph_value.nodes()[node].edges.items;
        for (edges) |*edge| {
            if (!graph_mod.framesEql(edge.addr, addr) or !fits.accepts(&edge.value)) continue;
            var tied: std.ArrayList(usize) = .empty;
            errdefer tied.deinit(self.allocator);
            for (edges, 0..) |*other, j| if (graph_mod.framesEql(other.addr, addr) and other.value.eql(&edge.value)) try tied.append(self.allocator, j);
            const owned = try tied.toOwnedSlice(self.allocator);
            walk.pending.deinit(walk.allocator);
            walk.pending = .{ .tie = .{ .node = node, .edges = owned } };
            return .{ .served = &edge.value };
        }
        try walk.diverge(stream, position);
        walk.emptyPending();
        return .exhausted;
    }
    fn resolveLive(self: *Replay, stream: []const usize, position: usize, fits: Fits) Allocator.Error!Resolved {
        const set = self.shared;
        set.mutex.lock();
        defer set.mutex.unlock();
        if (set.anyLive()) {
            for (self.timelines, 0..) |_, k| {
                if (!set.live_flags[k]) continue;
                const stored = self.valueAt(k, position) orelse continue;
                if (!fits.accepts(stored)) continue;
                var batch: std.ArrayList(usize) = .empty;
                defer batch.deinit(self.allocator);
                for (self.timelines, 0..) |_, j| {
                    const other = self.valueAt(j, position);
                    if (set.live_flags[j] and (other == null or !other.?.eql(stored))) try batch.append(self.allocator, j);
                }
                try set.prune(try batch.toOwnedSlice(self.allocator));
                return .{ .served = stored };
            }
            var batch: std.ArrayList(usize) = .empty;
            defer batch.deinit(self.allocator);
            for (set.live_flags, 0..) |is_live, k| if (is_live) try batch.append(self.allocator, k);
            try set.prune(try batch.toOwnedSlice(self.allocator));
            try set.diverge(stream, position);
        }
        var reverse = set.pruned.items.len;
        while (reverse > 0) {
            reverse -= 1;
            for (set.pruned.items[reverse]) |k| if (self.valueAt(k, position)) |stored| {
                if (fits.accepts(stored)) return .{ .served = stored };
            };
        }
        return .exhausted;
    }
    pub fn cloneChild(self: *Replay, stream: []const usize, position: usize, frames: []const graph_mod.Frame) choices.Error!Replay {
        if (self.graph_walk) |walk| {
            walk.mutex.lock();
            defer walk.mutex.unlock();
            return self.cloneFromGraph(walk, stream, position, frames);
        }
        if (self.external_shared) |external_ref| return .{ .allocator = self.allocator, .rescue = .continue_replaying, .shared = self.shared.retain(), .external_shared = external_ref.retain() };
        const set = self.shared;
        set.mutex.lock();
        defer set.mutex.unlock();
        var child = try initSlots(self.allocator, set.retain(), self.rescue, self.timelines.len);
        errdefer child.deinit();
        var batch: std.ArrayList(usize) = .empty;
        defer batch.deinit(self.allocator);
        for (self.timelines, 0..) |_, k| {
            if (self.valueAt(k, position)) |stored| {
                if (stored.* == .clone) {
                    const record = stored.clone;
                    child.timelines[k] = try record.ownedValues(self.allocator);
                    if (self.rescue == .pun) if (record.realizedNodes()) |nodes| {
                        child.nodes[k] = try choices.cloneNodes(self.allocator, nodes);
                    };
                    continue;
                }
            }
            if (set.live_flags[k]) try batch.append(self.allocator, k);
        }
        switch (self.rescue) {
            .pun => if (child.timelines[0] == null) {
                child.timelines[0] = try self.allocator.alloc(Value, 0);
            },
            .continue_replaying => {
                try set.prune(try batch.toOwnedSlice(self.allocator));
                if (!set.anyLive()) try set.diverge(stream, position);
            },
        }
        return child;
    }
    fn cloneFromGraph(self: *Replay, walk: *GraphWalk, stream: []const usize, position: usize, addr: []const graph_mod.Frame) choices.Error!Replay {
        var ident = try walk.identAt(addr);
        defer ident.deinit(walk.allocator);
        const node = try walk.arrive(ident, stream, position);
        var indices: std.ArrayList(usize) = .empty;
        defer indices.deinit(self.allocator);
        var records: std.ArrayList([]Value) = .empty;
        defer {
            for (records.items) |record| choices.deinitValues(self.allocator, record);
            records.deinit(self.allocator);
        }
        if (node) |n| for (walk.graph_value.nodes()[n].edges.items, 0..) |*edge, i| {
            if (edge.value != .clone or !graph_mod.framesEql(edge.addr, addr)) continue;
            const values = try edge.value.clone.ownedValues(self.allocator);
            errdefer choices.deinitValues(self.allocator, values);
            try indices.append(self.allocator, i);
            try records.append(self.allocator, values);
        };
        var child = try initSlots(self.allocator, try LiveSet.create(self.allocator, records.items.len), .continue_replaying, records.items.len);
        errdefer child.deinit();
        for (records.items, child.timelines) |record, *timeline| timeline.* = record;
        records.items.len = 0;
        try walk.children.ensureUnusedCapacity(walk.allocator, 1);
        const owned = try indices.toOwnedSlice(self.allocator);
        walk.pending.deinit(walk.allocator);
        if (node != null and owned.len > 0) {
            walk.pending = .{ .clone = .{ .node = node.?, .edges = owned, .shared = child.shared.retain() } };
        } else {
            self.allocator.free(owned);
            walk.pending = .{ .nodes = &.{} };
            try walk.diverge(stream, position);
        }
        walk.children.appendAssumeCapacity(child.shared.retain());
        return child;
    }
    pub fn divergence(self: *const Replay) ?Divergence {
        if (self.graph_walk) |walk| {
            walk.mutex.lock();
            defer walk.mutex.unlock();
            return walk.divergence();
        }
        if (self.external_shared) |external_ref| {
            external_ref.mutex.lock();
            defer external_ref.mutex.unlock();
            return external_ref.resolver.vtable.divergence(external_ref.resolver.context);
        }
        self.shared.mutex.lock();
        defer self.shared.mutex.unlock();
        return self.shared.first_divergence;
    }
    pub fn settled(self: *const Replay, gpa: Allocator) Allocator.Error![]graph_mod.Settled {
        if (self.graph_walk) |walk| {
            walk.mutex.lock();
            defer walk.mutex.unlock();
            return walk.settled(gpa);
        }
        return gpa.alloc(graph_mod.Settled, 0);
    }
    pub fn endedOnEnd(self: *const Replay) bool {
        if (self.graph_walk) |walk| {
            walk.mutex.lock();
            defer walk.mutex.unlock();
            return walk.endedOnEnd();
        }
        return false;
    }
    pub fn live(self: *const Replay, gpa: Allocator) Allocator.Error![]bool {
        self.shared.mutex.lock();
        defer self.shared.mutex.unlock();
        return gpa.dupe(bool, self.shared.live_flags);
    }
    pub fn longest(self: *const Replay) usize {
        if (self.external_shared) |external_ref| {
            external_ref.mutex.lock();
            defer external_ref.mutex.unlock();
            return external_ref.resolver.vtable.longest(external_ref.resolver.context);
        }
        var length: usize = 0;
        for (self.timelines) |timeline| if (timeline) |values| {
            length = @max(length, values.len);
        };
        return length;
    }
};

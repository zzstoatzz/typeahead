// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const Allocator = std.mem.Allocator;
const Managed = std.math.big.int.Managed;

pub const Sign = enum { minus, no_sign, plus };
pub const BigInt = Integer(true);
pub const BigUint = Integer(false);

fn Integer(comptime signed: bool) type {
    return struct {
        const Self = @This();
        value: Managed,

        pub fn fromInt(allocator: Allocator, value: anytype) !Self {
            if (!signed and value < 0) return error.NegativeUnsigned;
            return .{ .value = try Managed.initSet(allocator, value) };
        }

        pub fn zero(allocator: Allocator) !Self {
            return fromInt(allocator, @as(u8, 0));
        }

        pub fn fromString(allocator: Allocator, base: u8, text: []const u8) !Self {
            var result: Self = .{ .value = try Managed.init(allocator) };
            errdefer result.deinit();
            try result.value.setString(base, text);
            if (!signed and result.sign() == .minus) return error.NegativeUnsigned;
            return result;
        }

        pub fn fromBytesLe(allocator: Allocator, bytes: []const u8) !Self {
            return readBytes(allocator, bytes, .little, .unsigned);
        }

        pub fn fromBytesBe(allocator: Allocator, sign_value: Sign, bytes: []const u8) !Self {
            var result = try readBytes(allocator, bytes, .big, .unsigned);
            if (sign_value == .minus and !result.isZero()) {
                if (!signed) {
                    result.deinit();
                    return error.NegativeUnsigned;
                }
                result.value.negate();
            }
            return result;
        }

        pub fn fromSignedBytesLe(allocator: Allocator, bytes: []const u8) !Self {
            var result = try readBytes(allocator, bytes, .little, .signed);
            if (!signed and result.sign() == .minus) {
                result.deinit();
                return error.NegativeUnsigned;
            }
            return result;
        }

        fn readBytes(allocator: Allocator, bytes: []const u8, endian: std.builtin.Endian, signedness: std.builtin.Signedness) !Self {
            var result: Self = .{ .value = try Managed.initCapacity(allocator, (bytes.len + @sizeOf(usize) - 1) / @sizeOf(usize) + 1) };
            var mutable = result.value.toMutable();
            mutable.readTwosComplement(bytes, bytes.len * 8, endian, signedness);
            result.value.setMetadata(mutable.positive, mutable.len);
            return result;
        }

        pub fn clone(self: Self, allocator: Allocator) !Self {
            return .{ .value = try self.value.cloneWithDifferentAllocator(allocator) };
        }

        pub fn deinit(self: *Self) void {
            self.value.deinit();
            self.* = undefined;
        }

        pub fn isZero(self: Self) bool {
            return self.value.eqlZero();
        }

        pub fn sign(self: Self) Sign {
            return if (self.isZero()) .no_sign else if (self.value.isPositive()) .plus else .minus;
        }

        pub fn bits(self: Self) usize {
            return self.value.bitCountAbs();
        }

        pub fn order(self: Self, other: Self) std.math.Order {
            return self.value.order(other.value);
        }

        pub fn eql(self: Self, other: Self) bool {
            return self.value.eql(other.value);
        }

        pub fn toInt(self: Self, comptime T: type) ?T {
            return self.value.toInt(T) catch null;
        }

        pub fn toF64(self: Self) f64 {
            return self.value.toFloat(f64, .nearest_even)[0];
        }

        pub fn toString(self: Self, allocator: Allocator, base: u8) ![]u8 {
            return self.value.toString(allocator, base, .lower);
        }

        pub fn toSignedBytesLe(self: Self, allocator: Allocator) ![]u8 {
            const bit_count = self.value.toConst().bitCountTwosCompForSignedness(.signed);
            const result = try allocator.alloc(u8, @max(1, (bit_count + 7) / 8));
            self.value.toConst().writeTwosComplement(result, .little);
            return result;
        }

        pub fn toBytesBe(self: Self, allocator: Allocator) !struct { Sign, []u8 } {
            const result = try allocator.alloc(u8, (self.bits() + 7) / 8);
            var magnitude_value = self.value.toConst();
            magnitude_value.positive = true;
            magnitude_value.writeTwosComplement(result, .big);
            return .{ self.sign(), result };
        }

        pub fn magnitude(self: Self, allocator: Allocator) !BigUint {
            var result: BigUint = .{ .value = try self.value.cloneWithDifferentAllocator(allocator) };
            result.value.abs();
            return result;
        }

        pub fn asSigned(self: Self, allocator: Allocator) !BigInt {
            return .{ .value = try self.value.cloneWithDifferentAllocator(allocator) };
        }

        pub fn abs(self: Self, allocator: Allocator) !Self {
            var result = try self.clone(allocator);
            result.value.abs();
            return result;
        }

        pub fn negate(self: Self, allocator: Allocator) !Self {
            if (!signed and !self.isZero()) return error.NegativeUnsigned;
            var result = try self.clone(allocator);
            if (!result.isZero()) result.value.negate();
            return result;
        }

        pub fn add(self: Self, allocator: Allocator, other: Self) !Self {
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.add(&self.value, &other.value);
            return result;
        }

        pub fn sub(self: Self, allocator: Allocator, other: Self) !Self {
            if (!signed and self.order(other) == .lt) return error.NegativeUnsigned;
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.sub(&self.value, &other.value);
            return result;
        }

        pub fn mul(self: Self, allocator: Allocator, other: Self) !Self {
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.mul(&self.value, &other.value);
            return result;
        }

        pub fn divRem(self: Self, allocator: Allocator, other: Self) !struct { Self, Self } {
            if (other.isZero()) return error.DivisionByZero;
            var quotient = try Self.zero(allocator);
            errdefer quotient.deinit();
            var remainder = try Self.zero(allocator);
            errdefer remainder.deinit();
            try Managed.divTrunc(&quotient.value, &remainder.value, &self.value, &other.value);
            return .{ quotient, remainder };
        }

        pub fn div(self: Self, allocator: Allocator, other: Self) !Self {
            var pair = try self.divRem(allocator, other);
            pair[1].deinit();
            return pair[0];
        }

        pub fn rem(self: Self, allocator: Allocator, other: Self) !Self {
            var pair = try self.divRem(allocator, other);
            pair[0].deinit();
            return pair[1];
        }

        pub fn shl(self: Self, allocator: Allocator, shift: usize) !Self {
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.shiftLeft(&self.value, shift);
            return result;
        }

        pub fn shr(self: Self, allocator: Allocator, shift: usize) !Self {
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.shiftRight(&self.value, shift);
            return result;
        }

        pub fn pow(self: Self, allocator: Allocator, exponent: u32) !Self {
            var result = try Self.zero(allocator);
            errdefer result.deinit();
            try result.value.pow(&self.value, exponent);
            return result;
        }

        pub fn addInt(self: Self, allocator: Allocator, amount: anytype) !Self {
            var other = try Self.fromInt(allocator, amount);
            defer other.deinit();
            return self.add(allocator, other);
        }

        pub fn subInt(self: Self, allocator: Allocator, amount: anytype) !Self {
            var other = try Self.fromInt(allocator, amount);
            defer other.deinit();
            return self.sub(allocator, other);
        }
    };
}

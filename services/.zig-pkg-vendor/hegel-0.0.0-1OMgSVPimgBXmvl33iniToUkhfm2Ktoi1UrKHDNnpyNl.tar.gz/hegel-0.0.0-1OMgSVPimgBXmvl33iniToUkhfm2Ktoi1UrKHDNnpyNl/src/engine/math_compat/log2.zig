// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/e_log2.c
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
// Developed at SunSoft, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
const c = @import("log.zig");
const ivln2_hi: f64 = 1.44269504072144627571e+00;
const ivln2_lo: f64 = 1.67517131648865118353e-10;

pub fn log2(input: f64) f64 {
    @setFloatMode(.strict);
    var x = input;
    var bits: u64 = @bitCast(x);
    var hx: u32 = @truncate(bits >> 32);
    var k: i32 = 0;
    if (hx < 0x00100000 or hx >> 31 != 0) {
        if (bits << 1 == 0) return -1.0 / (x * x);
        if (hx >> 31 != 0) return (x - x) / 0.0;
        k -= 54;
        x *= 0x1p54;
        bits = @bitCast(x);
        hx = @truncate(bits >> 32);
    } else if (hx >= 0x7ff00000) {
        return x;
    } else if (hx == 0x3ff00000 and bits << 32 == 0) {
        return 0.0;
    }
    hx += 0x3ff00000 - 0x3fe6a09e;
    k += @as(i32, @intCast(hx >> 20)) - 0x3ff;
    hx = (hx & 0x000fffff) + 0x3fe6a09e;
    bits = (@as(u64, hx) << 32) | (bits & 0xffffffff);
    x = @bitCast(bits);
    const f = x - 1.0;
    const hfsq = 0.5 * f * f;
    const s = f / (2.0 + f);
    const z = s * s;
    const w = z * z;
    const t1 = w * (c.lg2 + w * (c.lg4 + w * c.lg6));
    const t2 = z * (c.lg1 + w * (c.lg3 + w * (c.lg5 + w * c.lg7)));
    const r = t2 + t1;
    var hi = f - hfsq;
    bits = @bitCast(hi);
    bits &= 0xffffffff00000000;
    hi = @bitCast(bits);
    const lo = f - hi - hfsq + s * (hfsq + r);
    const val_hi = hi * ivln2_hi;
    const val_lo = (lo + hi) * ivln2_lo + lo * ivln2_hi;
    const y: f64 = @floatFromInt(k);
    const combined = y + val_hi;
    return (val_lo + ((y - combined) + val_hi)) + combined;
}

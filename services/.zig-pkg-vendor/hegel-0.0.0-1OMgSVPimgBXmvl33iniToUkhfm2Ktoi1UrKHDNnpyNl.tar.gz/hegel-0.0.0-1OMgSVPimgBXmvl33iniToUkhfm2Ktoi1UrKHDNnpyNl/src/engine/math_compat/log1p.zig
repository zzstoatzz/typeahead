// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/s_log1p.c
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
// Developed at SunPro, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
const std = @import("std");
const coeff = @import("log.zig");

pub fn log1p(x: f64) f64 {
    @setFloatMode(.strict);
    var bits: u64 = @bitCast(x);
    const hx: u32 = @truncate(bits >> 32);
    var k: i32 = 1;
    var f: f64 = 0.0;
    var c: f64 = 0.0;
    if (hx < 0x3fda827a or hx >> 31 != 0) {
        if (hx >= 0xbff00000) {
            if (x == -1.0) return x / 0.0;
            return (x - x) / 0.0;
        }
        if (hx << 1 < @as(u32, 0x3ca00000) << 1) {
            if (hx & 0x7ff00000 == 0) std.mem.doNotOptimizeAway(@as(f32, @floatCast(x)));
            return x;
        }
        if (hx <= 0xbfd2bec4) {
            k = 0;
            c = 0.0;
            f = x;
        }
    } else if (hx >= 0x7ff00000) {
        return x;
    }
    if (k > 0) {
        bits = @bitCast(1.0 + x);
        var hu: u32 = @truncate(bits >> 32);
        hu += 0x3ff00000 - 0x3fe6a09e;
        k = @as(i32, @intCast(hu >> 20)) - 0x3ff;
        if (k < 54) {
            const u: f64 = @bitCast(bits);
            c = if (k >= 2) 1.0 - (u - x) else x - (u - 1.0);
            c /= u;
        } else {
            c = 0.0;
        }
        hu = (hu & 0x000fffff) + 0x3fe6a09e;
        bits = (@as(u64, hu) << 32) | (bits & 0xffffffff);
        f = @as(f64, @bitCast(bits)) - 1.0;
    }
    const hfsq = 0.5 * f * f;
    const s = f / (2.0 + f);
    const z = s * s;
    const w = z * z;
    const t1 = w * (coeff.lg2 + w * (coeff.lg4 + w * coeff.lg6));
    const t2 = z * (coeff.lg1 + w * (coeff.lg3 + w * (coeff.lg5 + w * coeff.lg7)));
    const r = t2 + t1;
    const dk: f64 = @floatFromInt(k);
    return s * (hfsq + r) + (dk * coeff.ln2_lo + c) - hfsq + f + dk * coeff.ln2_hi;
}

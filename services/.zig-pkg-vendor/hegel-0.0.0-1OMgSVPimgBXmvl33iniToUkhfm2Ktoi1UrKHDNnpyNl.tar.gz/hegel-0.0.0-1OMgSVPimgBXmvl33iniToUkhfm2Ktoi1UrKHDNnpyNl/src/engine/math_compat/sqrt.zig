// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
pub fn sqrt(x: f64) f64 {
    @setFloatMode(.strict);
    return @sqrt(x);
}

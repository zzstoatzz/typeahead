// SPDX-License-Identifier: MIT AND MPL-2.0
// origin: FreeBSD /usr/src/lib/msun/src/e_rem_pio2.c
//
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
//
// Developed at SunPro, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
//
// Optimized by Bruce D. Evans. */
const EPS: f64 = 2.2204460492503131e-16;
const TO_INT: f64 = 1.5 / EPS;
const INV_PIO2: f64 = 6.36619772367581382433e-01;
const PIO2_1: f64 = 1.57079632673412561417e+00;
const PIO2_1T: f64 = 6.07710050650619224932e-11;
const PIO2_2: f64 = 6.07710050630396597660e-11;
const PIO2_2T: f64 = 2.02226624879595063154e-21;
const PIO2_3: f64 = 2.02226624871116645580e-21;
const PIO2_3T: f64 = 8.47842766036889956997e-32;
const large = @import("rem_pio2_large.zig").remPio2Large;
const Result = struct { i32, f64, f64 };
fn medium(x: f64, ix: u32) Result {
    @setFloatMode(.strict);
    const tmp = x * INV_PIO2 + TO_INT;
    const fnn = tmp - TO_INT;
    const n: i32 = @intFromFloat(fnn);
    var r = x - fnn * PIO2_1;
    var w = fnn * PIO2_1T;
    var y0 = r - w;
    const ey: i32 = @intCast((@as(u64, @bitCast(y0)) >> 52) & 0x7ff);
    const ex: i32 = @intCast(ix >> 20);
    if (ex - ey > 16) {
        const t = r;
        w = fnn * PIO2_2;
        r = t - w;
        w = fnn * PIO2_2T - ((t - r) - w);
        y0 = r - w;
        const ey2: i32 = @intCast((@as(u64, @bitCast(y0)) >> 52) & 0x7ff);
        if (ex - ey2 > 49) {
            const t2 = r;
            w = fnn * PIO2_3;
            r = t2 - w;
            w = fnn * PIO2_3T - ((t2 - r) - w);
            y0 = r - w;
        }
    }
    return .{ n, y0, (r - y0) - w };
}
pub fn remPio2(x: f64) Result {
    @setFloatMode(.strict);
    const bits: u64 = @bitCast(x);
    const sign = bits >> 63;
    const ix: u32 = @truncate((bits >> 32) & 0x7fffffff);
    var times: f64 = 0;
    if (ix <= 0x400f6a7a) {
        if ((ix & 0xfffff) == 0x921fb) return medium(x, ix);
        times = if (ix <= 0x4002d97c) 1 else 2;
    } else if (ix <= 0x401c463b) {
        if (ix <= 0x4015fdbc) {
            if (ix == 0x4012d97c) return medium(x, ix);
            times = 3;
        } else {
            if (ix == 0x401921fb) return medium(x, ix);
            times = 4;
        }
    }
    if (times != 0) {
        if (sign == 0) {
            const z = x - times * PIO2_1;
            const y0 = z - times * PIO2_1T;
            return .{ @intFromFloat(times), y0, (z - y0) - times * PIO2_1T };
        }
        const z = x + times * PIO2_1;
        const y0 = z + times * PIO2_1T;
        return .{ -@as(i32, @intFromFloat(times)), y0, (z - y0) + times * PIO2_1T };
    }
    if (ix < 0x413921fb) return medium(x, ix);
    if (ix >= 0x7ff00000) return .{ 0, x - x, x - x };
    var z: f64 = @bitCast((bits & 0x000fffffffffffff) | (@as(u64, 0x3ff + 23) << 52));
    var tx: [3]f64 = undefined;
    for (0..2) |i| {
        tx[i] = @floatFromInt(@as(i32, @intFromFloat(z)));
        z = (z - tx[i]) * 0x1p24;
    }
    tx[2] = z;
    var i: usize = 2;
    while (i != 0 and tx[i] == 0) {
        i -= 1;
    }
    var ty: [3]f64 = @splat(0);
    const n = large(tx[0 .. i + 1], &ty, @as(i32, @intCast(ix >> 20)) - (0x3ff + 23));
    return if (sign != 0) .{ -n, -ty[0], -ty[1] } else .{ n, ty[0], ty[1] };
}

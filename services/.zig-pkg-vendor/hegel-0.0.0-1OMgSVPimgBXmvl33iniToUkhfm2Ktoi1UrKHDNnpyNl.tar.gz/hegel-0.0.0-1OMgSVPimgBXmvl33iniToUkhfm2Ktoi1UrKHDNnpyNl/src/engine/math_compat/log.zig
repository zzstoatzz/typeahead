// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/e_log.c
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
//
// Developed at SunSoft, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================

const std = @import("std");
pub const ln2_hi: f64 = 6.93147180369123816490e-01;
pub const ln2_lo: f64 = 1.90821492927058770002e-10;
pub const lg1: f64 = 6.666666666666735130e-01;
pub const lg2: f64 = 3.999999999940941908e-01;
pub const lg3: f64 = 2.857142874366239149e-01;
pub const lg4: f64 = 2.222219843214978396e-01;
pub const lg5: f64 = 1.818357216161805012e-01;
pub const lg6: f64 = 1.531383769920937332e-01;
pub const lg7: f64 = 1.479819860511658591e-01;

pub fn log(input: f64) f64 {
    @setFloatMode(.strict);
    var x = input;
    var bits: u64 = @bitCast(x);
    var hx: u32 = @truncate(bits >> 32);
    var k: i32 = 0;
    if (hx < 0x00100000 or hx >> 31 != 0) {
        if (bits << 1 == 0) return -1.0 / (x * x);
        if (hx >> 31 != 0) return (x - x) / 0.0;
        k -= 54;
        x *= 0x1p54;
        bits = @bitCast(x);
        hx = @truncate(bits >> 32);
    } else if (hx >= 0x7ff00000) {
        return x;
    } else if (hx == 0x3ff00000 and bits << 32 == 0) {
        return 0.0;
    }
    hx += 0x3ff00000 - 0x3fe6a09e;
    k += @as(i32, @intCast(hx >> 20)) - 0x3ff;
    hx = (hx & 0x000fffff) + 0x3fe6a09e;
    bits = (@as(u64, hx) << 32) | (bits & 0xffffffff);
    x = @bitCast(bits);
    const f = x - 1.0;
    const hfsq = 0.5 * f * f;
    const s = f / (2.0 + f);
    const z = s * s;
    const w = z * z;
    const t1 = w * (lg2 + w * (lg4 + w * lg6));
    const t2 = z * (lg1 + w * (lg3 + w * (lg5 + w * lg7)));
    const r = t2 + t1;
    const dk: f64 = @floatFromInt(k);
    return s * (hfsq + r) + dk * ln2_lo - hfsq + f + dk * ln2_hi;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/s_expm1.c
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
// Developed at SunPro, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
const std = @import("std");
const ln2_hi: f64 = 6.93147180369123816490e-01;
const ln2_lo: f64 = 1.90821492927058770002e-10;
const inv_ln2: f64 = 1.44269504088896338700e+00;
const q1: f64 = -3.33333333333331316428e-02;
const q2: f64 = 1.58730158725481460165e-03;
const q3: f64 = -7.93650757867487942473e-05;
const q4: f64 = 4.00821782732936239552e-06;
const q5: f64 = -2.01099218183624371326e-07;

pub fn expm1(input: f64) f64 {
    @setFloatMode(.strict);
    var x = input;
    var bits: u64 = @bitCast(x);
    const hx: u32 = @truncate((bits >> 32) & 0x7fffffff);
    const sign: i32 = @intCast(bits >> 63);
    if (hx >= 0x4043687a) {
        if (std.math.isNan(x)) return x;
        if (sign != 0) return -1.0;
        if (x > 7.09782712893383973096e+02) {
            x *= 0x1p1023;
            return x;
        }
    }
    var k: i32 = 0;
    var c: f64 = 0.0;
    if (hx > 0x3fd62e42) {
        const hi: f64, const lo: f64 = if (hx < 0x3ff0a2b2) blk: {
            if (sign == 0) {
                k = 1;
                break :blk .{ x - ln2_hi, ln2_lo };
            }
            k = -1;
            break :blk .{ x + ln2_hi, -ln2_lo };
        } else blk: {
            k = @intFromFloat(inv_ln2 * x + @as(f64, if (sign != 0) -0.5 else 0.5));
            const t: f64 = @floatFromInt(k);
            break :blk .{ x - t * ln2_hi, t * ln2_lo };
        };
        x = hi - lo;
        c = (hi - x) - lo;
    } else if (hx < 0x3c900000) {
        if (hx < 0x00100000) std.mem.doNotOptimizeAway(x);
        return x;
    }
    const hfx = 0.5 * x;
    const hxs = x * hfx;
    const r1 = 1.0 + hxs * (q1 + hxs * (q2 + hxs * (q3 + hxs * (q4 + hxs * q5))));
    const t = 3.0 - r1 * hfx;
    var e = hxs * ((r1 - t) / (6.0 - x * t));
    if (k == 0) return x - (x * e - hxs);
    e = x * (e - c) - c;
    e -= hxs;
    if (k == -1) return 0.5 * (x - e) - 0.5;
    if (k == 1) {
        if (x < -0.25) return -2.0 * (e - (x + 0.5));
        return 1.0 + 2.0 * (x - e);
    }
    bits = @as(u64, @intCast(0x3ff + k)) << 52;
    const twopk: f64 = @bitCast(bits);
    if (k < 0 or k > 56) {
        var y = x - e + 1.0;
        if (k == 1024) y = y * 2.0 * 0x1p1023 else y = y * twopk;
        return y - 1.0;
    }
    bits = @as(u64, @intCast(0x3ff - k)) << 52;
    const uf: f64 = @bitCast(bits);
    return if (k < 20) (x - e + (1.0 - uf)) * twopk else (x - (e + uf) + 1.0) * twopk;
}

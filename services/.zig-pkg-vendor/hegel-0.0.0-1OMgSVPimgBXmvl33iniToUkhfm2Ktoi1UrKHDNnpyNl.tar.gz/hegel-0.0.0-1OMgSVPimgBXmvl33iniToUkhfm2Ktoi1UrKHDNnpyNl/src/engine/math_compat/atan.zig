// SPDX-License-Identifier: MIT AND MPL-2.0
// Retained upstream libm notice; see LICENSES/libm-origin-notices.txt.
//
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
//
// Developed at SunPro, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
// /

const ATANHI = [4]f64{
    4.63647609000806093515e-01,
    7.85398163397448278999e-01,
    9.82793723247329054082e-01,
    1.57079632679489655800e+00,
};
const ATANLO = [4]f64{
    2.26987774529616870924e-17,
    3.06161699786838301793e-17,
    1.39033110312309984516e-17,
    6.12323399573676603587e-17,
};
const AT = [11]f64{
    3.33333333333329318027e-01,
    -1.99999999998764832476e-01,
    1.42857142725034663711e-01,
    -1.11111104054623557880e-01,
    9.09088713343650656196e-02,
    -7.69187620504482999495e-02,
    6.66107313738753120669e-02,
    -5.83357013379057348645e-02,
    4.97687799461593236017e-02,
    -3.65315727442169155270e-02,
    1.62858201153657823623e-02,
};

pub fn atan(input: f64) f64 {
    @setFloatMode(.strict);
    var x = input;
    const bits: u64 = @bitCast(x);
    const sign = bits >> 63;
    const ix: u32 = @truncate((bits >> 32) & 0x7fffffff);
    if (ix >= 0x44100000) {
        if (@import("std").math.isNan(x)) return x;
        const z = ATANHI[3] + @as(f64, @bitCast(@as(u64, 0x03800000)));
        return if (sign != 0) -z else z;
    }
    var id: i32 = -1;
    if (ix < 0x3fdc0000) {
        if (ix < 0x3e400000) {
            if (ix < 0x00100000) @import("std").mem.doNotOptimizeAway(@as(f32, @floatCast(x)));
            return x;
        }
    } else {
        x = @abs(x);
        if (ix < 0x3ff30000) {
            if (ix < 0x3fe60000) {
                x = (2 * x - 1) / (2 + x);
                id = 0;
            } else {
                x = (x - 1) / (x + 1);
                id = 1;
            }
        } else if (ix < 0x40038000) {
            x = (x - 1.5) / (1 + 1.5 * x);
            id = 2;
        } else {
            x = -1 / x;
            id = 3;
        }
    }
    const z = x * x;
    const w = z * z;
    const s1 = z * (AT[0] + w * (AT[2] + w * (AT[4] + w * (AT[6] + w * (AT[8] + w * AT[10])))));
    const s2 = w * (AT[1] + w * (AT[3] + w * (AT[5] + w * (AT[7] + w * AT[9]))));
    if (id < 0) return x - x * (s1 + s2);
    const result = ATANHI[@intCast(id)] - (x * (s1 + s2) - ATANLO[@intCast(id)] - x);
    return if (sign != 0) -result else result;
}

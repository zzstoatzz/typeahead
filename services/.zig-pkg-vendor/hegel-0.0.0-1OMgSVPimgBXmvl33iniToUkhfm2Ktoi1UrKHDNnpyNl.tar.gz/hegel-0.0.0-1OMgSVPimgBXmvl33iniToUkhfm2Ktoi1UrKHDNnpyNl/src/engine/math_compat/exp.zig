// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/e_exp.c
// ====================================================
// Copyright (C) 2004 by Sun Microsystems, Inc. All rights reserved.
//
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================

const std = @import("std");
const scalbn = @import("scalbn.zig").scalbn;
const half = [_]f64{ 0.5, -0.5 };
const ln2_hi: f64 = 6.93147180369123816490e-01;
const ln2_lo: f64 = 1.90821492927058770002e-10;
const inv_ln2: f64 = 1.44269504088896338700e+00;
const p1: f64 = 1.66666666666666019037e-01;
const p2: f64 = -2.77777777770155933842e-03;
const p3: f64 = 6.61375632143793436117e-05;
const p4: f64 = -1.65339022054652515390e-06;
const p5: f64 = 4.13813679705723846039e-08;

pub fn exp(input: f64) f64 {
    @setFloatMode(.strict);
    var x = input;
    const bits: u64 = @bitCast(x);
    const sign: i32 = @intCast(bits >> 63);
    const hx: u32 = @as(u32, @truncate(bits >> 32)) & 0x7fffffff;
    if (hx >= 0x4086232b) {
        if (std.math.isNan(x)) return x;
        if (x > 709.782712893383973096) {
            x *= 0x1p1023;
            return x;
        }
        if (x < -708.39641853226410622) {
            std.mem.doNotOptimizeAway(@as(f32, @floatCast(-0x1p-149 / x)));
            if (x < -745.13321910194110842) return 0.0;
        }
    }
    const k: i32, const hi: f64, const lo: f64 = if (hx > 0x3fd62e42) blk: {
        const k: i32 = if (hx >= 0x3ff0a2b2) @intFromFloat(inv_ln2 * x + half[@intCast(sign)]) else 1 - sign - sign;
        const hi = x - @as(f64, @floatFromInt(k)) * ln2_hi;
        const lo = @as(f64, @floatFromInt(k)) * ln2_lo;
        x = hi - lo;
        break :blk .{ k, hi, lo };
    } else if (hx > 0x3e300000) .{ 0, x, 0.0 } else {
        std.mem.doNotOptimizeAway(0x1p1023 + x);
        return 1.0 + x;
    };
    const xx = x * x;
    const c = x - xx * (p1 + xx * (p2 + xx * (p3 + xx * (p4 + xx * p5))));
    const y = 1.0 + (x * c / (2.0 - c) - lo + hi);
    return if (k == 0) y else scalbn(y, k);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
pub fn scalbn(input: f64, exponent: i32) f64 {
    @setFloatMode(.strict);
    var x = input;
    var n = exponent;
    if (n > 1023) {
        x *= 0x1p1023;
        n -= 1023;
        if (n > 1023) {
            x *= 0x1p1023;
            n -= 1023;
            if (n > 1023) n = 1023;
        }
    } else if (n < -1022) {
        x *= 0x1p-969;
        n += 969;
        if (n < -1022) {
            x *= 0x1p-969;
            n += 969;
            if (n < -1022) n = -1022;
        }
    }
    const scale: f64 = @bitCast(@as(u64, @intCast(1023 + n)) << 52);
    return x * scale;
}

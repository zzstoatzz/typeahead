// SPDX-License-Identifier: MIT AND MPL-2.0
// origin: FreeBSD /usr/src/lib/msun/src/s_sin.c */
//
// ====================================================
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
//
// Developed at SunPro, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================

const std = @import("std");
const ks = @import("k_sin.zig").k_sin;
const kc = @import("k_cos.zig").k_cos;
const rem = @import("rem_pio2.zig").remPio2;
pub fn sin(x: f64) f64 {
    @setFloatMode(.strict);
    const ix: u32 = @truncate((@as(u64, @bitCast(x)) >> 32) & 0x7fffffff);
    if (ix <= 0x3fe921fb) {
        if (ix < 0x3e500000) {
            if (ix < 0x00100000) {
                std.mem.doNotOptimizeAway(x / 0x1p120);
            } else {
                std.mem.doNotOptimizeAway(x + 0x1p120);
            }
            return x;
        }
        return ks(x, 0, 0);
    }
    if (ix >= 0x7ff00000) return x - x;
    const r = rem(x);
    return switch (r[0] & 3) {
        0 => ks(r[1], r[2], 1),
        1 => kc(r[1], r[2]),
        2 => -ks(r[1], r[2], 1),
        else => -kc(r[1], r[2]),
    };
}

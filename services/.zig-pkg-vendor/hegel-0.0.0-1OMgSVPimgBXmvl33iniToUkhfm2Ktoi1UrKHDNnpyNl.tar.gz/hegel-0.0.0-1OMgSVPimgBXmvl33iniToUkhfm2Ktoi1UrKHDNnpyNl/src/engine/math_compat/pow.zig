// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-provenance.json and LICENSES/libm-0.2.16.txt.
// origin: FreeBSD /usr/src/lib/msun/src/e_pow.c
// ====================================================
// Copyright (C) 2004 by Sun Microsystems, Inc. All rights reserved.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
// ====================================================
const scalbn = @import("scalbn.zig").scalbn;
const sqrt = @import("sqrt.zig").sqrt;

const BP: [2]f64 = .{ 1.0, 1.5 };
const DP_H: [2]f64 = .{ 0.0, 5.84962487220764160156e-01 };
const DP_L: [2]f64 = .{ 0.0, 1.35003920212974897128e-08 };
const TWO53: f64 = 9007199254740992.0;
const HUGE: f64 = 1.0e300;
const TINY: f64 = 1.0e-300;
const L1: f64 = 5.99999999999994648725e-01;
const L2: f64 = 4.28571428578550184252e-01;
const L3: f64 = 3.33333329818377432918e-01;
const L4: f64 = 2.72728123808534006489e-01;
const L5: f64 = 2.30660745775561754067e-01;
const L6: f64 = 2.06975017800338417784e-01;
const P1: f64 = 1.66666666666666019037e-01;
const P2: f64 = -2.77777777770155933842e-03;
const P3: f64 = 6.61375632143793436117e-05;
const P4: f64 = -1.65339022054652515390e-06;
const P5: f64 = 4.13813679705723846039e-08;
const LG2: f64 = 6.93147180559945286227e-01;
const LG2_H: f64 = 6.93147182464599609375e-01;
const LG2_L: f64 = -1.90465429995776804525e-09;
const OVT: f64 = 8.0085662595372944372e-017;
const CP: f64 = 9.61796693925975554329e-01;
const CP_H: f64 = 9.61796700954437255859e-01;
const CP_L: f64 = -7.02846165095275826516e-09;
const IVLN2: f64 = 1.44269504088896338700e+00;
const IVLN2_H: f64 = 1.44269502162933349609e+00;
const IVLN2_L: f64 = 1.92596299112661746887e-08;

fn highWord(x: f64) u32 {
    const bits: u64 = @bitCast(x);
    return @truncate(bits >> 32);
}

fn setHighWord(x: f64, word: u32) f64 {
    const bits: u64 = @bitCast(x);
    return @bitCast((@as(u64, word) << 32) | (bits & 0xffffffff));
}

fn setLowWord(x: f64, word: u32) f64 {
    const bits: u64 = @bitCast(x);
    return @bitCast((bits & 0xffffffff00000000) | word);
}

pub fn pow(x: f64, y: f64) f64 {
    @setFloatMode(.strict);
    const xbits: u64 = @bitCast(x);
    const ybits: u64 = @bitCast(y);
    const hx: i32 = @bitCast(@as(u32, @truncate(xbits >> 32)));
    const hy: i32 = @bitCast(@as(u32, @truncate(ybits >> 32)));
    const lx: u32 = @truncate(xbits);
    const ly: u32 = @truncate(ybits);
    var ix: i32 = hx & 0x7fffffff;
    const iy: i32 = hy & 0x7fffffff;
    if (@as(u32, @intCast(iy)) | ly == 0) return 1.0;
    if (hx == 0x3ff00000 and lx == 0) return 1.0;
    if (ix > 0x7ff00000 or (ix == 0x7ff00000 and lx != 0) or iy > 0x7ff00000 or (iy == 0x7ff00000 and ly != 0)) return x + y;
    var y_is_int: i32 = 0;
    var k: i32 = undefined;
    var j: i32 = undefined;
    if (hx < 0) {
        if (iy >= 0x43400000) {
            y_is_int = 2;
        } else if (iy >= 0x3ff00000) {
            k = (iy >> 20) - 0x3ff;
            if (k > 20) {
                j = @bitCast(ly >> @intCast(52 - k));
                if (j << @intCast(52 - k) == @as(i32, @bitCast(ly))) y_is_int = 2 - (j & 1);
            } else if (ly == 0) {
                j = iy >> @intCast(20 - k);
                if (j << @intCast(20 - k) == iy) y_is_int = 2 - (j & 1);
            }
        }
    }
    if (ly == 0) {
        if (iy == 0x7ff00000) {
            return if ((ix - 0x3ff00000) | @as(i32, @bitCast(lx)) == 0) 1.0 else if (ix >= 0x3ff00000) (if (hy >= 0) y else 0.0) else (if (hy >= 0) 0.0 else -y);
        }
        if (iy == 0x3ff00000) return if (hy >= 0) x else 1.0 / x;
        if (hy == 0x40000000) return x * x;
        if (hy == 0x3fe00000 and hx >= 0) return sqrt(x);
    }
    var ax = @abs(x);
    if (lx == 0 and (ix == 0x7ff00000 or ix == 0 or ix == 0x3ff00000)) {
        var z = ax;
        if (hy < 0) z = 1.0 / z;
        if (hx < 0) {
            if ((ix - 0x3ff00000) | y_is_int == 0) z = (z - z) / (z - z) else if (y_is_int == 1) z = -z;
        }
        return z;
    }
    var sign: f64 = 1.0;
    if (hx < 0) {
        if (y_is_int == 0) return (x - x) / (x - x);
        if (y_is_int == 1) sign = -1.0;
    }
    var log_hi: f64 = undefined;
    var log_lo: f64 = undefined;
    if (iy > 0x41e00000) {
        if (iy > 0x43f00000) {
            if (ix <= 0x3fefffff) return if (hy < 0) HUGE * HUGE else TINY * TINY;
            if (ix >= 0x3ff00000) return if (hy > 0) HUGE * HUGE else TINY * TINY;
        }
        if (ix < 0x3fefffff) return if (hy < 0) sign * HUGE * HUGE else sign * TINY * TINY;
        if (ix > 0x3ff00000) return if (hy > 0) sign * HUGE * HUGE else sign * TINY * TINY;
        const t = ax - 1.0;
        const w = (t * t) * (0.5 - t * (0.3333333333333333333333 - t * 0.25));
        const u = IVLN2_H * t;
        const v = t * IVLN2_L - w * IVLN2;
        log_hi = setLowWord(u + v, 0);
        log_lo = v - (log_hi - u);
    } else {
        var n: i32 = 0;
        if (ix < 0x00100000) {
            ax *= TWO53;
            n -= 53;
            ix = @bitCast(highWord(ax));
        }
        n += (ix >> 20) - 0x3ff;
        j = ix & 0x000fffff;
        ix = j | 0x3ff00000;
        const interval: usize = if (j <= 0x3988e) 0 else if (j < 0xbb67a) 1 else blk: {
            n += 1;
            ix -= 0x00100000;
            break :blk 0;
        };
        ax = setHighWord(ax, @bitCast(ix));
        const delta = ax - BP[interval];
        const inv_sum = 1.0 / (ax + BP[interval]);
        const ss = delta * inv_sum;
        const s_hi = setLowWord(ss, 0);
        const denominator_hi = setHighWord(0.0, ((@as(u32, @bitCast(ix)) >> 1) | 0x20000000) + 0x00080000 + (@as(u32, @intCast(interval)) << 18));
        const denominator_lo = ax - (denominator_hi - BP[interval]);
        const s_lo = inv_sum * ((delta - s_hi * denominator_hi) - s_hi * denominator_lo);
        const s_squared = ss * ss;
        var r = s_squared * s_squared * (L1 + s_squared * (L2 + s_squared * (L3 + s_squared * (L4 + s_squared * (L5 + s_squared * L6)))));
        r += s_lo * (s_hi + ss);
        const squared_hi = s_hi * s_hi;
        const polynomial_hi = setLowWord(3.0 + squared_hi + r, 0);
        const polynomial_lo = r - ((polynomial_hi - 3.0) - squared_hi);
        const correction_hi = s_hi * polynomial_hi;
        const correction_lo = s_lo * polynomial_hi + polynomial_lo * ss;
        const p_hi = setLowWord(correction_hi + correction_lo, 0);
        const p_lo = correction_lo - (p_hi - correction_hi);
        const z_hi = CP_H * p_hi;
        const z_lo = CP_L * p_hi + p_lo * CP + DP_L[interval];
        const exponent: f64 = @floatFromInt(n);
        log_hi = setLowWord(((z_hi + z_lo) + DP_H[interval]) + exponent, 0);
        log_lo = z_lo - (((log_hi - exponent) - DP_H[interval]) - z_hi);
    }
    const y1 = setLowWord(y, 0);
    const product_lo = (y - y1) * log_hi + y * log_lo;
    var product_hi = y1 * log_hi;
    const product = product_lo + product_hi;
    j = @bitCast(highWord(product));
    const low: i32 = @bitCast(@as(u32, @truncate(@as(u64, @bitCast(product)))));
    if (j >= 0x40900000) {
        if ((j - 0x40900000) | low != 0) return sign * HUGE * HUGE;
        if (product_lo + OVT > product - product_hi) return sign * HUGE * HUGE;
    } else if (j & 0x7fffffff >= 0x4090cc00) {
        if ((@as(u32, @bitCast(j)) - 0xc090cc00) | @as(u32, @bitCast(low)) != 0) return sign * TINY * TINY;
        if (product_lo <= product - product_hi) return sign * TINY * TINY;
    }
    const absolute_high = j & 0x7fffffff;
    k = (absolute_high >> 20) - 0x3ff;
    var n: i32 = 0;
    if (absolute_high > 0x3fe00000) {
        n = j + (@as(i32, 0x00100000) >> @intCast(k + 1));
        k = ((n & 0x7fffffff) >> 20) - 0x3ff;
        const t = setHighWord(0.0, @bitCast(n & ~(@as(i32, 0x000fffff) >> @intCast(k))));
        n = ((n & 0x000fffff) | 0x00100000) >> @intCast(20 - k);
        if (j < 0) n = -n;
        product_hi -= t;
    }
    const t = setLowWord(product_lo + product_hi, 0);
    const u = t * LG2_H;
    const v = (product_lo - (t - product_hi)) * LG2 + t * LG2_L;
    var z = u + v;
    const w = v - (z - u);
    const squared = z * z;
    const polynomial = z - squared * (P1 + squared * (P2 + squared * (P3 + squared * (P4 + squared * P5))));
    const r = (z * polynomial) / (polynomial - 2.0) - (w + z * w);
    z = 1.0 - (r - z);
    j = @bitCast(highWord(z));
    j += n << 20;
    if (j >> 20 <= 0) z = scalbn(z, n) else z = setHighWord(z, @bitCast(j));
    return sign * z;
}

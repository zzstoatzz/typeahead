// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs: RunResult.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const cache = @import("exec_cache.zig");
const replay = @import("replay.zig");
const graph = @import("graph.zig");
const Allocator = std.mem.Allocator;
const state = @import("state.zig");
pub const Event = state.FamilyCore.Event;
pub const RunResult = struct {
    status: c.Status,
    nodes: []c.ChoiceNode,
    spans: []c.Span,
    origin: ?[]u8,
    target_observations: std.StringHashMapUnmanaged(f64) = .empty,
    events: []Event = &.{},
    divergence: ?replay.Divergence = null,
    settled: []graph.Settled = &.{},
    ended: bool = false,
    pub fn fromCached(run: cache.CachedRun) RunResult {
        return .{ .status = run.status, .nodes = run.nodes, .spans = run.spans, .origin = run.origin };
    }
    pub fn deepClone(self: RunResult, gpa: Allocator) !RunResult {
        var result = fromCached(try cache.CachedRun.init(gpa, self.status, self.origin, self.nodes, self.spans));
        errdefer result.deinit(gpa);
        var targets = self.target_observations.iterator();
        while (targets.next()) |entry| {
            const label = try gpa.dupe(u8, entry.key_ptr.*);
            errdefer gpa.free(label);
            try result.target_observations.put(gpa, label, entry.value_ptr.*);
        }
        const events = try gpa.alloc(Event, self.events.len);
        var event_count: usize = 0;
        errdefer if (result.events.len == 0) {
            for (events[0..event_count]) |event| gpa.free(event.label);
            gpa.free(events);
        };
        for (events, self.events) |*dest, source| {
            dest.* = .{ .label = try gpa.dupe(u8, source.label), .value = source.value };
            event_count += 1;
        }
        result.events = events;
        result.divergence = if (self.divergence) |d| try d.deepClone(gpa) else null;
        result.settled = try gpa.dupe(graph.Settled, self.settled);
        result.ended = self.ended;
        return result;
    }
    pub fn deinit(self: *RunResult, gpa: Allocator) void {
        var serving: cache.CachedRun = .{ .status = self.status, .origin = self.origin, .nodes = self.nodes, .spans = self.spans };
        serving.deinit(gpa);
        var keys = self.target_observations.keyIterator();
        while (keys.next()) |key| gpa.free(key.*);
        self.target_observations.deinit(gpa);
        for (self.events) |event| gpa.free(event.label);
        gpa.free(self.events);
        if (self.divergence) |*d| d.deinit(gpa);
        gpa.free(self.settled);
        self.* = undefined;
    }
    pub fn realizedValues(self: RunResult, gpa: Allocator) ![]c.ChoiceValue {
        const values = try gpa.alloc(c.ChoiceValue, self.nodes.len);
        var count: usize = 0;
        errdefer {
            for (values[0..count]) |*v| v.deinit(gpa);
            gpa.free(values);
        }
        for (self.nodes, values) |node, *value| {
            value.* = try node.value(gpa);
            count += 1;
        }
        return values;
    }
};

pub const Executor = struct {
    context: *anyopaque,
    call: *const fn (*anyopaque, *state.NativeTestCaseHandle) anyerror!void,
    pub fn execute(self: Executor, gpa: Allocator, native_case: state.NativeTestCase) !RunResult {
        var owned_case = native_case;
        const handle = state.NativeTestCaseHandle.create(gpa, owned_case) catch |err| {
            owned_case.deinit();
            return err;
        };
        defer handle.release();
        try self.call(self.context, handle);
        return snapshot(gpa, handle);
    }
};
pub fn snapshot(gpa: Allocator, handle: *state.NativeTestCaseHandle) !RunResult {
    const native_case = handle.lock();
    defer handle.unlock();
    try native_case.reassemble();
    const family = native_case.family;
    family.mutex.lock();
    defer family.mutex.unlock();
    const status = family.status() orelse return error.UnconcludedCase;
    const view: RunResult = .{
        .status = status,
        .nodes = native_case.nodes.items,
        .spans = native_case.spans.inner.items,
        .origin = family.origin,
        .target_observations = family.target_observations,
        .events = family.events.items,
        .divergence = native_case.divergence(),
        .ended = native_case.endedOnEnd(),
    };
    var result = try view.deepClone(gpa);
    errdefer result.deinit(gpa);
    gpa.free(result.settled);
    result.settled = &.{};
    result.settled = try native_case.settledEdges(gpa);
    return result;
}

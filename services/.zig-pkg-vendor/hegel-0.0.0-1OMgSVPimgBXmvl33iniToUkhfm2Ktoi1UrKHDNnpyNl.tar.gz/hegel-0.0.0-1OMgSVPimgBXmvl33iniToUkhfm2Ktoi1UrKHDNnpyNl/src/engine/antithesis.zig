// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/antithesis.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const builtin = @import("builtin");
const settings = @import("settings.zig");
const Allocator = std.mem.Allocator;
pub const Environment = settings.Environment;
pub const TestLocation = struct { function: []const u8, class: []const u8, file: []const u8, begin_line: u32 };
pub fn checkEnvironment(gpa: Allocator, io: std.Io, env: settings.Environment) !?[]u8 {
    if (builtin.os.tag == .windows or builtin.target.cpu.arch.isWasm()) return null;
    const dir = env.get(env.context, "ANTITHESIS_OUTPUT_DIR") orelse return null;
    std.Io.Dir.cwd().access(io, dir, .{}) catch return try std.fmt.allocPrint(gpa, "Expected ANTITHESIS_OUTPUT_DIR={s} to exist when running inside of Antithesis", .{dir});
    return null;
}
pub fn assertionLines(gpa: Allocator, location: TestLocation, passed: bool) ![]u8 {
    const id = try std.fmt.allocPrint(gpa, "{s}::{s} passes properties", .{ location.class, location.function });
    defer gpa.free(id);
    const Location = struct { class: []const u8, function: []const u8, file: []const u8, begin_line: u32, begin_column: u32 = 0 };
    const Assertion = struct { hit: bool, must_hit: bool = true, assert_type: []const u8 = "always", display_type: []const u8 = "Always", condition: bool, id: []const u8, message: []const u8, location: Location };
    const Payload = struct { antithesis_assert: Assertion };
    var payload: Payload = .{ .antithesis_assert = .{ .hit = false, .condition = false, .id = id, .message = id, .location = .{ .class = location.class, .function = location.function, .file = location.file, .begin_line = location.begin_line } } };
    const declaration = try std.json.Stringify.valueAlloc(gpa, payload, .{});
    defer gpa.free(declaration);
    payload.antithesis_assert.hit = true;
    payload.antithesis_assert.condition = passed;
    const evaluation = try std.json.Stringify.valueAlloc(gpa, payload, .{});
    defer gpa.free(evaluation);
    return std.fmt.allocPrint(gpa, "{s}\n{s}\n", .{ declaration, evaluation });
}
pub fn report(gpa: Allocator, io: std.Io, env: settings.Environment, location: TestLocation, passed: bool, output: settings.Output) !void {
    if (builtin.os.tag == .windows) return;
    const directory = env.get(env.context, "ANTITHESIS_OUTPUT_DIR") orelse return;
    const path = try std.fmt.allocPrint(gpa, "{s}/sdk.jsonl", .{directory});
    defer gpa.free(path);
    const lines = try assertionLines(gpa, location, passed);
    defer gpa.free(lines);
    append(gpa, path, lines) catch {
        const message = try std.fmt.allocPrint(gpa, "Failed to write the Antithesis assertion for {s}::{s} passes properties to {s}", .{ location.class, location.function, path });
        defer gpa.free(message);
        output.line(io, message);
    };
}
fn append(gpa: Allocator, path: []const u8, bytes: []const u8) !void {
    if (builtin.target.cpu.arch.isWasm() or builtin.os.tag == .windows) return error.Unavailable;
    const zpath = try gpa.dupeSentinel(u8, path, 0);
    defer gpa.free(zpath);
    const fd = std.c.open(zpath, .{ .ACCMODE = .WRONLY, .CREAT = true, .APPEND = true }, @as(std.c.mode_t, 0o666));
    if (fd < 0) return error.FileSystem;
    defer _ = std.c.close(fd);
    var written: usize = 0;
    while (written < bytes.len) {
        const amount = std.c.write(fd, bytes[written..].ptr, bytes.len - written);
        if (amount < 0) {
            if (std.c.errno(amount) == .INTR) continue;
            return error.FileSystem;
        }
        if (amount == 0) return error.FileSystem;
        written += @intCast(amount);
    }
}

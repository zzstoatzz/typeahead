// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/settings.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const builtin = @import("builtin");
const Allocator = std.mem.Allocator;
pub const HealthCheck = enum { filter_too_much, too_slow, test_cases_too_large, large_initial_test_case };
pub const Phase = enum { explicit, reuse, generate, target, shrink };
pub const Backend = enum { default, urandom };
pub const Verbosity = enum { quiet, normal, verbose, debug };
pub const NondeterminismStrictness = enum {
    quiet,
    warn,
    @"error",
    pub fn parse(s: []const u8) ?@This() {
        inline for (.{ "quiet", "warn", "error" }) |name| {
            if (std.mem.eql(u8, s, name)) return @field(@This(), name);
        }
        return null;
    }
};
pub const Output = struct {
    context: ?*anyopaque = null,
    callback: ?*const fn (?*anyopaque, []const u8) void = null,
    pub fn line(self: Output, io: std.Io, text: []const u8) void {
        if (self.callback) |sink| return sink(self.context, text);
        std.Io.File.stderr().writeStreamingAll(io, text) catch return;
        std.Io.File.stderr().writeStreamingAll(io, "\n") catch {};
    }
};
pub const Database = union(enum) { unset, disabled, path: []const u8 };
pub const Environment = struct {
    context: ?*anyopaque,
    get: *const fn (?*anyopaque, []const u8) ?[]const u8,
    pub fn value(self: Environment, key: []const u8) ?[]const u8 {
        const s = self.get(self.context, key) orelse return null;
        return if (s.len == 0) null else s;
    }
};
pub const Settings = struct {
    test_cases: u64 = 100,
    verbosity: Verbosity = .normal,
    output: Output = .{},
    seed: ?u64 = null,
    derandomize: bool = false,
    database: Database = if (builtin.target.cpu.arch.isWasm()) .disabled else .unset,
    suppress_health_check: []const HealthCheck = &.{},
    in_antithesis: bool = false,
    phases: []const Phase = &.{ .explicit, .reuse, .generate, .target, .shrink },
    report_multiple_failures: bool = false,
    show_statistics: bool = false,
    print_blob: bool = true,
    backend: Backend = .default,
    config_path: ?[]const u8 = null,
    unbounded_choices: bool = false,
    nondeterminism_strictness: NondeterminismStrictness = .quiet,
    nd_force: bool = false,
    pub fn healthCheckSuppressed(self: Settings, check: HealthCheck) bool {
        return std.mem.indexOfScalar(HealthCheck, self.suppress_health_check, check) != null;
    }
    pub fn choiceBound(self: Settings) usize {
        return if (self.unbounded_choices or self.healthCheckSuppressed(.test_cases_too_large)) std.math.maxInt(usize) else 1 << 20;
    }
    pub fn hasPhase(self: Settings, phase: Phase) bool {
        return std.mem.indexOfScalar(Phase, self.phases, phase) != null;
    }
    pub fn withEnvOverrides(self: Settings, env: Environment) error{InvalidEnvironment}!Settings {
        var result = self;
        if (env.value("HEGEL_TEST_CASES")) |s| {
            result.test_cases = parseU64(s) orelse return error.InvalidEnvironment;
            if (result.test_cases == 0) return error.InvalidEnvironment;
        }
        if (env.value("HEGEL_DATABASE")) |s| result.database = if (std.mem.eql(u8, s, "disabled")) .disabled else .{ .path = s };
        if (env.value("HEGEL_STATISTICS")) |s| {
            if (!std.mem.eql(u8, s, "0")) result.show_statistics = true;
        }
        if (env.value("HEGEL_SEED")) |s| result.seed = if (std.mem.eql(u8, s, "none")) null else parseU64(s) orelse return error.InvalidEnvironment;
        if (env.value("HEGEL_DERANDOMIZE")) |s| result.derandomize = parseBool(s) orelse return error.InvalidEnvironment;
        if (env.value("HEGEL_PRINT_BLOB")) |s| result.print_blob = parseBool(s) orelse return error.InvalidEnvironment;
        if (env.value("HEGEL_NONDETERMINISM_STRICTNESS")) |s| result.nondeterminism_strictness = NondeterminismStrictness.parse(s) orelse return error.InvalidEnvironment;
        return result;
    }
    pub fn deepClone(self: Settings, gpa: Allocator) Allocator.Error!Settings {
        var result = self;
        result.database = switch (self.database) {
            .path => |s| .{ .path = try gpa.dupe(u8, s) },
            else => self.database,
        };
        errdefer if (result.database == .path) gpa.free(result.database.path);
        result.suppress_health_check = try gpa.dupe(HealthCheck, self.suppress_health_check);
        errdefer gpa.free(result.suppress_health_check);
        result.phases = try gpa.dupe(Phase, self.phases);
        errdefer gpa.free(result.phases);
        result.config_path = if (self.config_path) |s| try gpa.dupe(u8, s) else null;
        return result;
    }
    pub fn deinitOwned(self: *Settings, gpa: Allocator) void {
        if (self.database == .path) gpa.free(self.database.path);
        gpa.free(self.suppress_health_check);
        gpa.free(self.phases);
        if (self.config_path) |s| gpa.free(s);
        self.* = undefined;
    }
};
pub fn parseBool(s: []const u8) ?bool {
    for ([_][]const u8{ "true", "1", "yes" }) |v| if (std.mem.eql(u8, s, v)) return true;
    for ([_][]const u8{ "false", "0", "no" }) |v| if (std.mem.eql(u8, s, v)) return false;
    return null;
}
fn parseU64(s: []const u8) ?u64 {
    if (s.len == 0) return null;
    const digits = if (s[0] == '+') s[1..] else s;
    if (digits.len == 0) return null;
    for (digits) |c| if (c < '0' or c > '9') return null;
    return std.fmt.parseInt(u64, digits, 10) catch null;
}
pub fn isInCi(env: Environment) bool {
    for ([_][]const u8{ "CI", "CODEBUILD_BUILD_ID", "GITLAB_CI", "HEROKU_TEST_RUN_ID", "TEAMCITY_VERSION", "bamboo.buildKey" }) |key| {
        if (env.get(env.context, key) != null) return true;
    }
    for ([_][]const u8{ "TF_BUILD", "BUILDKITE", "CIRCLECI", "CIRRUS_CI", "GITHUB_ACTIONS" }) |key| {
        if (env.get(env.context, key)) |s| if (std.mem.eql(u8, s, "true")) return true;
    }
    return false;
}
pub fn inAntithesis(env: Environment) bool {
    return builtin.os.tag != .windows and env.get(env.context, "ANTITHESIS_OUTPUT_DIR") != null;
}

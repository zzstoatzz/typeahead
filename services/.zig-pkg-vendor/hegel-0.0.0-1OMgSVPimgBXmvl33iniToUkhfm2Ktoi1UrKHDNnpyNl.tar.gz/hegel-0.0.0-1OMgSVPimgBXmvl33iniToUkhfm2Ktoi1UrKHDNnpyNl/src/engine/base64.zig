// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

pub fn encode(allocator: std.mem.Allocator, data: []const u8) ![]u8 {
    const len = std.math.mul(usize, std.math.divCeil(usize, data.len, 3) catch unreachable, 4) catch return error.OutOfMemory;
    const result = try allocator.alloc(u8, len);
    var from: usize = 0;
    var to: usize = 0;
    while (from < data.len) : (from += 3) {
        const chunk = data[from..@min(from + 3, data.len)];
        const n = (@as(u32, chunk[0]) << 16) | (@as(u32, if (chunk.len > 1) chunk[1] else 0) << 8) | @as(u32, if (chunk.len > 2) chunk[2] else 0);
        result[to] = alphabet[(n >> 18) & 63];
        result[to + 1] = alphabet[(n >> 12) & 63];
        result[to + 2] = if (chunk.len > 1) alphabet[(n >> 6) & 63] else '=';
        result[to + 3] = if (chunk.len > 2) alphabet[n & 63] else '=';
        to += 4;
    }
    return result;
}

fn value(c: u8) ?u8 {
    return switch (c) {
        'A'...'Z' => c - 'A',
        'a'...'z' => c - 'a' + 26,
        '0'...'9' => c - '0' + 52,
        '+' => 62,
        '/' => 63,
        else => null,
    };
}

pub fn decode(allocator: std.mem.Allocator, data: []const u8) !?[]u8 {
    if (data.len % 4 != 0) return null;
    var result: std.ArrayList(u8) = .empty;
    defer result.deinit(allocator);
    try result.ensureTotalCapacity(allocator, data.len / 4 * 3);
    var i: usize = 0;
    while (i < data.len) : (i += 4) {
        const chunk = data[i..][0..4];
        const c0 = value(chunk[0]) orelse return null;
        const c1 = value(chunk[1]) orelse return null;
        const pad2 = chunk[2] == '=';
        const pad3 = chunk[3] == '=';
        if ((pad2 or pad3) and i + 4 != data.len) return null;
        if (pad2 and !pad3) return null;
        const c2: u8 = if (pad2) 0 else value(chunk[2]) orelse return null;
        const c3: u8 = if (pad3) 0 else value(chunk[3]) orelse return null;
        const n = (@as(u32, c0) << 18) | (@as(u32, c1) << 12) | (@as(u32, c2) << 6) | c3;
        result.appendAssumeCapacity(@truncate(n >> 16));
        if (!pad2) result.appendAssumeCapacity(@truncate(n >> 8));
        if (!pad3) result.appendAssumeCapacity(@truncate(n));
    }
    return try result.toOwnedSlice(allocator);
}

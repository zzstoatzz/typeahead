// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
const data = @embedFile("unicode/rust_char_data.tsv");
pub const unicode_version = [3]u8{ 17, 0, 0 };
const Mapping = struct { cp: u32, lower: u32, upper: u32 };
const Run = struct { start: u32, end: u32, flags: u8 };
fn count(comptime tag: u8) usize {
    @setEvalBranchQuota(3000000);
    var lines = std.mem.splitScalar(u8, data, '\n');
    var n: usize = 0;
    while (lines.next()) |line| if (line.len > 0 and line[0] == tag) {
        n += 1;
    };
    return n;
}
const Tables = struct { mapping: [count('M')]Mapping, ranges: [count('R')]Run };
const tables = blk: {
    @setEvalBranchQuota(3000000);
    var result: Tables = undefined;
    var m: usize = 0;
    var r: usize = 0;
    var lines = std.mem.splitScalar(u8, data, '\n');
    while (lines.next()) |line| {
        if (line.len == 0 or line[0] == 'V') continue;
        var parts = std.mem.tokenizeScalar(u8, line, ' ');
        const tag = parts.next().?[0];
        const a = std.fmt.parseInt(u32, parts.next().?, 16) catch unreachable;
        const b = std.fmt.parseInt(u32, parts.next().?, 16) catch unreachable;
        const c = std.fmt.parseInt(u32, parts.next().?, if (tag == 'M') 16 else 10) catch unreachable;
        if (tag == 'M') {
            result.mapping[m] = .{ .cp = a, .lower = b, .upper = c };
            m += 1;
        } else {
            result.ranges[r] = .{ .start = a, .end = b, .flags = @intCast(c) };
            r += 1;
        }
    }
    break :blk result;
};
fn mapping(cp: u32) ?Mapping {
    var lo: usize = 0;
    var hi: usize = tables.mapping.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (tables.mapping[mid].cp < cp) lo = mid + 1 else hi = mid;
    }
    return if (lo < tables.mapping.len and tables.mapping[lo].cp == cp) tables.mapping[lo] else null;
}
pub fn lower(cp: u32) u32 {
    return if (mapping(cp)) |value| value.lower else cp;
}
pub fn upper(cp: u32) u32 {
    return if (mapping(cp)) |value| value.upper else cp;
}
fn flags(cp: u32) u8 {
    var lo: usize = 0;
    var hi: usize = tables.ranges.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (tables.ranges[mid].end < cp) lo = mid + 1 else hi = mid;
    }
    return if (lo < tables.ranges.len) tables.ranges[lo].flags else 0;
}
pub fn isAlphabetic(cp: u32) bool {
    return flags(cp) & 1 != 0;
}
pub fn isAlphanumeric(cp: u32) bool {
    return flags(cp) & 2 != 0;
}
pub fn isWhitespace(cp: u32) bool {
    return flags(cp) & 4 != 0;
}
test "Rust Unicode character semantics" {
    try std.testing.expectEqual(@as(u32, 'i'), lower(0x130));
    try std.testing.expectEqual(@as(u32, 'S'), upper(0xdf));
    try std.testing.expect(isAlphabetic(0x345));
    try std.testing.expect(isAlphanumeric(0xb2));
    try std.testing.expect(!isAlphabetic(0xb2));
}

pub const mappings = tables.mapping;

pub const MappingResult = struct {
    values: [3]u32,
    len: u8,
    pub fn slice(self: *const MappingResult) []const u32 {
        return self.values[0..self.len];
    }
};
const Expansion = struct { cp: u32, upper: bool, mapping: MappingResult };
const expansion_data = @embedFile("unicode/rust_char_expansions.tsv");
const expansions = blk: {
    @setEvalBranchQuota(100000);
    var result: [std.mem.count(u8, expansion_data, "\n")]Expansion = undefined;
    var lines = std.mem.tokenizeScalar(u8, expansion_data, '\n');
    var i: usize = 0;
    while (lines.next()) |line| {
        var parts = std.mem.tokenizeScalar(u8, line, ' ');
        const upper_case = parts.next().?[0] == 'U';
        const cp = std.fmt.parseInt(u32, parts.next().?, 16) catch unreachable;
        var value: MappingResult = .{ .values = @splat(0), .len = 0 };
        while (parts.next()) |part| {
            value.values[value.len] = std.fmt.parseInt(u32, part, 16) catch unreachable;
            value.len += 1;
        }
        result[i] = .{ .cp = cp, .upper = upper_case, .mapping = value };
        i += 1;
    }
    break :blk result;
};
pub fn lowerMapping(cp: u32) MappingResult {
    for (expansions) |entry| if (entry.cp == cp and !entry.upper) return entry.mapping;
    return .{ .values = .{ lower(cp), 0, 0 }, .len = 1 };
}
pub fn upperMapping(cp: u32) MappingResult {
    for (expansions) |entry| if (entry.cp == cp and entry.upper) return entry.mapping;
    return .{ .values = .{ upper(cp), 0, 0 }, .len = 1 };
}
test "case mappings retain all Unicode expansion codepoints" {
    const l = lowerMapping(0x130);
    try std.testing.expectEqualSlices(u32, &.{ 0x69, 0x307 }, l.slice());
    const u = upperMapping(0xdf);
    try std.testing.expectEqualSlices(u32, &.{ 'S', 'S' }, u.slice());
}

pub fn needsDebugEscape(cp: u32) bool {
    return flags(cp) & 8 != 0;
}

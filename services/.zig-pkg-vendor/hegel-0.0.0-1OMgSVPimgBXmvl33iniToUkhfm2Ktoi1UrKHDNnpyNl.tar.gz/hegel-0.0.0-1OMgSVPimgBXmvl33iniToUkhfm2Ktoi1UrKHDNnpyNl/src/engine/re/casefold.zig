// SPDX-License-Identifier: MIT AND MPL-2.0 AND Python-2.0 AND LicenseRef-CNRI-Python-1.6
// See LICENSES/Python-SRE-NOTICE.txt and docs/native-port-licensing.md.
const std = @import("std");
const chars = @import("../unicode_char.zig");
const c = @import("constants.zig");
pub fn extraCases(cp: u32) []const u32 {
    return switch (cp) {
        0x0069 => &.{0x0131},
        0x0073 => &.{0x017f},
        0x00b5 => &.{0x03bc},
        0x0131 => &.{0x0069},
        0x017f => &.{0x0073},
        0x0345 => &.{ 0x03b9, 0x1fbe },
        0x0390 => &.{0x1fd3},
        0x03b0 => &.{0x1fe3},
        0x03b2 => &.{0x03d0},
        0x03b5 => &.{0x03f5},
        0x03b8 => &.{0x03d1},
        0x03b9 => &.{ 0x0345, 0x1fbe },
        0x03ba => &.{0x03f0},
        0x03bc => &.{0x00b5},
        0x03c0 => &.{0x03d6},
        0x03c1 => &.{0x03f1},
        0x03c2 => &.{0x03c3},
        0x03c3 => &.{0x03c2},
        0x03c6 => &.{0x03d5},
        0x03d0 => &.{0x03b2},
        0x03d1 => &.{0x03b8},
        0x03d5 => &.{0x03c6},
        0x03d6 => &.{0x03c0},
        0x03f0 => &.{0x03ba},
        0x03f1 => &.{0x03c1},
        0x03f5 => &.{0x03b5},
        0x0432 => &.{0x1c80},
        0x0434 => &.{0x1c81},
        0x043e => &.{0x1c82},
        0x0441 => &.{0x1c83},
        0x0442 => &.{ 0x1c84, 0x1c85 },
        0x044a => &.{0x1c86},
        0x0463 => &.{0x1c87},
        0x1c80 => &.{0x0432},
        0x1c81 => &.{0x0434},
        0x1c82 => &.{0x043e},
        0x1c83 => &.{0x0441},
        0x1c84 => &.{ 0x0442, 0x1c85 },
        0x1c85 => &.{ 0x0442, 0x1c84 },
        0x1c86 => &.{0x044a},
        0x1c87 => &.{0x0463},
        0x1c88 => &.{0xa64b},
        0x1e61 => &.{0x1e9b},
        0x1e9b => &.{0x1e61},
        0x1fbe => &.{ 0x0345, 0x03b9 },
        0x1fd3 => &.{0x0390},
        0x1fe3 => &.{0x03b0},
        0xa64b => &.{0x1c88},
        0xfb05 => &.{0xfb06},
        0xfb06 => &.{0xfb05},
        else => &.{},
    };
}
pub fn lower(cp: u32, flags: u32) u32 {
    return if (flags & c.SRE_FLAG_ASCII != 0) if (cp >= 'A' and cp <= 'Z') cp + 32 else cp else chars.lower(cp);
}
pub fn isCased(cp: u32, flags: u32) bool {
    return if (flags & c.SRE_FLAG_ASCII != 0) (cp >= 'A' and cp <= 'Z') or (cp >= 'a' and cp <= 'z') else lower(cp, flags) != cp or chars.upper(cp) != cp;
}
const ascii_upper = blk: {
    var result: [26]u32 = undefined;
    for (&result, 0..) |*cp, i| cp.* = 'A' + i;
    break :blk result;
};
fn upperCount() usize {
    @setEvalBranchQuota(3000000);
    var n: usize = 0;
    for (chars.mappings) |m| if (m.lower != m.cp) {
        n += 1;
    };
    return n;
}
const upper_table = blk: {
    @setEvalBranchQuota(3000000);
    const Pair = struct { lower: u32, upper: u32 };
    var pairs: [upperCount()]Pair = undefined;
    var i: usize = 0;
    for (chars.mappings) |m| if (m.lower != m.cp) {
        pairs[i] = .{ .lower = m.lower, .upper = m.cp };
        i += 1;
    };
    std.mem.sort(Pair, &pairs, {}, struct {
        fn less(_: void, a: Pair, b: Pair) bool {
            return a.lower < b.lower or (a.lower == b.lower and a.upper < b.upper);
        }
    }.less);
    var lows: [pairs.len]u32 = undefined;
    var ups = lows;
    for (pairs, 0..) |p, j| {
        lows[j] = p.lower;
        ups[j] = p.upper;
    }
    break :blk .{ .lower = lows, .upper = ups };
};
const upper_keys: [upperCount()]u32 = upper_table.lower;
const upper_values: [upperCount()]u32 = upper_table.upper;
pub fn uppersOf(cp: u32, flags: u32) []const u32 {
    if (flags & c.SRE_FLAG_ASCII != 0) return if (cp >= 'a' and cp <= 'z') ascii_upper[cp - 'a' ..][0..1] else &.{};
    var lo: usize = 0;
    var hi: usize = upper_keys.len;
    while (lo < hi) {
        const mid = lo + (hi - lo) / 2;
        if (upper_keys[mid] < cp) lo = mid + 1 else hi = mid;
    }
    var end = lo;
    while (end < upper_keys.len and upper_keys[end] == cp) end += 1;
    return upper_values[lo..end];
}
pub fn literalMatches(want: u32, got: u32, flags: u32) bool {
    if (got == want) return true;
    if (flags & c.SRE_FLAG_IGNORECASE == 0 or !isCased(want, flags)) return false;
    const g = lower(got, flags);
    const l = lower(want, flags);
    if (g == l) return true;
    if (flags & c.SRE_FLAG_ASCII == 0) for (extraCases(l)) |extra| if (extra == g) return true;
    return false;
}
pub fn rangeMatches(lo: u32, hi: u32, cp: u32, flags: u32) bool {
    if (flags & c.SRE_FLAG_IGNORECASE == 0) return lo <= cp and cp <= hi;
    const l = lower(cp, flags);
    if (targetInRange(lo, hi, l, flags)) return true;
    if (flags & c.SRE_FLAG_ASCII == 0) for (extraCases(l)) |extra| if (targetInRange(lo, hi, extra, flags)) return true;
    return false;
}
fn targetInRange(lo: u32, hi: u32, target: u32, flags: u32) bool {
    if (lo <= target and target <= hi) return true;
    for (uppersOf(target, flags)) |up| if (lo <= up and up <= hi) return true;
    return false;
}
pub fn grouprefEq(a: u32, b: u32, flags: u32) bool {
    return a == b or (flags & c.SRE_FLAG_IGNORECASE != 0 and lower(a, flags) == lower(b, flags));
}
pub fn pushEquivalents(allocator: std.mem.Allocator, out: *std.ArrayList(u32), cp: u32, flags: u32) std.mem.Allocator.Error!void {
    try out.append(allocator, cp);
    if (flags & c.SRE_FLAG_IGNORECASE == 0 or !isCased(cp, flags)) return;
    const l = lower(cp, flags);
    try out.append(allocator, l);
    try out.appendSlice(allocator, uppersOf(l, flags));
    if (flags & c.SRE_FLAG_ASCII == 0) for (extraCases(l)) |extra| {
        try out.append(allocator, extra);
        try out.appendSlice(allocator, uppersOf(extra, flags));
    };
}
test "Python casefold extras and backreferences" {
    try std.testing.expect(literalMatches('s', 0x17f, c.SRE_FLAG_IGNORECASE));
    try std.testing.expect(!grouprefEq('s', 0x17f, c.SRE_FLAG_IGNORECASE));
    try std.testing.expect(rangeMatches('A', 'Z', 0x212a, c.SRE_FLAG_IGNORECASE));
    try std.testing.expect(!literalMatches('s', 0x17f, c.SRE_FLAG_IGNORECASE | c.SRE_FLAG_ASCII));
}

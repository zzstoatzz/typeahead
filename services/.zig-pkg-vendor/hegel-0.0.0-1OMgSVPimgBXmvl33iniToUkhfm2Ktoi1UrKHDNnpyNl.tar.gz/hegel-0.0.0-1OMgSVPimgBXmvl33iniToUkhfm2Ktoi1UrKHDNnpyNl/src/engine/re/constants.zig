// SPDX-License-Identifier: MIT AND MPL-2.0 AND Python-2.0 AND LicenseRef-CNRI-Python-1.6
// See LICENSES/Python-SRE-NOTICE.txt and docs/native-port-licensing.md.
pub const MAXREPEAT: u32 = 0xffffffff;
pub const MAXGROUPS: u32 = 500;
pub const MAX_NESTING: u32 = 100;
pub const SRE_FLAG_IGNORECASE: u32 = 2;
pub const SRE_FLAG_LOCALE: u32 = 4;
pub const SRE_FLAG_MULTILINE: u32 = 8;
pub const SRE_FLAG_DOTALL: u32 = 16;
pub const SRE_FLAG_UNICODE: u32 = 32;
pub const SRE_FLAG_VERBOSE: u32 = 64;
pub const SRE_FLAG_ASCII: u32 = 256;
pub const TYPE_FLAGS: u32 = SRE_FLAG_ASCII | SRE_FLAG_LOCALE | SRE_FLAG_UNICODE;
pub const AtCode = enum {
    Beginning,
    BeginningString,
    Boundary,
    NonBoundary,
    End,
    EndString,
};
pub const ChCode = enum {
    Digit,
    NotDigit,
    Space,
    NotSpace,
    Word,
    NotWord,
};

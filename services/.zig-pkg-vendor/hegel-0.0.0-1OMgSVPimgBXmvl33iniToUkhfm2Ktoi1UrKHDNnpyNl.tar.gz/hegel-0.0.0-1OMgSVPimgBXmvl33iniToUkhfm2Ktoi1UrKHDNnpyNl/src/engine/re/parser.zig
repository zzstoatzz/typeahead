// SPDX-License-Identifier: MIT AND MPL-2.0 AND Python-2.0 AND LicenseRef-CNRI-Python-1.6
// See LICENSES/Python-SRE-NOTICE.txt and docs/native-port-licensing.md.
const std = @import("std");
const chars = @import("../unicode_char.zig");
const c = @import("constants.zig");
const Allocator = std.mem.Allocator;
pub const AtCode = c.AtCode;
pub const ChCode = c.ChCode;
pub const SetItem = union(enum) { Literal: u32, Negate, Range: struct { lo: u32, hi: u32 }, Category: ChCode };
pub const OpCode = union(enum) {
    Literal: u32,
    NotLiteral: u32,
    Any,
    At: AtCode,
    In: []const SetItem,
    Branch: []const SubPattern,
    Subpattern: struct { group: ?u32, add_flags: u32, del_flags: u32, p: SubPattern },
    GroupRef: u32,
    GroupRefExists: struct { cond_group: u32, yes: SubPattern, no: ?SubPattern },
    Assert: struct { direction: i32, p: SubPattern },
    AssertNot: struct { direction: i32, p: SubPattern },
    AtomicGroup: SubPattern,
    MaxRepeat: Repeat,
    MinRepeat: Repeat,
    PossessiveRepeat: Repeat,
    Failure,
    pub const Repeat = struct { min: u32, max: u32, item: SubPattern };
};
pub const SubPattern = struct {
    data: std.ArrayList(OpCode) = .empty,
    pub fn isEmpty(self: SubPattern) bool {
        return self.data.items.len == 0;
    }
    pub fn len(self: SubPattern) usize {
        return self.data.items.len;
    }
    pub fn push(self: *SubPattern, allocator: Allocator, op: OpCode) Allocator.Error!void {
        try self.data.append(allocator, op);
    }
};
pub const ParsedPattern = struct { pattern: SubPattern, flags: u32 };
pub const ParseError = struct { msg: []const u8, pos: usize };
pub const Result = struct {
    arena: std.heap.ArenaAllocator,
    parsed: ?ParsedPattern = null,
    failure: ?ParseError = null,
    pub fn deinit(self: *Result) void {
        self.arena.deinit();
        self.* = undefined;
    }
};
const Error = Allocator.Error || error{InvalidPattern};
const DIGITS = "0123456789";
const OCTDIGITS = "01234567";
const HEXDIGITS = "0123456789abcdefABCDEF";
const ASCIILETTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const WHITESPACE = " \t\n\r\x0b\x0c";
fn contains(set: []const u8, cp: u32) bool {
    return cp < 128 and std.mem.indexOfScalar(u8, set, @intCast(cp)) != null;
}
fn tokenEql(token: ?[]const u32, text: []const u8) bool {
    const t = token orelse return false;
    if (t.len != text.len) return false;
    for (t, text) |a, b| if (a != b) return false;
    return true;
}
fn validScalar(cp: u32) bool {
    return cp <= 0x10ffff and !(cp >= 0xd800 and cp <= 0xdfff);
}
fn isPythonIdentifier(name: []const u32) bool {
    if (name.len == 0 or !(name[0] == '_' or chars.isAlphabetic(name[0]))) return false;
    for (name[1..]) |cp| if (cp != '_' and !chars.isAlphanumeric(cp)) return false;
    return true;
}
const State = struct { flags: u32 = 0, groupdict: std.StringHashMapUnmanaged(u32) = .empty, groupwidths: std.ArrayList(bool) = .empty, lookbehindgroups: ?u32 = null, grouprefpos: std.AutoHashMapUnmanaged(u32, usize) = .empty };
const Parser = struct {
    allocator: Allocator,
    characters: []const u32,
    index: usize = 0,
    next: ?[]const u32 = null,
    state: State = .{},
    failure: ?ParseError = null,
    fn init(allocator: Allocator, pattern: []const u8) Error!Parser {
        const view = std.unicode.Utf8View.init(pattern) catch return error.InvalidPattern;
        var it = view.iterator();
        var points: std.ArrayList(u32) = .empty;
        while (it.nextCodepoint()) |cp| try points.append(allocator, cp);
        var p: Parser = .{ .allocator = allocator, .characters = points.items };
        try p.state.groupwidths.append(allocator, false);
        return p;
    }
    fn fail(self: *Parser, comptime format: []const u8, args: anytype, offset: usize) Error {
        self.failure = .{ .msg = std.fmt.allocPrint(self.allocator, format, args) catch return error.OutOfMemory, .pos = self.tell() -| offset };
        return error.InvalidPattern;
    }
    fn failAt(self: *Parser, comptime format: []const u8, args: anytype, pos: usize) Error {
        self.failure = .{ .msg = std.fmt.allocPrint(self.allocator, format, args) catch return error.OutOfMemory, .pos = pos };
        return error.InvalidPattern;
    }
    fn advance(self: *Parser) Error!void {
        if (self.index >= self.characters.len) {
            self.next = null;
            return;
        }
        const start = self.index;
        self.index += 1;
        if (self.characters[start] == '\\') {
            if (self.index >= self.characters.len) return self.failAt("bad escape (end of pattern)", .{}, self.characters.len -| 1);
            self.index += 1;
        }
        self.next = self.characters[start..self.index];
    }
    fn peek(self: *const Parser) ?u32 {
        const token = self.next orelse return null;
        return token[0];
    }
    fn takeMatch(self: *Parser, cp: u32) Error!bool {
        if (self.next) |t| if (t.len == 1 and t[0] == cp) {
            try self.advance();
            return true;
        };
        return false;
    }
    fn get(self: *Parser) Error!?[]const u32 {
        const token = self.next;
        try self.advance();
        return token;
    }
    fn getWhile(self: *Parser, n: usize, set: []const u8) Error![]const u32 {
        var result: std.ArrayList(u32) = .empty;
        for (0..n) |_| {
            const token = self.next orelse break;
            if (token.len != 1 or !contains(set, token[0])) break;
            try result.append(self.allocator, token[0]);
            try self.advance();
        }
        return result.items;
    }
    fn getUntil(self: *Parser, terminator: u32, name: []const u8) Error![]const u32 {
        var result: std.ArrayList(u32) = .empty;
        while (true) {
            const token = try self.get();
            if (token) |t| {
                if (t.len == 1 and t[0] == terminator) {
                    if (result.items.len == 0) return self.fail("missing {s}", .{name}, 1);
                    return result.items;
                }
                try result.appendSlice(self.allocator, t);
            } else {
                if (result.items.len == 0) return self.fail("missing {s}", .{name}, 0);
                return self.fail("missing {u}, unterminated name", .{@as(u21, @intCast(terminator))}, result.items.len);
            }
        }
    }
    fn tell(self: *const Parser) usize {
        return self.index - (if (self.next) |t| t.len else 0);
    }
    fn seek(self: *Parser, index: usize) Error!void {
        self.index = index;
        try self.advance();
    }
    fn string(self: *Parser, points: []const u32) Allocator.Error![]const u8 {
        var out: std.ArrayList(u8) = .empty;
        for (points) |cp| {
            var buffer: [4]u8 = undefined;
            const n = std.unicode.utf8Encode(@intCast(cp), &buffer) catch unreachable;
            try out.appendSlice(self.allocator, buffer[0..n]);
        }
        return out.items;
    }
    fn checkGroupName(self: *Parser, name: []const u32, offset: usize) Error!void {
        if (!isPythonIdentifier(name)) return self.fail("bad character in group name '{s}'", .{try self.string(name)}, name.len + offset);
    }
    fn groups(self: *const Parser) u32 {
        return @intCast(self.state.groupwidths.items.len);
    }
    fn openGroup(self: *Parser, name: ?[]const u32) Error!u32 {
        const gid = self.groups();
        try self.state.groupwidths.append(self.allocator, false);
        if (self.groups() > c.MAXGROUPS) return self.failAt("too many groups", .{}, 0);
        if (name) |n| {
            const text = try self.string(n);
            if (self.state.groupdict.get(text)) |old| return self.failAt("redefinition of group name '{s}' as group {}; was group {}", .{ text, gid, old }, 0);
            try self.state.groupdict.put(self.allocator, text, gid);
        }
        return gid;
    }
    fn closeGroup(self: *Parser, gid: u32) void {
        if (gid < self.state.groupwidths.items.len) self.state.groupwidths.items[gid] = true;
    }
    fn checkGroup(self: *const Parser, gid: u32) bool {
        return gid < self.state.groupwidths.items.len and self.state.groupwidths.items[gid];
    }
    fn checkLookbehindGroup(self: *Parser, gid: u32) Error!void {
        if (self.state.lookbehindgroups) |lb| {
            if (!self.checkGroup(gid)) return self.fail("cannot refer to an open group", .{}, 0);
            if (gid >= lb) return self.fail("cannot refer to group defined in the same lookbehind subpattern", .{}, 0);
        }
    }
    fn numeric(self: *Parser, escape: []const u32, digits: []const u32, radix: u8) Error!u32 {
        return std.fmt.parseInt(u32, try self.string(digits), radix) catch return self.fail("bad escape {s}", .{try self.string(escape)}, escape.len);
    }
    fn appendToken(self: *Parser, escape: []const u32, more: []const u32) Allocator.Error![]const u32 {
        const result = try self.allocator.alloc(u32, escape.len + more.len);
        @memcpy(result[0..escape.len], escape);
        @memcpy(result[escape.len..], more);
        return result;
    }
    fn classEscape(self: *Parser, token: []const u32) Error!SetItem {
        const ch = token[1];
        if (escapeLiteral(ch)) |cp| return .{ .Literal = cp };
        if (category(ch)) |cat| switch (cat) {
            .In => |code| return .{ .Category = code },
            else => {},
        };
        var escape = token;
        switch (ch) {
            'x', 'u', 'U' => {
                const n: usize = switch (ch) {
                    'x' => 2,
                    'u' => 4,
                    else => 8,
                };
                escape = try self.appendToken(escape, try self.getWhile(n, HEXDIGITS));
                if (escape.len != n + 2) return self.fail("incomplete escape {s}", .{try self.string(escape)}, escape.len);
                const cp = try self.numeric(escape, escape[2..], 16);
                if (ch != 'x' and !validScalar(cp)) return if (ch == 'u') self.fail("surrogate codepoint {s} cannot appear in a string", .{try self.string(escape)}, escape.len) else self.fail("bad escape {s}", .{try self.string(escape)}, escape.len);
                return .{ .Literal = cp };
            },
            'N' => return self.fail("\\N{{...}} named unicode escapes not yet supported in native regex parser", .{}, 0),
            '0'...'7' => {
                escape = try self.appendToken(escape, try self.getWhile(2, OCTDIGITS));
                const n = try self.numeric(escape, escape[1..], 8);
                if (n > 0o377) return self.fail("octal escape value {s} outside of range 0-0o377", .{try self.string(escape)}, escape.len);
                return .{ .Literal = n };
            },
            else => {
                if (contains(DIGITS, ch) or contains(ASCIILETTERS, ch)) return self.fail("bad escape {s}", .{try self.string(escape)}, escape.len);
                return .{ .Literal = ch };
            },
        }
    }
    fn escapeCode(self: *Parser, token: []const u32) Error!OpCode {
        const ch = token[1];
        if (category(ch)) |cat| return switch (cat) {
            .At => |at| .{ .At = at },
            .In => |code| .{ .In = try self.allocator.dupe(SetItem, &.{.{ .Category = code }}) },
        };
        if (escapeLiteral(ch)) |cp| return .{ .Literal = cp };
        var escape = token;
        switch (ch) {
            'x', 'u', 'U', 'N' => {
                const item = try self.classEscape(escape);
                return .{ .Literal = item.Literal };
            },
            '0' => {
                escape = try self.appendToken(escape, try self.getWhile(2, OCTDIGITS));
                return .{ .Literal = try self.numeric(escape, escape[1..], 8) };
            },
            '1'...'9' => {
                if (self.peek()) |next| if (contains(DIGITS, next)) {
                    escape = try self.appendToken(escape, (try self.get()).?);
                    if (contains(OCTDIGITS, escape[1]) and contains(OCTDIGITS, escape[2]) and (if (self.peek()) |x| contains(OCTDIGITS, x) else false)) {
                        escape = try self.appendToken(escape, (try self.get()).?);
                        const n = try self.numeric(escape, escape[1..], 8);
                        if (n > 0o377) return self.fail("octal escape value {s} outside of range 0-0o377", .{try self.string(escape)}, escape.len);
                        return .{ .Literal = n };
                    }
                };
                const gid = try self.numeric(escape, escape[1..], 10);
                if (gid < self.groups()) {
                    if (!self.checkGroup(gid)) return self.fail("cannot refer to an open group", .{}, escape.len);
                    try self.checkLookbehindGroup(gid);
                    return .{ .GroupRef = gid };
                }
                return self.fail("invalid group reference {}", .{gid}, escape.len - 1);
            },
            else => {
                if (contains(ASCIILETTERS, ch)) return self.fail("bad escape {s}", .{try self.string(escape)}, escape.len);
                return .{ .Literal = ch };
            },
        }
    }
    fn parseSub(self: *Parser, verbose_initial: bool, nested: u32) Error!SubPattern {
        var verbose = verbose_initial;
        var items: std.ArrayList(SubPattern) = .empty;
        while (true) {
            const first = nested == 0 and items.items.len == 0;
            try items.append(self.allocator, try self.parse(verbose, nested + 1, first));
            if (!try self.takeMatch('|')) break;
            if (nested == 0) verbose = self.state.flags & c.SRE_FLAG_VERBOSE != 0;
        }
        if (items.items.len == 1) return items.items[0];
        var result: SubPattern = .{};
        while (true) {
            var prefix: ?OpCode = null;
            var shared = true;
            for (items.items) |item| {
                if (item.isEmpty()) {
                    shared = false;
                    break;
                }
                if (prefix) |p| {
                    if (!opEql(item.data.items[0], p)) {
                        shared = false;
                        break;
                    }
                } else prefix = item.data.items[0];
            }
            if (!shared or prefix == null) break;
            for (items.items) |*item| {
                _ = item.data.orderedRemove(0);
            }
            try result.push(self.allocator, prefix.?);
        }
        var set: std.ArrayList(SetItem) = .empty;
        var flatten = true;
        for (items.items) |item| {
            if (item.len() != 1) {
                flatten = false;
                break;
            }
            switch (item.data.items[0]) {
                .Literal => |cp| try set.append(self.allocator, .{ .Literal = cp }),
                .In => |inner| {
                    if (inner.len > 0 and inner[0] == .Negate) {
                        flatten = false;
                        break;
                    }
                    try set.appendSlice(self.allocator, inner);
                },
                else => {
                    flatten = false;
                    break;
                },
            }
        }
        if (flatten) try result.push(self.allocator, .{ .In = try self.uniqSet(set.items) }) else try result.push(self.allocator, .{ .Branch = items.items });
        return result;
    }
    fn uniqSet(self: *Parser, items: []const SetItem) Error![]const SetItem {
        var result: std.ArrayList(SetItem) = .empty;
        for (items) |item| {
            const seen = for (result.items) |old| {
                if (setEql(old, item)) break true;
            } else false;
            if (!seen) try result.append(self.allocator, item);
        }
        return result.items;
    }
    fn parseClass(self: *Parser) Error!OpCode {
        const here = self.tell() -| 1;
        var set: std.ArrayList(SetItem) = .empty;
        const negate = try self.takeMatch('^');
        while (true) {
            const cur = (try self.get()) orelse return self.fail("unterminated character set", .{}, self.tell() -| here);
            if (tokenEql(cur, "]") and set.items.len > 0) break;
            const code1: SetItem = if (cur[0] == '\\') try self.classEscape(cur) else .{ .Literal = cur[0] };
            if (try self.takeMatch('-')) {
                const that = (try self.get()) orelse return self.fail("unterminated character set", .{}, self.tell() -| here);
                if (tokenEql(that, "]")) {
                    try set.append(self.allocator, code1);
                    try set.append(self.allocator, .{ .Literal = '-' });
                    break;
                }
                const code2: SetItem = if (that[0] == '\\') try self.classEscape(that) else .{ .Literal = that[0] };
                if (code1 != .Literal or code2 != .Literal or code2.Literal < code1.Literal) return self.fail("bad character range {s}-{s}", .{ try self.string(cur), try self.string(that) }, cur.len + 1 + that.len);
                try set.append(self.allocator, .{ .Range = .{ .lo = code1.Literal, .hi = code2.Literal } });
            } else try set.append(self.allocator, code1);
        }
        const unique = try self.uniqSet(set.items);
        if (unique.len == 1 and unique[0] == .Literal) return if (negate) .{ .NotLiteral = unique[0].Literal } else .{ .Literal = unique[0].Literal };
        if (!negate) return .{ .In = unique };
        const final = try self.allocator.alloc(SetItem, unique.len + 1);
        final[0] = .Negate;
        @memcpy(final[1..], unique);
        return .{ .In = final };
    }
    fn parseRepeat(self: *Parser, pattern: *SubPattern, ch: u32) Error!void {
        const here = self.tell();
        var min: u32 = 0;
        var max: u32 = c.MAXREPEAT;
        switch (ch) {
            '?' => max = 1,
            '*' => {},
            '+' => min = 1,
            '{' => {
                if (self.peek() == '}') {
                    try pattern.push(self.allocator, .{ .Literal = ch });
                    return;
                }
                const lo = try self.getWhile(std.math.maxInt(usize), DIGITS);
                const hi = if (try self.takeMatch(',')) try self.getWhile(std.math.maxInt(usize), DIGITS) else lo;
                if (!try self.takeMatch('}')) {
                    try pattern.push(self.allocator, .{ .Literal = ch });
                    try self.seek(here);
                    return;
                }
                if (lo.len > 0) {
                    const n = std.fmt.parseInt(u64, try self.string(lo), 10) catch return self.fail("the repetition number is too large", .{}, 0);
                    if (n >= c.MAXREPEAT) return self.fail("the repetition number is too large", .{}, 0);
                    min = @intCast(n);
                }
                if (hi.len > 0) {
                    const n = std.fmt.parseInt(u64, try self.string(hi), 10) catch return self.fail("the repetition number is too large", .{}, 0);
                    if (n >= c.MAXREPEAT) return self.fail("the repetition number is too large", .{}, 0);
                    max = @intCast(n);
                    if (max < min) return self.fail("min repeat greater than max repeat", .{}, self.tell() -| here);
                }
            },
            else => unreachable,
        }
        if (pattern.isEmpty() or pattern.data.items[pattern.len() - 1] == .At) return self.fail("nothing to repeat", .{}, (self.tell() -| here) + 1);
        const op = pattern.data.items[pattern.len() - 1];
        if (isRepeatOpcode(op)) return self.fail("multiple repeat", .{}, (self.tell() -| here) + 1);
        var inner: SubPattern = .{};
        if (op == .Subpattern and op.Subpattern.group == null and op.Subpattern.add_flags == 0 and op.Subpattern.del_flags == 0) inner = op.Subpattern.p else try inner.push(self.allocator, op);
        _ = pattern.data.pop();
        const repeat: OpCode.Repeat = .{ .min = min, .max = max, .item = inner };
        const result: OpCode = if (try self.takeMatch('?')) .{ .MinRepeat = repeat } else if (try self.takeMatch('+')) .{ .PossessiveRepeat = repeat } else .{ .MaxRepeat = repeat };
        try pattern.push(self.allocator, result);
    }
    fn parse(self: *Parser, verbose_initial: bool, nested: u32, first: bool) Error!SubPattern {
        if (nested > c.MAX_NESTING) return self.fail("regex nesting too deep", .{}, 0);
        var verbose = verbose_initial;
        var result: SubPattern = .{};
        while (self.next) |token| {
            if (tokenEql(token, "|") or tokenEql(token, ")")) break;
            try self.advance();
            const ch = token[0];
            if (verbose and token.len == 1) {
                if (contains(WHITESPACE, ch)) continue;
                if (ch == '#') {
                    while (try self.get()) |comment| {
                        if (tokenEql(comment, "\n")) break;
                    }
                    continue;
                }
            }
            if (ch == '\\') {
                try result.push(self.allocator, try self.escapeCode(token));
                continue;
            }
            if (!contains(".\\[{()*+?^$|", ch)) {
                try result.push(self.allocator, .{ .Literal = ch });
                continue;
            }
            switch (ch) {
                '[' => try result.push(self.allocator, try self.parseClass()),
                '?', '*', '+', '{' => try self.parseRepeat(&result, ch),
                '.' => try result.push(self.allocator, .Any),
                '(' => {
                    if (try self.parseGroup(&verbose, nested, first, result.isEmpty())) |group| try result.push(self.allocator, group);
                },
                '^' => try result.push(self.allocator, .{ .At = .Beginning }),
                '$' => try result.push(self.allocator, .{ .At = .End }),
                else => unreachable,
            }
        }
        var i = result.len();
        while (i > 0) {
            i -= 1;
            const op = result.data.items[i];
            if (op == .Subpattern and op.Subpattern.group == null and op.Subpattern.add_flags == 0 and op.Subpattern.del_flags == 0) {
                _ = result.data.orderedRemove(i);
                try result.data.insertSlice(self.allocator, i, op.Subpattern.p.data.items);
                i += op.Subpattern.p.len();
            }
        }
        return result;
    }
    fn parseGroup(self: *Parser, verbose: *bool, nested: u32, first: bool, empty: bool) Error!?OpCode {
        const start = self.tell() -| 1;
        var capture = true;
        var atomic = false;
        var name: ?[]const u32 = null;
        var add_flags: u32 = 0;
        var del_flags: u32 = 0;
        if (try self.takeMatch('?')) {
            const token = (try self.get()) orelse return self.fail("unexpected end of pattern", .{}, 0);
            const ch = if (token.len == 1) token[0] else 0;
            switch (ch) {
                'P' => {
                    if (try self.takeMatch('<')) {
                        const n = try self.getUntil('>', "group name");
                        try self.checkGroupName(n, 1);
                        name = n;
                    } else if (try self.takeMatch('=')) {
                        const n = try self.getUntil(')', "group name");
                        try self.checkGroupName(n, 1);
                        const text = try self.string(n);
                        const gid = self.state.groupdict.get(text) orelse return self.fail("unknown group name '{s}'", .{text}, n.len + 1);
                        if (!self.checkGroup(gid)) return self.fail("cannot refer to an open group", .{}, n.len + 1);
                        try self.checkLookbehindGroup(gid);
                        return .{ .GroupRef = gid };
                    } else {
                        const next = (try self.get()) orelse return self.fail("unexpected end of pattern", .{}, 0);
                        return self.fail("unknown extension ?P{s}", .{try self.string(next)}, next.len + 2);
                    }
                },
                ':' => capture = false,
                '#' => {
                    while (true) {
                        if (self.next == null) return self.fail("missing ), unterminated comment", .{}, self.tell() -| start);
                        if (tokenEql(try self.get(), ")")) break;
                    }
                    return null;
                },
                '=', '!', '<' => {
                    var direction: i32 = 1;
                    var marker = ch;
                    const saved = self.state.lookbehindgroups;
                    if (ch == '<') {
                        const next = (try self.get()) orelse return self.fail("unexpected end of pattern", .{}, 0);
                        if (!tokenEql(next, "=") and !tokenEql(next, "!")) return self.fail("unknown extension ?<{s}", .{try self.string(next)}, next.len + 2);
                        direction = -1;
                        if (self.state.lookbehindgroups == null) self.state.lookbehindgroups = self.groups();
                        marker = next[0];
                    }
                    const p = try self.parseSub(verbose.*, nested + 1);
                    if (direction < 0 and saved == null) self.state.lookbehindgroups = null;
                    if (!try self.takeMatch(')')) return self.fail("missing ), unterminated subpattern", .{}, self.tell() -| start);
                    return if (marker == '=') .{ .Assert = .{ .direction = direction, .p = p } } else if (!p.isEmpty()) .{ .AssertNot = .{ .direction = direction, .p = p } } else .Failure;
                },
                '(' => {
                    const condname = try self.getUntil(')', "group name");
                    const text = try self.string(condname);
                    var gid: u32 = undefined;
                    const digits = condname.len > 0 and for (condname) |cp| {
                        if (!contains(DIGITS, cp)) break false;
                    } else true;
                    if (!digits) {
                        try self.checkGroupName(condname, 1);
                        gid = self.state.groupdict.get(text) orelse return self.fail("unknown group name '{s}'", .{text}, condname.len + 1);
                    } else {
                        gid = std.fmt.parseInt(u32, text, 10) catch return self.fail("invalid group reference {s}", .{text}, condname.len + 1);
                        if (gid == 0) return self.fail("bad group number", .{}, condname.len + 1);
                        if (gid >= c.MAXGROUPS) return self.fail("invalid group reference {}", .{gid}, condname.len + 1);
                        const entry = try self.state.grouprefpos.getOrPut(self.allocator, gid);
                        if (!entry.found_existing) entry.value_ptr.* = self.tell() -| (condname.len + 1);
                    }
                    try self.checkLookbehindGroup(gid);
                    const yes = try self.parse(verbose.*, nested + 1, false);
                    var no: ?SubPattern = null;
                    if (try self.takeMatch('|')) {
                        no = try self.parse(verbose.*, nested + 1, false);
                        if (self.peek() == '|') return self.fail("conditional backref with more than two branches", .{}, 0);
                    }
                    if (!try self.takeMatch(')')) return self.fail("missing ), unterminated subpattern", .{}, self.tell() -| start);
                    return .{ .GroupRefExists = .{ .cond_group = gid, .yes = yes, .no = no } };
                },
                '>' => {
                    capture = false;
                    atomic = true;
                },
                else => {
                    if (flagForChar(token[0]) != null or ch == '-') {
                        const flags = try self.parseFlags(token[0]);
                        if (flags) |f| {
                            add_flags = f.add;
                            del_flags = f.del;
                            capture = false;
                        } else {
                            if (!first or !empty) return self.fail("global flags not at the start of the expression", .{}, self.tell() -| start);
                            verbose.* = self.state.flags & c.SRE_FLAG_VERBOSE != 0;
                            return null;
                        }
                    } else return self.fail("unknown extension ?{s}", .{try self.string(token)}, token.len + 1);
                },
            }
        }
        const group: ?u32 = if (capture) try self.openGroup(name) else null;
        const sub_verbose = (verbose.* or add_flags & c.SRE_FLAG_VERBOSE != 0) and del_flags & c.SRE_FLAG_VERBOSE == 0;
        const p = try self.parseSub(sub_verbose, nested + 1);
        if (!try self.takeMatch(')')) return self.fail("missing ), unterminated subpattern", .{}, self.tell() -| start);
        if (group) |gid| self.closeGroup(gid);
        return if (atomic) .{ .AtomicGroup = p } else .{ .Subpattern = .{ .group = group, .add_flags = add_flags, .del_flags = del_flags, .p = p } };
    }
    const Flags = struct { add: u32, del: u32 };
    fn parseFlags(self: *Parser, first: u32) Error!?Flags {
        var add: u32 = 0;
        var del: u32 = 0;
        var token: []const u32 = try self.allocator.dupe(u32, &.{first});
        if (first != '-') {
            while (true) {
                const ch = token[0];
                const flag = flagForChar(ch) orelse return self.fail("unknown flag", .{}, 0);
                if (tokenEql(token, "L")) return self.fail("bad inline flags: cannot use 'L' flag with a str pattern", .{}, 0);
                add |= flag;
                if (flag & c.TYPE_FLAGS != 0 and add & c.TYPE_FLAGS != flag) return self.fail("bad inline flags: flags 'a', 'u' and 'L' are incompatible", .{}, 0);
                token = (try self.get()) orelse return self.fail("missing -, : or )", .{}, 0);
                if (tokenEql(token, ")") or tokenEql(token, "-") or tokenEql(token, ":")) break;
                if (flagForChar(token[0]) == null) return self.fail("{s}", .{if (chars.isAlphabetic(token[0])) "unknown flag" else "missing -, : or )"}, token.len);
            }
        }
        if (tokenEql(token, ")")) {
            self.state.flags |= add;
            return null;
        }
        if (tokenEql(token, "-")) {
            token = (try self.get()) orelse return self.fail("missing flag", .{}, 0);
            if (flagForChar(token[0]) == null) return self.fail("{s}", .{if (chars.isAlphabetic(token[0])) "unknown flag" else "missing flag"}, token.len);
            while (true) {
                const flag = flagForChar(token[0]).?;
                if (flag & c.TYPE_FLAGS != 0) return self.fail("bad inline flags: cannot turn off flags 'a', 'u' and 'L'", .{}, 0);
                del |= flag;
                token = (try self.get()) orelse return self.fail("missing :", .{}, 0);
                if (tokenEql(token, ":")) break;
                if (flagForChar(token[0]) == null) return self.fail("{s}", .{if (chars.isAlphabetic(token[0])) "unknown flag" else "missing :"}, token.len);
            }
        }
        if (add & del != 0) return self.fail("bad inline flags: flag turned on and off", .{}, 1);
        return .{ .add = add, .del = del };
    }
    fn run(self: *Parser, flags: u32) Error!ParsedPattern {
        self.state.flags = flags;
        try self.advance();
        const pattern = try self.parseSub(flags & c.SRE_FLAG_VERBOSE != 0, 0);
        if (self.state.flags & c.SRE_FLAG_LOCALE != 0) return self.failAt("cannot use LOCALE flag with a str pattern", .{}, 0);
        if (self.state.flags & c.SRE_FLAG_ASCII == 0) self.state.flags |= c.SRE_FLAG_UNICODE else if (self.state.flags & c.SRE_FLAG_UNICODE != 0) return self.failAt("ASCII and UNICODE flags are incompatible", .{}, 0);
        if (self.next != null) return self.fail("unbalanced parenthesis", .{}, 0);
        var it = self.state.grouprefpos.iterator();
        while (it.next()) |entry| if (entry.key_ptr.* >= self.groups()) return self.failAt("invalid group reference {}", .{entry.key_ptr.*}, entry.value_ptr.*);
        return .{ .pattern = pattern, .flags = self.state.flags };
    }
};
fn escapeLiteral(cp: u32) ?u32 {
    return switch (cp) {
        'a' => 7,
        'b' => 8,
        'f' => 12,
        'n' => 10,
        'r' => 13,
        't' => 9,
        'v' => 11,
        '\\' => '\\',
        else => null,
    };
}
const CategoryCode = union(enum) { At: AtCode, In: ChCode };
fn category(cp: u32) ?CategoryCode {
    return switch (cp) {
        'A' => .{ .At = .BeginningString },
        'b' => .{ .At = .Boundary },
        'B' => .{ .At = .NonBoundary },
        'd' => .{ .In = .Digit },
        'D' => .{ .In = .NotDigit },
        's' => .{ .In = .Space },
        'S' => .{ .In = .NotSpace },
        'w' => .{ .In = .Word },
        'W' => .{ .In = .NotWord },
        'Z' => .{ .At = .EndString },
        else => null,
    };
}
fn flagForChar(cp: u32) ?u32 {
    return switch (cp) {
        'i' => c.SRE_FLAG_IGNORECASE,
        'L' => c.SRE_FLAG_LOCALE,
        'm' => c.SRE_FLAG_MULTILINE,
        's' => c.SRE_FLAG_DOTALL,
        'x' => c.SRE_FLAG_VERBOSE,
        'a' => c.SRE_FLAG_ASCII,
        'u' => c.SRE_FLAG_UNICODE,
        else => null,
    };
}
fn isRepeatOpcode(op: OpCode) bool {
    return switch (op) {
        .MinRepeat, .MaxRepeat, .PossessiveRepeat => true,
        else => false,
    };
}
pub fn setEql(a: SetItem, b: SetItem) bool {
    if (std.meta.activeTag(a) != std.meta.activeTag(b)) return false;
    return switch (a) {
        .Literal => |v| v == b.Literal,
        .Negate => true,
        .Range => |r| r.lo == b.Range.lo and r.hi == b.Range.hi,
        .Category => |v| v == b.Category,
    };
}
pub fn patternEql(a: SubPattern, b: SubPattern) bool {
    if (a.len() != b.len()) return false;
    for (a.data.items, b.data.items) |aa, bb| if (!opEql(aa, bb)) return false;
    return true;
}
pub fn opEql(a: OpCode, b: OpCode) bool {
    if (std.meta.activeTag(a) != std.meta.activeTag(b)) return false;
    return switch (a) {
        .Literal => |v| v == b.Literal,
        .NotLiteral => |v| v == b.NotLiteral,
        .Any, .Failure => true,
        .At => |v| v == b.At,
        .GroupRef => |v| v == b.GroupRef,
        .In => |items| blk: {
            if (items.len != b.In.len) break :blk false;
            for (items, b.In) |aa, bb| if (!setEql(aa, bb)) break :blk false;
            break :blk true;
        },
        .Branch => |items| blk: {
            if (items.len != b.Branch.len) break :blk false;
            for (items, b.Branch) |aa, bb| if (!patternEql(aa, bb)) break :blk false;
            break :blk true;
        },
        .Subpattern => |v| v.group == b.Subpattern.group and v.add_flags == b.Subpattern.add_flags and v.del_flags == b.Subpattern.del_flags and patternEql(v.p, b.Subpattern.p),
        .GroupRefExists => |v| v.cond_group == b.GroupRefExists.cond_group and patternEql(v.yes, b.GroupRefExists.yes) and (if (v.no) |n| if (b.GroupRefExists.no) |bn| patternEql(n, bn) else false else b.GroupRefExists.no == null),
        .Assert => |v| v.direction == b.Assert.direction and patternEql(v.p, b.Assert.p),
        .AssertNot => |v| v.direction == b.AssertNot.direction and patternEql(v.p, b.AssertNot.p),
        .AtomicGroup => |v| patternEql(v, b.AtomicGroup),
        .MaxRepeat => |v| repeatEql(v, b.MaxRepeat),
        .MinRepeat => |v| repeatEql(v, b.MinRepeat),
        .PossessiveRepeat => |v| repeatEql(v, b.PossessiveRepeat),
    };
}
fn repeatEql(a: OpCode.Repeat, b: OpCode.Repeat) bool {
    return a.min == b.min and a.max == b.max and patternEql(a.item, b.item);
}
pub fn parsePattern(allocator: Allocator, pattern: []const u8, flags: u32) Allocator.Error!Result {
    var arena: std.heap.ArenaAllocator = .init(allocator);
    errdefer arena.deinit();
    var parser = Parser.init(arena.allocator(), pattern) catch |err| switch (err) {
        error.OutOfMemory => return error.OutOfMemory,
        error.InvalidPattern => return .{ .arena = arena, .failure = .{ .msg = "pattern must be valid UTF-8", .pos = 0 } },
    };
    const parsed = parser.run(flags) catch |err| switch (err) {
        error.OutOfMemory => return error.OutOfMemory,
        error.InvalidPattern => return .{ .arena = arena, .failure = parser.failure.? },
    };
    return .{ .arena = arena, .parsed = parsed };
}
test "parser handles captures, alternation, classes and repetition" {
    var result = try parsePattern(std.testing.allocator, "(?i)(?P<x>a|b)+(?P=x)", 0);
    defer result.deinit();
    try std.testing.expect(result.failure == null);
    try std.testing.expectEqual(@as(u32, 34), result.parsed.?.flags);
    try std.testing.expectEqual(@as(usize, 2), result.parsed.?.pattern.len());
}

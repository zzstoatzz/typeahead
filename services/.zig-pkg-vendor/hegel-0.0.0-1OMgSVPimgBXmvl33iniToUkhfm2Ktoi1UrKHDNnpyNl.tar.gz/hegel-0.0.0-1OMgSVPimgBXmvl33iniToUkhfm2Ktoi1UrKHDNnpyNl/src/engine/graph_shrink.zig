// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-provenance/state.json.
const std = @import("std");
const c = @import("choices.zig");
const g = @import("graph.zig");
const nd = @import("nd.zig");
const Allocator = std.mem.Allocator;
pub const SweepMode = @import("shrinker.zig").SweepMode;
pub const WARM_UP_GRAFTS: u32 = 8;
pub const COUNT_LOWERINGS: u32 = 3;
pub const Outcome = struct {
    failed: bool,
    divergence: bool,
    ended: bool,
    settled: []g.Settled,
    nodes: []c.ChoiceNode,
    spans: []c.Span,
    pub fn clean(self: Outcome) bool {
        return self.failed and !self.divergence and self.ended;
    }
    pub fn run(self: *const Outcome, gpa: Allocator) c.Error!g.Run {
        return g.Run.fromNodes(gpa, self.nodes, self.spans);
    }
    pub fn deinit(self: *Outcome, gpa: Allocator) void {
        gpa.free(self.settled);
        c.deinitNodes(gpa, self.nodes);
        gpa.free(self.spans);
    }
};
pub const GraphProbe = struct {
    context: *anyopaque,
    replay: *const fn (*anyopaque, *const g.Graph, usize) anyerror!Outcome,
    charge: *const fn (*anyopaque, f64, bool) u64,
    adopted: *const fn (*anyopaque, *const g.Graph, []const c.ChoiceNode, []const c.Span, f64, usize) anyerror!void,
};
pub const SpanEntry = struct { addr: g.Addr, start: usize };
pub fn spansOf(gpa: Allocator, run: *const g.Run) Allocator.Error![]SpanEntry {
    var spans: std.ArrayList(SpanEntry) = .empty;
    errdefer {
        for (spans.items) |span| gpa.free(span.addr);
        spans.deinit(gpa);
    }
    for (run.steps.items, 0..) |step, i| {
        for (1..step.addr.len) |depth| {
            const addr = step.addr[0..depth];
            var seen = false;
            for (spans.items) |span| if (g.framesEql(span.addr, addr)) {
                seen = true;
                break;
            };
            if (!seen) {
                const owned = try gpa.dupe(g.Frame, addr);
                errdefer gpa.free(owned);
                try spans.append(gpa, .{ .addr = owned, .start = i });
            }
        }
    }
    std.mem.sort(SpanEntry, spans.items, {}, struct {
        fn less(_: void, a: SpanEntry, b: SpanEntry) bool {
            return if (a.start == b.start) a.addr.len < b.addr.len else a.start > b.start;
        }
    }.less);
    return spans.toOwnedSlice(gpa);
}
fn startsWith(addr: []const g.Frame, prefix: []const g.Frame) bool {
    return addr.len >= prefix.len and g.framesEql(addr[0..prefix.len], prefix);
}
pub fn withoutSpan(gpa: Allocator, run: *const g.Run, span: []const g.Frame) c.Error!g.Run {
    var result = g.Run.init(gpa);
    errdefer result.deinit();
    const depth = span.len - 1;
    const frame = span[depth];
    for (run.steps.items) |step| {
        if (startsWith(step.addr, span)) continue;
        const addr = try gpa.dupe(g.Frame, step.addr);
        defer gpa.free(addr);
        if (addr.len > depth and g.framesEql(addr[0..depth], span[0..depth]) and addr[depth].label == frame.label and addr[depth].ordinal > frame.ordinal) addr[depth].ordinal -= 1;
        try result.append(addr, &step.value);
    }
    return result;
}
pub const EdgeKey = struct {
    from: g.Ident,
    addr: g.Addr,
    value: c.ChoiceValue,
    to: g.Ident,
    fn deinit(self: *EdgeKey, gpa: Allocator) void {
        self.from.deinit(gpa);
        gpa.free(self.addr);
        self.value.deinit(gpa);
        self.to.deinit(gpa);
    }
    fn deepClone(self: *const EdgeKey, gpa: Allocator) c.Error!EdgeKey {
        var from = try self.from.deepClone(gpa);
        errdefer from.deinit(gpa);
        const addr = try gpa.dupe(g.Frame, self.addr);
        errdefer gpa.free(addr);
        var value = try self.value.deepClone(gpa);
        errdefer value.deinit(gpa);
        return .{ .from = from, .addr = addr, .value = value, .to = try self.to.deepClone(gpa) };
    }
};
fn edgeKeys(gpa: Allocator, graph: *const g.Graph) c.Error![]EdgeKey {
    var result: std.ArrayList(EdgeKey) = .empty;
    errdefer {
        for (result.items) |*key| key.deinit(gpa);
        result.deinit(gpa);
    }
    const reachable = try graph.reachable(gpa);
    defer gpa.free(reachable);
    for (reachable) |n| for (graph.nodes()[n].edges.items) |*edge| {
        const borrowed: EdgeKey = .{ .from = graph.nodes()[n].ident, .addr = edge.addr, .value = edge.value, .to = graph.nodes()[edge.target].ident };
        var key = try borrowed.deepClone(gpa);
        errdefer key.deinit(gpa);
        try result.append(gpa, key);
    };
    return result.toOwnedSlice(gpa);
}
fn locate(graph: *const g.Graph, key: *const EdgeKey) ?g.Settled {
    const n = graph.node(key.from) orelse return null;
    for (graph.nodes()[n].edges.items, 0..) |*edge, i| if (g.framesEql(edge.addr, key.addr) and edge.value.eql(&key.value) and graph.nodes()[edge.target].ident.eql(key.to)) return .{ .node = n, .edge = i };
    return null;
}
pub const Edit = union(enum) { delete, value: struct { node: usize, addr: []const g.Frame, value: *const c.ChoiceValue } };
pub const Verdict = union(enum) { rejected, accepted: struct { graph: g.Graph, witness: Outcome, lower_bound: f64 } };
const Constraint = struct {
    ident: g.Ident,
    addr: g.Addr,
    data: c.ChoiceData,
    fn deinit(self: *Constraint, gpa: Allocator) void {
        self.ident.deinit(gpa);
        gpa.free(self.addr);
        self.data.deinit(gpa);
    }
};
pub const GraphShrinker = struct {
    allocator: Allocator,
    graph_value: g.Graph,
    witness_nodes: []c.ChoiceNode,
    witness_spans: []c.Span,
    anchor_value: f64,
    constraints: std.ArrayList(Constraint) = .empty,
    longest: usize = 0,
    sweep: SweepMode = .fast,
    deadline: ?i128 = null,
    clock_context: ?*anyopaque = null,
    now: ?*const fn (?*anyopaque) ?i128 = null,
    timed_out: bool = false,
    replay_count: u64 = 0,
    pub fn init(gpa: Allocator, source: *const g.Graph, nodes: []const c.ChoiceNode, spans: []const c.Span, initial_anchor: f64) c.Error!GraphShrinker {
        var graph_copy = try source.deepCloneWithAllocator(gpa);
        errdefer graph_copy.deinit();
        const owned = try c.cloneNodes(gpa, nodes);
        errdefer c.deinitNodes(gpa, owned);
        const span_copy = try gpa.dupe(c.Span, spans);
        errdefer gpa.free(span_copy);
        var result: GraphShrinker = .{ .allocator = gpa, .graph_value = graph_copy, .witness_nodes = owned, .witness_spans = span_copy, .anchor_value = initial_anchor, .longest = c.flattenedLen(nodes) };
        errdefer {
            for (result.constraints.items) |*item| item.deinit(gpa);
            result.constraints.deinit(gpa);
        }
        try result.learnConstraints(nodes, spans);
        return result;
    }
    pub fn deinit(self: *GraphShrinker) void {
        const gpa = self.allocator;
        self.graph_value.deinit();
        c.deinitNodes(gpa, self.witness_nodes);
        gpa.free(self.witness_spans);
        for (self.constraints.items) |*item| item.deinit(gpa);
        self.constraints.deinit(gpa);
    }
    pub fn graph(self: *const GraphShrinker) *const g.Graph {
        return &self.graph_value;
    }
    pub fn anchor(self: *const GraphShrinker) f64 {
        return self.anchor_value;
    }
    pub fn replays(self: *const GraphShrinker) u64 {
        return self.replay_count;
    }
    pub fn setLongest(self: *GraphShrinker, longest: usize) void {
        self.longest = @max(self.longest, longest);
    }
    fn expired(self: *const GraphShrinker) bool {
        if (self.deadline) |deadline| if (self.now) |clock| if (clock(self.clock_context)) |now| return now >= deadline;
        return false;
    }
    fn constraint(self: *const GraphShrinker, ident: g.Ident, addr: []const g.Frame) ?*const c.ChoiceData {
        for (self.constraints.items) |*item| if (item.ident.eql(ident) and g.framesEql(item.addr, addr)) return &item.data;
        return null;
    }
    pub fn learnConstraints(self: *GraphShrinker, nodes: []const c.ChoiceNode, spans: []const c.Span) c.Error!void {
        const gpa = self.allocator;
        var run = try g.Run.fromNodes(gpa, nodes, spans);
        defer run.deinit();
        const idents = try run.idents(gpa);
        defer {
            for (idents) |*id| id.deinit(gpa);
            gpa.free(idents);
        }
        var p: usize = 0;
        for (nodes) |*node| {
            if (node.was_forced) continue;
            defer p += 1;
            if (node.data == .clone) continue;
            const before: g.Ident = if (p == 0) .start else idents[p - 1];
            const addr = run.steps.items[p].addr;
            var existing: ?*Constraint = null;
            for (self.constraints.items) |*item| if (item.ident.eql(before) and g.framesEql(item.addr, addr)) {
                existing = item;
                break;
            };
            var data = try node.data.deepClone(gpa);
            errdefer data.deinit(gpa);
            if (existing) |item| {
                item.data.deinit(gpa);
                item.data = data;
            } else {
                var ident = try before.deepClone(gpa);
                errdefer ident.deinit(gpa);
                const address = try gpa.dupe(g.Frame, addr);
                errdefer gpa.free(address);
                try self.constraints.append(gpa, .{ .ident = ident, .addr = address, .data = data });
            }
        }
    }
    fn graft(self: *GraphShrinker, run: *const g.Run) c.Error!void {
        if (self.graph_value.walkVerdict(run) == .gap) _ = try self.graph_value.insert(run);
    }
    pub fn shrink(self: *GraphShrinker, probe: GraphProbe) anyerror!void {
        while (true) {
            const deleted = try self.deletePass(probe);
            const trimmed = try self.spanPass(probe);
            const shrunk = try self.valuePass(probe);
            if (self.timed_out) return;
            if (deleted or trimmed or shrunk) self.sweep = .fast else if (self.sweep == .fast) self.sweep = .confirm else return;
        }
    }
    pub fn deletePass(self: *GraphShrinker, probe: GraphProbe) anyerror!bool {
        const keys = try edgeKeys(self.allocator, &self.graph_value);
        defer {
            for (keys) |*key| key.deinit(self.allocator);
            self.allocator.free(keys);
        }
        var changed = false;
        for (keys) |*key| {
            if (self.timed_out) break;
            const edge = locate(&self.graph_value, key) orelse continue;
            const candidate = try self.graph_value.deleteEdge(edge.node, edge.edge);
            switch (try self.judge(probe, candidate, .delete)) {
                .accepted => |accepted| {
                    try self.adopt(probe, accepted.graph, accepted.witness, accepted.lower_bound);
                    changed = true;
                },
                .rejected => {},
            }
        }
        return changed;
    }
    fn cloneRun(self: *GraphShrinker, source: *const g.Run) c.Error!g.Run {
        var result = g.Run.init(self.allocator);
        errdefer result.deinit();
        for (source.steps.items) |*step| try result.append(step.addr, &step.value);
        return result;
    }
    pub fn spanPass(self: *GraphShrinker, probe: GraphProbe) anyerror!bool {
        const gpa = self.allocator;
        var initial = try g.Run.fromNodes(gpa, self.witness_nodes, self.witness_spans);
        defer initial.deinit();
        const spans = try spansOf(gpa, &initial);
        defer {
            for (spans) |span| gpa.free(span.addr);
            gpa.free(spans);
        }
        var changed = false;
        for (spans) |span| {
            if (self.timed_out) break;
            var current = try g.Run.fromNodes(gpa, self.witness_nodes, self.witness_spans);
            defer current.deinit();
            var exists = false;
            for (current.steps.items) |step| if (startsWith(step.addr, span.addr)) {
                exists = true;
                break;
            };
            if (!exists) continue;
            var shorter = try withoutSpan(gpa, &current, span.addr);
            defer shorter.deinit();
            if (shorter.steps.items.len == 0) continue;
            if (try self.tryRun(probe, &shorter)) {
                changed = true;
                continue;
            }
            const idents = try current.idents(gpa);
            defer {
                for (idents) |*id| id.deinit(gpa);
                gpa.free(idents);
            }
            var tried: u32 = 0;
            var j = span.start;
            while (j > 0) {
                j -= 1;
                const before: g.Ident = if (j == 0) .start else idents[j - 1];
                var lowered_run = try self.lowered(&shorter, j, before) orelse continue;
                defer lowered_run.deinit();
                tried += 1;
                if (try self.tryRun(probe, &lowered_run)) {
                    changed = true;
                    break;
                }
                if (tried == COUNT_LOWERINGS) break;
            }
        }
        return changed;
    }
    fn lowered(self: *GraphShrinker, run: *const g.Run, j: usize, before: g.Ident) c.Error!?g.Run {
        if (j >= run.steps.items.len) return null;
        const step = &run.steps.items[j];
        if (step.value != .integer) return null;
        const data = self.constraint(before, step.addr) orelse return null;
        if (data.* != .integer) return null;
        var simplest = try data.integer.constraint.simplest(self.allocator);
        defer simplest.deinit();
        if (step.value.integer.order(simplest) != .gt) return null;
        var result = try self.cloneRun(run);
        errdefer result.deinit();
        const value = try step.value.integer.addInt(self.allocator, @as(i32, -1));
        result.steps.items[j].value.deinit(self.allocator);
        result.steps.items[j].value = .{ .integer = value };
        return result;
    }
    fn tryRun(self: *GraphShrinker, probe: GraphProbe, run: *const g.Run) anyerror!bool {
        switch (try self.judge(probe, try g.Graph.fromRun(self.allocator, run), .delete)) {
            .accepted => |accepted| {
                try self.adopt(probe, accepted.graph, accepted.witness, accepted.lower_bound);
                return true;
            },
            .rejected => return false,
        }
    }
    pub fn valuePass(self: *GraphShrinker, probe: GraphProbe) anyerror!bool {
        const keys = try edgeKeys(self.allocator, &self.graph_value);
        defer {
            for (keys) |*key| key.deinit(self.allocator);
            self.allocator.free(keys);
        }
        var changed = false;
        for (keys) |*key| {
            if (self.timed_out) break;
            const found = self.constraint(key.from, key.addr) orelse continue;
            var data = try found.deepClone(self.allocator);
            defer data.deinit(self.allocator);
            changed = (try self.shrinkValue(probe, key, &data)) or changed;
        }
        return changed;
    }
    fn tryValue(self: *GraphShrinker, probe: GraphProbe, key: *EdgeKey, data: *const c.ChoiceData, value: *const c.ChoiceValue) anyerror!bool {
        if (self.timed_out or value.eql(&key.value)) return false;
        var fitted = try data.withValue(self.allocator, value) orelse return false;
        fitted.deinit(self.allocator);
        const node = self.graph_value.node(key.from) orelse return false;
        var found = false;
        for (self.graph_value.nodes()[node].edges.items) |*edge| if (g.framesEql(edge.addr, key.addr) and edge.value.eql(&key.value)) {
            found = true;
            break;
        };
        if (!found) return false;
        var copy = try value.deepClone(self.allocator);
        var owns_copy = true;
        defer if (owns_copy) copy.deinit(self.allocator);
        const candidate = try self.graph_value.setValue(node, key.addr, &key.value, value);
        switch (try self.judge(probe, candidate, .{ .value = .{ .node = node, .addr = key.addr, .value = value } })) {
            .accepted => |accepted| {
                try self.adopt(probe, accepted.graph, accepted.witness, accepted.lower_bound);
                key.value.deinit(self.allocator);
                key.value = copy;
                owns_copy = false;
                return true;
            },
            .rejected => return false,
        }
    }
    fn shrinkValue(self: *GraphShrinker, probe: GraphProbe, source: *const EdgeKey, data: *const c.ChoiceData) anyerror!bool {
        const gpa = self.allocator;
        var key = try source.deepClone(gpa);
        defer key.deinit(gpa);
        var simplest = try data.simplestValue(gpa);
        defer simplest.deinit(gpa);
        if (try self.tryValue(probe, &key, data, &simplest)) return true;
        switch (data.*) {
            .integer => |ic| {
                if (key.value != .integer) return false;
                var small = try ic.constraint.simplest(gpa);
                defer small.deinit();
                var lo = small.toInt(i128) orelse return false;
                var hi = key.value.integer.toInt(i128) orelse return false;
                var changed = false;
                while (!self.timed_out and absDiff(hi, lo) > 1) {
                    const mid: i128 = @intCast(@as(i256, lo) + @divTrunc(@as(i256, hi) - lo, 2));
                    var value: c.ChoiceValue = .{ .integer = try c.BigInt.fromInt(gpa, mid) };
                    defer value.deinit(gpa);
                    if (try self.tryValue(probe, &key, data, &value)) {
                        hi = mid;
                        changed = true;
                    } else lo = mid;
                }
                return changed;
            },
            .float => {
                if (key.value != .float) return false;
                const whole = @trunc(key.value.float);
                return if (whole != key.value.float) self.tryValue(probe, &key, data, &.{ .float = whole }) else false;
            },
            .bytes => |bc| {
                if (key.value != .bytes) return false;
                return self.shrinkSequence(u8, probe, &key, data, key.value.bytes, bc.constraint.min_size, 0);
            },
            .string => |sc| {
                if (key.value != .string) return false;
                return self.shrinkSequence(u32, probe, &key, data, key.value.string, sc.constraint.min_size, try sc.constraint.simplestCodepoint());
            },
            else => return false,
        }
    }
    fn shrinkSequence(self: *GraphShrinker, comptime T: type, probe: GraphProbe, key: *EdgeKey, data: *const c.ChoiceData, original: []const T, min_len: usize, zero: T) anyerror!bool {
        const gpa = self.allocator;
        const v = try gpa.dupe(T, original);
        defer gpa.free(v);
        var len = v.len;
        var changed = false;
        while (true) {
            const target = @max(len / 2, min_len);
            if (target == len) break;
            const value = sequenceValue(T, v[0..target]);
            if (!(try self.tryValue(probe, key, data, &value))) break;
            len = target;
            changed = true;
        }
        if (len > min_len) {
            const value = sequenceValue(T, v[0 .. len - 1]);
            if (try self.tryValue(probe, key, data, &value)) {
                len -= 1;
                changed = true;
            }
        }
        for (0..len) |i| {
            if (v[i] == zero) continue;
            const old = v[i];
            v[i] = zero;
            const value = sequenceValue(T, v[0..len]);
            if (try self.tryValue(probe, key, data, &value)) changed = true else v[i] = old;
        }
        return changed;
    }
    pub fn judge(self: *GraphShrinker, probe: GraphProbe, owned_candidate: g.Graph, edit: Edit) anyerror!Verdict {
        const gpa = self.allocator;
        var candidate = owned_candidate;
        defer candidate.deinit();
        const min_fails = probe.charge(probe.context, self.anchor_value, self.sweep == .confirm);
        var evidence: nd.Evidence = .{};
        var witness: ?Outcome = null;
        defer if (witness) |*out| out.deinit(gpa);
        var exercised = edit == .delete;
        var settled: std.ArrayList(g.Settled) = .empty;
        defer settled.deinit(gpa);
        var grafts: u32 = 0;
        var accepted = false;
        while (true) {
            if (accepted and evidence.runs() >= nd.ANCHOR_SEED_RUNS) break;
            if (!accepted and self.expired()) {
                self.timed_out = true;
                return .rejected;
            }
            var out = try probe.replay(probe.context, &candidate, nd.continuationBudget(self.longest));
            var owns_out = true;
            defer if (owns_out) out.deinit(gpa);
            self.replay_count += 1;
            try self.learnConstraints(out.nodes, out.spans);
            const clean = out.clean();
            if (clean) {
                self.longest = @max(self.longest, c.flattenedLen(out.nodes));
                if (edit == .value) for (out.settled) |edge_id| {
                    const edge = &candidate.nodes()[edge_id.node].edges.items[edge_id.edge];
                    if (edge_id.node == edit.value.node and g.framesEql(edge.addr, edit.value.addr) and edge.value.eql(edit.value.value)) exercised = true;
                };
                try settled.appendSlice(gpa, out.settled);
                if (witness == null or try c.nodesOrder(gpa, out.nodes, witness.?.nodes) == .lt) {
                    if (witness) |*old| old.deinit(gpa);
                    witness = out;
                    owns_out = false;
                }
            } else if (out.failed) {
                var run = try out.run(gpa);
                defer run.deinit();
                try self.graft(&run);
                if (!accepted and edit == .value and grafts < WARM_UP_GRAFTS and candidate.walkVerdict(&run) == .gap and try candidate.insert(&run)) {
                    grafts += 1;
                    continue;
                }
            }
            evidence.record(clean);
            if (accepted) continue;
            if (!clean and self.sweep == .fast) return .rejected;
            switch (nd.gauntlet(evidence, self.anchor_value, min_fails)) {
                .accept => {
                    if (!exercised) return .rejected;
                    accepted = true;
                },
                .reject => return .rejected,
                .continue_replaying => {},
            }
        }
        if (edit == .value) try candidate.retainSettled(settled.items);
        var pruned = try candidate.pruned();
        errdefer pruned.deinit();
        var candidate_key = try pruned.key();
        defer candidate_key.deinit();
        var incumbent_key = try self.graph_value.key();
        defer incumbent_key.deinit();
        if (candidate_key.order(incumbent_key) != .lt) {
            pruned.deinit();
            return .rejected;
        }
        const chosen = witness orelse return error.InternalError;
        witness = null;
        return .{ .accepted = .{ .graph = pruned, .witness = chosen, .lower_bound = evidence.lowerBound() } };
    }
    fn adopt(self: *GraphShrinker, probe: GraphProbe, owned_graph: g.Graph, owned_witness: Outcome, lower_bound: f64) anyerror!void {
        var graph_value = owned_graph;
        var owns_graph = true;
        errdefer if (owns_graph) graph_value.deinit();
        var witness = owned_witness;
        defer witness.deinit(self.allocator);
        self.anchor_value = @max(self.anchor_value, @min(lower_bound, nd.anchorCeiling()));
        var standing = try g.Run.fromNodes(self.allocator, self.witness_nodes, self.witness_spans);
        defer standing.deinit();
        if (try c.nodesOrder(self.allocator, witness.nodes, self.witness_nodes) == .lt or graph_value.walkVerdict(&standing) != .whole) {
            c.deinitNodes(self.allocator, self.witness_nodes);
            self.allocator.free(self.witness_spans);
            self.witness_nodes = witness.nodes;
            self.witness_spans = witness.spans;
            witness.nodes = &.{};
            witness.spans = &.{};
        }
        self.graph_value.deinit();
        self.graph_value = graph_value;
        owns_graph = false;
        try probe.adopted(probe.context, &self.graph_value, self.witness_nodes, self.witness_spans, self.anchor_value, self.longest);
    }
};
fn sequenceValue(comptime T: type, slice: []T) c.ChoiceValue {
    return if (T == u8) .{ .bytes = slice } else .{ .string = slice };
}
fn absDiff(a: i128, b: i128) u256 {
    const delta = @as(i256, a) - b;
    return @intCast(if (delta < 0) -delta else delta);
}

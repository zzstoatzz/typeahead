// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const graph = @import("graph.zig");
const execution = @import("execution.zig");
const nd = @import("nd.zig");
pub const ReproSource = union(enum) { graph: struct { source: *const graph.Graph, longest: usize }, sequence: []const c.ChoiceValue };
pub const NdReplay = struct {
    run: execution.RunResult,
    failed: bool,
    pub fn deinit(self: *NdReplay, gpa: std.mem.Allocator) void {
        self.run.deinit(gpa);
    }
};
pub const NdBatch = struct {
    bar_accepted: bool,
    evidence: nd.Evidence,
    witness: ?execution.RunResult,
    graph: graph.Graph,
    longest: usize,
    pub fn deinit(self: *NdBatch, gpa: std.mem.Allocator) void {
        if (self.witness) |*run| run.deinit(gpa);
        self.graph.deinit();
        self.* = undefined;
    }
};
pub const Backtrack = union(enum) { restored: struct { nodes: []c.ChoiceNode, spans: []c.Span }, exhausted: struct { fails: u64, replays: u64 } };
pub const Reproduction = struct { witness: ?execution.RunResult, evidence: nd.Evidence };
pub const ReplaySource = struct {
    graph: graph.Graph,
    longest: usize,
    pub fn deinit(self: *ReplaySource) void {
        self.graph.deinit();
    }
};

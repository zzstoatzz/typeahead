// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");

pub const Interval = struct { start: u32, end: u32 };

pub const IntervalSet = struct {
    allocator: std.mem.Allocator,
    intervals: []Interval,
    offsets: []usize,
    size: usize,
    idx_of_zero: usize,
    idx_of_z: isize,
    string_constants_mask: *std.atomic.Value(?*Mask),

    pub const Mask = struct { values: []bool };

    pub fn init(allocator: std.mem.Allocator, intervals: []const Interval) !IntervalSet {
        const owned = try allocator.dupe(Interval, intervals);
        errdefer allocator.free(owned);
        const offsets = try allocator.alloc(usize, intervals.len);
        errdefer allocator.free(offsets);
        var size: usize = 0;
        for (intervals, offsets) |interval, *offset| {
            if (interval.start > interval.end) return error.InternalError;
            offset.* = size;
            const width: u64 = @as(u64, interval.end) - interval.start + 1;
            size = std.math.add(usize, size, std.math.cast(usize, width) orelse return error.InternalError) catch return error.InternalError;
        }
        const memo = try allocator.create(std.atomic.Value(?*Mask));
        memo.* = .init(null);
        var set: IntervalSet = .{
            .allocator = allocator,
            .intervals = owned,
            .offsets = offsets,
            .size = size,
            .idx_of_zero = 0,
            .idx_of_z = -1,
            .string_constants_mask = memo,
        };
        set.idx_of_zero = set.indexAbove('0');
        set.idx_of_z = if (size == 0) -1 else @intCast(@min(set.indexAbove('Z'), size - 1));
        return set;
    }

    pub fn deinit(self: *IntervalSet) void {
        self.allocator.free(self.intervals);
        self.allocator.free(self.offsets);
        if (self.string_constants_mask.load(.acquire)) |mask| {
            self.allocator.free(mask.values);
            self.allocator.destroy(mask);
        }
        self.allocator.destroy(self.string_constants_mask);
        self.* = undefined;
    }

    pub fn clone(self: *const IntervalSet) !IntervalSet {
        return self.cloneWithAllocator(self.allocator);
    }

    pub fn cloneWithAllocator(self: *const IntervalSet, allocator: std.mem.Allocator) !IntervalSet {
        var result = try init(allocator, self.intervals);
        errdefer result.deinit();
        if (self.getStringConstantsMask()) |mask| _ = try result.cacheStringConstantsMaskOwned(try allocator.dupe(bool, mask));
        return result;
    }

    pub fn getStringConstantsMask(self: *const IntervalSet) ?[]const bool {
        const mask = self.string_constants_mask.load(.acquire) orelse return null;
        return mask.values;
    }

    pub fn cacheStringConstantsMaskOwned(self: *const IntervalSet, values: []bool) ![]const bool {
        const mask = self.allocator.create(Mask) catch |err| {
            self.allocator.free(values);
            return err;
        };
        mask.* = .{ .values = values };
        if (self.string_constants_mask.cmpxchgStrong(null, mask, .acq_rel, .acquire)) |existing| {
            self.allocator.free(values);
            self.allocator.destroy(mask);
            return existing.?.values;
        }
        return values;
    }

    pub fn len(self: *const IntervalSet) usize {
        return self.size;
    }

    pub fn isEmpty(self: *const IntervalSet) bool {
        return self.size == 0;
    }

    pub fn get(self: *const IntervalSet, position: isize) ?u32 {
        const resolved = if (position < 0) std.math.add(isize, @intCast(self.size), position) catch return null else position;
        if (resolved < 0 or @as(usize, @intCast(resolved)) >= self.size) return null;
        const i: usize = @intCast(resolved);
        var lo: usize = 0;
        var hi = self.offsets.len;
        while (lo + 1 < hi) {
            const mid = lo + (hi - lo) / 2;
            if (self.offsets[mid] <= i) lo = mid else hi = mid;
        }
        return self.intervals[lo].start + @as(u32, @intCast(i - self.offsets[lo]));
    }

    fn intervalFor(self: *const IntervalSet, elem: u32) ?usize {
        var lo: usize = 0;
        var hi = self.intervals.len;
        while (lo < hi) {
            const mid = lo + (hi - lo) / 2;
            if (self.intervals[mid].start <= elem) lo = mid + 1 else hi = mid;
        }
        return if (lo == 0) null else lo - 1;
    }

    pub fn contains(self: *const IntervalSet, elem: u32) bool {
        const j = self.intervalFor(elem) orelse return false;
        return elem <= self.intervals[j].end;
    }

    pub fn index(self: *const IntervalSet, elem: u32) ?usize {
        const j = self.intervalFor(elem) orelse return null;
        const interval = self.intervals[j];
        return if (elem <= interval.end) self.offsets[j] + elem - interval.start else null;
    }

    pub fn indexAbove(self: *const IntervalSet, elem: u32) usize {
        const j = self.intervalFor(elem) orelse return 0;
        const interval = self.intervals[j];
        if (elem <= interval.end) return self.offsets[j] + elem - interval.start;
        return if (j + 1 < self.intervals.len) self.offsets[j + 1] else self.size;
    }

    pub fn unionWith(self: *const IntervalSet, other: *const IntervalSet) !IntervalSet {
        if (self.intervals.len == 0) return init(self.allocator, other.intervals);
        if (other.intervals.len == 0) return init(self.allocator, self.intervals);
        var merged: std.ArrayList(Interval) = .empty;
        defer merged.deinit(self.allocator);
        try merged.appendSlice(self.allocator, self.intervals);
        try merged.appendSlice(self.allocator, other.intervals);
        std.mem.sort(Interval, merged.items, {}, struct {
            fn less(_: void, a: Interval, b: Interval) bool {
                return a.start < b.start;
            }
        }.less);
        var result: std.ArrayList(Interval) = .empty;
        defer result.deinit(self.allocator);
        for (merged.items) |interval| {
            if (result.items.len > 0) {
                const last = &result.items[result.items.len - 1];
                if (interval.start <= last.end +| 1) {
                    last.end = @max(last.end, interval.end);
                    continue;
                }
            }
            try result.append(self.allocator, interval);
        }
        return init(self.allocator, result.items);
    }

    pub fn difference(self: *const IntervalSet, other: *const IntervalSet) !IntervalSet {
        const x = try self.allocator.dupe(Interval, self.intervals);
        defer self.allocator.free(x);
        var result: std.ArrayList(Interval) = .empty;
        defer result.deinit(self.allocator);
        var i: usize = 0;
        var j: usize = 0;
        while (i < x.len and j < other.intervals.len) {
            const a = x[i];
            const b = other.intervals[j];
            if (b.end < a.start) {
                j += 1;
            } else if (b.start > a.end) {
                try result.append(self.allocator, a);
                i += 1;
            } else if (b.start <= a.start) {
                if (b.end >= a.end) {
                    i += 1;
                } else {
                    x[i].start = b.end + 1;
                    j += 1;
                }
            } else {
                try result.append(self.allocator, .{ .start = a.start, .end = b.start - 1 });
                if (b.end < a.end) {
                    x[i].start = b.end + 1;
                    j += 1;
                } else {
                    i += 1;
                }
            }
        }
        try result.appendSlice(self.allocator, x[i..]);
        return init(self.allocator, result.items);
    }

    pub fn intersection(self: *const IntervalSet, other: *const IntervalSet) !IntervalSet {
        var result: std.ArrayList(Interval) = .empty;
        defer result.deinit(self.allocator);
        var i: usize = 0;
        var j: usize = 0;
        while (i < self.intervals.len and j < other.intervals.len) {
            const a = self.intervals[i];
            const b = other.intervals[j];
            if (a.start > b.end) {
                j += 1;
            } else if (b.start > a.end) {
                i += 1;
            } else {
                try result.append(self.allocator, .{ .start = @max(a.start, b.start), .end = @min(a.end, b.end) });
                if (a.end < b.end) i += 1 else j += 1;
            }
        }
        return init(self.allocator, result.items);
    }

    pub fn charInShrinkOrder(self: *const IntervalSet, position: usize) u32 {
        var i: isize = @intCast(position);
        if (i <= self.idx_of_z) {
            const n = self.idx_of_z - @as(isize, @intCast(self.idx_of_zero));
            if (i <= n) i += @intCast(self.idx_of_zero) else i = @as(isize, @intCast(self.idx_of_zero)) - (i - n);
        }
        const cp = self.get(i).?;
        std.debug.assert(cp <= 0x10ffff and !(cp >= 0xd800 and cp <= 0xdfff));
        return cp;
    }

    pub fn indexFromCharInShrinkOrder(self: *const IntervalSet, c: u21) usize {
        return self.indexFromCodepointInShrinkOrder(c);
    }

    pub fn indexFromCodepointInShrinkOrder(self: *const IntervalSet, cp: u32) usize {
        var i: isize = @intCast(self.index(cp).?);
        const zero: isize = @intCast(self.idx_of_zero);
        if (i <= self.idx_of_z) {
            const n = self.idx_of_z - zero;
            if (zero <= i and i <= self.idx_of_z) i -= zero else i = zero - i + n;
        }
        return @intCast(i);
    }

    pub fn eql(self: *const IntervalSet, other: *const IntervalSet) bool {
        if (self.intervals.len != other.intervals.len) return false;
        for (self.intervals, other.intervals) |a, b| if (a.start != b.start or a.end != b.end) return false;
        return true;
    }
};

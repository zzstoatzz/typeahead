// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/exec_cache.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const database = @import("database.zig");
const Allocator = std.mem.Allocator;
pub const Digest = struct {
    value: u128 = 0x6c62272e07bb014262b821756295c58d,
    pub fn update(self: *Digest, bytes: []const u8) void {
        for (bytes) |b| self.value = (self.value ^ @as(u128, b)) *% 0x0000000001000000000000000000013b;
    }
    pub fn of(bytes: []const u8) Digest {
        var result: Digest = .{};
        result.update(bytes);
        return result;
    }
};
const Verdict = struct { status: c.Status, origin: ?[]u8 };
pub const CachedRun = struct {
    status: c.Status,
    origin: ?[]u8,
    nodes: []c.ChoiceNode,
    spans: []c.Span,
    pub fn init(gpa: Allocator, status: c.Status, origin: ?[]const u8, nodes: []const c.ChoiceNode, spans: []const c.Span) !CachedRun {
        const owned_origin = if (origin) |v| try gpa.dupe(u8, v) else null;
        errdefer if (owned_origin) |v| gpa.free(v);
        const owned_nodes = try gpa.alloc(c.ChoiceNode, nodes.len);
        var count: usize = 0;
        errdefer {
            for (owned_nodes[0..count]) |*n| n.deinit(gpa);
            gpa.free(owned_nodes);
        }
        for (nodes, owned_nodes) |n, *dest| {
            dest.* = try n.deepClone(gpa);
            count += 1;
        }
        return .{ .status = status, .origin = owned_origin, .nodes = owned_nodes, .spans = try gpa.dupe(c.Span, spans) };
    }
    pub fn deinit(self: *CachedRun, gpa: Allocator) void {
        if (self.origin) |v| gpa.free(v);
        c.deinitNodes(gpa, self.nodes);
        gpa.free(self.spans);
        self.* = undefined;
    }
    fn cost(self: CachedRun, key_len: usize) usize {
        return key_len + self.nodes.len * 56 + self.spans.len * 48 + 80;
    }
};
pub const Recorded = struct {
    duplicate: bool,
    verdict_mismatch: bool,
    mismatched_origin: ?[]u8,
    pub fn deinit(self: *Recorded, gpa: Allocator) void {
        if (self.mismatched_origin) |v| gpa.free(v);
        self.* = undefined;
    }
};
const FullEntry = struct { key: []u8, run: CachedRun };
pub const ExecCache = struct {
    allocator: Allocator,
    verdicts: std.AutoHashMapUnmanaged(u128, Verdict) = .empty,
    full: std.ArrayList(FullEntry) = .empty,
    full_bytes: usize = 0,
    max_full_bytes: usize = 8 << 20,
    pub fn init(gpa: Allocator) ExecCache {
        return .{ .allocator = gpa };
    }
    pub fn clear(self: *ExecCache) void {
        var it = self.verdicts.valueIterator();
        while (it.next()) |v| if (v.origin) |s| self.allocator.free(s);
        self.verdicts.clearRetainingCapacity();
        for (self.full.items) |*entry| {
            self.allocator.free(entry.key);
            entry.run.deinit(self.allocator);
        }
        self.full.clearRetainingCapacity();
        self.full_bytes = 0;
    }
    pub fn deinit(self: *ExecCache) void {
        self.clear();
        self.verdicts.deinit(self.allocator);
        self.full.deinit(self.allocator);
        self.* = undefined;
    }
    pub fn record(self: *ExecCache, key: []const u8, status: c.Status, origin: ?[]const u8, nodes: []const c.ChoiceNode, spans: []const c.Span, keep_full: bool) !Recorded {
        const gpa = self.allocator;
        const digest = Digest.of(key).value;
        var recorded: Recorded = .{ .duplicate = false, .verdict_mismatch = false, .mismatched_origin = null };
        errdefer recorded.deinit(gpa);
        if (self.verdicts.get(digest)) |v| {
            recorded.duplicate = true;
            recorded.verdict_mismatch = v.status != status or !optionalEqual(v.origin, origin);
            const mismatch_origin = v.origin orelse origin;
            recorded.mismatched_origin = if (mismatch_origin) |s| try gpa.dupe(u8, s) else null;
        } else {
            const owned_origin = if (origin) |s| try gpa.dupe(u8, s) else null;
            errdefer if (owned_origin) |s| gpa.free(s);
            try self.verdicts.put(gpa, digest, .{ .status = status, .origin = owned_origin });
        }
        if (keep_full and !recorded.verdict_mismatch and self.find(key) == null) {
            const owned_key = try gpa.dupe(u8, key);
            errdefer gpa.free(owned_key);
            var run = try CachedRun.init(gpa, status, origin, nodes, spans);
            errdefer run.deinit(gpa);
            try self.full.append(gpa, .{ .key = owned_key, .run = run });
            self.full_bytes += run.cost(key.len);
            while (self.full_bytes > self.max_full_bytes and self.full.items.len > 0) {
                var evicted = self.full.orderedRemove(0);
                self.full_bytes -= evicted.run.cost(evicted.key.len);
                gpa.free(evicted.key);
                evicted.run.deinit(gpa);
            }
        }
        return recorded;
    }
    fn find(self: *const ExecCache, key: []const u8) ?*const CachedRun {
        for (self.full.items) |*entry| if (std.mem.eql(u8, entry.key, key)) return &entry.run;
        return null;
    }
    pub fn serve(self: *const ExecCache, key: []const u8) !?CachedRun {
        const run = self.find(key) orelse return null;
        return try CachedRun.init(self.allocator, run.status, run.origin, run.nodes, run.spans);
    }
};
fn optionalEqual(a: ?[]const u8, b: ?[]const u8) bool {
    if (a == null or b == null) return a == null and b == null;
    return std.mem.eql(u8, a.?, b.?);
}
pub const KindMismatch = struct { position: usize, expected: c.ChoiceKind, actual: c.ChoiceKind };
pub const KindLedger = struct {
    allocator: Allocator,
    entries: std.AutoHashMapUnmanaged(u128, c.ChoiceKind) = .empty,
    capacity: usize = 1 << 16,
    pub fn init(gpa: Allocator) KindLedger {
        return .{ .allocator = gpa };
    }
    pub fn clear(self: *KindLedger) void {
        var it = self.entries.valueIterator();
        while (it.next()) |kind| kind.deinit(self.allocator);
        self.entries.clearRetainingCapacity();
    }
    pub fn deinit(self: *KindLedger) void {
        self.clear();
        self.entries.deinit(self.allocator);
        self.* = undefined;
    }
    pub fn observe(self: *KindLedger, nodes: []const c.ChoiceNode) !?KindMismatch {
        var prefix: Digest = .{};
        var scratch: std.ArrayList(u8) = .empty;
        defer scratch.deinit(self.allocator);
        for (nodes, 0..) |*node, position| {
            const kind = node.kind();
            if (self.entries.get(prefix.value)) |expected| {
                if (!expected.eql(kind)) return .{ .position = position, .expected = expected, .actual = kind };
            } else if (self.entries.count() < self.capacity) {
                var owned = try kind.deepClone(self.allocator);
                errdefer owned.deinit(self.allocator);
                try self.entries.put(self.allocator, prefix.value, owned);
            }
            scratch.clearRetainingCapacity();
            if (!try database.serializeOneChoice(self.allocator, &scratch, node.data.valueRef())) return error.InternalError;
            prefix.update(scratch.items);
        }
        return null;
    }
};

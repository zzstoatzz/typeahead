// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const math = @import("math_compat.zig");
const Status = @import("choices.zig").Status;
pub const InvalidBudget = struct { base: u64, per_valid: u64 };
pub fn invalidThresholds(rate: f64, confidence: f64) InvalidBudget {
    return .{ .base = @intFromFloat(@ceil(math.log(1.0 - confidence) / math.log(1.0 - rate)) - 1.0), .per_valid = @intFromFloat(@ceil(1.0 / rate)) };
}
pub fn withinInvalidBudget(invalid: u64, overruns: u64, valid: u64, budget: InvalidBudget) bool {
    return invalid + overruns <= budget.base + budget.per_valid * valid;
}
pub fn shouldGenerateMore(no_bug_yet: bool, calls: u64, first_bug_at: ?u64, last_bug_at: ?u64, shrink_enabled: bool, report_multiple: bool, first_bug_elapsed_ns: ?u128) bool {
    if (no_bug_yet) return true;
    if (!shrink_enabled or !report_multiple) return false;
    if (first_bug_elapsed_ns) |elapsed| if (elapsed > 10 * std.time.ns_per_s) return false;
    const first = first_bug_at orelse return false;
    const last = last_bug_at orelse first;
    const heuristic = @min(first +| 1000, last *| 2);
    return calls < 10 or calls < heuristic;
}
pub fn tooSlow(valid: u64, total_ns: u128, threshold_ns: u128, suppressed: bool) bool {
    return valid < 10 and total_ns > threshold_ns and !suppressed;
}
pub fn tooLarge(valid: u64, overruns: u64, suppressed: bool) bool {
    return valid < 10 and overruns >= 20 and !suppressed;
}
pub fn largeInitial(overran: bool, status: Status, node_count: usize, choice_bound: usize, suppressed: bool) bool {
    return !suppressed and (overran or (status == .valid and node_count *| 2 > choice_bound));
}
pub fn shortlex(a: []const u8, b: []const u8) std.math.Order {
    return if (a.len != b.len) std.math.order(a.len, b.len) else std.mem.order(u8, a, b);
}
pub const TargetingSchedule = struct {
    step: u64,
    next_at: u64,
    pub fn init(max_test_cases: u64) TargetingSchedule {
        const small_cap = @min(max_test_cases / 10, 50);
        const step = @max(@max(max_test_cases / 2, small_cap +| 1), 10);
        return .{ .step = step, .next_at = step };
    }
    pub fn shouldFire(self: *TargetingSchedule, valid: u64) bool {
        if (valid < self.next_at) return false;
        self.next_at = valid +| self.step;
        return true;
    }
};
pub fn formatDuration(gpa: std.mem.Allocator, nanoseconds: u128) ![]u8 {
    const unit: u128 = if (nanoseconds >= std.time.ns_per_s) std.time.ns_per_s else if (nanoseconds >= std.time.ns_per_ms) std.time.ns_per_ms else if (nanoseconds >= std.time.ns_per_us) std.time.ns_per_us else 1;
    const suffix: []const u8 = if (unit == std.time.ns_per_s) "s" else if (unit == std.time.ns_per_ms) "ms" else if (unit == std.time.ns_per_us) "µs" else "ns";
    const whole = nanoseconds / unit;
    const fraction = nanoseconds % unit;
    if (fraction == 0) return std.fmt.allocPrint(gpa, "{d}{s}", .{ whole, suffix });
    var buffer: [9]u8 = undefined;
    const digits = if (unit == std.time.ns_per_s) try std.fmt.bufPrint(&buffer, "{d:0>9}", .{fraction}) else if (unit == std.time.ns_per_ms) try std.fmt.bufPrint(&buffer, "{d:0>6}", .{fraction}) else try std.fmt.bufPrint(&buffer, "{d:0>3}", .{fraction});
    return std.fmt.allocPrint(gpa, "{d}.{s}{s}", .{ whole, std.mem.trimEnd(u8, digits, "0"), suffix });
}

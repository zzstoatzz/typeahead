// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/mod.rs; see provenance.
const std = @import("std");
pub const ShrinkPass = @import("shrinker/scheduling.zig").ShrinkPass;
pub const search = @import("shrinker/search.zig");
pub const choices = @import("choices.zig");
const c = choices;
const Allocator = std.mem.Allocator;
pub const database = @import("database.zig");
pub const CachedRun = @import("exec_cache.zig").CachedRun;
pub const SweepMode = enum { fast, confirm };
pub const Request = union(enum) { full: []const c.ChoiceNode, probe: struct { prefix: []const c.ChoiceValue, max_size: usize } };
pub const Outcome = struct { interesting: bool, run: CachedRun };
pub const Eval = struct {
    context: *anyopaque,
    call: *const fn (*anyopaque, Request) anyerror!Outcome,
    set_sweep_mode: ?*const fn (*anyopaque, SweepMode) ?SweepMode = null,
    candidate_adopted: ?*const fn (*anyopaque) anyerror!void = null,
};
pub const Replacement = struct { index: usize, value: c.ChoiceValue };
pub const Shrinker = struct {
    const Self = @This();
    allocator: Allocator,
    evaluator: Eval,
    current_nodes: []c.ChoiceNode,
    current_spans: []c.Span,
    improvements: usize = 0,
    downgraded: std.ArrayList([]c.ChoiceValue) = .empty,
    max_improvements: usize = 500,
    calls: usize = 0,
    calls_at_last_shrink: usize = 0,
    max_stall: usize = 500,
    last_checkpoint_nodes: []c.ChoiceNode,
    all_changed_nodes: std.AutoHashMapUnmanaged(usize, void) = .empty,
    sweep: SweepMode = .fast,
    timed_out: bool = false,
    deadline: ?i128 = null,
    clock_context: ?*anyopaque = null,
    now: ?*const fn (?*anyopaque) ?i128 = null,
    debug_context: ?*anyopaque = null,
    debug: ?*const fn (?*anyopaque, []const u8) void = null,
    pub fn init(gpa: Allocator, evaluator: Eval, nodes: []const c.ChoiceNode, spans: []const c.Span) !Self {
        const owned = try c.cloneNodes(gpa, nodes);
        errdefer c.deinitNodes(gpa, owned);
        const checkpoint = try c.cloneNodes(gpa, nodes);
        errdefer c.deinitNodes(gpa, checkpoint);
        return .{ .allocator = gpa, .evaluator = evaluator, .current_nodes = owned, .current_spans = try gpa.dupe(c.Span, spans), .last_checkpoint_nodes = checkpoint };
    }
    pub fn fixateShrinkPasses(self: *Self, passes: []ShrinkPass) !void {
        return @import("shrinker/scheduling.zig").fixateShrinkPasses(self, passes);
    }
    pub fn removeDiscarded(self: *Self) !bool {
        return @import("shrinker/spans.zig").removeDiscarded(self);
    }
    pub fn tryTrivialSpans(self: *Self) !void {
        return @import("shrinker/spans.zig").tryTrivialSpans(self);
    }
    pub fn replaceInt(self: *Self, i: usize, value: *const c.BigInt) anyerror!bool {
        return @import("shrinker/integers.zig").replaceInt(self, i, value);
    }
    pub fn zeroChoices(self: *Self) !void {
        return @import("shrinker/integers.zig").zeroChoices(self);
    }
    pub fn swapIntegerSign(self: *Self) !void {
        return @import("shrinker/integers.zig").swapIntegerSign(self);
    }
    pub fn lowerCommonNodeOffset(self: *Self) anyerror!void {
        return @import("shrinker/integers.zig").lowerCommonNodeOffset(self);
    }
    pub fn initialCoarseReduction(self: *Self) !void {
        return @import("shrinker/coarse.zig").initialCoarseReduction(self);
    }
    pub fn binarySearchIntegerTowardsZero(self: *Self) !void {
        return @import("shrinker/integers.zig").binarySearchIntegerTowardsZero(self);
    }
    pub fn deleteChunks(self: *Self) !void {
        return @import("shrinker/deletion.zig").deleteChunks(self);
    }
    pub fn bindDeletion(self: *Self) !void {
        return @import("shrinker/deletion.zig").bindDeletion(self);
    }
    pub fn tryReplaceWithDeletion(self: *Self, idx: usize, value: *const c.ChoiceValue, expected_len: usize) !bool {
        return @import("shrinker/deletion.zig").tryReplaceWithDeletion(self, idx, value, expected_len);
    }
    pub fn passToDescendant(self: *Self) !void {
        return @import("shrinker/spans.zig").passToDescendant(self);
    }
    pub fn reorderSpans(self: *Self) !void {
        return @import("shrinker/spans.zig").reorderSpans(self);
    }
    pub fn deleteSpans(self: *Self) !void {
        return @import("shrinker/spans.zig").deleteSpans(self);
    }
    pub fn redistributeIntegers(self: *Self) !void {
        return @import("shrinker/integers.zig").redistributeIntegers(self);
    }
    pub fn lowerIntegersTogether(self: *Self) !void {
        return @import("shrinker/integers.zig").lowerIntegersTogether(self);
    }
    pub fn shrinkDuplicates(self: *Self) !void {
        return @import("shrinker/integers.zig").shrinkDuplicates(self);
    }
    pub fn nodeProgram(self: *Self, n: usize) !void {
        return @import("shrinker/deletion.zig").nodeProgram(self, n);
    }
    pub fn deleteBetweenRepeats(self: *Self) !void {
        return @import("shrinker/deletion.zig").deleteBetweenRepeats(self);
    }
    pub fn minimizeIndividualChoices(self: *Self) !void {
        return @import("shrinker/deletion.zig").minimizeIndividualChoices(self);
    }
    pub fn lowerAndBump(self: *Self) !void {
        return @import("shrinker/index_passes.zig").lowerAndBump(self);
    }
    pub fn tryShorteningViaIncrement(self: *Self) !void {
        return @import("shrinker/index_passes.zig").tryShorteningViaIncrement(self);
    }
    pub fn shrinkBytes(self: *Self) !void {
        return @import("shrinker/bytes.zig").shrinkBytes(self);
    }
    pub fn redistributeBytesPairs(self: *Self) !void {
        return @import("shrinker/bytes.zig").redistributeBytesPairs(self);
    }
    pub fn shrinkFloats(self: *Self) !void {
        return @import("shrinker/floats.zig").shrinkFloats(self);
    }
    pub fn redistributeNumericPairs(self: *Self) !void {
        return @import("shrinker/floats.zig").redistributeNumericPairs(self);
    }
    pub fn scaleNumericPairs(self: *Self) !void {
        return @import("shrinker/floats.zig").scaleNumericPairs(self);
    }
    pub fn shrinkStrings(self: *Self) !void {
        return @import("shrinker/strings.zig").shrinkStrings(self);
    }
    pub fn redistributeStringPairs(self: *Self) !void {
        return @import("shrinker/strings.zig").redistributeStringPairs(self);
    }
    pub fn lowerDuplicatedCharacters(self: *Self) !void {
        return @import("shrinker/strings.zig").lowerDuplicatedCharacters(self);
    }
    pub fn normalizeUnicodeChars(self: *Self) !void {
        return @import("shrinker/strings.zig").normalizeUnicodeChars(self);
    }
    pub fn mutateAndShrink(self: *Self) !void {
        return @import("shrinker/mutation.zig").mutateAndShrink(self);
    }
    pub fn shrinkCloneStreams(self: *Self) anyerror!void {
        return @import("shrinker/clones.zig").shrinkCloneStreams(self);
    }
    fn removeDiscardedPass(self: *Self) anyerror!void {
        _ = try self.removeDiscarded();
    }
    fn nodeProgram1(self: *Self) anyerror!void {
        return self.nodeProgram(1);
    }
    fn nodeProgram2(self: *Self) anyerror!void {
        return self.nodeProgram(2);
    }
    fn nodeProgram3(self: *Self) anyerror!void {
        return self.nodeProgram(3);
    }
    fn nodeProgram4(self: *Self) anyerror!void {
        return self.nodeProgram(4);
    }
    fn nodeProgram5(self: *Self) anyerror!void {
        return self.nodeProgram(5);
    }
    pub fn shrink(self: *Self) anyerror!void {
        var passes = [_]ShrinkPass{
            .{ .name = "remove_discarded", .run = removeDiscardedPass },
            .{ .name = "delete_spans", .run = deleteSpans },
            .{ .name = "shrink_duplicates", .run = shrinkDuplicates },
            .{ .name = "try_trivial_spans", .run = tryTrivialSpans },
            .{ .name = "pass_to_descendant", .run = passToDescendant },
            .{ .name = "reorder_spans", .run = reorderSpans },
            .{ .name = "node_program_5", .run = nodeProgram5 },
            .{ .name = "node_program_4", .run = nodeProgram4 },
            .{ .name = "node_program_3", .run = nodeProgram3 },
            .{ .name = "node_program_2", .run = nodeProgram2 },
            .{ .name = "node_program_1", .run = nodeProgram1 },
            .{ .name = "delete_chunks", .run = deleteChunks },
            .{ .name = "delete_between_repeats", .run = deleteBetweenRepeats },
            .{ .name = "zero_choices", .run = zeroChoices },
            .{ .name = "swap_integer_sign", .run = swapIntegerSign },
            .{ .name = "binary_search_integer_towards_zero", .run = binarySearchIntegerTowardsZero },
            .{ .name = "bind_deletion", .run = bindDeletion },
            .{ .name = "minimize_individual_choices", .run = minimizeIndividualChoices },
            .{ .name = "lower_common_node_offset", .run = lowerCommonNodeOffset },
            .{ .name = "redistribute_integers", .run = redistributeIntegers },
            .{ .name = "lower_integers_together", .run = lowerIntegersTogether },
            .{ .name = "sort_values", .run = sortValues },
            .{ .name = "swap_adjacent_blocks", .run = swapAdjacentBlocks },
            .{ .name = "shrink_floats", .run = shrinkFloats },
            .{ .name = "redistribute_numeric_pairs", .run = redistributeNumericPairs },
            .{ .name = "scale_numeric_pairs", .run = scaleNumericPairs },
            .{ .name = "shrink_bytes", .run = shrinkBytes },
            .{ .name = "redistribute_bytes_pairs", .run = redistributeBytesPairs },
            .{ .name = "shrink_strings", .run = shrinkStrings },
            .{ .name = "lower_duplicated_characters", .run = lowerDuplicatedCharacters },
            .{ .name = "normalize_unicode_chars", .run = normalizeUnicodeChars },
            .{ .name = "redistribute_string_pairs", .run = redistributeStringPairs },
            .{ .name = "lower_and_bump", .run = lowerAndBump },
            .{ .name = "try_shortening_via_increment", .run = tryShorteningViaIncrement },
            .{ .name = "shrink_clone_streams", .run = shrinkCloneStreams },
            .{ .name = "mutate_and_shrink", .run = mutateAndShrink, .stochastic = true },
        };
        const initial_size = self.current_nodes.len;
        const initial_calls = self.calls;
        const outcome = self.fixateShrinkPasses(&passes);
        try @import("shrinker/scheduling.zig").emitProfileReport(self, &passes, initial_size, initial_calls);
        outcome catch |err| {
            if (err != error.ShrinkStop) return err;
        };
    }
    pub fn passStats(self: *Self, passes: []const ShrinkPass) ![]@import("shrinker/scheduling.zig").PassStat {
        return @import("shrinker/scheduling.zig").passStats(self.allocator, passes);
    }
    pub fn sortValues(self: *Self) !void {
        return @import("shrinker/sequence.zig").sortValues(self);
    }
    pub fn swapAdjacentBlocks(self: *Self) !void {
        return @import("shrinker/sequence.zig").swapAdjacentBlocks(self);
    }
    pub fn deinit(self: *Self) void {
        c.deinitNodes(self.allocator, self.current_nodes);
        self.allocator.free(self.current_spans);
        c.deinitNodes(self.allocator, self.last_checkpoint_nodes);
        for (self.downgraded.items) |v| c.deinitValues(self.allocator, v);
        self.downgraded.deinit(self.allocator);
        self.all_changed_nodes.deinit(self.allocator);
    }
    pub fn pastDeadline(self: *Self) bool {
        if (self.timed_out) return true;
        if (self.deadline) |d| if (self.now) |now| {
            if (now(self.clock_context)) |time| {
                if (time >= d) {
                    self.timed_out = true;
                    return true;
                }
            }
        };
        return false;
    }
    pub fn debugMsg(self: *Self, msg: []const u8) void {
        if (self.debug) |f| f(self.debug_context, msg);
    }
    pub fn runTestFn(self: *Self, req: Request) !Outcome {
        if (self.pastDeadline()) return error.ShrinkStop;
        return self.evaluator.call(self.evaluator.context, req);
    }
    fn stalled(self: *Self) bool {
        return self.improvements > 0 and self.calls -| self.calls_at_last_shrink >= self.max_stall;
    }
    pub fn consider(self: *Self, nodes: []const c.ChoiceNode) anyerror!bool {
        if (try c.nodesOrder(self.allocator, nodes, self.current_nodes) == .eq) return true;
        const cmp = nodes[0..@min(nodes.len, self.current_nodes.len)];
        if (try c.nodesOrder(self.allocator, self.current_nodes, cmp) == .lt) return false;
        if (nodes.len == self.current_nodes.len) {
            for (nodes, self.current_nodes) |*candidate, *current| {
                if (current.was_forced and !candidate.data.valueRef().eql(current.data.valueRef())) return false;
            }
        }
        if (self.improvements >= self.max_improvements) return error.ShrinkStop;
        if (self.sweep == .fast and self.stalled()) return false;
        var out = try self.runTestFn(.{ .full = nodes });
        defer out.run.deinit(self.allocator);
        self.calls += 1;
        if (out.interesting and try c.nodesOrder(self.allocator, out.run.nodes, self.current_nodes) == .lt) {
            try self.acceptImprovement(out.run.nodes, out.run.spans);
            return true;
        }
        return false;
    }
    pub fn considerReshaped(self: *Self, req: Request) anyerror!?[]c.ChoiceNode {
        if (self.improvements >= self.max_improvements) return error.ShrinkStop;
        if (self.stalled()) return null;
        var out = try self.runTestFn(req);
        defer out.run.deinit(self.allocator);
        self.calls += 1;
        if (out.interesting and try c.nodesOrder(self.allocator, out.run.nodes, self.current_nodes) == .lt) try self.acceptImprovement(out.run.nodes, out.run.spans);
        return try c.cloneNodes(self.allocator, out.run.nodes);
    }
    pub fn probe(self: *Self, prefix: []const c.ChoiceValue, max_size: usize) anyerror!void {
        if (self.improvements >= self.max_improvements) return error.ShrinkStop;
        if (self.sweep == .fast and self.stalled()) return;
        var out = try self.runTestFn(.{ .probe = .{ .prefix = prefix, .max_size = max_size } });
        defer out.run.deinit(self.allocator);
        self.calls += 1;
        if (out.interesting and try c.nodesOrder(self.allocator, out.run.nodes, self.current_nodes) == .lt) try self.acceptImprovement(out.run.nodes, out.run.spans);
    }
    pub fn acceptImprovement(self: *Self, nodes: []const c.ChoiceNode, spans: []const c.Span) anyerror!void {
        const new = try c.cloneNodes(self.allocator, nodes);
        errdefer c.deinitNodes(self.allocator, new);
        const new_spans = try self.allocator.dupe(c.Span, spans);
        errdefer self.allocator.free(new_spans);
        const old = try self.allocator.alloc(c.ChoiceValue, self.current_nodes.len);
        var count: usize = 0;
        errdefer {
            for (old[0..count]) |*v| v.deinit(self.allocator);
            self.allocator.free(old);
        }
        for (self.current_nodes, old) |*n, *v| {
            v.* = try n.value(self.allocator);
            count += 1;
        }
        try self.downgraded.ensureUnusedCapacity(self.allocator, 1);
        try self.updateChangeTracking(nodes);
        if (self.evaluator.candidate_adopted) |f| try f(self.evaluator.context);
        self.downgraded.appendAssumeCapacity(old);
        self.improvements += 1;
        self.max_stall = @max(self.max_stall, (self.calls -| self.calls_at_last_shrink) *| 2);
        self.calls_at_last_shrink = self.calls;
        c.deinitNodes(self.allocator, self.current_nodes);
        self.allocator.free(self.current_spans);
        self.current_nodes = new;
        self.current_spans = new_spans;
    }
    fn updateChangeTracking(self: *Self, nodes: []const c.ChoiceNode) !void {
        if (self.last_checkpoint_nodes.len != nodes.len) {
            self.all_changed_nodes.clearRetainingCapacity();
            return;
        }
        for (self.last_checkpoint_nodes, nodes) |a, b| {
            if (std.meta.activeTag(a.data) != std.meta.activeTag(b.data)) {
                self.all_changed_nodes.clearRetainingCapacity();
                return;
            }
        }
        for (self.last_checkpoint_nodes, nodes, 0..) |*a, *b, i| {
            if (!a.data.valueRef().eql(b.data.valueRef())) try self.all_changed_nodes.put(self.allocator, i, {});
        }
    }
    pub fn clearChangeTracking(self: *Self) !void {
        const new = try c.cloneNodes(self.allocator, self.current_nodes);
        c.deinitNodes(self.allocator, self.last_checkpoint_nodes);
        self.last_checkpoint_nodes = new;
        self.all_changed_nodes.clearRetainingCapacity();
    }
    pub fn replace(self: *Self, values: []const Replacement) anyerror!bool {
        const attempt = try c.cloneNodes(self.allocator, self.current_nodes);
        defer c.deinitNodes(self.allocator, attempt);
        for (values) |*v| {
            if (v.index >= attempt.len or attempt[v.index].was_forced) return false;
            const replaced = try attempt[v.index].withValue(self.allocator, &v.value) orelse return false;
            attempt[v.index].deinit(self.allocator);
            attempt[v.index] = replaced;
        }
        return self.consider(attempt);
    }
};

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");

pub const Evidence = struct {
    failures: u64 = 0,
    replays: u64 = 0,

    pub fn record(self: *Evidence, failed: bool) void {
        self.replays += 1;
        self.failures += @intFromBool(failed);
    }

    pub fn fails(self: Evidence) u64 {
        return self.failures;
    }

    pub fn runs(self: Evidence) u64 {
        return self.replays;
    }

    pub fn lowerBound(self: Evidence) f64 {
        return wilsonBound(@floatFromInt(self.failures), @floatFromInt(self.replays), false);
    }

    pub fn upperBound(self: Evidence) f64 {
        return wilsonBound(@floatFromInt(self.failures), @floatFromInt(self.replays), true);
    }
};

pub fn wilsonBound(fails: f64, runs: f64, upper: bool) f64 {
    if (runs <= 0) return if (upper) 1 else 0;
    const z: f64 = 1.96;
    const p = fails / runs;
    const z2 = z * z;
    const denominator = 1 + z2 / runs;
    const center = p + z2 / (2 * runs);
    const margin = z * @sqrt((p * (1 - p) + z2 / (4 * runs)) / runs);
    return std.math.clamp((if (upper) center + margin else center - margin) / denominator, 0, 1);
}

pub const GATE_RUNS: u64 = 10;
pub const CONFIRM_CAP: u64 = 40;
pub const CONFIRM_MIN_FAILS: u64 = 4;
pub const BAR_ATTEMPTS_PER_RUN: u64 = 5;
pub const BACKTRACK_BAR_ATTEMPTS: u64 = 3;
pub const GAUNTLET_CAP: u64 = 30;
pub const GAUNTLET_GAMMA: f64 = 0.8;
pub const GAUNTLET_FLOOR: f64 = 0.05;
pub const GAUNTLET_MIN_FAILS: u64 = 4;
pub const RETENTION_HIGH_WATER: f64 = 0.8;
pub const ANCHOR_SEED_RUNS: u64 = 20;
pub const GAUNTLET_ALPHA_BUDGET: f64 = 0.02;
pub const GAUNTLET_MIN_FAILS_CEILING: u64 = 8;
pub const CHARGE_FLUKE_RATE: f64 = 0.02;
pub const BOOST_POOL: usize = 16;
pub const BOOST_HOLDOUT: u64 = ANCHOR_SEED_RUNS;
pub const BOOST_RELIABILITY_FLOOR: f64 = 0.30;
pub const TARGET_ND_POOL: usize = 16;
pub const TARGET_ND_HOLDOUT: u64 = ANCHOR_SEED_RUNS;
pub const TARGET_ND_RACES: u64 = 4;
pub const TARGET_FAILURE_RATE: f64 = 0.1;
pub const REUSE_MISS_TOLERANCE: f64 = 0.05;
pub const FINAL_REPLAY_FRESH: u64 = 4;
pub const V1_BLOB_REPLAYS: u64 = 4;

pub const BarVerdict = enum { accept, reject, continue_replaying };
pub const GauntletVerdict = enum { accept, reject, continue_replaying };

pub fn discoveryBar(evidence: Evidence) BarVerdict {
    if (evidence.failures >= CONFIRM_MIN_FAILS) return .accept;
    if (evidence.failures == 0 and evidence.replays >= GATE_RUNS) return .reject;
    if (evidence.failures + (CONFIRM_CAP -| evidence.replays) < CONFIRM_MIN_FAILS) return .reject;
    return .continue_replaying;
}

pub fn anchorCeiling() f64 {
    return (Evidence{ .failures = ANCHOR_SEED_RUNS, .replays = ANCHOR_SEED_RUNS }).lowerBound();
}

pub fn gauntletThreshold(anchor: f64) f64 {
    const gamma = if (anchor >= RETENTION_HIGH_WATER) @as(f64, 1) else GAUNTLET_GAMMA;
    return @max(gamma * anchor, GAUNTLET_FLOOR);
}

pub fn gauntlet(evidence: Evidence, anchor: f64, min_fails: u64) GauntletVerdict {
    return gauntletAt(evidence, gauntletThreshold(anchor), min_fails);
}

pub fn gauntletAt(evidence: Evidence, threshold: f64, min_fails: u64) GauntletVerdict {
    if (evidence.failures >= min_fails and evidence.lowerBound() >= threshold) return .accept;
    if (evidence.upperBound() < threshold or evidence.replays >= GAUNTLET_CAP) return .reject;
    return .continue_replaying;
}

pub const GauntletSpend = struct {
    remaining: f64 = GAUNTLET_ALPHA_BUDGET,
    min_fails: u64 = GAUNTLET_MIN_FAILS,

    pub fn charge(self: *GauntletSpend, seed: Evidence, anchor: f64, drive: bool, pinned: ?u64) u64 {
        const threshold = gauntletThreshold(anchor);
        if (pinned) |minimum| {
            self.remaining -= proposalCharge(seed, threshold, minimum, drive);
            return minimum;
        }
        while (true) {
            const cost = proposalCharge(seed, threshold, self.min_fails, drive);
            if (cost <= self.remaining or self.min_fails >= GAUNTLET_MIN_FAILS_CEILING) {
                self.remaining -= cost;
                return self.min_fails;
            }
            self.min_fails += 1;
        }
    }
};

fn proposalCharge(seed: Evidence, threshold: f64, min_fails: u64, drive: bool) f64 {
    return if (drive) gauntletAlpha(seed, threshold, min_fails) else CHARGE_FLUKE_RATE * gauntletAlpha(.{ .failures = seed.failures + 1, .replays = seed.replays + 1 }, threshold, min_fails);
}

pub fn gauntletAlpha(seed: Evidence, threshold: f64, min_fails: u64) f64 {
    switch (gauntletAt(seed, threshold, min_fails)) {
        .accept => return 1,
        .reject => return 0,
        .continue_replaying => {},
    }
    var mass: [GAUNTLET_CAP + 1]f64 = @splat(0);
    mass[@intCast(seed.failures)] = 1;
    var accept: f64 = 0;
    var runs = seed.replays;
    while (runs <= GAUNTLET_CAP) : (runs += 1) {
        var next: [GAUNTLET_CAP + 1]f64 = @splat(0);
        var live = false;
        for (mass[0..@intCast(runs + 1)], 0..) |probability, fails| {
            if (probability == 0) continue;
            switch (gauntletAt(.{ .failures = fails, .replays = runs }, threshold, min_fails)) {
                .accept => accept += probability,
                .reject => {},
                .continue_replaying => {
                    next[fails + 1] += probability * CHARGE_FLUKE_RATE;
                    next[fails] += probability * (1 - CHARGE_FLUKE_RATE);
                    live = true;
                },
            }
        }
        if (!live) break;
        mass = next;
    }
    return accept;
}

pub fn boostKeep(candidates: usize) usize {
    return candidates / 2 + candidates % 2;
}

pub fn targetAdopt(beats: u64, runs: u64) bool {
    return wilsonBound(@floatFromInt(beats), @floatFromInt(runs), false) > 0.5;
}

pub fn targetMedian(gpa: std.mem.Allocator, scores: []const f64) std.mem.Allocator.Error!?f64 {
    if (scores.len == 0) return null;
    const sorted = try gpa.dupe(f64, scores);
    defer gpa.free(sorted);
    std.mem.sort(f64, sorted, {}, struct {
        fn less(_: void, left: f64, right: f64) bool {
            const a: i64 = @bitCast(left);
            const b: i64 = @bitCast(right);
            const a_key = a ^ @as(i64, @intCast(@as(u64, @bitCast(a >> 63)) >> 1));
            const b_key = b ^ @as(i64, @intCast(@as(u64, @bitCast(b >> 63)) >> 1));
            return a_key < b_key;
        }
    }.less);
    return sorted[sorted.len / 2];
}

pub fn continuationBudget(len: usize) usize {
    return len + @max(@as(usize, 4), len / 8);
}

pub fn replayBudget(rate: f64, tolerance: f64) u64 {
    const result = @ceil(@log(tolerance) / @log(1 - rate));
    if (std.math.isNan(result) or result <= 0) return 0;
    if (result >= @as(f64, @floatFromInt(std.math.maxInt(u64)))) return std.math.maxInt(u64);
    return @intFromFloat(result);
}

pub fn reuseReplayBudget() u64 {
    return replayBudget(TARGET_FAILURE_RATE, REUSE_MISS_TOLERANCE);
}

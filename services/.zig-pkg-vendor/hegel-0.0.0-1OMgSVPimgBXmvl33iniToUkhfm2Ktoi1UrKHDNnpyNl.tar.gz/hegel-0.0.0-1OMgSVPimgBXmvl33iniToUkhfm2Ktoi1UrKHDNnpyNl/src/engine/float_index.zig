// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");

pub fn encodeExponent(biased_exp: u64) u64 {
    if (biased_exp == 2047) return 2047;
    return if (biased_exp >= 1023) biased_exp - 1023 else 2046 - biased_exp;
}

pub fn decodeExponent(encoded: u64) u64 {
    if (encoded == 2047) return 2047;
    return if (encoded <= 1023) encoded + 1023 else 2046 - encoded;
}

pub fn reverseBitsN(value: u64, n: u64) u64 {
    if (n == 0) return 0;
    return @bitReverse(value) >> @as(u6, @intCast(64 - n));
}

pub fn updateMantissa(unbiased_exp: i64, mantissa: u64) u64 {
    if (unbiased_exp <= 0) return reverseBitsN(mantissa, 52);
    if (unbiased_exp <= 51) {
        const n_frac: u6 = @intCast(52 - unbiased_exp);
        const mask = (@as(u64, 1) << n_frac) - 1;
        const frac = mantissa & mask;
        return (mantissa ^ frac) | reverseBitsN(frac, n_frac);
    }
    return mantissa;
}

pub fn floatToIndex(value: f64) u64 {
    if (!std.math.signbit(value) and std.math.isFinite(value) and value < @as(f64, @floatFromInt(@as(u64, 1) << 56))) {
        const integral: u64 = @intFromFloat(value);
        if (@as(f64, @floatFromInt(integral)) == value) return integral;
    }
    const bits: u64 = @bitCast(value);
    const exponent = (bits >> 52) & 0x7ff;
    const mantissa = bits & ((@as(u64, 1) << 52) - 1);
    const unbiased: i64 = @as(i64, @intCast(exponent)) - 1023;
    return (@as(u64, 1) << 63) | (encodeExponent(exponent) << 52) | updateMantissa(unbiased, mantissa);
}

pub fn indexToFloat(index: u64) f64 {
    if (index >> 63 == 0) return @floatFromInt(index & ((@as(u64, 1) << 56) - 1));
    const exponent = decodeExponent((index >> 52) & 0x7ff);
    const mantissa = index & ((@as(u64, 1) << 52) - 1);
    const unbiased: i64 = @as(i64, @intCast(exponent)) - 1023;
    return @bitCast((exponent << 52) | updateMantissa(unbiased, mantissa));
}

pub fn simplestInRange(lo: f64, hi: f64) error{InternalError}!f64 {
    if (!(lo > 0 and lo <= hi and std.math.isFinite(hi))) return error.InternalError;
    const mask: u64 = (@as(u64, 1) << 52) - 1;
    const integral = @ceil(lo);
    if (integral <= hi and integral < @as(f64, @floatFromInt(@as(u64, 1) << 56))) return integral;
    const lo_bits: u64 = @bitCast(lo);
    const hi_bits: u64 = @bitCast(hi);
    const e_lo = lo_bits >> 52;
    const e_hi = hi_bits >> 52;
    const m_lo = lo_bits & mask;
    const m_hi = hi_bits & mask;
    const e = if (e_lo >= 1023) e_lo else e_hi;
    if (e_lo < 1023 and e_hi >= 1023) return error.InternalError;
    const m_min = if (e_lo >= 1023 or e_lo == e_hi) m_lo else 0;
    const m_max = if (e_lo >= 1023 and e_hi != e_lo) mask else m_hi;
    const unbiased: i64 = @as(i64, @intCast(e)) - 1023;
    const m_best = if (unbiased >= 52) m_min else blk: {
        const n_frac: u6 = if (unbiased <= 0) 52 else @intCast(52 - unbiased);
        const low_mask = (@as(u64, 1) << n_frac) - 1;
        const h = m_min >> n_frac;
        if (m_max >> n_frac != h) return error.InternalError;
        break :blk (h << n_frac) | try minReversedInRange(m_min & low_mask, m_max & low_mask, n_frac);
    };
    return @bitCast((e << 52) | m_best);
}

pub fn minReversedInRange(lo: u64, hi: u64, n: u32) error{InternalError}!u64 {
    if (n == 0) {
        if (lo != 0 or hi != 0) return error.InternalError;
        return 0;
    }
    const k_lo = lo / 2 + lo % 2;
    const k_hi = hi / 2;
    if (k_lo <= k_hi) return try minReversedInRange(k_lo, k_hi, n - 1) * 2;
    if (lo != hi) return error.InternalError;
    return lo;
}

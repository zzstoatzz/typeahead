// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.
const std = @import("std");
pub const FloatDisplay = struct {
    value: f64,
    pub fn format(self: FloatDisplay, writer: *std.Io.Writer) std.Io.Writer.Error!void {
        if (std.math.isNan(self.value)) return writer.writeAll("NaN");
        return writer.print("{d}", .{self.value});
    }
};
pub fn floatDisplay(value: f64) FloatDisplay {
    return .{ .value = value };
}

pub const PaddedDecimal = struct {
    value: i64,
    width: usize,
    pub fn format(self: PaddedDecimal, writer: *std.Io.Writer) std.Io.Writer.Error!void {
        var buffer: [32]u8 = undefined;
        const digits = std.fmt.bufPrint(&buffer, "{d}", .{@abs(self.value)}) catch unreachable;
        if (self.value < 0) try writer.writeByte('-');
        const prefix: usize = @intFromBool(self.value < 0);
        for (0..self.width -| (digits.len + prefix)) |_| try writer.writeByte('0');
        try writer.writeAll(digits);
    }
};
pub fn paddedDecimal(value: i64, width: usize) PaddedDecimal {
    return .{ .value = value, .width = width };
}

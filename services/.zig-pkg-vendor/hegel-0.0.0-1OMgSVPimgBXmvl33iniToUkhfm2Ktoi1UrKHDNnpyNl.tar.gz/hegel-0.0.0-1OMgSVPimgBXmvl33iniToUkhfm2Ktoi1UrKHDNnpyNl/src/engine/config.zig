// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/config.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const profiles = @import("profiles.zig");
const settings = @import("settings.zig");
const parser = @import("vendor/z_toml/parser.zig");
const types = @import("vendor/z_toml/value.zig");
const spans_mod = @import("vendor/z_toml/span.zig");
const hints = @import("vendor/z_toml/output/hints.zig");
const Allocator = std.mem.Allocator;
pub const Diagnostic = struct {
    line: usize = 0,
    message: ?[]u8 = null,
    path: ?[]u8 = null,
    pub fn deinit(self: *Diagnostic, gpa: Allocator) void {
        if (self.message) |v| gpa.free(v);
        if (self.path) |v| gpa.free(v);
        self.* = .{};
    }
};
pub const OwnedConfig = struct {
    arena: std.heap.ArenaAllocator,
    config: profiles.Config = .{},
    pub fn view(self: *const OwnedConfig) profiles.Config {
        return self.config;
    }
    pub fn deinit(self: *OwnedConfig) void {
        self.arena.deinit();
        self.* = undefined;
    }
};
const Context = struct {
    allocator: Allocator,
    diagnostic_allocator: Allocator,
    diagnostic: ?*Diagnostic,
    text: []const u8,
    spans: spans_mod.ParseSpans,
    fn fail(self: *Context, line_no: usize, comptime format: []const u8, args: anytype) error{ InvalidConfig, OutOfMemory } {
        if (self.diagnostic) |out| {
            out.line = line_no;
            out.message = try std.fmt.allocPrint(self.diagnostic_allocator, format, args);
        }
        return error.InvalidConfig;
    }
    fn line(self: *const Context, path: []const hints.PathSegment) usize {
        const key: hints.HintPath = .{ .segments = path };
        var offset: usize = 0;
        if (self.spans.entries) |entries| {
            if (entries.get(key)) |entry| {
                offset = entry.value.start;
                return 1 + std.mem.count(u8, self.text[0..@min(offset, self.text.len)], "\n");
            }
        }
        if (self.spans.headers) |headers| {
            if (headers.get(key)) |entry| offset = entry.header.start;
        }
        return 1 + std.mem.count(u8, self.text[0..@min(offset, self.text.len)], "\n");
    }
    fn string(self: *Context, value: types.Value, line_no: usize, key: []const u8) ![]const u8 {
        return switch (value) {
            .string => |s| s,
            else => self.fail(line_no, "`{s}` expects a string, got {s}", .{ key, kind(value) }),
        };
    }
    fn boolean(self: *Context, value: types.Value, line_no: usize, key: []const u8) !bool {
        return switch (value) {
            .boolean => |v| v,
            else => self.fail(line_no, "`{s}` expects a boolean, got {s}", .{ key, kind(value) }),
        };
    }
    fn integer(self: *Context, value: types.Value, line_no: usize, key: []const u8, min: i128, max: i128) !u64 {
        if (value != .integer) return self.fail(line_no, "`{s}` expects an integer, got {s}", .{ key, kind(value) });
        const n = value.integer.value;
        if (n < min or n > max) return self.fail(line_no, "`{s}` must be between {d} and {d}, got {d}", .{ key, min, max, n });
        return @intCast(n);
    }
    fn strings(self: *Context, value: types.Value, line_no: usize, key: []const u8) ![]const []const u8 {
        if (value != .array) return self.fail(line_no, "`{s}` expects an array of strings, got {s}", .{ key, kind(value) });
        const result = try self.allocator.alloc([]const u8, value.array.items.len);
        for (value.array.items, result) |item, *dest| {
            if (item != .string) return self.fail(line_no, "elements of `{s}` must be strings, got {s}", .{ key, kind(item) });
            dest.* = item.string;
        }
        return result;
    }
    fn name(self: *Context, name_value: []const u8, line_no: usize) !void {
        if (!profiles.validName(name_value)) return self.fail(line_no, "invalid profile name \"{s}\": use only ASCII letters, digits, '-' and '_'", .{name_value});
    }
    fn assign(self: *Context, delta: *profiles.ProfileDelta, key: []const u8, value: types.Value, line_no: usize) !void {
        if (eq(key, "default")) return self.fail(line_no, "`default` is a top-level key, not a profile setting: move it above the first [profiles.<name>] header", .{});
        if (eq(key, "extends")) {
            const name_value = try self.string(value, line_no, key);
            try self.name(name_value, line_no);
            delta.extends = name_value;
            return;
        }
        if (eq(key, "test_cases")) {
            delta.test_cases = try self.integer(value, line_no, key, 1, std.math.maxInt(u64));
            return;
        }
        if (eq(key, "seed")) {
            if (value == .string) {
                if (!eq(value.string, "none")) return self.fail(line_no, "`seed` expects an integer or \"none\", got \"{s}\"", .{value.string});
                delta.seed = @as(?u64, null);
            } else delta.seed = try self.integer(value, line_no, key, 0, std.math.maxInt(u64));
            return;
        }
        if (eq(key, "derandomize")) {
            delta.derandomize = try self.boolean(value, line_no, key);
            return;
        }
        if (eq(key, "report_multiple_failures")) {
            delta.report_multiple_failures = try self.boolean(value, line_no, key);
            return;
        }
        if (eq(key, "show_statistics")) {
            delta.show_statistics = try self.boolean(value, line_no, key);
            return;
        }
        if (eq(key, "print_blob")) {
            delta.print_blob = try self.boolean(value, line_no, key);
            return;
        }
        if (eq(key, "verbosity")) {
            const text = try self.string(value, line_no, key);
            if (eq(text, "quiet")) {
                delta.verbosity = .quiet;
                return;
            }
            if (eq(text, "normal")) {
                delta.verbosity = .normal;
                return;
            }
            if (eq(text, "verbose")) {
                delta.verbosity = .verbose;
                return;
            }
            if (eq(text, "debug")) {
                delta.verbosity = .debug;
                return;
            }
            return self.fail(line_no, "`verbosity` expects one of quiet|normal|verbose|debug, got \"{s}\"", .{text});
        }
        if (eq(key, "backend")) {
            const text = try self.string(value, line_no, key);
            if (eq(text, "default")) {
                delta.backend = .default;
                return;
            }
            if (eq(text, "urandom")) {
                delta.backend = .urandom;
                return;
            }
            return self.fail(line_no, "`backend` expects one of default|urandom, got \"{s}\"", .{text});
        }
        if (eq(key, "nondeterminism_strictness")) {
            const text = try self.string(value, line_no, key);
            if (eq(text, "quiet")) {
                delta.nondeterminism_strictness = .quiet;
                return;
            }
            if (eq(text, "warn")) {
                delta.nondeterminism_strictness = .warn;
                return;
            }
            if (eq(text, "error")) {
                delta.nondeterminism_strictness = .@"error";
                return;
            }
            return self.fail(line_no, "`nondeterminism_strictness` expects one of quiet|warn|error, got \"{s}\"", .{text});
        }
        if (eq(key, "database")) {
            const text = try self.string(value, line_no, key);
            if (text.len == 0) return self.fail(line_no, "`database` expects a path, \"disabled\", or \"default\", got \"\"", .{});
            delta.database = if (eq(text, "disabled")) .disabled else if (eq(text, "default")) .unset else .{ .path = text };
            return;
        }
        if (eq(key, "phases")) {
            const items = try self.strings(value, line_no, key);
            const result = try self.allocator.alloc(settings.Phase, items.len);
            for (items, result) |item, *dest| {
                var parsed: ?settings.Phase = null;
                inline for (.{ "explicit", "reuse", "generate", "target", "shrink" }) |v| if (eq(item, v)) {
                    parsed = @field(settings.Phase, v);
                };
                dest.* = parsed orelse return self.fail(line_no, "`phases` does not recognise \"{s}\". Known names: explicit, reuse, generate, target, shrink", .{item});
            }
            delta.phases = result;
            return;
        }
        if (eq(key, "suppress_health_check")) {
            const items = try self.strings(value, line_no, key);
            for (items) |item| if (eq(item, "all")) {
                if (items.len != 1) return self.fail(line_no, "\"all\" must be the only element of `suppress_health_check`", .{});
                delta.suppress_health_check = &.{ .filter_too_much, .too_slow, .test_cases_too_large, .large_initial_test_case };
                return;
            };
            const result = try self.allocator.alloc(settings.HealthCheck, items.len);
            for (items, result) |item, *dest| {
                var parsed: ?settings.HealthCheck = null;
                inline for (.{ "filter_too_much", "too_slow", "test_cases_too_large", "large_initial_test_case" }) |v| if (eq(item, v)) {
                    parsed = @field(settings.HealthCheck, v);
                };
                dest.* = parsed orelse return self.fail(line_no, "`suppress_health_check` does not recognise \"{s}\". Known names: all, filter_too_much, too_slow, test_cases_too_large, large_initial_test_case", .{item});
            }
            delta.suppress_health_check = result;
            return;
        }
        return self.fail(line_no, "unknown key `{s}`", .{key});
    }
};
fn eq(a: []const u8, b: []const u8) bool {
    return std.mem.eql(u8, a, b);
}
fn kind(value: types.Value) []const u8 {
    return switch (value) {
        .string => "a string",
        .integer => "an integer",
        .float => "a float",
        .boolean => "a boolean",
        .array => "an array",
        .table => "a table",
        else => "a datetime",
    };
}
pub fn parse(gpa: Allocator, text: []const u8) !OwnedConfig {
    return parseDetailed(gpa, text, null);
}
pub fn parseDetailed(gpa: Allocator, text: []const u8, diagnostic: ?*Diagnostic) !OwnedConfig {
    var result: OwnedConfig = .{ .arena = std.heap.ArenaAllocator.init(gpa) };
    errdefer result.deinit();
    const arena = result.arena.allocator();
    var entries: spans_mod.EntrySpanMap = .empty;
    var headers: spans_mod.HeaderSpanMap = .empty;
    var ctx: Context = .{ .allocator = arena, .diagnostic_allocator = gpa, .diagnostic = diagnostic, .text = text, .spans = .{ .entries = &entries, .headers = &headers } };
    if (!std.unicode.utf8ValidateSlice(text)) return ctx.fail(0, "file is not valid UTF-8", .{});
    var error_info: parser.ErrorInfo = .{};
    const tree = parser.parseSliceWithSpans(arena, text, &error_info, &ctx.spans) catch |err| {
        if (err == error.OutOfMemory) return err;
        return ctx.fail(error_info.line, "{s}", .{error_info.message()});
    };
    var configured: std.ArrayList(profiles.NamedProfile) = .empty;
    for (tree.keys(), tree.values()) |key, value| {
        if (eq(key, "default")) {
            const line_no = ctx.line(&.{.{ .key = "default" }});
            const name_value = try ctx.string(value, line_no, key);
            if (eq(name_value, "default")) return ctx.fail(line_no, "`default` cannot name the \"default\" alias it resolves", .{});
            try ctx.name(name_value, line_no);
            result.config.default = name_value;
        } else if (eq(key, "profiles")) {
            if (value != .table) return ctx.fail(ctx.line(&.{.{ .key = key }}), "`profiles` expects [profiles.<name>] tables, got {s}", .{kind(value)});
            for (value.table.keys(), value.table.values()) |name_value, table| {
                const line_no = ctx.line(&.{ .{ .key = "profiles" }, .{ .key = name_value } });
                if (eq(name_value, "base")) return ctx.fail(line_no, "\"base\" is the reserved base profile and cannot be modified; customize [profiles.development] instead", .{});
                if (eq(name_value, "default")) return ctx.fail(line_no, "\"default\" is an alias for the default profile and cannot be defined; choose it with `default = \"<profile>\"` instead", .{});
                try ctx.name(name_value, line_no);
                if (table != .table) return ctx.fail(line_no, "`profiles.{s}` expects a table of settings, got {s}", .{ name_value, kind(table) });
                var delta: profiles.ProfileDelta = .{};
                for (table.table.keys(), table.table.values()) |field, v| try ctx.assign(&delta, field, v, ctx.line(&.{ .{ .key = "profiles" }, .{ .key = name_value }, .{ .key = field } }));
                try configured.append(arena, .{ .name = name_value, .delta = delta });
            }
        } else return ctx.fail(ctx.line(&.{.{ .key = key }}), "unknown top-level key `{s}`: only `default` and [profiles.<name>] tables are allowed", .{key});
    }
    result.config.profiles = try configured.toOwnedSlice(arena);
    return result;
}
pub const Found = struct {
    path: []u8,
    bytes: []u8,
    pub fn deinit(self: *Found, gpa: Allocator) void {
        gpa.free(self.path);
        gpa.free(self.bytes);
    }
};
pub fn parentOn(dir: []const u8, windows: bool) ?[]const u8 {
    var end = dir.len;
    while (end > 0 and separator(dir[end - 1], windows)) end -= 1;
    if (end == 0) return null;
    var index = end;
    while (index > 0) {
        index -= 1;
        if (separator(dir[index], windows)) {
            if (index == 0) return dir[0..1];
            if (windows and dir[index - 1] == ':') return dir[0 .. index + 1];
            return dir[0..index];
        }
    }
    return null;
}
fn separator(byte: u8, windows: bool) bool {
    return byte == '/' or (windows and byte == '\\');
}
fn join(gpa: Allocator, dir: []const u8, name_value: []const u8) ![]u8 {
    const has_separator = dir.len > 0 and separator(dir[dir.len - 1], @import("builtin").os.tag == .windows);
    return std.fmt.allocPrint(gpa, "{s}{s}{s}", .{ dir, if (has_separator) "" else "/", name_value });
}
fn read(gpa: Allocator, io: std.Io, path: []const u8) !?[]u8 {
    return std.Io.Dir.cwd().readFileAlloc(io, path, gpa, .unlimited) catch |err| switch (err) {
        error.OutOfMemory => return err,
        else => null,
    };
}
pub fn discover(gpa: Allocator, io: std.Io, cwd: ?[]const u8) !?Found {
    var dir = cwd orelse {
        const bytes = (try read(gpa, io, "hegel.toml")) orelse return null;
        errdefer gpa.free(bytes);
        return .{ .path = try gpa.dupe(u8, "hegel.toml"), .bytes = bytes };
    };
    while (true) {
        const path = try join(gpa, dir, "hegel.toml");
        errdefer gpa.free(path);
        if (try read(gpa, io, path)) |bytes| return .{ .path = path, .bytes = bytes };
        gpa.free(path);
        dir = parentOn(dir, @import("builtin").os.tag == .windows) orelse return null;
    }
}
pub fn load(gpa: Allocator, io: std.Io, env: settings.Environment, cwd: ?[]const u8) !OwnedConfig {
    return loadDetailed(gpa, io, env, cwd, null);
}
pub fn loadDetailed(gpa: Allocator, io: std.Io, env: settings.Environment, cwd: ?[]const u8, diagnostic: ?*Diagnostic) !OwnedConfig {
    var found: Found = if (env.value("HEGEL_CONFIG")) |path| blk: {
        const bytes = (try read(gpa, io, path)) orelse {
            if (diagnostic) |out| {
                out.line = 0;
                out.path = try gpa.dupe(u8, path);
                out.message = try gpa.dupe(u8, "cannot read the file named by HEGEL_CONFIG");
            }
            return error.InvalidConfig;
        };
        errdefer gpa.free(bytes);
        break :blk .{ .path = try gpa.dupe(u8, path), .bytes = bytes };
    } else (try discover(gpa, io, cwd)) orelse return .{ .arena = std.heap.ArenaAllocator.init(gpa) };
    defer found.deinit(gpa);
    var result = parseDetailed(gpa, found.bytes, diagnostic) catch |err| {
        if (diagnostic) |out| out.path = try gpa.dupe(u8, found.path);
        return err;
    };
    errdefer result.deinit();
    result.config.path = try result.arena.allocator().dupe(u8, found.path);
    return result;
}

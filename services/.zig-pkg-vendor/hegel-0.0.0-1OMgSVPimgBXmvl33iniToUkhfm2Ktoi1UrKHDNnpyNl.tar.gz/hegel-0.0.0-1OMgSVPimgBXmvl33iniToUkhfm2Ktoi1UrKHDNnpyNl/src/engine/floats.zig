// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");

pub fn signAwareLte(x: f64, y: f64) bool {
    if (x == 0 and y == 0) return @intFromBool(!std.math.signbit(x)) <= @intFromBool(!std.math.signbit(y));
    return x <= y;
}

pub fn nextUp(value: f64) f64 {
    if (std.math.isNan(value) or value == std.math.inf(f64)) return value;
    if (value == 0) return if (std.math.signbit(value)) 0 else @bitCast(@as(u64, 1));
    const bits: u64 = @bitCast(value);
    return @bitCast(if (value < 0) bits - 1 else bits + 1);
}

pub fn nextDown(value: f64) f64 {
    return -nextUp(-value);
}

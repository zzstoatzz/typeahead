// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-provenance/state.json.
const std = @import("std");
const c = @import("choices.zig");
const graph_mod = @import("graph.zig");
const database = @import("database.zig");
const nd = @import("nd.zig");
const Allocator = std.mem.Allocator;
pub const Error = c.Error || error{MalformedData};
pub const RunResult = @import("execution.zig").RunResult;
pub const Standing = union(enum) { unconfirmed, trusted, confirmed: struct { anchor: f64, witness: ?RunResult } };
pub const HISTORY_BYTES: usize = 32 << 20;
pub const HistoryEntry = struct {
    nodes: []c.ChoiceNode,
    spans: []c.Span,
    accept: bool,
    pub fn run(self: *const HistoryEntry, gpa: Allocator) Error!graph_mod.Run {
        return graph_mod.Run.fromNodes(gpa, self.nodes, self.spans);
    }
    fn deinit(self: *HistoryEntry, gpa: Allocator) void {
        c.deinitNodes(gpa, self.nodes);
        gpa.free(self.spans);
    }
    fn bytes(self: HistoryEntry) usize {
        return self.nodes.len * @sizeOf(c.ChoiceNode) + self.spans.len * @sizeOf(c.Span);
    }
};
pub const History = struct {
    allocator: Allocator,
    entries_list: std.ArrayList(HistoryEntry) = .empty,
    seen: std.AutoHashMapUnmanaged(u64, void) = .empty,
    byte_count: usize = 0,
    pub fn init(gpa: Allocator) History {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *History) void {
        for (self.entries_list.items) |*entry| entry.deinit(self.allocator);
        self.entries_list.deinit(self.allocator);
        self.seen.deinit(self.allocator);
    }
    pub fn record(self: *History, nodes: []const c.ChoiceNode, spans: []const c.Span, accept: bool) Error!void {
        const key = try database.serializeNodes(self.allocator, nodes) orelse return error.InternalError;
        defer self.allocator.free(key);
        const hash = database.fnv1a(key);
        if (self.seen.contains(hash)) return;
        const owned_nodes = try c.cloneNodes(self.allocator, nodes);
        errdefer c.deinitNodes(self.allocator, owned_nodes);
        const owned_spans = try self.allocator.dupe(c.Span, spans);
        errdefer self.allocator.free(owned_spans);
        try self.entries_list.ensureUnusedCapacity(self.allocator, 1);
        try self.seen.put(self.allocator, hash, {});
        const entry: HistoryEntry = .{ .nodes = owned_nodes, .spans = owned_spans, .accept = accept };
        self.byte_count += entry.bytes();
        self.entries_list.appendAssumeCapacity(entry);
        self.thin();
    }
    pub fn thin(self: *History) void {
        while (self.byte_count > HISTORY_BYTES and self.entries_list.items.len > 1) {
            var raw: ?usize = null;
            for (self.entries_list.items, 0..) |entry, i| if (!entry.accept) {
                raw = i;
                break;
            };
            const victim: usize = if (raw != null and raw.? + 1 < self.entries_list.items.len) raw.? else if (self.entries_list.items.len > 2) 1 else 0;
            var removed = self.entries_list.orderedRemove(victim);
            self.byte_count -= removed.bytes();
            removed.deinit(self.allocator);
        }
    }
    pub fn bytes(self: *const History) usize {
        return self.byte_count;
    }
    pub fn entries(self: *const History) []const HistoryEntry {
        return self.entries_list.items;
    }
    pub fn isEmpty(self: *const History) bool {
        return self.entries_list.items.len == 0;
    }
};
pub const Counterexample = struct {
    allocator: Allocator,
    incumbent_nodes: ?[]c.ChoiceNode = null,
    incumbent_spans: []c.Span = &.{},
    graph_value: ?graph_mod.Graph = null,
    longest_run: usize = 0,
    standing: Standing = .unconfirmed,
    fails: u64 = 0,
    replays: u64 = 0,
    report_fails: u64 = 0,
    report_replays: u64 = 0,
    seed: ?nd.Evidence = null,
    history_value: History,
    checked_first: bool = false,
    bar_attempts: u64 = 0,
    backtrack_attempts: u64 = 0,
    gauntlet_spend: nd.GauntletSpend = .{},
    pub fn init(gpa: Allocator) Counterexample {
        return .{ .allocator = gpa, .history_value = History.init(gpa) };
    }
    pub fn deinit(self: *Counterexample) void {
        if (self.incumbent_nodes) |nodes| c.deinitNodes(self.allocator, nodes);
        self.allocator.free(self.incumbent_spans);
        if (self.graph_value) |*g| g.deinit();
        if (self.standing == .confirmed) {
            if (self.standing.confirmed.witness) |*w| w.deinit(self.allocator);
        }
        self.history_value.deinit();
    }
    pub fn anchor(self: *const Counterexample) ?f64 {
        return if (self.standing == .confirmed) self.standing.confirmed.anchor else null;
    }
    pub fn incumbent(self: *const Counterexample) ?[]const c.ChoiceNode {
        return self.incumbent_nodes;
    }
    pub fn incumbentSpans(self: *const Counterexample) []const c.Span {
        return self.incumbent_spans;
    }
    pub fn incumbentRun(self: *const Counterexample) Error!?graph_mod.Run {
        const nodes = self.incumbent_nodes orelse return null;
        return try graph_mod.Run.fromNodes(self.allocator, nodes, self.incumbent_spans);
    }
    pub fn adopt(self: *Counterexample, nodes: []const c.ChoiceNode, spans: []const c.Span) Error!bool {
        if (self.incumbent_nodes) |current| if (try c.nodesOrder(self.allocator, nodes, current) != .lt) return false;
        try self.replace(nodes, spans);
        return true;
    }
    pub fn replace(self: *Counterexample, nodes: []const c.ChoiceNode, spans: []const c.Span) Error!void {
        const copy = try c.cloneNodes(self.allocator, nodes);
        errdefer c.deinitNodes(self.allocator, copy);
        const copied_spans = try self.allocator.dupe(c.Span, spans);
        if (self.incumbent_nodes) |old| c.deinitNodes(self.allocator, old);
        self.allocator.free(self.incumbent_spans);
        self.incumbent_nodes = copy;
        self.incumbent_spans = copied_spans;
    }
    pub fn evict(self: *Counterexample) ?[]c.ChoiceNode {
        self.allocator.free(self.incumbent_spans);
        self.incumbent_spans = &.{};
        const old = self.incumbent_nodes;
        self.incumbent_nodes = null;
        return old;
    }
    pub fn graph(self: *const Counterexample) ?*const graph_mod.Graph {
        return if (self.graph_value) |*g| g else null;
    }
    pub fn replayGraph(self: *const Counterexample) Error!?graph_mod.Graph {
        if (self.graph_value) |*g| return try g.deepCloneWithAllocator(self.allocator);
        var run = try self.incumbentRun() orelse return null;
        defer run.deinit();
        return try graph_mod.Graph.fromRun(self.allocator, &run);
    }
    pub fn longest(self: *const Counterexample) usize {
        return @max(self.longest_run, if (self.incumbent_nodes) |nodes| c.flattenedLen(nodes) else 0);
    }
    pub fn reproState(self: *const Counterexample) Error!@import("blob.zig").NdReproState {
        var g = try self.replayGraph() orelse return error.InternalError;
        errdefer g.deinit();
        const bytes = try g.encode() orelse return error.InternalError;
        defer self.allocator.free(bytes);
        return .{ .graph = g, .entropy = database.fnv1a(bytes), .longest = @truncate(self.longest()) };
    }
    pub fn needsConfirmation(self: *const Counterexample) bool {
        return self.standing == .unconfirmed;
    }
    pub const Stored = struct { graph: *const graph_mod.Graph, longest: usize };
    pub const EvidenceCounts = struct { fails: u64, replays: u64 };
    pub fn trust(self: *Counterexample, stored: ?Stored, evidence: EvidenceCounts) Error!void {
        if (self.standing == .confirmed) return;
        var copy: ?graph_mod.Graph = if (stored) |s| try s.graph.deepCloneWithAllocator(self.allocator) else null;
        errdefer if (copy) |*g| g.deinit();
        if (self.standing == .trusted) {
            self.fails += evidence.fails;
            self.replays += evidence.replays;
        } else {
            self.standing = .trusted;
            self.fails = evidence.fails;
            self.replays = evidence.replays;
            self.report_fails = 0;
            self.report_replays = 0;
        }
        if (copy) |g| {
            if (self.graph_value) |*old| old.deinit();
            self.graph_value = g;
            self.longest_run = stored.?.longest;
        }
    }
    pub fn recordTrustedBatch(self: *Counterexample, evidence: EvidenceCounts) void {
        if (self.standing == .trusted) {
            self.fails += evidence.fails;
            self.replays += evidence.replays;
        }
    }
    pub fn confirm(self: *Counterexample, anchor_value: f64, witness: ?*const RunResult, source: *const graph_mod.Graph, longest_value: usize, evidence: EvidenceCounts) !void {
        if (self.standing == .confirmed) return error.InternalError;
        var g = try source.deepCloneWithAllocator(self.allocator);
        errdefer g.deinit();
        const w = if (witness) |run| try run.deepClone(self.allocator) else null;
        if (self.graph_value) |*old| old.deinit();
        self.graph_value = g;
        self.standing = .{ .confirmed = .{ .anchor = anchor_value, .witness = w } };
        self.longest_run = longest_value;
        self.fails += evidence.fails;
        self.replays += evidence.replays;
        self.clearHistory();
    }
    pub fn install(self: *Counterexample, source: *const graph_mod.Graph, nodes: []const c.ChoiceNode, spans: []const c.Span, anchor_value: f64, longest_value: usize) Error!void {
        var g = try source.deepCloneWithAllocator(self.allocator);
        errdefer g.deinit();
        try self.replace(nodes, spans);
        if (self.graph_value) |*old| old.deinit();
        self.graph_value = g;
        self.longest_run = longest_value;
        self.raiseAnchor(anchor_value);
    }
    pub fn raiseAnchor(self: *Counterexample, value: f64) void {
        if (self.standing == .confirmed and value > self.standing.confirmed.anchor) self.standing.confirmed.anchor = value;
    }
    pub const Witness = struct { run: RunResult, anchor: f64 };
    pub fn takeWitness(self: *Counterexample) ?Witness {
        if (self.standing != .confirmed) return null;
        const run = self.standing.confirmed.witness orelse return null;
        self.standing.confirmed.witness = null;
        return .{ .run = run, .anchor = self.standing.confirmed.anchor };
    }
    pub fn recordFinalReplay(self: *Counterexample, evidence: EvidenceCounts) void {
        if (!self.needsConfirmation()) {
            self.report_fails += evidence.fails;
            self.report_replays += evidence.replays;
        }
    }
    pub fn reject(self: *Counterexample, evidence: EvidenceCounts) ?[]c.ChoiceNode {
        if (!self.needsConfirmation()) return null;
        self.fails += evidence.fails;
        self.replays += evidence.replays;
        return self.evict();
    }
    pub fn seedEvidence(self: *Counterexample, evidence: nd.Evidence) void {
        self.seed = evidence;
    }
    pub fn takeSeed(self: *Counterexample) ?nd.Evidence {
        const seed = self.seed;
        self.seed = null;
        return seed;
    }
    pub fn recordSighting(self: *Counterexample, nodes: []const c.ChoiceNode, spans: []const c.Span, accept: bool) Error!void {
        try self.history_value.record(nodes, spans, accept);
    }
    pub fn history(self: *const Counterexample) *const History {
        return &self.history_value;
    }
    pub fn clearHistory(self: *Counterexample) void {
        self.history_value.deinit();
        self.history_value = History.init(self.allocator);
    }
    pub fn firstChecked(self: *const Counterexample) bool {
        return self.checked_first;
    }
    pub fn markFirstChecked(self: *Counterexample) void {
        self.checked_first = true;
    }
    pub fn spendBarAttempt(self: *Counterexample) bool {
        if (self.bar_attempts >= nd.BAR_ATTEMPTS_PER_RUN) return false;
        self.bar_attempts += 1;
        return true;
    }
    pub fn backtrackAttemptsLeft(self: *const Counterexample) bool {
        return self.backtrack_attempts < nd.BACKTRACK_BAR_ATTEMPTS;
    }
    pub fn spendBacktrackAttempt(self: *Counterexample) bool {
        if (!self.backtrackAttemptsLeft()) return false;
        self.backtrack_attempts += 1;
        return true;
    }
    pub fn caveat(self: *const Counterexample) Allocator.Error![]u8 {
        const gpa = self.allocator;
        if (self.standing == .confirmed) {
            if (self.report_replays > 0 and self.report_fails == 0) return std.fmt.allocPrint(gpa, "nondeterministic failure, confirmed earlier this run (failed {d} of {d} replays) but not reproduced at report time — a rare failure, or something in the environment changed after discovery", .{ self.fails, self.replays });
            if (self.report_replays > 0) return std.fmt.allocPrint(gpa, "nondeterministic failure, confirmed: failed {d} of {d} replays at confirmation and {d} of {d} at report time", .{ self.fails, self.replays, self.report_fails, self.report_replays });
            return std.fmt.allocPrint(gpa, "nondeterministic failure, confirmed: failed {d} of {d} replays this run", .{ self.fails, self.replays });
        }
        if (self.standing == .trusted) {
            if (self.report_replays > 0 and self.report_fails == 0) return std.fmt.allocPrint(gpa, "nondeterministic failure, reproduced from stored state earlier this run (failed {d} of {d} replays) but not reproduced at report time — a rare failure, or something in the environment changed after discovery", .{ self.fails, self.replays });
            if (self.report_replays > 0) return std.fmt.allocPrint(gpa, "nondeterministic failure, reproduced from stored state: failed {d} of {d} replays at reuse and {d} of {d} at report time", .{ self.fails, self.replays, self.report_fails, self.report_replays });
            return std.fmt.allocPrint(gpa, "nondeterministic failure, reproduced from stored state: failed {d} of {d} replays this run", .{ self.fails, self.replays });
        }
        if (self.fails > 0) return std.fmt.allocPrint(gpa, "unconfirmed failure: failed {d} of {d} replays this run, below the confirmation bar — likely rare", .{ self.fails, self.replays });
        if (self.replays == 0) return gpa.dupe(u8, "unconfirmed failure: observed once, never replayed — a rare failure, or the environment changed between executions");
        return std.fmt.allocPrint(gpa, "unconfirmed failure: failed 0 of {d} replays after the observed failure — a rare failure, or the environment changed between executions", .{self.replays});
    }
};
pub const Counterexamples = struct {
    allocator: Allocator,
    origins: std.ArrayList(Origin) = .empty,
    pub const Origin = struct { origin: []u8, record: Counterexample };
    pub const Live = struct { origin: []const u8, nodes: []const c.ChoiceNode };
    pub fn init(gpa: Allocator) Counterexamples {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *Counterexamples) void {
        for (self.origins.items) |*o| {
            self.allocator.free(o.origin);
            o.record.deinit();
        }
        self.origins.deinit(self.allocator);
    }
    fn position(self: *const Counterexamples, origin: []const u8) usize {
        for (self.origins.items, 0..) |o, i| if (std.mem.order(u8, o.origin, origin) != .lt) return i;
        return self.origins.items.len;
    }
    pub fn get(self: *const Counterexamples, origin: []const u8) ?*const Counterexample {
        const i = self.position(origin);
        return if (i < self.origins.items.len and std.mem.eql(u8, self.origins.items[i].origin, origin)) &self.origins.items[i].record else null;
    }
    pub fn getMut(self: *Counterexamples, origin: []const u8) ?*Counterexample {
        return if (self.get(origin)) |record| @constCast(record) else null;
    }
    pub fn entry(self: *Counterexamples, origin: []const u8) Allocator.Error!*Counterexample {
        const i = self.position(origin);
        if (i < self.origins.items.len and std.mem.eql(u8, self.origins.items[i].origin, origin)) return &self.origins.items[i].record;
        const key = try self.allocator.dupe(u8, origin);
        errdefer self.allocator.free(key);
        try self.origins.insert(self.allocator, i, .{ .origin = key, .record = Counterexample.init(self.allocator) });
        return &self.origins.items[i].record;
    }
    pub fn incumbent(self: *const Counterexamples, origin: []const u8) ?[]const c.ChoiceNode {
        return if (self.get(origin)) |record| record.incumbent() else null;
    }
    pub fn needsConfirmation(self: *const Counterexamples, origin: []const u8) bool {
        return if (self.get(origin)) |record| record.needsConfirmation() else true;
    }
    pub fn anyLive(self: *const Counterexamples) bool {
        for (self.origins.items) |*o| if (o.record.incumbent() != null) return true;
        return false;
    }
    pub fn live(self: *const Counterexamples, gpa: Allocator) Allocator.Error![]Live {
        var result: std.ArrayList(Live) = .empty;
        errdefer result.deinit(gpa);
        for (self.origins.items) |*o| if (o.record.incumbent()) |nodes| try result.append(gpa, .{ .origin = o.origin, .nodes = nodes });
        return result.toOwnedSlice(gpa);
    }
    pub fn iter(self: *const Counterexamples) []const Origin {
        return self.origins.items;
    }
    pub fn iterMut(self: *Counterexamples) []Origin {
        return self.origins.items;
    }
    pub fn liveOrigins(self: *const Counterexamples, gpa: Allocator) Allocator.Error![][]u8 {
        return self.originNames(gpa, false);
    }
    pub fn unconfirmed(self: *const Counterexamples, gpa: Allocator) Allocator.Error![][]u8 {
        return self.originNames(gpa, true);
    }
    fn originNames(self: *const Counterexamples, gpa: Allocator, unconfirmed_only: bool) Allocator.Error![][]u8 {
        var result: std.ArrayList([]u8) = .empty;
        errdefer {
            for (result.items) |name| gpa.free(name);
            result.deinit(gpa);
        }
        for (self.origins.items) |*o| {
            if (if (unconfirmed_only) o.record.needsConfirmation() else o.record.incumbent() != null) {
                const name = try gpa.dupe(u8, o.origin);
                errdefer gpa.free(name);
                try result.append(gpa, name);
            }
        }
        return result.toOwnedSlice(gpa);
    }
    pub fn caveat(self: *const Counterexamples, origin: []const u8) Allocator.Error!?[]u8 {
        return if (self.get(origin)) |record| try record.caveat() else null;
    }
};

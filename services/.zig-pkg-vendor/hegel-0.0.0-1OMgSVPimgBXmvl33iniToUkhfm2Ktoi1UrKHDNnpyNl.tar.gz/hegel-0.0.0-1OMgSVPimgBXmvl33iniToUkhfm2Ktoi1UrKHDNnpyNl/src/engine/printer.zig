// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated/adapted from pinned libhegel printer and derived Debug behavior;
// see docs/native-port-provenance.json and LICENSES/Dashu-Int-NOTICE.md.
const std = @import("std");
pub const database = @import("database.zig");
pub const choices = @import("choices.zig");
const c = choices;
const Allocator = std.mem.Allocator;
const Buffer = struct {
    allocator: Allocator,
    bytes: std.ArrayList(u8) = .empty,
    fn deinit(self: *@This()) void {
        self.bytes.deinit(self.allocator);
    }
    fn add(self: *@This(), text: []const u8) !void {
        try self.bytes.appendSlice(self.allocator, text);
    }
    fn fmt(self: *@This(), comptime format: []const u8, args: anytype) !void {
        const text = try std.fmt.allocPrint(self.allocator, format, args);
        defer self.allocator.free(text);
        try self.add(text);
    }
    fn integer(self: *@This(), v: c.BigInt) !void {
        const text = try v.toString(self.allocator, 10);
        defer self.allocator.free(text);
        try self.add("BigInt(");
        if (v.bits() <= 128) {
            try self.add(text);
        } else {
            const negative = text[0] == '-';
            const digits = text[@intFromBool(negative)..];
            if (negative) try self.add("-");
            try self.add(digits[0..19]);
            try self.add("..");
            try self.add(digits[digits.len - 19 ..]);
        }
        try self.add(")");
    }
    fn float(self: *@This(), v: f64) !void {
        if (std.math.isNan(v)) return self.add("NaN");
        if (std.math.isInf(v)) return self.add(if (std.math.signbit(v)) "-inf" else "inf");
        var buf: [400]u8 = undefined;
        const scientific = @abs(v) != 0 and (@abs(v) < 1e-4 or @abs(v) >= 1e16);
        const text = try std.fmt.float.render(&buf, v, .{ .mode = if (scientific) .scientific else .decimal });
        try self.add(text);
        if (!scientific and std.mem.indexOfScalar(u8, text, '.') == null) try self.add(".0");
    }
    fn numbers(self: *@This(), values: anytype) !void {
        try self.add("[");
        for (values, 0..) |v, i| {
            if (i != 0) try self.add(", ");
            try self.fmt("{d}", .{v});
        }
        try self.add("]");
    }
    fn integerConstraint(self: *@This(), ic: c.IntegerChoice) !void {
        try self.add("IntegerChoice { min_value: ");
        try self.integer(ic.min_value);
        try self.add(", max_value: ");
        try self.integer(ic.max_value);
        try self.add(", shrink_towards: ");
        try self.integer(ic.shrink_towards);
        try self.add(" }");
    }
    fn booleanConstraint(self: *@This(), bc: c.BooleanChoice) !void {
        try self.add("BooleanChoice { p: ");
        try self.float(bc.p);
        try self.add(" }");
    }
    fn floatConstraint(self: *@This(), fc: c.FloatChoice) !void {
        try self.add("FloatChoice { min_value: ");
        try self.float(fc.min_value);
        try self.add(", max_value: ");
        try self.float(fc.max_value);
        try self.fmt(", allow_nan: {}, allow_infinity: {}, smallest_nonzero_magnitude: ", .{ fc.allow_nan, fc.allow_infinity });
        try self.float(fc.smallest_nonzero_magnitude);
        try self.add(" }");
    }
    fn bytesConstraint(self: *@This(), bc: c.BytesChoice) !void {
        try self.fmt("BytesChoice {{ min_size: {d}, max_size: {d} }}", .{ bc.min_size, bc.max_size });
    }
    fn stringConstraint(self: *@This(), sc: c.StringChoice) !void {
        const set = sc.intervals;
        try self.add("StringChoice { intervals: IntervalSet { intervals: [");
        for (set.intervals, 0..) |range, i| {
            if (i != 0) try self.add(", ");
            try self.fmt("({d}, {d})", .{ range.start, range.end });
        }
        try self.add("], offsets: ");
        try self.numbers(set.offsets);
        try self.fmt(", size: {d}, idx_of_zero: {d}, idx_of_z: {d}, string_constants_mask: OnceBox(0x{x}) }}, min_size: {d}, max_size: {d} }}", .{ set.size, set.idx_of_zero, set.idx_of_z, if (set.string_constants_mask.load(.acquire)) |p| @intFromPtr(p) else @as(usize, 0), sc.min_size, sc.max_size });
    }
    fn kind(self: *@This(), k: c.ChoiceKind) anyerror!void {
        switch (k) {
            .integer => |ic| {
                try self.add("Integer(");
                try self.integerConstraint(ic.*);
                try self.add(")");
            },
            .boolean => |bc| {
                try self.add("Boolean(");
                try self.booleanConstraint(bc);
                try self.add(")");
            },
            .float => |fc| {
                try self.add("Float(");
                try self.floatConstraint(fc);
                try self.add(")");
            },
            .bytes => |bc| {
                try self.add("Bytes(");
                try self.bytesConstraint(bc);
                try self.add(")");
            },
            .string => |sc| {
                try self.add("String(");
                try self.stringConstraint(sc);
                try self.add(")");
            },
            .clone => try self.add("Clone"),
        }
    }
    fn value(self: *@This(), v: c.ChoiceValueRef) anyerror!void {
        switch (v) {
            .integer => |n| {
                try self.add("Integer(");
                try self.integer(n.*);
                try self.add(")");
            },
            .boolean => |b| try self.fmt("Boolean({})", .{b}),
            .float => |f| {
                try self.add("Float(");
                try self.float(f);
                try self.add(")");
            },
            .bytes => |b| {
                try self.add("Bytes(");
                try self.numbers(b);
                try self.add(")");
            },
            .string => |s| {
                try self.add("String(");
                try self.numbers(s);
                try self.add(")");
            },
            .clone => |children| {
                try self.add("Clone(CloneRecord { children: ");
                switch (children) {
                    .record => |record| {
                        if (record.realized()) |realized| {
                            try self.add("Realized(");
                            try self.stream(realized);
                            try self.add(")");
                        } else {
                            try self.add("Values { values: [");
                            for (0..record.len()) |i| {
                                if (i != 0) try self.add(", ");
                                try self.value(record.valueAt(i));
                            }
                            try self.fmt("], flat_len: {d} }}", .{record.flatLen()});
                        }
                    },
                    .stream => |realized| {
                        try self.add("Realized(");
                        try self.stream(realized);
                        try self.add(")");
                    },
                }
                try self.add(" })");
            },
        }
    }
    fn stream(self: *@This(), s: *const c.RealizedStream) anyerror!void {
        try self.add("RealizedStream { nodes: [");
        for (s.nodes, 0..) |*n, i| {
            if (i != 0) try self.add(", ");
            try self.add("ChoiceNode { data: ");
            try self.data(&n.data);
            try self.fmt(", was_forced: {} }}", .{n.was_forced});
        }
        try self.add("], spans: [");
        for (s.spans, 0..) |span, i| {
            if (i != 0) try self.add(", ");
            try self.fmt("Span {{ start: {d}, end: {d}, label: {d}, depth: {d}, parent: ", .{ span.start, span.end, span.label, span.depth });
            if (span.parent) |p| {
                try self.fmt("Some({d})", .{p});
            } else try self.add("None");
            try self.fmt(", discarded: {} }}", .{span.discarded});
        }
        try self.fmt("], flat_len: {d} }}", .{s.flat_len});
    }
    fn data(self: *@This(), d: *const c.ChoiceData) anyerror!void {
        if (d.* == .clone) {
            try self.add("Clone(");
            try self.stream(d.clone);
            try self.add(")");
            return;
        }
        const k = d.kind();
        const tag: []const u8 = switch (k) {
            .integer => "Integer",
            .boolean => "Boolean",
            .float => "Float",
            .bytes => "Bytes",
            .string => "String",
            .clone => unreachable,
        };
        try self.add(tag);
        try self.add("(");
        switch (k) {
            .integer => |v| try self.integerConstraint(v.*),
            .boolean => |v| try self.booleanConstraint(v),
            .float => |v| try self.floatConstraint(v),
            .bytes => |v| try self.bytesConstraint(v),
            .string => |v| try self.stringConstraint(v),
            .clone => unreachable,
        }
        try self.add(", ");
        switch (d.valueRef()) {
            .integer => |v| try self.integer(v.*),
            .boolean => |v| try self.fmt("{}", .{v}),
            .float => |v| try self.float(v),
            .bytes => |v| try self.numbers(v),
            .string => |v| try self.numbers(v),
            .clone => unreachable,
        }
        try self.add(")");
    }
};
pub fn debugChoiceValue(gpa: Allocator, value: *const c.ChoiceValue) ![]u8 {
    var b = Buffer{ .allocator = gpa };
    errdefer b.deinit();
    try b.value(value.valueRef());
    return b.bytes.toOwnedSlice(gpa);
}
pub fn debugChoiceKind(gpa: Allocator, kind: c.ChoiceKind) ![]u8 {
    var b = Buffer{ .allocator = gpa };
    errdefer b.deinit();
    try b.kind(kind);
    return b.bytes.toOwnedSlice(gpa);
}
pub const engine = @import("printer/engine.zig");
pub const Printer = engine.Printer;
pub const PrinterShared = engine.PrinterShared;
pub const Target = engine.Target;
pub const SlotId = engine.SlotId;
pub const PrinterError = engine.Error;
pub const errorMessage = engine.errorMessage;
pub const reflow = @import("reflow.zig");

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-provenance/state.json.
const std = @import("std");
const c = @import("choices.zig");
const replay_mod = @import("replay.zig");
const graph = @import("graph.zig");
pub const sampling = @import("sampling.zig");
const Allocator = std.mem.Allocator;
pub const BigInt = @import("bignum.zig").BigInt;
pub const EngineRng = @import("rng.zig").EngineRng;
pub const Status = c.Status;
pub const InterestingOrigin = c.InterestingOrigin;
pub const Span = c.Span;
pub const GenerationParameters = sampling.GenerationParameters;
pub const ManyState = sampling.ManyState;
pub const RecursionState = sampling.RecursionState;
pub const FloatWidth = sampling.FloatWidth;
pub const Error = c.Error || c.EngineError;
pub const MAX_DEPTH: u32 = 1000;
pub const MAX_CLONE_DEPTH: usize = 100;
const Mutex = @import("sync.zig").Mutex;
pub const FreshIds = struct {
    allocator: Allocator,
    used: std.AutoHashMapUnmanaged(i64, void) = .empty,
    smallest_unused: i64 = 0,
    max_used: i64 = -1,
    pub fn init(gpa: Allocator) FreshIds {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *FreshIds) void {
        self.used.deinit(self.allocator);
    }
    pub fn insert(self: *FreshIds, id: i64) Allocator.Error!void {
        try self.used.put(self.allocator, id, {});
        self.max_used = @max(self.max_used, id);
        while (self.used.contains(self.smallest_unused)) self.smallest_unused += 1;
    }
    pub fn contains(self: *const FreshIds, id: i64) bool {
        return self.used.contains(id);
    }
    pub fn smallestUnused(self: *const FreshIds) i64 {
        return self.smallest_unused;
    }
    pub fn maxUsed(self: *const FreshIds) i64 {
        return self.max_used;
    }
};
pub const NativeVariables = struct {
    allocator: Allocator,
    variables: std.ArrayList(i64) = .empty,
    removed: std.AutoHashMapUnmanaged(i64, void) = .empty,
    pub fn init(gpa: Allocator) NativeVariables {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *NativeVariables) void {
        self.variables.deinit(self.allocator);
        self.removed.deinit(self.allocator);
    }
    pub fn add(self: *NativeVariables, id: i64) Allocator.Error!void {
        try self.variables.append(self.allocator, id);
    }
    pub fn active(self: *const NativeVariables, gpa: Allocator) Allocator.Error![]i64 {
        var out: std.ArrayList(i64) = .empty;
        errdefer out.deinit(gpa);
        for (self.variables.items) |id| if (!self.removed.contains(id)) try out.append(gpa, id);
        return out.toOwnedSlice(gpa);
    }
    pub fn consume(self: *NativeVariables, id: i64) Allocator.Error!void {
        try self.removed.put(self.allocator, id, {});
        while (self.variables.getLastOrNull()) |last| {
            if (!self.removed.remove(last)) break;
            _ = self.variables.pop();
        }
    }
};
pub const Spans = struct {
    allocator: Allocator,
    inner: std.ArrayList(Span) = .empty,
    pub fn init(gpa: Allocator) Spans {
        return .{ .allocator = gpa };
    }
    pub fn deinit(self: *Spans) void {
        self.inner.deinit(self.allocator);
    }
    pub fn len(self: *const Spans) usize {
        return self.inner.items.len;
    }
    pub fn isEmpty(self: *const Spans) bool {
        return self.len() == 0;
    }
    pub fn push(self: *Spans, span: Span) Allocator.Error!void {
        try self.inner.append(self.allocator, span);
    }
    pub fn get(self: *const Spans, i: usize) ?*const Span {
        return if (i < self.len()) &self.inner.items[i] else null;
    }
    pub fn getMut(self: *Spans, i: usize) ?*Span {
        return if (i < self.len()) &self.inner.items[i] else null;
    }
    pub fn asSlice(self: *const Spans) []const Span {
        return self.inner.items;
    }
    pub fn intoVec(self: *Spans) Allocator.Error![]Span {
        return self.inner.toOwnedSlice(self.allocator);
    }
    pub fn trivial(self: *const Spans, idx: usize, nodes: []const c.ChoiceNode) Error!bool {
        const span = self.get(idx) orelse return false;
        const end = @min(span.end, nodes.len);
        if (span.start > end) return false;
        for (nodes[span.start..end]) |*node| if (!node.was_forced and !(try node.data.isSimplest(self.allocator))) return false;
        return true;
    }
};
pub const DataObserver = struct {
    context: *anyopaque,
    vtable: *const VTable,
    pub const VTable = struct {
        draw_boolean: ?*const fn (*anyopaque, bool, bool) void = null,
        draw_integer: ?*const fn (*anyopaque, *const BigInt, bool) void = null,
        draw_float: ?*const fn (*anyopaque, f64, bool) void = null,
        draw_bytes: ?*const fn (*anyopaque, []const u8, bool) void = null,
        draw_string: ?*const fn (*anyopaque, []const u8, bool) void = null,
        conclude_test: ?*const fn (*anyopaque, Status, ?InterestingOrigin) void = null,
        deinit: ?*const fn (*anyopaque, Allocator) void = null,
    };
};
pub const FamilyCore = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize) = .init(1),
    mutex: Mutex = .{},
    fresh_mutex: Mutex = .{},
    concluded_status: std.atomic.Value(u8) = .init(255),
    total_draws: std.atomic.Value(usize) = .init(0),
    budget: std.atomic.Value(usize),
    origin: ?[]u8 = null,
    target_observations: std.StringHashMapUnmanaged(f64) = .empty,
    events: std.ArrayList(Event) = .empty,
    fresh_ids: FreshIds,
    params: ?GenerationParameters = null,
    pub const Event = struct { label: []u8, value: ?f64 };
    pub const Conclusion = struct { status: Status, origin: ?InterestingOrigin };
    pub fn create(gpa: Allocator, budget: usize) Allocator.Error!*FamilyCore {
        const result = try gpa.create(FamilyCore);
        result.* = .{ .allocator = gpa, .budget = .init(budget), .fresh_ids = FreshIds.init(gpa) };
        return result;
    }
    pub fn retain(self: *FamilyCore) *FamilyCore {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *FamilyCore) void {
        if (self.references.fetchSub(1, .acq_rel) != 1) return;
        const gpa = self.allocator;
        if (self.origin) |o| gpa.free(o);
        var keys = self.target_observations.keyIterator();
        while (keys.next()) |key| gpa.free(key.*);
        self.target_observations.deinit(gpa);
        for (self.events.items) |observation| gpa.free(observation.label);
        self.events.deinit(gpa);
        self.fresh_ids.deinit();
        gpa.destroy(self);
    }
    pub fn generationParameters(self: *FamilyCore) GenerationParameters {
        self.mutex.lock();
        defer self.mutex.unlock();
        return self.params orelse .{};
    }
    pub fn setGenerationParameters(self: *FamilyCore, params: GenerationParameters) void {
        self.mutex.lock();
        defer self.mutex.unlock();
        if (self.params == null) self.params = params;
    }
    pub fn status(self: *const FamilyCore) ?Status {
        const raw = self.concluded_status.load(.acquire);
        return if (raw == 255) null else @fromBackingInt(@intCast(raw));
    }
    pub fn conclude(self: *FamilyCore, status_value: Status, origin: ?InterestingOrigin) Allocator.Error!void {
        self.mutex.lock();
        defer self.mutex.unlock();
        if (self.status() != null) return;
        self.origin = if (origin) |o| try self.allocator.dupe(u8, o) else null;
        self.concluded_status.store(@backingInt(status_value), .release);
    }
    pub fn conclusion(self: *FamilyCore) ?Conclusion {
        self.mutex.lock();
        defer self.mutex.unlock();
        return .{ .status = self.status() orelse return null, .origin = self.origin };
    }
    pub fn tryTakeDraw(self: *FamilyCore) bool {
        return self.total_draws.fetchAdd(1, .monotonic) < self.budget.load(.monotonic);
    }
    pub fn setBudget(self: *FamilyCore, budget: usize) void {
        self.budget.store(budget, .monotonic);
    }
    pub fn target(self: *FamilyCore, label: []const u8, value: f64) Error!void {
        self.mutex.lock();
        defer self.mutex.unlock();
        if (self.target_observations.contains(label)) return error.InvalidArgument;
        const owned = try self.allocator.dupe(u8, label);
        errdefer self.allocator.free(owned);
        try self.target_observations.put(self.allocator, owned, value);
    }
    pub fn event(self: *FamilyCore, label: []const u8, value: ?f64) Allocator.Error!void {
        self.mutex.lock();
        defer self.mutex.unlock();
        const owned = try self.allocator.dupe(u8, label);
        errdefer self.allocator.free(owned);
        try self.events.append(self.allocator, .{ .label = owned, .value = value });
    }
};
pub const NativeTestCaseHandle = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize) = .init(1),
    mutex: Mutex = .{},
    value: NativeTestCase,
    pub fn create(gpa: Allocator, value: NativeTestCase) Allocator.Error!*NativeTestCaseHandle {
        const result = try gpa.create(NativeTestCaseHandle);
        result.* = .{ .allocator = gpa, .value = value };
        return result;
    }
    pub fn retain(self: *NativeTestCaseHandle) *NativeTestCaseHandle {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *NativeTestCaseHandle) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            const gpa = self.allocator;
            self.value.deinit();
            gpa.destroy(self);
        }
    }
    pub fn lock(self: *NativeTestCaseHandle) *NativeTestCase {
        self.mutex.lock();
        return &self.value;
    }
    pub fn unlock(self: *NativeTestCaseHandle) void {
        self.mutex.unlock();
    }
};
pub const NativeTestCase = struct {
    allocator: Allocator,
    replay: replay_mod.Replay,
    rng: ?EngineRng = null,
    max_size: usize,
    nodes: std.ArrayList(c.ChoiceNode) = .empty,
    frozen: bool = false,
    diagnostic: ?[]u8 = null,
    should_capture: bool = false,
    family: *FamilyCore,
    clone_id: []usize = &.{},
    clone_counter: usize = 0,
    clone_children: std.ArrayList(CloneChild) = .empty,
    spans: Spans,
    span_stack: std.ArrayList(usize) = .empty,
    span_ordinals: std.ArrayList(usize) = .empty,
    sibling_counts: std.AutoHashMapUnmanaged(Sibling, usize) = .empty,
    child_nodes: std.ArrayList(usize) = .empty,
    top_child_nodes: usize = 0,
    has_discards: bool = false,
    observer: ?DataObserver = null,
    trailing_template: ?c.ChoiceTemplate = null,
    const Sibling = struct { parent: usize, label: u64 };
    const CloneChild = struct { index: usize, handle: *NativeTestCaseHandle };
    fn newStream(gpa: Allocator, replay: replay_mod.Replay, max_size: usize, family: *FamilyCore) NativeTestCase {
        return .{ .allocator = gpa, .replay = replay, .max_size = max_size, .family = family, .spans = Spans.init(gpa) };
    }
    pub fn deinit(self: *NativeTestCase) void {
        const gpa = self.allocator;
        self.replay.deinit();
        for (self.nodes.items) |*node| node.deinit(gpa);
        self.nodes.deinit(gpa);
        for (self.clone_children.items) |child| child.handle.release();
        self.clone_children.deinit(gpa);
        self.spans.deinit();
        self.span_stack.deinit(gpa);
        self.span_ordinals.deinit(gpa);
        self.sibling_counts.deinit(gpa);
        self.child_nodes.deinit(gpa);
        gpa.free(self.clone_id);
        if (self.observer) |obs| if (obs.vtable.deinit) |f| f(obs.context, gpa);
        if (self.diagnostic) |message| gpa.free(message);
        self.family.release();
    }
    pub fn forChoicesAndTemplate(gpa: Allocator, prefix: []const c.ChoiceValue, prefix_nodes: ?[]const c.ChoiceNode, trailing: ?c.ChoiceTemplate, max_size: usize, observer: ?DataObserver) Error!NativeTestCase {
        var replay = try replay_mod.Replay.pun(gpa, prefix, prefix_nodes);
        errdefer replay.deinit();
        const size = @max(max_size, prefix.len);
        const family = try FamilyCore.create(gpa, if (trailing != null) size else std.math.maxInt(usize));
        var result = newStream(gpa, replay, size, family);
        result.trailing_template = trailing;
        result.observer = observer;
        return result;
    }
    pub fn forChoices(gpa: Allocator, prefix: []const c.ChoiceValue, prefix_nodes: ?[]const c.ChoiceNode, observer: ?DataObserver) Error!NativeTestCase {
        return forChoicesAndTemplate(gpa, prefix, prefix_nodes, null, prefix.len, observer);
    }
    pub fn forSimplest(gpa: Allocator, max_size: usize) Error!NativeTestCase {
        return forChoicesAndTemplate(gpa, &.{}, null, try c.ChoiceTemplate.simplest(null), max_size, null);
    }
    pub fn newRandom(gpa: Allocator, rng: EngineRng) Error!NativeTestCase {
        return forProbe(gpa, &.{}, rng, 1 << 20);
    }
    pub fn newRandomWithParams(gpa: Allocator, rng: EngineRng, params: GenerationParameters, max_size: usize) Error!NativeTestCase {
        var result = try forChoicesAndTemplate(gpa, &.{}, null, null, max_size, null);
        result.withRandomAndParams(rng, params);
        return result;
    }
    pub fn forProbe(gpa: Allocator, prefix: []const c.ChoiceValue, rng: EngineRng, max_size: usize) Error!NativeTestCase {
        var result = try forChoicesAndTemplate(gpa, prefix, null, null, max_size, null);
        errdefer result.deinit();
        try result.withRandom(rng);
        return result;
    }
    pub fn forCounterexample(gpa: Allocator, timelines: []const []const c.ChoiceValue, rng: EngineRng, max_size: usize) Error!NativeTestCase {
        var replay = try replay_mod.Replay.counterexample(gpa, timelines);
        errdefer replay.deinit();
        const family = try FamilyCore.create(gpa, std.math.maxInt(usize));
        var result = newStream(gpa, replay, @max(max_size, replay.longest()), family);
        errdefer family.release();
        try result.withRandom(rng);
        return result;
    }
    pub fn forGraph(gpa: Allocator, source: *const graph.Graph, rng: EngineRng, max_size: usize) Error!NativeTestCase {
        var replay = try replay_mod.Replay.graph(gpa, source);
        errdefer replay.deinit();
        const family = try FamilyCore.create(gpa, std.math.maxInt(usize));
        errdefer family.release();
        var result = newStream(gpa, replay, max_size, family);
        try result.withRandom(rng);
        return result;
    }
    pub fn forExternal(gpa: Allocator, resolver: replay_mod.ExternalReplay, rng: EngineRng, max_size: usize) Error!NativeTestCase {
        var replay = try replay_mod.Replay.external(gpa, resolver);
        errdefer replay.deinit();
        const family = try FamilyCore.create(gpa, std.math.maxInt(usize));
        errdefer family.release();
        var result = newStream(gpa, replay, @max(max_size, replay.longest()), family);
        try result.withRandom(rng);
        return result;
    }
    fn withRandom(self: *NativeTestCase, rng: EngineRng) Error!void {
        var random = rng;
        const params = try GenerationParameters.draw(&random);
        self.withRandomAndParams(random, params);
    }
    pub fn withRandomAndParams(self: *NativeTestCase, rng: EngineRng, params: GenerationParameters) void {
        self.family.setGenerationParameters(params);
        self.rng = rng;
        self.family.setBudget(self.max_size);
    }
    pub fn divergence(self: *const NativeTestCase) ?replay_mod.Divergence {
        return self.replay.divergence();
    }
    pub fn liveTimelines(self: *const NativeTestCase, gpa: Allocator) Allocator.Error![]bool {
        return self.replay.live(gpa);
    }
    pub fn settledEdges(self: *const NativeTestCase, gpa: Allocator) Allocator.Error![]graph.Settled {
        return self.replay.settled(gpa);
    }
    pub fn endedOnEnd(self: *const NativeTestCase) bool {
        return self.replay.endedOnEnd();
    }
    pub fn setShouldCapture(self: *NativeTestCase) void {
        self.should_capture = true;
    }
    pub fn shouldCapture(self: *const NativeTestCase) bool {
        return self.should_capture;
    }
    pub fn setDiagnostic(self: *NativeTestCase, message: []const u8) Allocator.Error!void {
        const owned = try self.allocator.dupe(u8, message);
        if (self.diagnostic) |old| self.allocator.free(old);
        self.diagnostic = owned;
    }
    pub fn status(self: *const NativeTestCase) ?Status {
        return self.family.status();
    }
    pub fn conclude(self: *NativeTestCase, status_value: Status, origin: ?InterestingOrigin) Allocator.Error!void {
        try self.family.conclude(status_value, origin);
    }
    pub fn preChoice(self: *NativeTestCase) Error!void {
        if (self.status()) |s| return if (s == .invalid) error.InvalidTestCase else error.Overrun;
        if (self.nodes.items.len >= self.max_size or !self.family.tryTakeDraw()) {
            try self.conclude(.early_stop, null);
            return error.Overrun;
        }
    }
    pub fn startSpan(self: *NativeTestCase, label: u64) Error!usize {
        const gpa = self.allocator;
        const parent: ?usize = if (self.span_stack.getLastOrNull()) |idx| idx else null;
        const depth: u32 = @intCast(self.span_stack.items.len);
        const idx = self.spans.len();
        const start = self.nodes.items.len;
        try self.spans.inner.ensureUnusedCapacity(gpa, 1);
        try self.span_ordinals.ensureUnusedCapacity(gpa, 1);
        try self.child_nodes.ensureUnusedCapacity(gpa, 1);
        try self.span_stack.ensureUnusedCapacity(gpa, 1);
        const entry = try self.sibling_counts.getOrPut(gpa, .{ .parent = parent orelse std.math.maxInt(usize), .label = label });
        if (!entry.found_existing) entry.value_ptr.* = 0;
        self.spans.inner.appendAssumeCapacity(.{ .start = start, .end = start, .label = label, .depth = depth, .parent = parent, .discarded = false });
        self.span_ordinals.appendAssumeCapacity(entry.value_ptr.*);
        entry.value_ptr.* += 1;
        self.child_nodes.appendAssumeCapacity(0);
        self.span_stack.appendAssumeCapacity(idx);
        if (depth + 1 > MAX_DEPTH) {
            try self.conclude(.invalid, null);
            try self.freeze();
        }
        return idx;
    }
    pub fn spanDepth(self: *const NativeTestCase) usize {
        return self.span_stack.items.len;
    }
    pub fn drawAddress(self: *const NativeTestCase, gpa: Allocator) Allocator.Error![]graph.Frame {
        const result = try gpa.alloc(graph.Frame, self.span_stack.items.len + 1);
        for (self.span_stack.items, 0..) |idx, i| result[i] = .{ .label = self.spans.inner.items[idx].label, .ordinal = self.span_ordinals.items[idx] };
        const direct = if (self.span_stack.getLastOrNull()) |idx| self.nodes.items.len - self.spans.inner.items[idx].start - self.child_nodes.items[idx] else self.nodes.items.len - self.top_child_nodes;
        result[result.len - 1] = .{ .label = graph.DRAW_LABEL, .ordinal = direct };
        return result;
    }
    fn closeSpan(self: *NativeTestCase, idx: usize, end: usize) void {
        const span = &self.spans.inner.items[idx];
        span.end = end;
        const inside = end - span.start;
        if (span.parent) |parent| self.child_nodes.items[parent] += inside else self.top_child_nodes += inside;
    }
    pub fn stopSpan(self: *NativeTestCase, discard: bool) void {
        const idx = self.span_stack.pop() orelse return;
        self.closeSpan(idx, self.nodes.items.len);
        self.spans.inner.items[idx].discarded = discard;
        self.has_discards = self.has_discards or discard;
    }
    pub fn freeze(self: *NativeTestCase) Allocator.Error!void {
        if (self.frozen) return;
        self.frozen = true;
        while (self.span_stack.pop()) |idx| self.closeSpan(idx, self.nodes.items.len);
        try self.conclude(.valid, null);
        if (self.observer) |obs| if (obs.vtable.conclude_test) |f| {
            const result = self.family.conclusion().?;
            f(obs.context, result.status, result.origin);
        };
    }
    pub fn cloneStream(self: *NativeTestCase) Error!*NativeTestCaseHandle {
        try self.preChoice();
        if (self.clone_id.len + 1 > MAX_CLONE_DEPTH) {
            try self.conclude(.invalid, null);
            try self.freeze();
            return error.InvalidTestCase;
        }
        const gpa = self.allocator;
        const idx = self.nodes.items.len;
        const addr = if (self.replay.needsFrames()) try self.drawAddress(gpa) else &.{};
        defer gpa.free(addr);
        var child_replay = try self.replay.cloneChild(self.clone_id, idx, addr);
        errdefer child_replay.deinit();
        const child_rng = if (self.rng) |*rng| rng.spawn() else null;
        const child_template: ?c.ChoiceTemplate = if (self.trailing_template) |t| .{ .kind = t.kind, .count = null } else null;
        const child_max = if (child_rng != null or child_template != null) std.math.maxInt(usize) else child_replay.longest();
        const id = try gpa.alloc(usize, self.clone_id.len + 1);
        errdefer gpa.free(id);
        @memcpy(id[0..self.clone_id.len], self.clone_id);
        id[id.len - 1] = self.clone_counter;
        const empty_stream = try c.RealizedStream.empty(gpa);
        defer empty_stream.release();
        var placeholder = c.ChoiceNode.cloneStream(empty_stream, false);
        errdefer placeholder.deinit(gpa);
        try self.nodes.ensureUnusedCapacity(gpa, 1);
        try self.clone_children.ensureUnusedCapacity(gpa, 1);
        var child = newStream(gpa, child_replay, child_max, self.family);
        child.rng = child_rng;
        child.trailing_template = child_template;
        child.clone_id = id;
        child.should_capture = self.should_capture;
        const handle = try NativeTestCaseHandle.create(gpa, child);
        _ = self.family.retain();
        self.clone_counter += 1;
        self.nodes.appendAssumeCapacity(placeholder);
        self.clone_children.appendAssumeCapacity(.{ .index = idx, .handle = handle.retain() });
        return handle;
    }
    pub fn reassemble(self: *NativeTestCase) Error!void {
        if (self.status() == null) return;
        while (self.clone_children.items.len > 0) {
            const entry = self.clone_children.items[0];
            const child = entry.handle.lock();
            errdefer entry.handle.unlock();
            try child.freeze();
            try child.reassemble();
            const stream = try c.RealizedStream.create(self.allocator, child.nodes.items, child.spans.asSlice());
            defer stream.release();
            const forced = self.nodes.items[entry.index].was_forced;
            self.nodes.items[entry.index].deinit(self.allocator);
            self.nodes.items[entry.index] = c.ChoiceNode.cloneStream(stream, forced);
            _ = self.clone_children.orderedRemove(0);
            entry.handle.unlock();
            entry.handle.release();
        }
    }
    const Request = struct {
        kind: c.ChoiceKind,
        sample: union(enum) { standard, uniform, weighted: []const f64, precise, float_width: FloatWidth, fresh: struct { used: *FreshIds, fallback: i64, high: i64 }, set: struct { smallest: i64, high: i64, members: []const i64 } } = .standard,
        fn accepts(ctx: *anyopaque, value: *const c.ChoiceValue) bool {
            const self: *const Request = @ptrCast(@alignCast(ctx));
            switch (self.sample) {
                .fresh => |f| {
                    if (value.* != .integer) return false;
                    const id = value.integer.toInt(i64) orelse return false;
                    return id >= 0 and id <= f.high and !f.used.contains(id);
                },
                .set => |f| {
                    if (value.* != .integer) return false;
                    const id = value.integer.toInt(i64) orelse return false;
                    return id >= 0 and id <= f.high;
                },
                else => {},
            }
            return switch (self.kind) {
                .integer => |k| value.* == .integer and k.validate(value.integer),
                .boolean => value.* == .boolean,
                .float => |k| value.* == .float and k.validate(value.float),
                .bytes => |k| value.* == .bytes and k.validate(value.bytes),
                .string => |k| value.* == .string and k.validate(value.string),
                .clone => value.* == .clone,
            };
        }
        fn fallback(self: Request, gpa: Allocator, simplest: bool) Error!c.ChoiceValue {
            switch (self.sample) {
                .fresh => |f| return .{ .integer = try BigInt.fromInt(gpa, f.fallback) },
                .set => |f| return .{ .integer = try BigInt.fromInt(gpa, f.smallest) },
                else => return if (simplest) self.kind.simplest(gpa) else self.kind.unit(gpa),
            }
        }
        fn random(self: Request, gpa: Allocator, rng: *EngineRng, params: GenerationParameters) Error!c.ChoiceValue {
            switch (self.sample) {
                .uniform => return .{ .integer = try BigInt.fromInt(gpa, rng.rangeInclusive(u64, (self.kind.integer.min_value.toInt(u64) orelse return error.InternalError), (self.kind.integer.max_value.toInt(u64) orelse return error.InternalError))) },
                .weighted => |weights| return .{ .integer = try BigInt.fromInt(gpa, sampling.weightedIndexSample(weights, rng)) },
                .precise => return .{ .boolean = sampling.weightedBooleanSamplePrecise(self.kind.boolean.p, rng) },
                .float_width => |width| return .{ .float = try sampling.biasedFloatSample(self.kind.float, width, rng, params.float) },
                .fresh => |f| return .{ .integer = try BigInt.fromInt(gpa, f.fallback) },
                .set => |f| return .{ .integer = try BigInt.fromInt(gpa, f.members[rng.range(usize, 0, f.members.len)]) },
                .standard => {},
            }
            return switch (self.kind) {
                .integer => |k| .{ .integer = try sampling.biasedIntegerSample(gpa, k.*, rng, params.integer) },
                .boolean => |k| .{ .boolean = sampling.weightedBooleanSample(k.p, rng) },
                .float => |k| .{ .float = try sampling.biasedFloatSample(k, .F64, rng, params.float) },
                .bytes => |k| .{ .bytes = try sampling.biasedBytesSample(gpa, k, rng) },
                .string => |k| .{ .string = try sampling.biasedStringSample(gpa, k, rng) },
                .clone => error.InternalError,
            };
        }
    };
    fn resolveChoice(self: *NativeTestCase, request: Request) Error!c.ChoiceValue {
        try self.preChoice();
        const idx = self.nodes.items.len;
        const gpa = self.allocator;
        const addr = if (self.replay.needsFrames()) try self.drawAddress(gpa) else &.{};
        defer gpa.free(addr);
        var req = request;
        const resolved = self.replay.resolve(self.clone_id, idx, addr, .{ .context = &req, .call = Request.accepts }) catch |err| return switch (err) {
            error.OutOfMemory => error.OutOfMemory,
            else => error.InternalError,
        };
        switch (resolved) {
            .served => |v| return v.deepClone(gpa),
            .misfit => |m| {
                var simplest = false;
                if (self.replay.proposalNode(m.timeline, idx)) |node| {
                    var value = try node.data.simplestValue(gpa);
                    defer value.deinit(gpa);
                    simplest = m.value.eql(&value);
                }
                return request.fallback(gpa, simplest);
            },
            .exhausted => {},
        }
        if (self.trailing_template) |*template| {
            if (template.count == 0) {
                try self.conclude(.early_stop, null);
                return error.Overrun;
            }
            const value = try request.fallback(gpa, true);
            if (template.count) |*count| count.* -= 1;
            return value;
        }
        if (self.rng) |*rng| return request.random(gpa, rng, self.family.generationParameters());
        return error.InternalError;
    }
    fn record(self: *NativeTestCase, kind: c.ChoiceKind, value: *const c.ChoiceValue, forced: bool) Error!void {
        var data = (try kind.resolve(self.allocator, value)) orelse return error.InternalError;
        defer data.deinit(self.allocator);
        var node = c.ChoiceNode.init(try data.deepClone(self.allocator), forced);
        errdefer node.deinit(self.allocator);
        try self.nodes.append(self.allocator, node);
    }
    fn observe(self: *NativeTestCase, value: *const c.ChoiceValue, forced: bool) Error!void {
        const obs = self.observer orelse return;
        switch (value.*) {
            .integer => |*v| if (obs.vtable.draw_integer) |f| f(obs.context, v, forced),
            .boolean => |v| if (obs.vtable.draw_boolean) |f| f(obs.context, v, forced),
            .float => |v| if (obs.vtable.draw_float) |f| f(obs.context, v, forced),
            .bytes => |v| if (obs.vtable.draw_bytes) |f| f(obs.context, v, forced),
            .string => |v| if (obs.vtable.draw_string) |f| {
                const text = try sampling.codepointsToString(self.allocator, v);
                defer self.allocator.free(text);
                f(obs.context, text, forced);
            },
            .clone => {},
        }
    }
    fn integerKind(self: *NativeTestCase, min: BigInt, max: BigInt) Error!c.IntegerChoice {
        return .{ .min_value = min, .max_value = max, .shrink_towards = try BigInt.fromInt(self.allocator, @as(u8, 0)) };
    }
    fn integerDraw(self: *NativeTestCase, kind: *const c.IntegerChoice, sample: @FieldType(Request, "sample")) Error!BigInt {
        var value = try self.resolveChoice(.{ .kind = .{ .integer = kind }, .sample = sample });
        errdefer value.deinit(self.allocator);
        try self.observe(&value, false);
        try self.record(.{ .integer = kind }, &value, false);
        return value.integer;
    }
    pub fn drawInteger(self: *NativeTestCase, min: BigInt, max: BigInt) Error!BigInt {
        if (min.order(max) == .gt) return error.InternalError;
        var kind = try self.integerKind(min, max);
        defer kind.shrink_towards.deinit();
        return self.integerDraw(&kind, .standard);
    }
    pub fn drawIntegerUniform(self: *NativeTestCase, min: u64, max: u64) Error!u64 {
        var lo = try BigInt.fromInt(self.allocator, min);
        defer lo.deinit();
        var hi = try BigInt.fromInt(self.allocator, max);
        defer hi.deinit();
        var kind = try self.integerKind(lo, hi);
        defer kind.shrink_towards.deinit();
        var value = try self.integerDraw(&kind, .uniform);
        defer value.deinit();
        return value.toInt(u64) orelse error.InternalError;
    }
    pub fn drawIndexWeighted(self: *NativeTestCase, weights: []const f64) Error!usize {
        if (weights.len == 0) return error.InternalError;
        var only: ?usize = null;
        var count: usize = 0;
        for (weights, 0..) |w, i| if (w > 0) {
            count += 1;
            only = i;
        };
        var lo = try BigInt.fromInt(self.allocator, @as(u8, 0));
        defer lo.deinit();
        var hi = try BigInt.fromInt(self.allocator, weights.len - 1);
        defer hi.deinit();
        if (count == 1) {
            var value = try BigInt.fromInt(self.allocator, only.?);
            defer value.deinit();
            try self.drawIntegerForced(lo, hi, value);
            return only.?;
        }
        var kind = try self.integerKind(lo, hi);
        defer kind.shrink_towards.deinit();
        var value = try self.integerDraw(&kind, .{ .weighted = weights });
        defer value.deinit();
        return value.toInt(usize) orelse error.InternalError;
    }
    pub fn drawIntegerForced(self: *NativeTestCase, min: BigInt, max: BigInt, value: BigInt) Error!void {
        var kind = try self.integerKind(min, max);
        defer kind.shrink_towards.deinit();
        if (!kind.validate(value)) return error.InternalError;
        try self.preChoice();
        const v: c.ChoiceValue = .{ .integer = value };
        try self.observe(&v, true);
        try self.record(.{ .integer = &kind }, &v, true);
    }
    pub fn drawFreshId(self: *NativeTestCase) Error!i64 {
        self.family.fresh_mutex.lock();
        defer self.family.fresh_mutex.unlock();
        const used = &self.family.fresh_ids;
        const high = used.maxUsed() + 2;
        const fallback = used.smallestUnused();
        var lo = try BigInt.fromInt(self.allocator, @as(u8, 0));
        defer lo.deinit();
        var hi = try BigInt.fromInt(self.allocator, high);
        defer hi.deinit();
        var kind = try self.integerKind(lo, hi);
        defer kind.shrink_towards.deinit();
        var value = try self.integerDraw(&kind, .{ .fresh = .{ .used = used, .fallback = fallback, .high = high } });
        defer value.deinit();
        const id = value.toInt(i64) orelse return error.InternalError;
        try used.insert(id);
        return id;
    }
    pub fn drawFromSet(self: *NativeTestCase, members: []const i64) Error!i64 {
        if (members.len == 0) return error.InternalError;
        const sorted = try self.allocator.dupe(i64, members);
        defer self.allocator.free(sorted);
        std.mem.sort(i64, sorted, {}, std.sort.asc(i64));
        var count: usize = 0;
        for (sorted) |id| {
            if (count == 0 or sorted[count - 1] != id) {
                sorted[count] = id;
                count += 1;
            }
        }
        self.family.fresh_mutex.lock();
        const high = self.family.fresh_ids.maxUsed() + 1;
        self.family.fresh_mutex.unlock();
        if (sorted[0] < 0 or sorted[count - 1] > high) return error.InternalError;
        var lo = try BigInt.fromInt(self.allocator, @as(u8, 0));
        defer lo.deinit();
        var hi = try BigInt.fromInt(self.allocator, high);
        defer hi.deinit();
        var kind = try self.integerKind(lo, hi);
        defer kind.shrink_towards.deinit();
        var value = try self.resolveChoice(.{ .kind = .{ .integer = &kind }, .sample = .{ .set = .{ .smallest = sorted[0], .high = high, .members = sorted[0..count] } } });
        defer value.deinit(self.allocator);
        const raw = value.integer.toInt(i64) orelse return error.InternalError;
        var chosen = sorted[0];
        for (sorted[0..count]) |id| {
            if (id > raw) break;
            chosen = id;
        }
        var actual: c.ChoiceValue = .{ .integer = try BigInt.fromInt(self.allocator, chosen) };
        defer actual.deinit(self.allocator);
        try self.observe(&actual, false);
        try self.record(.{ .integer = &kind }, &actual, false);
        return chosen;
    }
    pub fn drawFloat(self: *NativeTestCase, width: FloatWidth, min: f64, max: f64, allow_nan: bool, allow_infinity: bool, smallest: f64) Error!f64 {
        const kind: c.ChoiceKind = .{ .float = .{ .min_value = min, .max_value = max, .allow_nan = allow_nan, .allow_infinity = allow_infinity, .smallest_nonzero_magnitude = smallest } };
        var value = try self.resolveChoice(.{ .kind = kind, .sample = .{ .float_width = width } });
        defer value.deinit(self.allocator);
        try self.record(kind, &value, false);
        try self.observe(&value, false);
        return value.float;
    }
    pub fn drawBytes(self: *NativeTestCase, min: usize, max: usize) Error![]u8 {
        if (min > max) return error.InternalError;
        const kind: c.ChoiceKind = .{ .bytes = .{ .min_size = min, .max_size = max } };
        var value = try self.resolveChoice(.{ .kind = kind });
        errdefer value.deinit(self.allocator);
        try self.record(kind, &value, false);
        try self.observe(&value, false);
        return value.bytes;
    }
    pub fn drawString(self: *NativeTestCase, intervals: *const c.IntervalSet, min: usize, max: usize) Error![]u8 {
        if (min > max or (intervals.intervals.len == 0 and max != 0)) return error.InternalError;
        const kind: c.ChoiceKind = .{ .string = .{ .intervals = intervals, .min_size = min, .max_size = max } };
        var value = try self.resolveChoice(.{ .kind = kind });
        defer value.deinit(self.allocator);
        try self.record(kind, &value, false);
        const text = try sampling.codepointsToString(self.allocator, value.string);
        errdefer self.allocator.free(text);
        if (self.observer) |obs| if (obs.vtable.draw_string) |f| f(obs.context, text, false);
        return text;
    }
    pub fn weighted(self: *NativeTestCase, p: f64, forced: ?bool) Error!bool {
        return self.weightedWith(p, forced, false);
    }
    pub fn weightedPrecise(self: *NativeTestCase, p: f64, forced: ?bool) Error!bool {
        return self.weightedWith(p, forced, true);
    }
    fn weightedWith(self: *NativeTestCase, p: f64, forced: ?bool, precise: bool) Error!bool {
        const actual_forced = forced orelse if (p <= 0) false else if (p >= 1) true else null;
        const kind: c.ChoiceKind = .{ .boolean = .{ .p = p } };
        var value = if (actual_forced) |v| blk: {
            try self.preChoice();
            break :blk c.ChoiceValue{ .boolean = v };
        } else try self.resolveChoice(.{ .kind = kind, .sample = if (precise) .precise else .standard });
        defer value.deinit(self.allocator);
        try self.record(kind, &value, actual_forced != null);
        try self.observe(&value, actual_forced != null);
        return value.boolean;
    }
};

// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const database = @import("database.zig");
const choices = @import("choices.zig");
const base64 = @import("base64.zig");
const graph = @import("graph.zig");
const Allocator = std.mem.Allocator;
pub const max_decompressed_len: usize = 64 << 20;
const magic = [_]u8{ 255, 255, 255, 255 };

pub const NdReproState = struct {
    graph: graph.Graph,
    entropy: u64,
    longest: u32,

    pub fn deinit(self: *NdReproState) void {
        self.graph.deinit();
        self.* = undefined;
    }
};

pub const DecodedBlob = union(enum) {
    choices: []choices.ChoiceValue,
    nd: NdReproState,

    pub fn deinit(self: *DecodedBlob, allocator: Allocator) void {
        switch (self.*) {
            .choices => |values| database.deinitValues(allocator, values),
            .nd => |*state| state.deinit(),
        }
        self.* = undefined;
    }
};

pub fn encodeFailure(allocator: Allocator, values: []const choices.ChoiceValue) !?[]u8 {
    const raw = try database.serializeChoices(allocator, values) orelse return null;
    defer allocator.free(raw);
    return try encodePayload(allocator, raw, 0);
}

pub fn encodeNdState(allocator: Allocator, state: *const NdReproState) !?[]u8 {
    const encoded = try state.graph.encode() orelse return null;
    defer state.graph.allocator.free(encoded);
    const out = try allocator.alloc(u8, 17 + encoded.len);
    @memcpy(out[0..4], &magic);
    out[4] = 3;
    std.mem.writeInt(u64, out[5..13], state.entropy, .little);
    std.mem.writeInt(u32, out[13..17], state.longest, .little);
    @memcpy(out[17..], encoded);
    return out;
}

pub fn decodeNdState(allocator: Allocator, bytes: []const u8) !?NdReproState {
    if (bytes.len < 17 or !std.mem.eql(u8, bytes[0..4], &magic) or bytes[4] != 3) return null;
    const parsed = try graph.Graph.decode(allocator, bytes[17..]) orelse return null;
    return .{
        .graph = parsed,
        .entropy = std.mem.readInt(u64, bytes[5..13], .little),
        .longest = std.mem.readInt(u32, bytes[13..17], .little),
    };
}

pub fn encodeNdFailure(allocator: Allocator, state: *const NdReproState) !?[]u8 {
    const raw = try encodeNdState(allocator, state) orelse return null;
    defer allocator.free(raw);
    return try encodePayload(allocator, raw, 2);
}

fn encodePayload(allocator: Allocator, raw: []const u8, raw_prefix: u8) ![]u8 {
    var compressed = try std.Io.Writer.Allocating.initCapacity(allocator, 256);
    defer compressed.deinit();
    var buffer: [std.compress.flate.max_window_len]u8 = undefined;
    var compressor = std.compress.flate.Compress.init(&compressed.writer, &buffer, .zlib, .default) catch return error.OutOfMemory;
    compressor.writer.writeAll(raw) catch return error.OutOfMemory;
    compressor.finish() catch return error.OutOfMemory;
    const use_compressed = compressed.written().len < raw.len and raw.len <= max_decompressed_len;
    const body = if (use_compressed) compressed.written() else raw;
    const payload = try allocator.alloc(u8, 1 + body.len);
    defer allocator.free(payload);
    payload[0] = raw_prefix + @intFromBool(use_compressed);
    @memcpy(payload[1..], body);
    return base64.encode(allocator, payload);
}

pub fn decodeBlob(allocator: Allocator, encoded: []const u8) !?DecodedBlob {
    const bytes = try base64.decode(allocator, encoded) orelse return null;
    defer allocator.free(bytes);
    if (bytes.len == 0 or bytes[0] > 3) return null;
    const prefix = bytes[0];
    const raw = if (prefix & 1 == 1) raw: {
        var input: std.Io.Reader = .fixed(bytes[1..]);
        var decompress = std.compress.flate.Decompress.init(&input, .zlib, &.{});
        break :raw decompress.reader.allocRemaining(allocator, .limited(max_decompressed_len)) catch |err| {
            if (err == error.OutOfMemory) return err;
            return null;
        };
    } else try allocator.dupe(u8, bytes[1..]);
    defer allocator.free(raw);
    if (prefix < 2) {
        return .{ .choices = try database.deserializeChoices(allocator, raw) orelse return null };
    }
    return .{ .nd = try decodeNdState(allocator, raw) orelse return null };
}

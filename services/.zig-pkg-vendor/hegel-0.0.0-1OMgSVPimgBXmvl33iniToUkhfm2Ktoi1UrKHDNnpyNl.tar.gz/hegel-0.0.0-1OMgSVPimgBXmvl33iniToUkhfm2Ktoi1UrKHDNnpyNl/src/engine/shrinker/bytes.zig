// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/bytes.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
fn bytesAt(self: *Shrinker, i: usize) !struct { c.BytesChoice, []const u8 } {
    if (i >= self.current_nodes.len) return error.NodeGone;
    const pair = self.current_nodes[i].data.asBytes() orelse return error.NodeGone;
    return .{ pair[0].*, pair[1] };
}
fn value(self: *Shrinker, a: std.mem.Allocator, i: usize) ![]u8 {
    const pair = try bytesAt(self, i);
    return a.dupe(u8, pair[1]);
}
fn replace(self: *Shrinker, i: usize, bytes: []u8) !bool {
    return self.replace(&.{.{ .index = i, .value = .{ .bytes = bytes } }});
}
pub fn shrinkBytes(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        shrinkBytesNode(self, i) catch |err| {
            if (err != error.NodeGone) return err;
        };
    }
}
fn shrinkBytesNode(self: *Shrinker, i: usize) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const pair = try bytesAt(self, i);
    const min = pair[0].min_size;
    const simplest = try a.alloc(u8, min);
    @memset(simplest, 0);
    if (!std.mem.eql(u8, simplest, pair[1])) _ = try replace(self, i, simplest);
    const captured = try value(self, a, i);
    if (captured.len > min) {
        var search = root.search.BinSearchDown.init(@intCast(min), @intCast(captured.len));
        while (search.probe()) |sz| {
            search.record(try replace(self, i, try a.dupe(u8, captured[0..@intCast(sz)])));
        }
    }
    const scan_end = @min(min + 8, (try value(self, a, i)).len);
    for (@min(min, scan_end)..scan_end) |size| {
        const current = try value(self, a, i);
        if (size > current.len) break;
        _ = try replace(self, i, try a.dupe(u8, current[0..size]));
    }
    var j = (try value(self, a, i)).len;
    while (j > 0) {
        j -= 1;
        const current = try value(self, a, i);
        if (current.len <= min) continue;
        const candidate = try a.alloc(u8, current.len - 1);
        @memcpy(candidate[0..j], current[0..j]);
        @memcpy(candidate[j..], current[j + 1 ..]);
        _ = try replace(self, i, candidate);
    }
    j = (try value(self, a, i)).len;
    while (j > 0) {
        j -= 1;
        const current = try value(self, a, i);
        if (current[j] == 0) continue;
        var search = root.search.BinSearchDown.init(0, current[j]);
        while (search.probe()) |e| {
            const candidate = try value(self, a, i);
            candidate[j] = @intCast(e);
            search.record(try replace(self, i, candidate));
        }
    }
    var pos: usize = 1;
    while (true) : (pos += 1) {
        const current = try value(self, a, i);
        if (pos >= current.len) break;
        j = pos;
        while (j > 0) {
            const cand = try value(self, a, i);
            if (cand[j - 1] <= cand[j]) break;
            std.mem.swap(u8, &cand[j - 1], &cand[j]);
            if (try replace(self, i, cand)) {
                j -= 1;
            } else break;
        }
    }
}
fn indices(self: *Shrinker, a: std.mem.Allocator) ![]usize {
    var list: std.ArrayList(usize) = .empty;
    for (self.current_nodes, 0..) |n, i| {
        if (n.data == .bytes) try list.append(a, i);
    }
    return list.toOwnedSlice(a);
}
pub fn redistributeBytesPairs(self: *Shrinker) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    for (1..3) |gap| {
        var idx: usize = 0;
        while (true) : (idx += 1) {
            const ids = try indices(self, a);
            if (idx + gap >= ids.len) break;
            redistributePair(self, ids[idx], ids[idx + gap]) catch |err| {
                if (err != error.NodeGone) return err;
            };
        }
    }
}
fn redistributePair(self: *Shrinker, i: usize, j: usize) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const s = try value(self, a, i);
    const pair = try bytesAt(self, j);
    const kind = pair[0];
    const t = try a.dupe(u8, pair[1]);
    if (s.len == 0) return;
    if (try redistribute(self, a, i, j, s, t, s.len, kind)) return;
    if (!try redistribute(self, a, i, j, s, t, 1, kind)) return;
    var search = root.search.FindInteger.init();
    while (search.probe()) |extra| {
        const n = 1 + extra;
        search.record(if (n > s.len) false else try redistribute(self, a, i, j, s, t, n, kind));
    }
}
fn redistribute(self: *Shrinker, a: std.mem.Allocator, i: usize, j: usize, s: []const u8, t: []const u8, n: usize, kind: c.BytesChoice) !bool {
    const new_t = try a.alloc(u8, n + t.len);
    @memcpy(new_t[0..n], s[s.len - n ..]);
    @memcpy(new_t[n..], t);
    if (!kind.validate(new_t)) return false;
    return self.replace(&.{ .{ .index = i, .value = .{ .bytes = try a.dupe(u8, s[0 .. s.len - n]) } }, .{ .index = j, .value = .{ .bytes = new_t } } });
}

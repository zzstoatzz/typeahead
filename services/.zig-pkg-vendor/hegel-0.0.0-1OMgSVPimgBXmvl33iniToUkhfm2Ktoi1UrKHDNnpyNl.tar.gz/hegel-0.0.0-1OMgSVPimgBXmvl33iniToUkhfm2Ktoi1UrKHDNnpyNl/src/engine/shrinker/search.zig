// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/search.rs; see provenance.
const std = @import("std");
pub const BigInt = @import("../bignum.zig").BigInt;
pub fn SearchStep(comptime T: type) type {
    return union(enum) { probe: T, done: T };
}
pub const FindInteger = struct {
    const Self = @This();
    state: union(enum) { linear: usize, grow: Bounds, narrow: Bounds, done: usize } = .{ .linear = 1 },
    const Bounds = struct { lo: usize, hi: usize };
    pub fn init() Self {
        return .{};
    }
    pub fn step(self: Self) SearchStep(usize) {
        return switch (self.state) {
            .linear => |i| .{ .probe = i },
            .grow => |b| .{ .probe = b.hi },
            .narrow => |b| .{ .probe = b.lo + (b.hi - b.lo) / 2 },
            .done => |v| .{ .done = v },
        };
    }
    pub fn probe(self: Self) ?usize {
        return switch (self.step()) {
            .probe => |v| v,
            .done => null,
        };
    }
    pub fn record(self: *Self, ok: bool) void {
        self.state = switch (self.state) {
            .linear => |i| if (!ok) .{ .done = i - 1 } else if (i < 4) .{ .linear = i + 1 } else .{ .grow = .{ .lo = 4, .hi = 5 } },
            .grow => |b| if (ok) blk: {
                const next = @mulWithOverflow(b.hi, @as(usize, 2));
                break :blk if (next[1] == 0) .{ .grow = .{ .lo = b.hi, .hi = next[0] } } else .{ .done = b.hi };
            } else narrowOrDone(b.lo, b.hi),
            .narrow => |b| blk: {
                const mid = b.lo + (b.hi - b.lo) / 2;
                break :blk if (ok) narrowOrDone(mid, b.hi) else narrowOrDone(b.lo, mid);
            },
            .done => |v| .{ .done = v },
        };
    }
    fn narrowOrDone(lo: usize, hi: usize) @FieldType(Self, "state") {
        return if (lo + 1 < hi) .{ .narrow = .{ .lo = lo, .hi = hi } } else .{ .done = lo };
    }
};
pub const BinSearchDown = struct {
    const Self = @This();
    const Bounds = struct { lo: i128, hi: i128 };
    state: union(enum) { check_lo: Bounds, narrow: Bounds, done: i128 },
    pub fn init(lo: i128, hi: i128) Self {
        return .{ .state = .{ .check_lo = .{ .lo = lo, .hi = hi } } };
    }
    pub fn step(self: Self) SearchStep(i128) {
        return switch (self.state) {
            .check_lo => |b| .{ .probe = b.lo },
            .narrow => |b| .{ .probe = b.lo + @divTrunc(b.hi - b.lo, 2) },
            .done => |v| .{ .done = v },
        };
    }
    pub fn probe(self: Self) ?i128 {
        return switch (self.step()) {
            .probe => |v| v,
            .done => null,
        };
    }
    pub fn record(self: *Self, ok: bool) void {
        self.state = switch (self.state) {
            .check_lo => |b| if (ok) .{ .done = b.lo } else narrowOrDone(b.lo, b.hi),
            .narrow => |b| blk: {
                const mid = b.lo + @divTrunc(b.hi - b.lo, 2);
                break :blk if (ok) narrowOrDone(b.lo, mid) else narrowOrDone(mid, b.hi);
            },
            .done => |v| .{ .done = v },
        };
    }
    fn narrowOrDone(lo: i128, hi: i128) @FieldType(Self, "state") {
        const next = @addWithOverflow(lo, @as(i128, 1));
        return if (next[1] == 0 and next[0] < hi) .{ .narrow = .{ .lo = lo, .hi = hi } } else .{ .done = hi };
    }
};
pub const BinSearchDownBig = struct {
    const Self = @This();
    allocator: std.mem.Allocator,
    lo: BigInt,
    hi: BigInt,
    phase: enum { check_lo, narrow, done } = .check_lo,
    pub fn init(gpa: std.mem.Allocator, lo: BigInt, hi: BigInt) Self {
        return .{ .allocator = gpa, .lo = lo, .hi = hi };
    }
    pub fn deinit(self: *Self) void {
        self.lo.deinit();
        self.hi.deinit();
    }
    fn midpoint(self: Self) !BigInt {
        var delta = try self.hi.sub(self.allocator, self.lo);
        defer delta.deinit();
        var two = try BigInt.fromInt(self.allocator, 2);
        defer two.deinit();
        var half = try delta.div(self.allocator, two);
        defer half.deinit();
        return self.lo.add(self.allocator, half);
    }
    pub fn step(self: Self) !SearchStep(BigInt) {
        return switch (self.phase) {
            .check_lo => .{ .probe = try self.lo.clone(self.allocator) },
            .narrow => .{ .probe = try self.midpoint() },
            .done => .{ .done = try self.hi.clone(self.allocator) },
        };
    }
    pub fn probe(self: Self) !?BigInt {
        return switch (self.phase) {
            .check_lo => try self.lo.clone(self.allocator),
            .narrow => try self.midpoint(),
            .done => null,
        };
    }
    pub fn record(self: *Self, ok: bool) !void {
        switch (self.phase) {
            .done => return,
            .check_lo => {
                if (ok) {
                    const n = try self.lo.clone(self.allocator);
                    self.hi.deinit();
                    self.hi = n;
                    self.phase = .done;
                    return;
                }
            },
            .narrow => {
                const mid = try self.midpoint();
                if (ok) {
                    self.hi.deinit();
                    self.hi = mid;
                } else {
                    self.lo.deinit();
                    self.lo = mid;
                }
            },
        }
        var next = try self.lo.addInt(self.allocator, 1);
        defer next.deinit();
        self.phase = if (next.order(self.hi) == .lt) .narrow else .done;
    }
};

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/sequence.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
pub fn sortValues(self: *Shrinker) !void {
    try sortGroup(self, .integer);
    try sortGroup(self, .boolean);
}
pub fn sortGroup(self: *Shrinker, tag: std.meta.Tag(c.ChoiceData)) !void {
    const gpa = self.allocator;
    var indices: std.ArrayList(usize) = .empty;
    defer indices.deinit(gpa);
    for (self.current_nodes, 0..) |node, i| {
        if (std.meta.activeTag(node.data) == tag) try indices.append(gpa, i);
    }
    if (indices.items.len < 2) return;
    const sorted = try gpa.dupe(usize, indices.items);
    defer gpa.free(sorted);
    // Stable insertion sort preserves the upstream stable key sort.
    for (1..sorted.len) |pos| {
        var j = pos;
        while (j > 0) : (j -= 1) {
            const a = self.current_nodes[sorted[j - 1] .. sorted[j - 1] + 1];
            const b = self.current_nodes[sorted[j] .. sorted[j] + 1];
            if (try c.nodesOrder(gpa, a, b) != .gt) break;
            std.mem.swap(usize, &sorted[j - 1], &sorted[j]);
        }
    }
    var different = false;
    for (indices.items, sorted) |a, b| {
        if (!self.current_nodes[a].data.valueRef().eql(self.current_nodes[b].data.valueRef())) {
            different = true;
            break;
        }
    }
    if (different) {
        var replacements: std.ArrayList(root.Replacement) = .empty;
        defer {
            for (replacements.items) |*r| r.value.deinit(gpa);
            replacements.deinit(gpa);
        }
        for (indices.items, sorted) |dest, source| {
            var v = try self.current_nodes[source].value(gpa);
            errdefer v.deinit(gpa);
            try replacements.append(gpa, .{ .index = dest, .value = v });
        }
        if (try self.replace(replacements.items)) return;
    }
    for (1..indices.items.len) |pos| {
        var j = pos;
        while (j > 0) {
            var valid: std.ArrayList(usize) = .empty;
            defer valid.deinit(gpa);
            for (indices.items) |i| {
                if (i < self.current_nodes.len and std.meta.activeTag(self.current_nodes[i].data) == tag) try valid.append(gpa, i);
            }
            if (j >= valid.items.len) break;
            const idx = valid.items[j];
            const prev = valid.items[j - 1];
            if (try c.nodesOrder(gpa, self.current_nodes[prev .. prev + 1], self.current_nodes[idx .. idx + 1]) != .gt) break;
            var v = try self.current_nodes[idx].value(gpa);
            defer v.deinit(gpa);
            var p = try self.current_nodes[prev].value(gpa);
            defer p.deinit(gpa);
            const swap = [_]root.Replacement{ .{ .index = prev, .value = v }, .{ .index = idx, .value = p } };
            if (try self.replace(&swap)) {
                j -= 1;
                continue;
            }
            break;
        }
    }
}
pub fn swapAdjacentBlocks(self: *Shrinker) !void {
    const gpa = self.allocator;
    for (2..9) |size| {
        var i: usize = 0;
        while (i + 2 * size <= self.current_nodes.len) : (i += 1) {
            const j = i + size;
            var match = true;
            var same = true;
            for (0..size) |k| {
                const a = &self.current_nodes[i + k];
                const b = &self.current_nodes[j + k];
                if (std.meta.activeTag(a.data) != std.meta.activeTag(b.data)) {
                    match = false;
                    break;
                }
                if (!a.data.valueRef().eql(b.data.valueRef())) same = false;
            }
            if (!match or same) continue;
            var swap: std.ArrayList(root.Replacement) = .empty;
            defer {
                for (swap.items) |*r| r.value.deinit(gpa);
                swap.deinit(gpa);
            }
            for (0..size) |k| {
                var b = try self.current_nodes[j + k].value(gpa);
                errdefer b.deinit(gpa);
                try swap.append(gpa, .{ .index = i + k, .value = b });
                var a = try self.current_nodes[i + k].value(gpa);
                errdefer a.deinit(gpa);
                try swap.append(gpa, .{ .index = j + k, .value = a });
            }
            _ = try self.replace(swap.items);
        }
    }
}

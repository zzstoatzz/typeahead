// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/coarse.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
pub fn initialCoarseReduction(self: *Shrinker) !void {
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        const node = try self.current_nodes[i].deepClone(gpa);
        var snapshot = node;
        defer snapshot.deinit(gpa);
        const pair = node.data.asInteger() orelse continue;
        const current = pair[1].toInt(i32) orelse continue;
        if (node.was_forced or current > 10 or !pair[0].min_value.isZero()) continue;
        const zeroed = try c.cloneNodes(gpa, self.current_nodes);
        defer c.deinitNodes(gpa, zeroed);
        var zero = c.ChoiceValue{ .integer = try c.BigInt.fromInt(gpa, 0) };
        defer zero.deinit(gpa);
        const replacement = try zeroed[i].withValue(gpa, &zero) orelse return error.InternalError;
        zeroed[i].deinit(gpa);
        zeroed[i] = replacement;
        var out = try self.runTestFn(.{ .full = zeroed });
        defer out.run.deinit(gpa);
        var changed = out.run.nodes.len != self.current_nodes.len;
        if (!changed) {
            for (i + 1..self.current_nodes.len) |j| {
                if (std.meta.activeTag(self.current_nodes[j].data) != std.meta.activeTag(out.run.nodes[j].data)) {
                    changed = true;
                    break;
                }
            }
        }
        if (changed) {
            var v: i32 = 0;
            while (v < current) : (v += 1) {
                var candidate = try c.BigInt.fromInt(gpa, v);
                defer candidate.deinit();
                if (try tryLowerNodeAsAlternative(self, i, &candidate)) break;
            }
        }
    }
}
pub fn tryLowerNodeAsAlternative(self: *Shrinker, i: usize, v: *const c.BigInt) !bool {
    if (i >= self.current_nodes.len) return error.InternalError;
    if (try self.replaceInt(i, v)) return true;
    const gpa = self.allocator;
    const prefix = try gpa.alloc(c.ChoiceValue, i + 1);
    var count: usize = 0;
    defer {
        for (prefix[0..count]) |*value| value.deinit(gpa);
        gpa.free(prefix);
    }
    for (self.current_nodes[0..i], prefix[0..i]) |*node, *dest| {
        dest.* = try node.value(gpa);
        count += 1;
    }
    prefix[i] = .{ .integer = try v.clone(gpa) };
    count += 1;
    const max_size = c.flattenedLen(self.current_nodes) + 16;
    const epoch = self.improvements;
    for (0..3) |_| {
        try self.probe(prefix, max_size);
        if (self.improvements > epoch) return true;
    }
    return false;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/scheduling.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const Shrinker = root.Shrinker;
pub const ShrinkPass = struct {
    name: []const u8,
    run: *const fn (*Shrinker) anyerror!void,
    calls: usize = 0,
    shrinks: usize = 0,
    deletions: usize = 0,
    stochastic: bool = false,
};
pub fn fixateShrinkPasses(self: *Shrinker, passes: []ShrinkPass) !void {
    while (true) {
        while (try passIteration(self, passes)) {}
        const mode = self.evaluator.set_sweep_mode orelse return;
        const previous = mode(self.evaluator.context, .confirm) orelse return;
        self.sweep = .confirm;
        const confirmed = passIteration(self, passes);
        _ = mode(self.evaluator.context, previous);
        self.sweep = .fast;
        if (!try confirmed) return;
    }
}
pub fn passIteration(self: *Shrinker, passes: []ShrinkPass) !bool {
    var any_ran = false;
    self.calls_at_last_shrink = self.calls;
    var can_discard = try self.removeDiscarded();
    const calls_at_loop_start = self.calls;
    var max_calls_per_failing_step: usize = 1;
    const keys = try self.allocator.alloc(i32, passes.len);
    defer self.allocator.free(keys);
    for (passes, 0..) |*pass, idx| {
        if (can_discard) can_discard = try self.removeDiscarded();
        const before_len = self.current_nodes.len;
        const epoch = self.improvements;
        const max_failures: usize = if (pass.stochastic) 6 else 1;
        var failures: usize = 0;
        while (failures < max_failures) {
            self.max_stall = @max(self.max_stall, max_calls_per_failing_step *| 2 +| (self.calls -| calls_at_loop_start));
            if (self.debug != null) {
                const msg = try std.fmt.allocPrint(self.allocator, "Trying shrink pass: {s}", .{pass.name});
                defer self.allocator.free(msg);
                self.debugMsg(msg);
            }
            pass.calls += 1;
            const before = self.improvements;
            const initial_calls = self.calls;
            try pass.run(self);
            if (self.improvements > before) {
                pass.shrinks += 1;
                if (self.current_nodes.len < before_len) pass.deletions += 1;
                any_ran = true;
                failures = 0;
                if (pass.stochastic) break;
            } else if (initial_calls != self.calls) {
                max_calls_per_failing_step = @max(max_calls_per_failing_step, self.calls -| initial_calls);
                failures += 1;
            } else break;
        }
        keys[idx] = if (self.current_nodes.len < before_len) -1 else if (self.improvements > epoch) 0 else 1;
    }
    for (@min(@as(usize, 1), passes.len)..passes.len) |pos| {
        var j = pos;
        while (j > 0 and keys[j] < keys[j - 1]) : (j -= 1) {
            std.mem.swap(i32, &keys[j], &keys[j - 1]);
            std.mem.swap(ShrinkPass, &passes[j], &passes[j - 1]);
        }
    }
    return any_ran;
}
pub const PassStat = struct { name: []const u8, calls: usize, shrinks: usize, deletions: usize };
pub fn passStats(gpa: std.mem.Allocator, passes: []const ShrinkPass) ![]PassStat {
    const out = try gpa.alloc(PassStat, passes.len);
    for (passes, out) |p, *v| v.* = .{ .name = p.name, .calls = p.calls, .shrinks = p.shrinks, .deletions = p.deletions };
    return out;
}
fn plural(n: usize) []const u8 {
    return if (n == 1) "" else "s";
}
fn statLess(_: void, a: PassStat, b: PassStat) bool {
    if (a.calls != b.calls) return a.calls > b.calls;
    if (a.deletions != b.deletions) return a.deletions < b.deletions;
    return a.shrinks < b.shrinks;
}
pub fn emitProfileReport(self: *Shrinker, passes: []const ShrinkPass, initial_size: usize, initial_calls: usize) !void {
    if (self.debug == null) return;
    const gpa = self.allocator;
    const total_calls = self.calls -| initial_calls;
    const deleted = initial_size -| self.current_nodes.len;
    self.debugMsg("---------------------");
    self.debugMsg("Shrink pass profiling");
    self.debugMsg("---------------------");
    self.debugMsg("");
    const summary = try std.fmt.allocPrint(gpa, "Shrinking made a total of {d} call{s} of which {d} shrank. This deleted {d} choice{s} out of {d}.", .{ total_calls, plural(total_calls), self.improvements, deleted, plural(deleted), initial_size });
    defer gpa.free(summary);
    self.debugMsg(summary);
    for ([_]bool{ true, false }) |useful| {
        self.debugMsg("");
        self.debugMsg(if (useful) "Useful passes:" else "Useless passes:");
        self.debugMsg("");
        var bucket: std.ArrayList(PassStat) = .empty;
        defer bucket.deinit(gpa);
        for (passes) |p| {
            if (p.calls > 0 and (p.shrinks > 0) == useful) try bucket.append(gpa, .{ .name = p.name, .calls = p.calls, .shrinks = p.shrinks, .deletions = p.deletions });
        }
        std.mem.sort(PassStat, bucket.items, {}, statLess);
        for (bucket.items) |p| {
            const line = try std.fmt.allocPrint(gpa, "  * {s} made {d} call{s} of which {d} shrank, deleting {d} choice{s}.", .{ p.name, p.calls, plural(p.calls), p.shrinks, p.deletions, plural(p.deletions) });
            defer gpa.free(line);
            self.debugMsg(line);
        }
    }
    self.debugMsg("");
}

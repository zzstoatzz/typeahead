// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/integers.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
const BigInt = c.BigInt;
const FindInteger = root.search.FindInteger;
pub fn intValue(self: *Shrinker, i: usize) !?BigInt {
    if (i >= self.current_nodes.len) return null;
    const v = self.current_nodes[i].data.asInteger() orelse return null;
    return try v[1].clone(self.allocator);
}
pub fn replaceInt(self: *Shrinker, i: usize, v: *const BigInt) anyerror!bool {
    const repl = [_]root.Replacement{.{ .index = i, .value = .{ .integer = v.* } }};
    const accepted = try self.replace(&repl);
    if (accepted) try lowerCommonNodeOffset(self);
    return accepted;
}
pub fn replaceTwo(self: *Shrinker, i: usize, vi: *const BigInt, j: usize, vj: *const BigInt) !bool {
    return self.replace(&.{ .{ .index = i, .value = .{ .integer = vi.* } }, .{ .index = j, .value = .{ .integer = vj.* } } });
}
pub fn zeroChoices(self: *Shrinker) !void {
    const gpa = self.allocator;
    var k = self.current_nodes.len;
    while (k > 0) : (k /= 2) {
        var i: usize = 0;
        while (i + k <= self.current_nodes.len) {
            if (try self.current_nodes[i].data.isSimplest(gpa)) {
                i += 1;
                continue;
            }
            var repl: std.ArrayList(root.Replacement) = .empty;
            defer {
                for (repl.items) |*r| r.value.deinit(gpa);
                repl.deinit(gpa);
            }
            for (i..i + k) |j| {
                var v = try self.current_nodes[j].data.simplestValue(gpa);
                errdefer v.deinit(gpa);
                try repl.append(gpa, .{ .index = j, .value = v });
            }
            _ = try self.replace(repl.items);
            i += k;
        }
    }
}
pub fn swapIntegerSign(self: *Shrinker) !void {
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        if (self.current_nodes[i].data.asInteger()) |pair| {
            var simplest = try pair[0].simplest(gpa);
            defer simplest.deinit();
            if (!pair[1].eql(simplest)) _ = try self.replace(&.{.{ .index = i, .value = .{ .integer = simplest } }});
            if (try intValue(self, i)) |owned| {
                var v = owned;
                defer v.deinit();
                if (v.sign() == .minus) {
                    var positive = try v.negate(gpa);
                    defer positive.deinit();
                    _ = try replaceInt(self, i, &positive);
                }
            }
        }
    }
}
pub fn lowerCommonNodeOffset(self: *Shrinker) anyerror!void {
    const gpa = self.allocator;
    var changed: std.ArrayList(usize) = .empty;
    defer changed.deinit(gpa);
    var keys = self.all_changed_nodes.keyIterator();
    while (keys.next()) |i| try changed.append(gpa, i.*);
    std.mem.sort(usize, changed.items, {}, std.sort.asc(usize));
    if (changed.items.len <= 1) return;
    const Entry = struct { index: usize, target: BigInt, distance: BigInt, positive: bool };
    var entries: std.ArrayList(Entry) = .empty;
    defer {
        for (entries.items) |*e| {
            e.target.deinit();
            e.distance.deinit();
        }
        entries.deinit(gpa);
    }
    for (changed.items) |i| {
        if (i >= self.current_nodes.len) return error.InternalError;
        const pair = self.current_nodes[i].data.asInteger() orelse continue;
        var target = try pair[0].simplest(gpa);
        errdefer target.deinit();
        if (pair[1].eql(target)) {
            target.deinit();
            continue;
        }
        var delta = try pair[1].sub(gpa, target);
        defer delta.deinit();
        var distance = try delta.abs(gpa);
        errdefer distance.deinit();
        try entries.append(gpa, .{ .index = i, .target = target, .distance = distance, .positive = pair[1].order(target) != .lt });
    }
    if (entries.items.len <= 1) return;
    var minimum: usize = 0;
    for (entries.items, 0..) |e, i| {
        if (e.distance.order(entries.items[minimum].distance) == .lt) minimum = i;
    }
    var offset = try entries.items[minimum].distance.clone(gpa);
    defer offset.deinit();
    for (entries.items) |*e| {
        const residual = try e.distance.sub(gpa, offset);
        e.distance.deinit();
        e.distance = residual;
    }
    for ([_]bool{ false, true }) |flip| {
        var search = FindInteger.init();
        while (search.probe()) |n| {
            var n_big = try BigInt.fromInt(gpa, n);
            defer n_big.deinit();
            var ok = false;
            if (n_big.order(offset) != .gt) {
                var new_offset = try offset.sub(gpa, n_big);
                defer new_offset.deinit();
                var repl: std.ArrayList(root.Replacement) = .empty;
                defer {
                    for (repl.items) |*r| r.value.deinit(gpa);
                    repl.deinit(gpa);
                }
                for (entries.items) |e| {
                    var distance = try new_offset.add(gpa, e.distance);
                    defer distance.deinit();
                    var value = if (e.positive != flip) try e.target.add(gpa, distance) else try e.target.sub(gpa, distance);
                    errdefer value.deinit();
                    try repl.append(gpa, .{ .index = e.index, .value = .{ .integer = value } });
                }
                ok = try self.replace(repl.items);
            }
            search.record(ok);
        }
    }
    try self.clearChangeTracking();
}
fn lowBits(gpa: std.mem.Allocator, v: BigInt, keep: usize) !BigInt {
    var top = try v.shr(gpa, keep);
    defer top.deinit();
    var shifted = try top.shl(gpa, keep);
    defer shifted.deinit();
    return v.sub(gpa, shifted);
}
fn trailingZerosPower(gpa: std.mem.Allocator, v: BigInt, radix: u32) !BigInt {
    var rest = try v.abs(gpa);
    defer rest.deinit();
    var base = try BigInt.fromInt(gpa, radix);
    defer base.deinit();
    var power = try BigInt.fromInt(gpa, 1);
    errdefer power.deinit();
    while (!rest.isZero()) {
        var rem = try rest.rem(gpa, base);
        defer rem.deinit();
        if (!rem.isZero()) break;
        const quotient = try rest.div(gpa, base);
        rest.deinit();
        rest = quotient;
        const product = try power.mul(gpa, base);
        power.deinit();
        power = product;
    }
    return power;
}
fn distanceFrom(self: *Shrinker, gpa: std.mem.Allocator, i: usize, target: BigInt) !BigInt {
    if (i >= self.current_nodes.len) return error.NodeGone;
    const pair = self.current_nodes[i].data.asInteger() orelse return error.NodeGone;
    var delta = try pair[1].sub(gpa, target);
    defer delta.deinit();
    return delta.abs(gpa);
}
fn tryAtDistance(self: *Shrinker, i: usize, ic: c.IntegerChoice, target: BigInt, d: BigInt) !bool {
    const gpa = self.allocator;
    var above = try target.add(gpa, d);
    defer above.deinit();
    var accepted = false;
    if (ic.validate(above)) accepted = try replaceInt(self, i, &above);
    if (!accepted and d.sign() == .plus) {
        var below = try target.sub(gpa, d);
        defer below.deinit();
        if (ic.validate(below)) accepted = try replaceInt(self, i, &below);
    }
    return accepted;
}
pub fn binarySearchIntegerTowardsZero(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        binarySearchNodeTowardsZero(self, i) catch |err| {
            if (err != error.NodeGone) return err;
        };
    }
}
fn binarySearchNodeTowardsZero(self: *Shrinker, i: usize) !void {
    const pair = self.current_nodes[i].data.asInteger() orelse return error.NodeGone;
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const gpa = arena.allocator();
    const ic = try pair[0].deepClone(gpa);
    const target = try ic.simplest(gpa);
    _ = try tryAtDistance(self, i, ic, target, try BigInt.fromInt(gpa, 0));
    _ = try tryAtDistance(self, i, ic, target, try BigInt.fromInt(gpa, 1));
    {
        const base = try distanceFrom(self, gpa, i, target);
        const bits = base.bits();
        var search = FindInteger.init();
        while (search.probe()) |k| {
            const ok = if (k >= bits) false else try tryAtDistance(self, i, ic, target, try lowBits(gpa, base, bits - k));
            search.record(ok);
        }
    }
    {
        const base = try distanceFrom(self, gpa, i, target);
        if (base.bits() > 8) {
            _ = try tryAtDistance(self, i, ic, target, try base.shr(gpa, base.bits() - 8));
            _ = try tryAtDistance(self, i, ic, target, try lowBits(gpa, base, 8));
        }
    }
    while (true) {
        const before = try distanceFrom(self, gpa, i, target);
        if (before.isZero()) break;
        const max_shift = before.bits() + 1;
        var search = FindInteger.init();
        while (search.probe()) |k| {
            const candidate = try before.shr(gpa, @min(k, max_shift));
            search.record(try tryAtDistance(self, i, ic, target, candidate));
        }
        for ([_]i32{ 3, 5, 7, 10 }) |divisor| {
            const base = try distanceFrom(self, gpa, i, target);
            const quotient = try base.div(gpa, try BigInt.fromInt(gpa, divisor));
            if (quotient.sign() == .plus) _ = try tryAtDistance(self, i, ic, target, quotient);
        }
        for ([_]u32{ 10, 2 }) |radix| {
            const base = try distanceFrom(self, gpa, i, target);
            const power = try trailingZerosPower(gpa, base, radix);
            const one = try BigInt.fromInt(gpa, 1);
            if (power.order(one) == .gt and power.order(base) == .lt) _ = try tryAtDistance(self, i, ic, target, power);
        }
        for ([_]u64{ 2, 1 }) |step| {
            const base = try distanceFrom(self, gpa, i, target);
            search = FindInteger.init();
            while (search.probe()) |n| {
                const sub = try (try BigInt.fromInt(gpa, step)).mul(gpa, try BigInt.fromInt(gpa, n));
                const ok = if (sub.order(base) == .gt) false else try tryAtDistance(self, i, ic, target, try base.sub(gpa, sub));
                search.record(ok);
            }
        }
        const after = try distanceFrom(self, gpa, i, target);
        if (after.eql(before)) break;
    }
}
const IntegerEntry = struct { index: usize, constraint: c.IntegerChoice, value: BigInt };
fn integerEntries(self: *Shrinker, gpa: std.mem.Allocator) ![]IntegerEntry {
    var list: std.ArrayList(IntegerEntry) = .empty;
    for (self.current_nodes, 0..) |*node, i| {
        if (node.data.asInteger()) |pair| {
            try list.append(gpa, .{ .index = i, .constraint = try pair[0].deepClone(gpa), .value = try pair[1].clone(gpa) });
        }
    }
    return list.toOwnedSlice(gpa);
}
pub fn redistributeIntegers(self: *Shrinker) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const n = (try integerEntries(self, a)).len;
    const max_gap = @min(@as(usize, 8), n);
    if (max_gap <= 1) return;
    for (1..max_gap) |gap| {
        var pair_idx = n -| (gap + 1);
        while (true) {
            const entries = try integerEntries(self, a);
            if (pair_idx + gap >= entries.len) {
                if (pair_idx == 0) break;
                pair_idx -= 1;
                continue;
            }
            const x = entries[pair_idx];
            const y = entries[pair_idx + gap];
            const target = try x.constraint.simplest(a);
            const delta = try x.value.sub(a, target);
            const distance = try delta.abs(a);
            if (distance.sign() == .plus) {
                const low = x.value.order(target) == .lt;
                var search = root.search.BinSearchDownBig.init(a, try BigInt.fromInt(a, 0), try distance.clone(a));
                defer search.deinit();
                while (try search.probe()) |d| {
                    const new_x = if (low) try target.sub(a, d) else try target.add(a, d);
                    const diff = try x.value.sub(a, new_x);
                    const new_y = try y.value.add(a, diff);
                    try search.record(try replaceTwo(self, x.index, &new_x, y.index, &new_y));
                }
            }
            if (pair_idx == 0) break;
            pair_idx -= 1;
        }
    }
}
pub fn lowerIntegersTogether(self: *Shrinker) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    var pair_idx: usize = 0;
    while (true) : (pair_idx += 1) {
        for (1..4) |gap| {
            const entries = try integerEntries(self, a);
            if (pair_idx >= entries.len) return;
            if (pair_idx + gap >= entries.len) break;
            const x = entries[pair_idx];
            const y = entries[pair_idx + gap];
            const target = try x.constraint.simplest(a);
            const order = x.value.order(target);
            if (order == .eq) continue;
            const max_k = if (order == .gt) try x.value.sub(a, target) else try target.sub(a, x.value);
            var search = FindInteger.init();
            while (search.probe()) |n| {
                const k = try BigInt.fromInt(a, n);
                var ok = false;
                if (k.order(max_k) != .gt) {
                    const new_x = if (order == .gt) try x.value.sub(a, k) else try x.value.add(a, k);
                    const new_y = if (order == .gt) try y.value.sub(a, k) else try y.value.add(a, k);
                    ok = try replaceTwo(self, x.index, &new_x, y.index, &new_y);
                }
                search.record(ok);
            }
        }
    }
}
fn matchesInteger(self: *Shrinker, i: usize, value: BigInt) bool {
    if (i >= self.current_nodes.len) return false;
    const pair = self.current_nodes[i].data.asInteger() orelse return false;
    return pair[1].eql(value);
}
fn groupReplace(self: *Shrinker, valid: []const usize, candidate: BigInt) !bool {
    var replacements: std.ArrayList(root.Replacement) = .empty;
    defer replacements.deinit(self.allocator);
    for (valid) |i| {
        if (i < self.current_nodes.len) try replacements.append(self.allocator, .{ .index = i, .value = .{ .integer = candidate } });
    }
    if (replacements.items.len < 2) return false;
    return self.replace(replacements.items);
}
fn liveBase(self: *Shrinker, a: std.mem.Allocator, valid: []const usize) !BigInt {
    if (valid.len == 0 or valid[0] >= self.current_nodes.len) return error.NodeGone;
    const pair = self.current_nodes[valid[0]].data.asInteger() orelse return error.NodeGone;
    return pair[1].clone(a);
}
fn shrinkIntDuplicateGroup(self: *Shrinker, value: BigInt, valid: []const usize, ic: c.IntegerChoice) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const simplest = try ic.simplest(a);
    if (!simplest.eql(value)) {
        var replacements: std.ArrayList(root.Replacement) = .empty;
        for (valid) |i| try replacements.append(a, .{ .index = i, .value = .{ .integer = simplest } });
        _ = try self.replace(replacements.items);
    }
    const cur = try liveBase(self, a, valid);
    const sign = cur.sign();
    if (sign == .no_sign) return;
    const positive = sign == .plus;
    const signed_simplest = if (positive) simplest else try simplest.negate(a);
    const zero = try BigInt.fromInt(a, 0);
    const lo = if (signed_simplest.order(zero) == .gt) signed_simplest else zero;
    const magnitude = if (positive) cur else try cur.negate(a);
    const delta = try magnitude.sub(a, lo);
    const distance = if (delta.order(zero) == .gt) delta else zero;
    if (distance.sign() == .plus) {
        const max_shift = distance.bits() + 1;
        var search = FindInteger.init();
        while (search.probe()) |k| {
            const shifted = try distance.shr(a, @min(k, max_shift));
            const abs = try lo.add(a, shifted);
            const candidate = if (positive) abs else try abs.negate(a);
            search.record(try groupReplace(self, valid, candidate));
        }
    }
    const bound = if (positive) lo else try lo.negate(a);
    for ([_]u128{ 2, 1 }) |step| {
        const base = liveBase(self, a, valid) catch |err| {
            if (err == error.NodeGone) break;
            return err;
        };
        if (if (positive) base.order(bound) == .gt else base.order(bound) == .lt) {
            var search = FindInteger.init();
            while (search.probe()) |n| {
                const live = try liveBase(self, a, valid);
                const amount = try BigInt.fromInt(a, step * @as(u128, n));
                const candidate = if (positive) try live.sub(a, amount) else try live.add(a, amount);
                search.record(try groupReplace(self, valid, candidate));
            }
        }
    }
}
fn absorbNodeGone(result: anyerror!void) anyerror!void {
    result catch |err| {
        if (err != error.NodeGone) return err;
    };
}
const Member = struct { index: usize, constraint: c.IntegerChoice };
fn shrinkStalledDuplicateSubgroups(self: *Shrinker, a: std.mem.Allocator, value: BigInt, members: []const Member) !void {
    const Partition = struct { constraint: c.IntegerChoice, indices: std.ArrayList(usize) = .empty };
    var partitions: std.ArrayList(Partition) = .empty;
    for (members) |m| {
        var found: ?usize = null;
        for (partitions.items, 0..) |p, i| {
            if (p.constraint.eql(m.constraint)) {
                found = i;
                break;
            }
        }
        if (found) |i| {
            try partitions.items[i].indices.append(a, m.index);
        } else {
            var p = Partition{ .constraint = m.constraint };
            try p.indices.append(a, m.index);
            try partitions.append(a, p);
        }
    }
    for (partitions.items) |p| {
        var indices: std.ArrayList(usize) = .empty;
        for (p.indices.items) |i| {
            if (matchesInteger(self, i, value)) try indices.append(a, i);
        }
        if (indices.items.len < 2) continue;
        if (indices.items.len < members.len) {
            try absorbNodeGone(shrinkIntDuplicateGroup(self, value, indices.items, p.constraint));
            if (!matchesInteger(self, indices.items[0], value)) continue;
        }
        if (indices.items.len < 3 or indices.items.len > 8) continue;
        for (0..indices.items.len) |left_out| {
            var subset: std.ArrayList(usize) = .empty;
            for (indices.items, 0..) |i, k| {
                if (k != left_out) try subset.append(a, i);
            }
            try absorbNodeGone(shrinkIntDuplicateGroup(self, value, subset.items, p.constraint));
            if (!matchesInteger(self, subset.items[0], value)) break;
        }
    }
}
pub fn shrinkDuplicates(self: *Shrinker) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const Group = struct { tag: std.meta.Tag(c.ChoiceData), value: c.ChoiceValue, indices: std.ArrayList(usize) = .empty };
    var groups: std.ArrayList(Group) = .empty;
    defer for(groups.items) |*g| g.value.deinit(a);
    for (self.current_nodes, 0..) |*node, i| {
        const tag = std.meta.activeTag(node.data);
        var found: ?usize = null;
        for (groups.items, 0..) |*g, j| {
            if (tag == g.tag and node.data.valueRef().eql(g.value.valueRef())) {
                found = j;
                break;
            }
        }
        if (found) |j| {
            try groups.items[j].indices.append(a, i);
        } else {
            var g = Group{ .tag = tag, .value = try node.value(a) };
            try g.indices.append(a, i);
            try groups.append(a, g);
        }
    }
    for (groups.items) |*group| {
        if (group.indices.items.len < 2) continue;
        var valid: std.ArrayList(usize) = .empty;
        for (group.indices.items) |i| {
            if (i < self.current_nodes.len and std.meta.activeTag(self.current_nodes[i].data) == group.tag and self.current_nodes[i].data.valueRef().eql(group.value.valueRef())) try valid.append(a, i);
        }
        if (valid.items.len < 2) continue;
        if (self.current_nodes[valid.items[0]].data.asInteger()) |pair| {
            const ic = try pair[0].deepClone(a);
            const value = try pair[1].clone(a);
            try absorbNodeGone(shrinkIntDuplicateGroup(self, value, valid.items, ic));
            if (!matchesInteger(self, valid.items[0], value)) continue;
            var members: std.ArrayList(Member) = .empty;
            for (valid.items) |i| {
                if (i < self.current_nodes.len) {
                    if (self.current_nodes[i].data.asInteger()) |entry| try members.append(a, .{ .index = i, .constraint = try entry[0].deepClone(a) });
                }
            }
            try shrinkStalledDuplicateSubgroups(self, a, value, members.items);
            continue;
        }
        const simplest = try self.current_nodes[valid.items[0]].data.simplestValue(a);
        if (!simplest.eql(&group.value)) {
            var replacements: std.ArrayList(root.Replacement) = .empty;
            for (valid.items) |i| try replacements.append(a, .{ .index = i, .value = simplest });
            _ = try self.replace(replacements.items);
        }
    }
}

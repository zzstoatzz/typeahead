// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/floats.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
const BigInt = c.BigInt;
const math = @import("../math_compat.zig");
const fi = @import("../float_index.zig");
const MAX_PRECISE_INTEGER: f64 = 0x1p53;
fn castI128(x: f64) i128 {
    if (std.math.isNan(x)) return 0;
    if (x >= @as(f64, @floatFromInt(std.math.maxInt(i128)))) return std.math.maxInt(i128);
    if (x <= @as(f64, @floatFromInt(std.math.minInt(i128)))) return std.math.minInt(i128);
    return @intFromFloat(x);
}
pub fn asIntegerRatio(v: f64) !?struct { u128, u128 } {
    if (!std.math.isFinite(v) or v <= 0) return error.InternalError;
    const bits: u64 = @bitCast(v);
    const biased: i32 = @intCast((bits >> 52) & 0x7ff);
    var num: u128 = if (biased == 0) bits & 0xfffffffffffff else (bits & 0xfffffffffffff) | (@as(u64, 1) << 52);
    var exp: i32 = if (biased == 0) -1074 else biased - 1023 - 52;
    const trailing = @ctz(num);
    num >>= @intCast(trailing);
    exp += @intCast(trailing);
    if (exp >= 0) {
        if (exp >= 128) return null;
        return .{ num << @intCast(exp), 1 };
    }
    if (-exp >= 128) return null;
    return .{ num, @as(u128, 1) << @intCast(-exp) };
}
fn at(self: *Shrinker, i: usize) !f64 {
    if (i >= self.current_nodes.len or self.current_nodes[i].data != .float) return error.NodeGone;
    return self.current_nodes[i].data.float.value;
}
fn replace(self: *Shrinker, i: usize, v: f64) !bool {
    return self.replace(&.{.{ .index = i, .value = .{ .float = v } }});
}
pub fn shrinkFloats(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        shrinkFloatNode(self, i) catch |err| {
            if (err != error.NodeGone) return err;
        };
    }
}
fn shrinkFloatNode(self: *Shrinker, i: usize) !void {
    @setFloatMode(.strict);
    if (self.current_nodes[i].data != .float) return;
    const fc = self.current_nodes[i].data.float.constraint;
    const original = try at(self, i);
    const simplest = try fc.simplest();
    if (@as(u64, @bitCast(simplest)) != @as(u64, @bitCast(original))) _ = try replace(self, i, simplest);
    var v = try at(self, i);
    if (v != 0) {
        const nonzero = try fc.simplestNonzero();
        if (@as(u64, @bitCast(nonzero)) != @as(u64, @bitCast(v))) _ = try replace(self, i, nonzero);
    }
    v = try at(self, i);
    if (std.math.isInf(v)) {
        if (v < 0 and fc.validate(std.math.inf(f64))) _ = try replace(self, i, std.math.inf(f64));
        v = try at(self, i);
        if (std.math.isInf(v)) {
            const candidate = if (v > 0) std.math.floatMax(f64) else -std.math.floatMax(f64);
            if (fc.validate(candidate)) _ = try replace(self, i, candidate);
        }
    }
    v = try at(self, i);
    if (std.math.isNan(v)) {
        var stepped = false;
        for ([_]f64{ std.math.floatMax(f64), std.math.inf(f64) }) |candidate| {
            if (fc.validate(candidate) and try replace(self, i, candidate)) {
                stepped = true;
                break;
            }
        }
        const nan: f64 = @bitCast(@as(u64, 0x7ff8000000000000));
        if (!stepped and @as(u64, @bitCast(v)) != @as(u64, @bitCast(nan)) and fc.validate(nan)) {
            const attempt = try c.cloneNodes(self.allocator, self.current_nodes);
            defer c.deinitNodes(self.allocator, attempt);
            const forced = attempt[i].was_forced;
            attempt[i].deinit(self.allocator);
            attempt[i] = c.ChoiceNode.float(fc, nan, forced);
            var out = try self.runTestFn(.{ .full = attempt });
            defer out.run.deinit(self.allocator);
            self.calls += 1;
            if (out.interesting and try c.nodesOrder(self.allocator, out.run.nodes, self.current_nodes) != .gt) {
                const new = try c.cloneNodes(self.allocator, out.run.nodes);
                errdefer c.deinitNodes(self.allocator, new);
                const spans = try self.allocator.dupe(c.Span, out.run.spans);
                c.deinitNodes(self.allocator, self.current_nodes);
                self.allocator.free(self.current_spans);
                self.current_nodes = new;
                self.current_spans = spans;
            }
        }
    }
    v = try at(self, i);
    if (std.math.isNan(v)) return;
    if (std.math.signbit(v) and fc.validate(-v)) _ = try replace(self, i, -v);
    v = try at(self, i);
    const abs = @abs(v);
    const neg = std.math.signbit(v);
    if (std.math.isFinite(abs) and abs > 0 and abs >= MAX_PRECISE_INTEGER) {
        const base = castI128(abs);
        var search = root.search.FindInteger.init();
        while (search.probe()) |k| {
            var ok = false;
            if (k < 127) {
                const mag: f64 = @floatFromInt(base >> @intCast(k));
                const candidate = if (neg) -mag else mag;
                if (fc.validate(candidate)) ok = try replace(self, i, candidate);
            }
            search.record(ok);
        }
        const current = try at(self, i);
        if (std.math.isFinite(current)) {
            const base_after = castI128(@abs(current));
            const lo = castI128(math.ceil(@max(if (neg) -fc.max_value else fc.min_value, 0)));
            for ([_]i128{ 2, 1 }) |step| {
                search = root.search.FindInteger.init();
                while (search.probe()) |n| {
                    const attempt = base_after - step * @as(i128, @intCast(n));
                    var ok = false;
                    if (attempt >= lo) {
                        const mag: f64 = @floatFromInt(attempt);
                        ok = try replace(self, i, if (neg) -mag else mag);
                    }
                    search.record(ok);
                }
            }
        }
    } else if (std.math.isFinite(abs) and abs > 0) {
        const current_abs = @abs(try at(self, i));
        var p: usize = 11;
        while (p > 0) {
            p -= 1;
            const scale: f64 = @floatFromInt(@as(u32, 1) << @intCast(p));
            const scaled = current_abs * scale;
            for ([_]f64{ math.floor(scaled), math.ceil(scaled) }) |rounded| {
                const mag = rounded / scale;
                if (!std.math.isFinite(mag) or fi.floatToIndex(mag) >= fi.floatToIndex(current_abs)) continue;
                const candidate = if (neg) -mag else mag;
                if (fc.validate(candidate)) _ = try replace(self, i, candidate);
            }
        }
    }
    v = try at(self, i);
    const index = fi.floatToIndex(@abs(v));
    const negative = std.math.signbit(v);
    if (index > 0) {
        var search = root.search.BinSearchDown.init(0, index);
        while (search.probe()) |idx| {
            const mag = fi.indexToFloat(@intCast(idx));
            const candidate = if (negative) -mag else mag;
            search.record(if (fc.validate(candidate)) try replace(self, i, candidate) else false);
        }
    }
    v = try at(self, i);
    if (std.math.isFinite(v) and v != 0) {
        const sign = std.math.signbit(v);
        if (try asIntegerRatio(@abs(v))) |ratio| {
            const m = ratio[0];
            const n = ratio[1];
            const initial = m / n;
            const r = m % n;
            if (initial > 0) {
                var search = root.search.BinSearchDown.init(0, @bitCast(initial));
                while (search.probe()) |k| {
                    const sum = @as(u128, @bitCast(k)) * n + r;
                    const mag = @as(f64, @floatFromInt(sum)) / @as(f64, @floatFromInt(n));
                    const candidate = if (sign) -mag else mag;
                    var ok = false;
                    if (fc.validate(candidate)) {
                        const epoch = self.improvements;
                        _ = try replace(self, i, candidate);
                        ok = self.improvements > epoch;
                    }
                    search.record(ok);
                }
            }
        }
    }
}
const Numeric = union(enum) {
    integer: struct { constraint: c.IntegerChoice, value: BigInt },
    float: struct { constraint: c.FloatChoice, value: f64 },
    fn asF64(self: Numeric) f64 {
        return switch (self) {
            .integer => |v| v.value.toF64(),
            .float => |v| v.value,
        };
    }
    fn target(self: Numeric, a: std.mem.Allocator) !f64 {
        return switch (self) {
            .integer => |v| (try v.constraint.simplest(a)).toF64(),
            .float => 0,
        };
    }
    fn canChoose(self: Numeric) bool {
        return switch (self) {
            .integer => true,
            .float => |v| std.math.isFinite(v.value) and @abs(v.value) < MAX_PRECISE_INTEGER,
        };
    }
    fn trivial(self: Numeric, a: std.mem.Allocator) !bool {
        return switch (self) {
            .integer => |v| v.value.eql(try v.constraint.simplest(a)),
            .float => |v| !std.math.isFinite(v.value) or v.value == try v.constraint.simplest(),
        };
    }
    fn add(self: Numeric, a: std.mem.Allocator, k: i128) !Numeric {
        return switch (self) {
            .integer => |v| .{ .integer = .{ .constraint = v.constraint, .value = try v.value.addInt(a, k) } },
            .float => |v| .{ .float = .{ .constraint = v.constraint, .value = v.value + @as(f64, @floatFromInt(k)) } },
        };
    }
    fn build(self: Numeric) ?c.ChoiceValue {
        return switch (self) {
            .integer => |v| if (v.constraint.validate(v.value)) .{ .integer = v.value } else null,
            .float => |v| if (v.constraint.validate(v.value)) .{ .float = v.value } else null,
        };
    }
};
fn numericAt(a: std.mem.Allocator, data: *const c.ChoiceData) !?Numeric {
    return switch (data.*) {
        .integer => |v| .{ .integer = .{ .constraint = try v.constraint.deepClone(a), .value = try v.value.clone(a) } },
        .float => |v| .{ .float = .{ .constraint = v.constraint, .value = v.value } },
        else => null,
    };
}
pub fn redistributeNumericPairs(self: *Shrinker) !void {
    @setFloatMode(.strict);
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const len = self.current_nodes.len;
    for (0..len) |i| {
        for (1..5) |gap| {
            const j = i + gap;
            if (j >= self.current_nodes.len) break;
            const x = try numericAt(a, &self.current_nodes[i].data) orelse continue;
            const y = try numericAt(a, &self.current_nodes[j].data) orelse continue;
            if (x == .integer and y == .integer) continue;
            if (!x.canChoose() or !y.canChoose() or try x.trivial(a)) continue;
            const lower = x.asF64() >= try x.target(a);
            var search = root.search.FindInteger.init();
            while (search.probe()) |k| {
                const signed: i128 = if (lower) -@as(i128, @intCast(k)) else @intCast(k);
                const cx = try x.add(a, signed);
                const cy = try y.add(a, -signed);
                var ok = false;
                if (cx.build()) |vx| {
                    if (cy.build()) |vy| ok = try self.replace(&.{ .{ .index = i, .value = vx }, .{ .index = j, .value = vy } });
                }
                search.record(ok);
            }
        }
    }
}
const ValuePair = struct { c.ChoiceValue, c.ChoiceValue };
fn pushIntegers(a: std.mem.Allocator, list: *std.ArrayList(ValuePair), ic: c.IntegerChoice, x: BigInt, jc: c.IntegerChoice, y: BigInt) !void {
    if (ic.validate(x) and jc.validate(y)) try list.append(a, .{ .{ .integer = x }, .{ .integer = y } });
}
fn pushFloats(a: std.mem.Allocator, list: *std.ArrayList(ValuePair), ic: c.FloatChoice, x: f64, jc: c.FloatChoice, y: f64) !void {
    if (ic.validate(x) and jc.validate(y)) try list.append(a, .{ .{ .float = x }, .{ .float = y } });
}
fn scaledCandidates(a: std.mem.Allocator, x: Numeric, y: Numeric) ![]ValuePair {
    @setFloatMode(.strict);
    var out: std.ArrayList(ValuePair) = .empty;
    if (x == .integer and y == .integer) {
        const ic = x.integer.constraint;
        const jc = y.integer.constraint;
        const tx = try ic.simplest(a);
        const ty = try jc.simplest(a);
        const dx = try x.integer.value.sub(a, tx);
        const dy = try y.integer.value.sub(a, ty);
        if (dx.isZero() or dy.isZero()) return out.toOwnedSlice(a);
        if (dx.sign() == .minus) try pushIntegers(a, &out, ic, try tx.sub(a, dx), jc, try ty.sub(a, dy));
        const bound = try (if (dy.sign() == .plus) jc.max_value else jc.min_value).sub(a, ty);
        const raised_values = [_]BigInt{ bound, try dy.mul(a, try BigInt.fromInt(a, 2)), try dy.mul(a, try BigInt.fromInt(a, 10)) };
        const mx = try dx.abs(a);
        const my = try dy.abs(a);
        for (raised_values) |raised| {
            const mr = try raised.abs(a);
            if (mr.order(my) != .gt) continue;
            const product = try mx.mul(a, my);
            const quotient_mag = try product.div(a, mr);
            const quotient = if (dx.sign() == .minus) try quotient_mag.negate(a) else quotient_mag;
            for ([_]BigInt{ quotient, try quotient.addInt(a, if (dx.sign() == .plus) @as(i32, 1) else @as(i32, -1)) }) |scaled| {
                const mag = try scaled.abs(a);
                if (mag.order(mx) == .lt) try pushIntegers(a, &out, ic, try tx.add(a, scaled), jc, try ty.add(a, raised));
            }
        }
    } else if (x == .float and y == .float) {
        const xv = x.float.value;
        const yv = y.float.value;
        const ic = x.float.constraint;
        const jc = y.float.constraint;
        if (!std.math.isFinite(xv) or !std.math.isFinite(yv) or xv == 0 or yv == 0) return out.toOwnedSlice(a);
        if (std.math.signbit(xv)) try pushFloats(a, &out, ic, -xv, jc, -yv);
        const bound = if (yv > 0) @min(jc.max_value, std.math.floatMax(f64)) else @max(jc.min_value, -std.math.floatMax(f64));
        for ([_]f64{ bound, yv * 2, yv * 10 }) |raised| {
            if (!std.math.isFinite(raised) or @abs(raised) <= @abs(yv)) continue;
            const scaled = xv * (yv / raised);
            if (@abs(scaled) < @abs(xv)) try pushFloats(a, &out, ic, scaled, jc, raised);
        }
    }
    return out.toOwnedSlice(a);
}
pub fn scaleNumericPairs(self: *Shrinker) !void {
    const len = self.current_nodes.len;
    for (0..len) |i| {
        for (1..5) |gap| {
            const j = i + gap;
            if (j >= self.current_nodes.len) break;
            while (true) {
                var arena = std.heap.ArenaAllocator.init(self.allocator);
                defer arena.deinit();
                const a = arena.allocator();
                if (i >= self.current_nodes.len or j >= self.current_nodes.len) break;
                const x = try numericAt(a, &self.current_nodes[i].data) orelse break;
                const y = try numericAt(a, &self.current_nodes[j].data) orelse break;
                const candidates = try scaledCandidates(a, x, y);
                var accepted = false;
                for (candidates) |pair| {
                    if (try self.replace(&.{ .{ .index = i, .value = pair[0] }, .{ .index = j, .value = pair[1] } })) {
                        accepted = true;
                        break;
                    }
                }
                if (!accepted) break;
            }
        }
    }
}

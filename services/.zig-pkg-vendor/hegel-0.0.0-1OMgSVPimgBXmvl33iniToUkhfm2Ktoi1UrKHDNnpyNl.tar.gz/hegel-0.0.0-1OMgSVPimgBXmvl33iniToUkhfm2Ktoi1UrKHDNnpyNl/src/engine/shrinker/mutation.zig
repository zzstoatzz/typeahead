// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/mutation.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
pub fn mutateAndShrink(self: *Shrinker) !void {
    if (self.current_nodes.len > 32) return;
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        const snapshot = try c.cloneNodes(gpa, self.current_nodes);
        defer c.deinitNodes(gpa, snapshot);
        const node = &snapshot[i];
        if (node.was_forced or node.data == .bytes or node.data == .string) continue;
        var arena = std.heap.ArenaAllocator.init(gpa);
        defer arena.deinit();
        const a = arena.allocator();
        const current = try node.data.toIndex(a) orelse continue;
        var candidates: std.ArrayList(c.ChoiceValue) = .empty;
        for (1..6) |delta| {
            for ([_]bool{ false, true }) |negative| {
                const d = try c.BigUint.fromInt(a, delta);
                if (negative and current.order(d) == .lt) continue;
                const index = if (negative) try current.sub(a, d) else try current.add(a, d);
                if (try node.data.fromIndex(a, index)) |v| {
                    if (node.data.valueRef().eql(v.valueRef())) continue;
                    var contains = false;
                    for (candidates.items) |*prev| {
                        if (prev.eql(&v)) {
                            contains = true;
                            break;
                        }
                    }
                    if (!contains) try candidates.append(a, v);
                }
            }
        }
        for (candidates.items) |*value| {
            const prefix = try gpa.alloc(c.ChoiceValue, i + 1);
            var count: usize = 0;
            defer {
                for (prefix[0..count]) |*v| v.deinit(gpa);
                gpa.free(prefix);
            }
            for (snapshot[0..i], prefix[0..i]) |*n, *v| {
                v.* = try n.value(gpa);
                count += 1;
            }
            prefix[i] = try value.deepClone(gpa);
            count += 1;
            const max_size = c.flattenedLen(snapshot);
            if (!try replayObservingDivergence(self, snapshot, value, i)) continue;
            for (0..32) |_| try self.probe(prefix, max_size);
            var offset: usize = 1;
            while (offset < 3 and i + offset < snapshot.len) {
                const j = i + offset;
                offset += 1;
                var unit = try snapshot[j].data.fromIndex(gpa, try c.BigUint.fromInt(a, 1)) orelse continue;
                defer unit.deinit(gpa);
                const two = try gpa.alloc(c.ChoiceValue, j + 1);
                var initialized: usize = 0;
                defer {
                    for (two[0..initialized]) |*v| v.deinit(gpa);
                    gpa.free(two);
                }
                for (prefix, two[0..prefix.len]) |*v, *dest| {
                    dest.* = try v.deepClone(gpa);
                    initialized += 1;
                }
                for (i + 1..j + 1) |k| {
                    two[k] = if (k == j) try unit.deepClone(gpa) else try snapshot[k].data.simplestValue(gpa);
                    initialized += 1;
                }
                for (0..3) |_| try self.probe(two, max_size);
            }
        }
    }
}
fn replayObservingDivergence(self: *Shrinker, snapshot: []const c.ChoiceNode, value: *const c.ChoiceValue, i: usize) !bool {
    if (self.improvements >= self.max_improvements) return error.ShrinkStop;
    if (self.sweep == .fast and self.improvements > 0 and self.calls -| self.calls_at_last_shrink >= self.max_stall) return false;
    var replaced = try snapshot[i].withValue(self.allocator, value) orelse return false;
    defer replaced.deinit(self.allocator);
    const attempt = try self.allocator.dupe(c.ChoiceNode, snapshot);
    defer self.allocator.free(attempt);
    attempt[i] = replaced;
    var out = try self.runTestFn(.{ .full = attempt });
    defer out.run.deinit(self.allocator);
    self.calls += 1;
    var diverged = false;
    if (out.run.nodes.len == snapshot.len) {
        for (out.run.nodes[i + 1 ..], snapshot[i + 1 ..]) |*actual, *expected| {
            if (!actual.kind().eql(expected.kind())) {
                diverged = true;
                break;
            }
        }
    }
    if (out.interesting and try c.nodesOrder(self.allocator, out.run.nodes, self.current_nodes) == .lt) try self.acceptImprovement(out.run.nodes, out.run.spans);
    return diverged;
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/index_passes.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
const BigUint = c.BigUint;
fn isSequence(data: c.ChoiceData) bool {
    return data == .bytes or data == .string;
}
pub fn tryBumpIJ(self: *Shrinker, i: usize, value: *const c.ChoiceValue, j: usize, bump: *const c.ChoiceValue) !bool {
    return self.replace(&.{ .{ .index = i, .value = value.* }, .{ .index = j, .value = bump.* } });
}
pub fn lowerAndBump(self: *Shrinker) !void {
    const gpa = self.allocator;
    const max_gap = @min(self.current_nodes.len, @as(usize, 4));
    if (max_gap <= 1) return;
    for (1..max_gap) |gap| {
        var i: usize = 0;
        while (i < self.current_nodes.len) : (i += 1) {
            var node = try self.current_nodes[i].deepClone(gpa);
            defer node.deinit(gpa);
            if (isSequence(node.data)) continue;
            var arena = std.heap.ArenaAllocator.init(gpa);
            defer arena.deinit();
            const a = arena.allocator();
            const current = try node.data.toIndex(a) orelse continue;
            if (current.isZero()) continue;
            var targets: std.ArrayList(c.ChoiceValue) = .empty;
            const one = try BigUint.fromInt(a, 1);
            if (current.order(one) == .gt) try targets.append(a, try node.data.fromIndex(a, try BigUint.fromInt(a, 0)) orelse return error.InternalError);
            if (try node.data.fromIndex(a, try current.sub(a, one))) |prev| {
                var contains = false;
                for (targets.items) |*v| {
                    if (v.eql(&prev)) {
                        contains = true;
                        break;
                    }
                }
                if (!contains) try targets.append(a, prev);
            }
            const j = i + gap;
            if (j >= self.current_nodes.len) continue;
            for (targets.items) |*value| {
                if (i >= self.current_nodes.len) break;
                if (gap == 1) {
                    const attempt = try c.cloneNodes(gpa, self.current_nodes);
                    defer c.deinitNodes(gpa, attempt);
                    if (try attempt[i].withValue(gpa, value)) |changed| {
                        attempt[i].deinit(gpa);
                        attempt[i] = changed;
                        if (try self.consider(attempt)) try descendIndex(self, i);
                        for (attempt[i + 1 ..]) |*n| {
                            const simple = try n.withSimplest(gpa);
                            n.deinit(gpa);
                            n.* = simple;
                        }
                        _ = try self.consider(attempt);
                    }
                }
                if (j < self.current_nodes.len and !isSequence(self.current_nodes[j].data)) {
                    var data = try self.current_nodes[j].data.deepClone(gpa);
                    defer data.deinit(gpa);
                    const target = try data.toIndex(a) orelse continue;
                    const max_j = try data.maxIndex(a) orelse continue;
                    var bumped = false;
                    for ([_]u32{ 1, 2, 4 }) |bump| {
                        if (try data.fromIndex(a, try target.addInt(a, bump))) |v| {
                            if (try tryBumpIJ(self, i, value, j, &v)) {
                                bumped = true;
                                break;
                            }
                        }
                    }
                    if (!bumped) {
                        var p = try BigUint.fromInt(a, 1);
                        for (0..8) |_| {
                            if (p.order(max_j) == .gt) break;
                            if (try data.fromIndex(a, try p.subInt(a, 1))) |v| {
                                _ = try tryBumpIJ(self, i, value, j, &v);
                            }
                            if (try data.fromIndex(a, p)) |v| {
                                _ = try tryBumpIJ(self, i, value, j, &v);
                            }
                            p = try p.mul(a, try BigUint.fromInt(a, 2));
                        }
                        if (try data.fromIndex(a, max_j)) |v| {
                            _ = try tryBumpIJ(self, i, value, j, &v);
                        }
                    }
                }
            }
        }
    }
}
fn descendIndex(self: *Shrinker, i: usize) !void {
    if (i >= self.current_nodes.len) return;
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const base = try self.current_nodes[i].data.toIndex(a) orelse try BigUint.fromInt(a, 0);
    var search = root.search.FindInteger.init();
    while (search.probe()) |n| {
        const step = try BigUint.fromInt(a, n);
        var ok = false;
        if (step.order(base) != .gt and i < self.current_nodes.len) {
            if (try self.current_nodes[i].data.fromIndex(a, try base.sub(a, step))) |v| {
                if (try self.current_nodes[i].withValue(self.allocator, &v)) |owned| {
                    var changed = owned;
                    defer changed.deinit(self.allocator);
                    const attempt = try self.allocator.dupe(c.ChoiceNode, self.current_nodes);
                    defer self.allocator.free(attempt);
                    attempt[i] = changed;
                    ok = try self.consider(attempt);
                }
            }
        }
        search.record(ok);
    }
}
pub fn tryShorteningViaIncrement(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        try shortenViaIncrementAt(self, i);
    }
}
fn shortenViaIncrementAt(self: *Shrinker, i: usize) !void {
    const gpa = self.allocator;
    var node = try self.current_nodes[i].deepClone(gpa);
    defer node.deinit(gpa);
    if (node.was_forced or isSequence(node.data)) return;
    var arena = std.heap.ArenaAllocator.init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    const current = try node.data.toIndex(a) orelse return;
    const plus = try current.addInt(a, 1);
    const max = try node.data.maxIndex(a);
    var targets = [_]BigUint{ plus, plus };
    var count: usize = 1;
    if (max) |m| {
        if (m.order(plus) == .gt) {
            targets[1] = m;
            count = 2;
        }
    }
    const epoch = self.improvements;
    for (targets[0..count]) |target| {
        const value = try node.data.fromIndex(a, target) orelse return;
        try shortenViaRaise(self, i, &node, &value);
        if (self.improvements > epoch) return;
    }
}
fn shortenViaRaise(self: *Shrinker, i: usize, node: *const c.ChoiceNode, value: *const c.ChoiceValue) !void {
    const gpa = self.allocator;
    const raised = try c.cloneNodes(gpa, self.current_nodes);
    defer c.deinitNodes(gpa, raised);
    const changed = try node.withValue(gpa, value) orelse return error.InternalError;
    raised[i].deinit(gpa);
    raised[i] = changed;
    const epoch = self.improvements;
    const prefix = try gpa.alloc(c.ChoiceValue, raised.len);
    var initialized: usize = 0;
    defer {
        for (prefix[0..initialized]) |*v| v.deinit(gpa);
        gpa.free(prefix);
    }
    for (raised, prefix) |*n, *v| {
        v.* = try n.value(gpa);
        initialized += 1;
    }
    const realised = try self.considerReshaped(.{ .probe = .{ .prefix = prefix, .max_size = c.flattenedLen(self.current_nodes) + 16 } }) orelse return;
    defer c.deinitNodes(gpa, realised);
    if (self.improvements > epoch) return;
    var unchanged = realised.len == raised.len;
    if (unchanged) {
        for (realised, raised) |*r, *n| {
            if (!r.data.valueRef().eql(n.data.valueRef())) {
                unchanged = false;
                break;
            }
        }
    }
    if (unchanged) return;
    const end = @min(raised.len, i + 1 + 8);
    const Region = struct { start: usize, end: usize };
    var regions: std.ArrayList(Region) = .empty;
    defer regions.deinit(gpa);
    for (self.current_spans) |s| {
        if (s.start > i and s.start < end and s.end > s.start and s.end <= raised.len) try regions.append(gpa, .{ .start = s.start, .end = s.end });
    }
    for (@min(i + 1, end)..end) |j| try regions.append(gpa, .{ .start = j, .end = j + 1 });
    var attempted: std.AutoHashMapUnmanaged(Region, void) = .empty;
    defer attempted.deinit(gpa);
    for (regions.items) |r| {
        const entry = try attempted.getOrPut(gpa, r);
        if (entry.found_existing) continue;
        var candidate: std.ArrayList(c.ChoiceNode) = .empty;
        defer candidate.deinit(gpa);
        try candidate.appendSlice(gpa, raised[0..r.start]);
        try candidate.appendSlice(gpa, raised[r.end..]);
        const outcome = try self.considerReshaped(.{ .full = candidate.items });
        if (outcome) |nodes| c.deinitNodes(gpa, nodes);
        if (outcome == null or self.improvements > epoch) return;
    }
}

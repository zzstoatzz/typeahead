// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/ordering.rs; see provenance.
const std = @import("std");
const FindInteger = @import("search.zig").FindInteger;
pub const Judge = struct { context: *anyopaque, compare: *const fn (*anyopaque, usize, usize) anyerror!std.math.Order, accept: *const fn (*anyopaque, []const usize) anyerror!bool };
fn sort(values: []usize, judge: Judge) !void {
    if (values.len < 2) return;
    for (1..values.len) |pos| {
        var j = pos;
        while (j > 0 and try judge.compare(judge.context, values[j], values[j - 1]) == .lt) : (j -= 1) std.mem.swap(usize, &values[j], &values[j - 1]);
    }
}
pub fn shrinkOrdering(gpa: std.mem.Allocator, n: usize, judge: Judge) !void {
    if (n <= 1) return;
    var arena = std.heap.ArenaAllocator.init(gpa);
    defer arena.deinit();
    const a = arena.allocator();
    var current = try a.alloc(usize, n);
    for (current, 0..) |*v, i| v.* = i;
    const sorted = try a.dupe(usize, current);
    try sort(sorted, judge);
    if (!std.mem.eql(usize, sorted, current) and try judge.accept(judge.context, sorted)) return;
    var i: usize = 0;
    while (i + 1 < current.len) {
        const snapshot = try a.dupe(usize, current);
        var best: ?[]usize = null;
        var search = FindInteger.init();
        while (search.probe()) |k| {
            var ok = false;
            if (k <= n - i) {
                const attempt = try a.dupe(usize, snapshot);
                try sort(attempt[i .. i + k], judge);
                if (std.mem.eql(usize, attempt, snapshot)) {
                    ok = true;
                } else if (try judge.accept(judge.context, attempt)) {
                    best = attempt;
                    ok = true;
                }
            }
            search.record(ok);
        }
        if (best) |b| current = b;
        i += @max(search.step().done, 1);
    }
    if (n < 3) return;
    for (1..n - 1) |centre| {
        if (try judge.compare(judge.context, current[centre - 1], current[centre]) != .gt and try judge.compare(judge.context, current[centre], current[centre + 1]) != .gt) continue;
        const left = centre;
        var right = centre + 1;
        const snapshot_r = try a.dupe(usize, current);
        var search = FindInteger.init();
        while (search.probe()) |k| {
            search.record(if (k > n - right) false else try trySortAround(a, snapshot_r, left, right + k, centre, judge));
        }
        right += search.step().done;
        const snapshot_l = try a.dupe(usize, current);
        search = FindInteger.init();
        while (search.probe()) |k| {
            search.record(if (k > left) false else try trySortAround(a, snapshot_l, left - k, right, centre, judge));
        }
    }
}
fn trySortAround(a: std.mem.Allocator, snapshot: []const usize, start: usize, end: usize, centre: usize, judge: Judge) !bool {
    if (start > centre or centre >= end or end > snapshot.len) return error.InternalError;
    const split = centre - start;
    const sides = try a.alloc(usize, end - start - 1);
    @memcpy(sides[0..split], snapshot[start..centre]);
    @memcpy(sides[split..], snapshot[centre + 1 .. end]);
    try sort(sides, judge);
    const attempt = try a.dupe(usize, snapshot);
    @memcpy(attempt[start..centre], sides[0..split]);
    @memcpy(attempt[centre + 1 .. end], sides[split..]);
    if (std.mem.eql(usize, attempt, snapshot)) return true;
    return judge.accept(judge.context, attempt);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/strings.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
fn stringsAt(self: *Shrinker, i: usize) !struct { c.StringChoice, []const u32 } {
    if (i >= self.current_nodes.len) return error.NodeGone;
    const pair = self.current_nodes[i].data.asString() orelse return error.NodeGone;
    return .{ pair[0].*, pair[1] };
}
fn value(self: *Shrinker, a: std.mem.Allocator, i: usize) ![]u32 {
    const pair = try stringsAt(self, i);
    return a.dupe(u32, pair[1]);
}
fn replace(self: *Shrinker, i: usize, strings: []u32) !bool {
    return self.replace(&.{.{ .index = i, .value = .{ .string = strings } }});
}
pub fn shrinkStrings(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        shrinkStringNode(self, i) catch |err| {
            if (err != error.NodeGone) return err;
        };
    }
}
fn shrinkStringNode(self: *Shrinker, i: usize) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    var snapshot = try self.current_nodes[i].deepClone(self.allocator);
    defer snapshot.deinit(self.allocator);
    const pair = try stringsAt(self, i);
    const kind = snapshot.data.string.constraint;
    const min = kind.min_size;
    const simplest = try kind.simplest(a);
    if (!std.mem.eql(u32, simplest, pair[1])) _ = try replace(self, i, simplest);
    const captured = try value(self, a, i);
    if (captured.len > min) {
        var search = root.search.BinSearchDown.init(@intCast(min), @intCast(captured.len));
        while (search.probe()) |sz| {
            search.record(try replace(self, i, try a.dupe(u32, captured[0..@intCast(sz)])));
        }
    }
    const scan_end = @min(min + 8, (try value(self, a, i)).len);
    for (@min(min, scan_end)..scan_end) |size| {
        const current = try value(self, a, i);
        if (size > current.len) break;
        _ = try replace(self, i, try a.dupe(u32, current[0..size]));
    }
    var j = (try value(self, a, i)).len;
    while (j > 0) {
        j -= 1;
        const current = try value(self, a, i);
        if (current.len <= min) continue;
        const candidate = try a.alloc(u32, current.len - 1);
        @memcpy(candidate[0..j], current[0..j]);
        @memcpy(candidate[j..], current[j + 1 ..]);
        _ = try replace(self, i, candidate);
    }

    const cur = try value(self, a, i);
    var duplicates: std.ArrayList(u32) = .empty;
    for (cur, 0..) |cp, pos| {
        var seen = false;
        for (cur[0..pos]) |v| {
            if (v == cp) {
                seen = true;
                break;
            }
        }
        if (seen) continue;
        var count: usize = 0;
        for (cur) |v| {
            if (v == cp) count += 1;
        }
        if (count > 1) try duplicates.append(a, cp);
    }
    try sortByKey(duplicates.items, kind);
    for (duplicates.items) |cp| {
        if (kind.codepointKey(cp) == 0) continue;
        for (try semanticCandidates(a, cp, kind)) |candidate| {
            _ = try replaceAll(self, a, i, cp, candidate);
            if (std.mem.indexOfScalar(u32, try value(self, a, i), cp) == null) break;
        }
        if (std.mem.indexOfScalar(u32, try value(self, a, i), cp) != null) {
            const key = kind.codepointKey(cp);
            if (key > 0) {
                var search = root.search.BinSearchDown.init(0, key);
                while (search.probe()) |k| {
                    const candidate = kind.keyToCodepoint(@intCast(k)) orelse return error.InternalError;
                    search.record(try replaceAll(self, a, i, cp, candidate));
                }
            }
        }
    }
    j = (try value(self, a, i)).len;
    while (j > 0) {
        j -= 1;
        const current = try value(self, a, i);
        if (kind.codepointKey(current[j]) == 0) continue;
        const original_cp = current[j];
        for (try semanticCandidates(a, original_cp, kind)) |cp| {
            const candidate = try value(self, a, i);
            if (kind.codepointKey(cp) >= kind.codepointKey(candidate[j])) continue;
            candidate[j] = cp;
            _ = try replace(self, i, candidate);
        }
        const current2 = try value(self, a, i);
        const key = kind.codepointKey(current2[j]);
        if (key > 0) {
            var search = root.search.BinSearchDown.init(0, key);
            while (search.probe()) |k| {
                const cp = kind.keyToCodepoint(@intCast(k)) orelse return error.InternalError;
                const candidate = try value(self, a, i);
                candidate[j] = cp;
                search.record(try replace(self, i, candidate));
            }
        }
    }
    var pos: usize = 1;
    while (true) : (pos += 1) {
        const current = try value(self, a, i);
        if (pos >= current.len) break;
        j = pos;
        while (j > 0) {
            const candidate = try value(self, a, i);
            if (kind.codepointKey(candidate[j - 1]) <= kind.codepointKey(candidate[j])) break;
            std.mem.swap(u32, &candidate[j - 1], &candidate[j]);
            if (try replace(self, i, candidate)) {
                j -= 1;
            } else break;
        }
    }
}
fn indices(self: *Shrinker, a: std.mem.Allocator) ![]usize {
    var list: std.ArrayList(usize) = .empty;
    for (self.current_nodes, 0..) |n, i| {
        if (n.data == .string) try list.append(a, i);
    }
    return list.toOwnedSlice(a);
}
pub fn redistributeStringPairs(self: *Shrinker) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    for (1..3) |gap| {
        var idx: usize = 0;
        while (true) : (idx += 1) {
            const ids = try indices(self, a);
            if (idx + gap >= ids.len) break;
            redistributePair(self, ids[idx], ids[idx + gap]) catch |err| {
                if (err != error.NodeGone) return err;
            };
        }
    }
}
fn redistributePair(self: *Shrinker, i: usize, j: usize) !void {
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const s = try value(self, a, i);
    var snapshot = try self.current_nodes[j].deepClone(self.allocator);
    defer snapshot.deinit(self.allocator);
    const pair = try stringsAt(self, j);
    const kind = snapshot.data.string.constraint;
    const t = try a.dupe(u32, pair[1]);
    if (s.len == 0) return;
    if (try redistribute(self, a, i, j, s, t, s.len, kind)) return;
    if (!try redistribute(self, a, i, j, s, t, 1, kind)) return;
    var search = root.search.FindInteger.init();
    while (search.probe()) |extra| {
        const n = 1 + extra;
        search.record(if (n > s.len) false else try redistribute(self, a, i, j, s, t, n, kind));
    }
}
fn redistribute(self: *Shrinker, a: std.mem.Allocator, i: usize, j: usize, s: []const u32, t: []const u32, n: usize, kind: c.StringChoice) !bool {
    const new_t = try a.alloc(u32, n + t.len);
    @memcpy(new_t[0..n], s[s.len - n ..]);
    @memcpy(new_t[n..], t);
    if (!kind.validate(new_t)) return false;
    return self.replace(&.{ .{ .index = i, .value = .{ .string = try a.dupe(u32, s[0 .. s.len - n]) } }, .{ .index = j, .value = .{ .string = new_t } } });
}

fn sortByKey(values: []u32, kind: c.StringChoice) !void {
    if (values.len < 2) return;
    for (1..values.len) |pos| {
        var j = pos;
        while (j > 0 and kind.codepointKey(values[j]) < kind.codepointKey(values[j - 1])) : (j -= 1) std.mem.swap(u32, &values[j], &values[j - 1]);
    }
}
fn semanticCandidates(a: std.mem.Allocator, cp: u32, kind: c.StringChoice) ![]u32 {
    var out: std.ArrayList(u32) = .empty;
    const key = kind.codepointKey(cp);
    const cap = @min(@as(u32, 62), @as(u32, @intCast(kind.alphaSize())));
    for (0..cap) |k| {
        if (k >= key) break;
        if (kind.keyToCodepoint(@intCast(k))) |v| try out.append(a, v);
    }
    if (cp >= 0x80) {
        if (@import("../unicodedata.zig").nfdBase(cp)) |base| {
            if (kind.intervals.contains(base) and kind.codepointKey(base) < key) try out.append(a, base);
        }
    }
    return out.toOwnedSlice(a);
}
fn replaceAll(self: *Shrinker, a: std.mem.Allocator, i: usize, cp: u32, candidate: u32) !bool {
    const current = try value(self, a, i);
    var changed = false;
    for (current) |*v| {
        if (v.* == cp) {
            v.* = candidate;
            changed = true;
        }
    }
    if (!changed) return false;
    return replace(self, i, current);
}
pub fn lowerDuplicatedCharacters(self: *Shrinker) !void {
    const len = self.current_nodes.len;
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    for (0..len) |i| {
        for (@min(i + 1, len)..@min(i + 5, len)) |j| {
            const xi = stringsAt(self, i) catch |err| {
                if (err == error.NodeGone) continue;
                return err;
            };
            const yj = stringsAt(self, j) catch |err| {
                if (err == error.NodeGone) continue;
                return err;
            };
            var snapshot_i = try self.current_nodes[i].deepClone(self.allocator);
            defer snapshot_i.deinit(self.allocator);
            var snapshot_j = try self.current_nodes[j].deepClone(self.allocator);
            defer snapshot_j.deinit(self.allocator);
            const ki = snapshot_i.data.string.constraint;
            const kj = snapshot_j.data.string.constraint;
            const x = try a.dupe(u32, xi[1]);
            const y = try a.dupe(u32, yj[1]);
            var shared: std.ArrayList(u32) = .empty;
            for (x) |cp| {
                if (std.mem.indexOfScalar(u32, y, cp) != null and std.mem.indexOfScalar(u32, shared.items, cp) == null) try shared.append(a, cp);
            }
            std.mem.sort(u32, shared.items, {}, std.sort.asc(u32));
            for (shared.items) |cp| {
                const key = ki.codepointKey(cp);
                if (key == 0) continue;
                var search = root.search.BinSearchDown.init(0, key);
                while (search.probe()) |new_key| {
                    const new = ki.keyToCodepoint(@intCast(new_key)) orelse return error.InternalError;
                    const nx = try a.dupe(u32, x);
                    const ny = try a.dupe(u32, y);
                    for (nx) |*v| {
                        if (v.* == cp) v.* = new;
                    }
                    for (ny) |*v| {
                        if (v.* == cp) v.* = new;
                    }
                    search.record(if (!ki.validate(nx) or !kj.validate(ny)) false else try self.replace(&.{ .{ .index = i, .value = .{ .string = nx } }, .{ .index = j, .value = .{ .string = ny } } }));
                }
            }
        }
    }
}
fn naturalSimplerChars(a: std.mem.Allocator, cp: u32, kind: c.StringChoice) ![]u32 {
    const unicode = @import("../unicode_char.zig");
    const key = kind.codepointKey(cp);
    var candidates: std.ArrayList(u32) = .empty;
    if (cp <= 0x10ffff and (cp < 0xd800 or cp > 0xdfff)) {
        const lower = unicode.lowerMapping(cp);
        for (lower.slice()) |v| {
            if (std.mem.indexOfScalar(u32, candidates.items, v) == null) try candidates.append(a, v);
        }
        const upper = unicode.upperMapping(cp);
        for (upper.slice()) |v| {
            if (std.mem.indexOfScalar(u32, candidates.items, v) == null) try candidates.append(a, v);
        }
    }
    if (@import("../unicodedata.zig").nfdBase(cp)) |base| {
        if (std.mem.indexOfScalar(u32, candidates.items, base) == null) try candidates.append(a, base);
    }
    var out: std.ArrayList(u32) = .empty;
    for (candidates.items) |v| {
        if (v != cp and kind.intervals.contains(v) and kind.codepointKey(v) < key) try out.append(a, v);
    }
    // Rust sorts (key, codepoint); the alphabet mapping is injective.
    try sortByKey(out.items, kind);
    return out.toOwnedSlice(a);
}
pub fn normalizeUnicodeChars(self: *Shrinker) !void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        normalizeUnicodeCharsAt(self, i) catch |err| {
            if (err != error.NodeGone) return err;
        };
    }
}
fn normalizeUnicodeCharsAt(self: *Shrinker, i: usize) !void {
    const pair = try stringsAt(self, i);
    var snapshot = try self.current_nodes[i].deepClone(self.allocator);
    defer snapshot.deinit(self.allocator);
    const kind = snapshot.data.string.constraint;
    var arena = std.heap.ArenaAllocator.init(self.allocator);
    defer arena.deinit();
    const a = arena.allocator();
    const original = try a.dupe(u32, pair[1]);
    for (original, 0..) |cp, pos| {
        const candidates = try naturalSimplerChars(a, cp, kind);
        const current = try value(self, a, i);
        if (pos >= current.len or current[pos] != cp) continue;
        for (candidates) |replacement| {
            const next = try a.dupe(u32, current);
            next[pos] = replacement;
            if (!kind.validate(next)) return error.InternalError;
            if (try replace(self, i, next)) break;
        }
    }
}

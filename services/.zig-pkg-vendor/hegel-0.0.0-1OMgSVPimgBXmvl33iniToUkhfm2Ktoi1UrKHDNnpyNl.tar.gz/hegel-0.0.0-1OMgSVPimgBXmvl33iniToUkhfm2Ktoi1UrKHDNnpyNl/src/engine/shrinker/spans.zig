// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/spans.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
pub fn removeDiscarded(self: *Shrinker) !bool {
    const gpa = self.allocator;
    while (true) {
        var discarded: std.ArrayList(struct { start: usize, end: usize }) = .empty;
        defer discarded.deinit(gpa);
        for (self.current_spans) |span| {
            if (span.end > span.start and span.discarded and (discarded.items.len == 0 or span.start >= discarded.items[discarded.items.len - 1].end)) try discarded.append(gpa, .{ .start = span.start, .end = span.end });
        }
        if (discarded.items.len == 0) return true;
        var attempt: std.ArrayList(c.ChoiceNode) = .empty;
        defer attempt.deinit(gpa);
        var pos: usize = 0;
        for (discarded.items) |range| {
            if (range.start > range.end or range.end > self.current_nodes.len) return error.InternalError;
            try attempt.appendSlice(gpa, self.current_nodes[pos..range.start]);
            pos = range.end;
        }
        try attempt.appendSlice(gpa, self.current_nodes[pos..]);
        if (!try self.consider(attempt.items)) return false;
    }
}
pub fn tryTrivialSpans(self: *Shrinker) !void {
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_spans.len) : (i += 1) {
        const epoch = self.improvements;
        const span = self.current_spans[i];
        if (span.end > self.current_nodes.len) continue;
        var trivial = true;
        for (self.current_nodes[span.start..span.end]) |*node| {
            if (!node.was_forced and !try node.data.isSimplest(gpa)) {
                trivial = false;
                break;
            }
        }
        if (trivial) continue;
        const attempt = try c.cloneNodes(gpa, self.current_nodes);
        defer c.deinitNodes(gpa, attempt);
        for (attempt[span.start..span.end]) |*node| {
            if (node.was_forced) continue;
            if (!try node.data.isSimplest(gpa)) {
                const simplest = try node.withSimplest(gpa);
                node.deinit(gpa);
                node.* = simplest;
            }
        }
        var out = try self.runTestFn(.{ .full = attempt });
        defer out.run.deinit(gpa);
        self.calls += 1;
        if (out.interesting and try c.nodesOrder(gpa, out.run.nodes, self.current_nodes) == .lt) {
            try self.acceptImprovement(out.run.nodes, out.run.spans);
            continue;
        }
        if (self.improvements == epoch and i < out.run.spans.len) {
            const new = out.run.spans[i];
            if (new.start <= new.end and new.end <= out.run.nodes.len) {
                var splice: std.ArrayList(c.ChoiceNode) = .empty;
                defer splice.deinit(gpa);
                try splice.appendSlice(gpa, self.current_nodes[0..span.start]);
                try splice.appendSlice(gpa, out.run.nodes[new.start..new.end]);
                try splice.appendSlice(gpa, self.current_nodes[span.end..]);
                _ = try self.consider(splice.items);
            }
        }
    }
}
const LabelIndex = struct { label: u64, index: usize };
fn labelLess(_: void, a: LabelIndex, b: LabelIndex) bool {
    return a.label < b.label or (a.label == b.label and a.index < b.index);
}
pub fn passToDescendant(self: *Shrinker) !void {
    const gpa = self.allocator;
    const spans = try gpa.dupe(c.Span, self.current_spans);
    defer gpa.free(spans);
    const indices = try gpa.alloc(LabelIndex, spans.len);
    defer gpa.free(indices);
    for (spans, indices, 0..) |s, *p, i| p.* = .{ .label = s.label, .index = i };
    std.mem.sort(LabelIndex, indices, {}, labelLess);
    var group: usize = 0;
    while (group < indices.len) {
        var end = group + 1;
        while (end < indices.len and indices[end].label == indices[group].label) : (end += 1) {}
        for (group..end) |ai| {
            const a = spans[indices[ai].index];
            const a_len = a.end -| a.start;
            if (a_len == 0) continue;
            for (ai + 1..end) |di| {
                const d = spans[indices[di].index];
                if (d.start >= a.end) break;
                const d_len = d.end -| d.start;
                if (d_len == 0 or d_len >= a_len or a.end > self.current_nodes.len) continue;
                if (d.start < a.start or d.end > a.end) return error.InternalError;
                var attempt: std.ArrayList(c.ChoiceNode) = .empty;
                defer attempt.deinit(gpa);
                try attempt.appendSlice(gpa, self.current_nodes[0..a.start]);
                try attempt.appendSlice(gpa, self.current_nodes[d.start..d.end]);
                try attempt.appendSlice(gpa, self.current_nodes[a.end..]);
                _ = try self.consider(attempt.items);
            }
        }
        group = end;
    }
}
const Endpoint = struct { start: usize, end: usize };
const ReorderJudge = struct {
    self: *Shrinker,
    nodes: []const c.ChoiceNode,
    endpoints: []const Endpoint,
    fn compare(p: *anyopaque, a: usize, b: usize) anyerror!std.math.Order {
        const ctx: *@This() = @ptrCast(@alignCast(p));
        const x = ctx.endpoints[a];
        const y = ctx.endpoints[b];
        return c.nodesOrder(ctx.self.allocator, ctx.nodes[x.start..x.end], ctx.nodes[y.start..y.end]);
    }
    fn accept(p: *anyopaque, permutation: []const usize) anyerror!bool {
        const ctx: *@This() = @ptrCast(@alignCast(p));
        const gpa = ctx.self.allocator;
        if (permutation.len != ctx.endpoints.len) return error.InternalError;
        var attempt: std.ArrayList(c.ChoiceNode) = .empty;
        defer attempt.deinit(gpa);
        try attempt.appendSlice(gpa, ctx.nodes[0..ctx.endpoints[0].start]);
        for (ctx.endpoints, 0..) |target, k| {
            const source = ctx.endpoints[permutation[k]];
            try attempt.appendSlice(gpa, ctx.nodes[source.start..source.end]);
            const end = if (k + 1 < ctx.endpoints.len) ctx.endpoints[k + 1].start else ctx.nodes.len;
            try attempt.appendSlice(gpa, ctx.nodes[target.end..end]);
        }
        return ctx.self.consider(attempt.items);
    }
};
fn parentLess(_: void, a: ?usize, b: ?usize) bool {
    if (a == null) return b != null;
    if (b == null) return false;
    return a.? < b.?;
}
pub fn reorderSpans(self: *Shrinker) !void {
    const gpa = self.allocator;
    var parents: std.ArrayList(?usize) = .empty;
    defer parents.deinit(gpa);
    for (self.current_spans) |s| {
        var seen = false;
        for (parents.items) |p| {
            if (p == s.parent) {
                seen = true;
                break;
            }
        }
        if (!seen) try parents.append(gpa, s.parent);
    }
    std.mem.sort(?usize, parents.items, {}, parentLess);
    for (parents.items) |parent| {
        var by_label: std.ArrayList(LabelIndex) = .empty;
        defer by_label.deinit(gpa);
        for (self.current_spans, 0..) |s, i| {
            if (s.parent == parent) try by_label.append(gpa, .{ .label = s.label, .index = i });
        }
        std.mem.sort(LabelIndex, by_label.items, {}, labelLess);
        var group: usize = 0;
        while (group < by_label.items.len) {
            const label = by_label.items[group].label;
            var end = group + 1;
            while (end < by_label.items.len and by_label.items[end].label == label) : (end += 1) {}
            var endpoints: std.ArrayList(Endpoint) = .empty;
            defer endpoints.deinit(gpa);
            for (by_label.items[group..end]) |entry| {
                if (entry.index >= self.current_spans.len) continue;
                const s = self.current_spans[entry.index];
                if (s.parent == parent and s.label == label) try endpoints.append(gpa, .{ .start = s.start, .end = s.end });
            }
            group = end;
            if (endpoints.items.len <= 1) continue;
            var valid = true;
            for (endpoints.items) |p| {
                if (p.end > self.current_nodes.len) {
                    valid = false;
                    break;
                }
            }
            if (!valid) continue;
            const snapshot = try c.cloneNodes(gpa, self.current_nodes);
            defer c.deinitNodes(gpa, snapshot);
            var ctx = ReorderJudge{ .self = self, .nodes = snapshot, .endpoints = endpoints.items };
            try @import("ordering.zig").shrinkOrdering(gpa, endpoints.items.len, .{ .context = &ctx, .compare = ReorderJudge.compare, .accept = ReorderJudge.accept });
        }
    }
}
pub fn deleteSpans(self: *Shrinker) !void {
    const gpa = self.allocator;
    var attempted: std.AutoHashMapUnmanaged(Endpoint, void) = .empty;
    defer attempted.deinit(gpa);
    var epoch = self.improvements;
    var i: usize = 0;
    while (i < self.current_spans.len) {
        const span = self.current_spans[i];
        i += 1;
        if (self.improvements != epoch) {
            epoch = self.improvements;
            attempted.clearRetainingCapacity();
        }
        if (span.end > self.current_nodes.len) continue;
        var widened = self.current_nodes.len;
        for (self.current_spans) |s| {
            if (s.start >= span.end) widened = @min(widened, s.start);
        }
        var extents: [2]Endpoint = undefined;
        var len: usize = 0;
        if (span.end -| span.start < 2) {
            var preceded = span.start > 0;
            if (preceded) {
                for (self.current_spans) |s| {
                    if (s.end == span.start and s.start < span.start) {
                        preceded = false;
                        break;
                    }
                }
            }
            if (preceded) {
                extents[0] = .{ .start = span.start - 1, .end = span.end };
                len = 1;
            } else if (widened > span.end) {
                extents[0] = .{ .start = span.start, .end = widened };
                len = 1;
            } else continue;
        } else {
            extents[0] = .{ .start = span.start, .end = span.end };
            extents[1] = .{ .start = span.start, .end = widened };
            len = 2;
        }
        for (extents[0..len]) |range| {
            if (range.start == 0 and range.end == self.current_nodes.len) continue;
            const entry = try attempted.getOrPut(gpa, range);
            if (entry.found_existing) continue;
            var attempt: std.ArrayList(c.ChoiceNode) = .empty;
            defer attempt.deinit(gpa);
            try attempt.appendSlice(gpa, self.current_nodes[0..range.start]);
            try attempt.appendSlice(gpa, self.current_nodes[range.end..]);
            if (try self.consider(attempt.items)) break;
            const follower = nodeAfterEnclosingSpan(self, i - 1, range.end) orelse continue;
            if (try considerWithNodeNudged(self, attempt.items, follower - (range.end - range.start))) break;
        }
    }
}
fn nodeAfterEnclosingSpan(self: *Shrinker, idx: usize, end: usize) ?usize {
    if (idx >= self.current_spans.len) return null;
    var span = self.current_spans[idx];
    while (true) {
        const parent = span.parent orelse return null;
        if (parent >= self.current_spans.len) return null;
        span = self.current_spans[parent];
        if (span.end > end) return if (span.end < self.current_nodes.len) span.end else null;
    }
}
fn considerWithNodeNudged(self: *Shrinker, attempt: []const c.ChoiceNode, idx: usize) !bool {
    if (idx >= attempt.len) return error.InternalError;
    const gpa = self.allocator;
    const node = &attempt[idx];
    var values: std.ArrayList(c.ChoiceValue) = .empty;
    defer {
        for (values.items) |*v| v.deinit(gpa);
        values.deinit(gpa);
    }
    switch (node.data) {
        .integer => |pair| {
            for ([_]i32{ -1, 1 }) |delta| {
                var candidate = try pair.value.addInt(gpa, delta);
                if (pair.constraint.validate(candidate)) {
                    errdefer candidate.deinit();
                    try values.append(gpa, .{ .integer = candidate });
                } else candidate.deinit();
            }
        },
        .boolean => |pair| try values.append(gpa, .{ .boolean = !pair.value }),
        .string => |pair| {
            if (pair.value.len > pair.constraint.min_size) {
                const shortened = try gpa.dupe(u32, pair.value[0 .. pair.value.len - 1]);
                errdefer gpa.free(shortened);
                try values.append(gpa, .{ .string = shortened });
            }
        },
        else => {},
    }
    for (values.items) |*v| {
        const modified = try gpa.dupe(c.ChoiceNode, attempt);
        defer gpa.free(modified);
        var changed = if (node.data == .boolean) c.ChoiceNode.boolean(node.data.boolean.constraint, v.boolean, node.was_forced) else (try node.withValue(gpa, v) orelse return error.InternalError);
        defer changed.deinit(gpa);
        modified[idx] = changed;
        if (try self.consider(modified)) return true;
    }
    return false;
}

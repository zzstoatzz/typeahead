// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/clones.rs; see provenance.
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
const std = @import("std");
fn spliceChild(gpa: std.mem.Allocator, template: []const c.ChoiceNode, i: usize, child: []const c.ChoiceNode) ![]c.ChoiceNode {
    const candidate = try c.cloneNodes(gpa, template);
    errdefer c.deinitNodes(gpa, candidate);
    const stream = try c.RealizedStream.create(gpa, child, &.{});
    defer stream.release();
    const forced = candidate[i].was_forced;
    candidate[i].deinit(gpa);
    candidate[i] = c.ChoiceNode.cloneStream(stream, forced);
    return candidate;
}
const NestedProbe = struct {
    gpa: std.mem.Allocator,
    eval: root.Eval,
    template: []const c.ChoiceNode,
    outer_values: []const c.ChoiceValue,
    index: usize,
    fn mode(p: *anyopaque, m: root.SweepMode) ?root.SweepMode {
        const self: *@This() = @ptrCast(@alignCast(p));
        if (self.eval.set_sweep_mode) |f| return f(self.eval.context, m);
        return null;
    }
    fn adopted(p: *anyopaque) anyerror!void {
        const self: *@This() = @ptrCast(@alignCast(p));
        if (self.eval.candidate_adopted) |f| try f(self.eval.context);
    }
    fn call(p: *anyopaque, req: root.Request) anyerror!root.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        var out: root.Outcome = undefined;
        switch (req) {
            .full => |child| {
                const candidate = try spliceChild(self.gpa, self.template, self.index, child);
                defer c.deinitNodes(self.gpa, candidate);
                out = try self.eval.call(self.eval.context, .{ .full = candidate });
            },
            .probe => |probe| {
                const values = try c.cloneValues(self.gpa, self.outer_values);
                defer c.deinitValues(self.gpa, values);
                const record = try c.CloneRecord.fromValuesCopy(self.gpa, probe.prefix);
                values[self.index].deinit(self.gpa);
                values[self.index] = .{ .clone = record };
                const extend = probe.max_size -| probe.prefix.len;
                out = try self.eval.call(self.eval.context, .{ .probe = .{ .prefix = values, .max_size = c.flattenedValuesLen(values) + extend } });
            },
        }
        defer out.run.deinit(self.gpa);
        if (self.index < out.run.nodes.len) {
            if (out.run.nodes[self.index].data.asClone()) |stream| {
                return .{ .interesting = out.interesting, .run = try root.CachedRun.init(self.gpa, out.run.status, null, stream.nodes, stream.spans) };
            }
        }
        return .{ .interesting = false, .run = try root.CachedRun.init(self.gpa, .valid, null, &.{}, &.{}) };
    }
};
pub fn shrinkCloneStreams(self: *Shrinker) anyerror!void {
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        try shrinkAt(self, i);
    }
}
fn shrinkAt(self: *Shrinker, i: usize) anyerror!void {
    const stream = self.current_nodes[i].data.asClone() orelse return;
    if (stream.nodes.len == 0) return;
    const gpa = self.allocator;
    const template = try c.cloneNodes(gpa, self.current_nodes);
    defer c.deinitNodes(gpa, template);
    const values = try gpa.alloc(c.ChoiceValue, template.len);
    var count: usize = 0;
    defer {
        for (values[0..count]) |*v| v.deinit(gpa);
        gpa.free(values);
    }
    for (template, values) |*n, *v| {
        v.* = try n.value(gpa);
        count += 1;
    }
    var ctx = NestedProbe{ .gpa = gpa, .eval = self.evaluator, .template = template, .outer_values = values, .index = i };
    var nested = try Shrinker.init(gpa, .{ .context = &ctx, .call = NestedProbe.call, .set_sweep_mode = NestedProbe.mode, .candidate_adopted = NestedProbe.adopted }, stream.nodes, stream.spans);
    defer nested.deinit();
    nested.deadline = self.deadline;
    nested.now = self.now;
    nested.clock_context = self.clock_context;
    try nested.shrink();
    self.timed_out = self.timed_out or nested.timed_out;
    const spliced = try spliceChild(gpa, self.current_nodes, i, nested.current_nodes);
    defer c.deinitNodes(gpa, spliced);
    _ = try self.consider(spliced);
}

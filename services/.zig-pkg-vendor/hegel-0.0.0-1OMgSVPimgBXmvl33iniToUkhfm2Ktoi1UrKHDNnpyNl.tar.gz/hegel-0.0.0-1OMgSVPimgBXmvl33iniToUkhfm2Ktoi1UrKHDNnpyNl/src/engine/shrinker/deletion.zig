// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/native/shrinker/deletion.rs; see provenance.
const std = @import("std");
const root = @import("../shrinker.zig");
const c = root.choices;
const Shrinker = root.Shrinker;
pub fn deleteChunks(self: *Shrinker) !void {
    const gpa = self.allocator;
    var k: usize = 8;
    while (k > 0) : (k -= 1) {
        var i = self.current_nodes.len -| (k + 1);
        while (true) {
            if (i >= self.current_nodes.len) break;
            const end = @min(i + k, self.current_nodes.len);
            var attempt: std.ArrayList(c.ChoiceNode) = .empty;
            defer attempt.deinit(gpa);
            try attempt.appendSlice(gpa, self.current_nodes[0..i]);
            try attempt.appendSlice(gpa, self.current_nodes[end..]);
            if (!try self.consider(attempt.items) and i > 0) {
                const prev = &attempt.items[i - 1];
                var lowered: ?c.ChoiceValue = null;
                defer if (lowered) |*v| v.deinit(gpa);
                switch (prev.data) {
                    .integer => |pair| {
                        var simplest = try pair.constraint.simplest(gpa);
                        defer simplest.deinit();
                        if (!pair.value.eql(simplest)) {
                            var candidate = try pair.value.subInt(gpa, 1);
                            if (pair.constraint.validate(candidate)) {
                                lowered = .{ .integer = candidate };
                            } else candidate.deinit();
                        }
                    },
                    .boolean => |pair| {
                        if (pair.value) lowered = .{ .boolean = false };
                    },
                    else => {},
                }
                if (lowered) |*value| {
                    const changed: ?c.ChoiceNode = if (prev.data == .boolean) c.ChoiceNode.boolean(prev.data.boolean.constraint, false, prev.was_forced) else try prev.withValue(gpa, value);
                    if (changed) |owned| {
                        var node = owned;
                        defer node.deinit(gpa);
                        attempt.items[i - 1] = node;
                        _ = try self.consider(attempt.items);
                    }
                }
            }
            if (i == 0) break;
            i -= 1;
        }
    }
}
pub fn bindDeletion(self: *Shrinker) !void {
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        const pair = self.current_nodes[i].data.asInteger() orelse continue;
        var simplest = try pair[0].simplest(gpa);
        errdefer simplest.deinit();
        if (pair[1].eql(simplest)) {
            simplest.deinit();
            continue;
        }
        const expected_len = self.current_nodes.len;
        const hi = try pair[1].clone(gpa);
        var search = root.search.BinSearchDownBig.init(gpa, simplest, hi);
        defer search.deinit();
        while (try search.probe()) |owned| {
            var v = c.ChoiceValue{ .integer = owned };
            defer v.deinit(gpa);
            const ok = try tryReplaceWithDeletion(self, i, &v, expected_len);
            try search.record(ok);
        }
    }
}
pub fn tryReplaceWithDeletion(self: *Shrinker, idx: usize, value: *const c.ChoiceValue, expected_len: usize) !bool {
    if (try self.replace(&.{.{ .index = idx, .value = value.* }})) return true;
    if (idx >= self.current_nodes.len) return false;
    const gpa = self.allocator;
    const attempt = try c.cloneNodes(gpa, self.current_nodes);
    defer c.deinitNodes(gpa, attempt);
    const replaced = try attempt[idx].withValue(gpa, value) orelse return false;
    attempt[idx].deinit(gpa);
    attempt[idx] = replaced;
    var out = try self.runTestFn(.{ .full = attempt });
    defer out.run.deinit(gpa);
    if (out.run.nodes.len >= expected_len) return false;
    const deficit = expected_len - out.run.nodes.len;
    const start = attempt.len -| deficit;
    if (start <= idx) return false;
    var j = start + 1;
    while (j > idx + 1) {
        j -= 1;
        var candidate: std.ArrayList(c.ChoiceNode) = .empty;
        defer candidate.deinit(gpa);
        try candidate.appendSlice(gpa, attempt[0..j]);
        try candidate.appendSlice(gpa, attempt[j + deficit ..]);
        if (try self.consider(candidate.items)) return true;
    }
    return false;
}
pub fn nodeProgram(self: *Shrinker, n: usize) !void {
    if (n == 0) return;
    var i: usize = 0;
    const gpa = self.allocator;
    while (i + n <= self.current_nodes.len) {
        if (!try runNodeProgramLive(self, i, n, 1)) {
            i += 1;
            continue;
        }
        const starting = i;
        var search = root.search.FindInteger.init();
        while (search.probe()) |k| {
            search.record(if (k > starting / n) false else try runNodeProgramLive(self, starting - k * n, n, 1));
        }
        const start = starting -| (search.step().done * n);
        const snapshot = try c.cloneNodes(gpa, self.current_nodes);
        defer c.deinitNodes(gpa, snapshot);
        search = root.search.FindInteger.init();
        while (search.probe()) |k| search.record(try runNodeProgram(self, snapshot, start, n, k));
        i = start +| n;
    }
}
fn runNodeProgramLive(self: *Shrinker, i: usize, n: usize, repeats: usize) !bool {
    const snapshot = try c.cloneNodes(self.allocator, self.current_nodes);
    defer c.deinitNodes(self.allocator, snapshot);
    return runNodeProgram(self, snapshot, i, n, repeats);
}
fn runNodeProgram(self: *Shrinker, original: []const c.ChoiceNode, i: usize, n: usize, repeats: usize) !bool {
    const total = n *| repeats;
    if (i > original.len or total > original.len - i) return false;
    var attempt: std.ArrayList(c.ChoiceNode) = .empty;
    defer attempt.deinit(self.allocator);
    try attempt.appendSlice(self.allocator, original[0..i]);
    try attempt.appendSlice(self.allocator, original[i + total ..]);
    const epoch = self.improvements;
    return try self.consider(attempt.items) and self.improvements > epoch;
}
fn gramsMatch(a: []const c.ChoiceNode, b: []const c.ChoiceNode) bool {
    for (a, b) |*x, *y| {
        if (x.data == .clone and y.data == .clone) continue;
        if (!x.eql(y)) return false;
    }
    return true;
}
const Region = struct { start: usize, end: usize };
fn reverseRegion(_: void, a: Region, b: Region) bool {
    return a.start > b.start or (a.start == b.start and a.end > b.end);
}
pub fn deleteBetweenRepeats(self: *Shrinker) !void {
    const gpa = self.allocator;
    const fingerprints = try gpa.alloc(u64, self.current_nodes.len);
    defer gpa.free(fingerprints);
    for (self.current_nodes, fingerprints) |*node, *dest| dest.* = if (node.data == .clone) 6 else node.data.valueRef().hash();
    const len = fingerprints.len;
    var proposals: std.ArrayList(Region) = .empty;
    defer proposals.deinit(gpa);
    var seen: std.AutoHashMapUnmanaged(Region, void) = .empty;
    defer seen.deinit(gpa);
    for ([_]usize{ 4, 3, 2, 1 }) |n| {
        if (n > len) continue;
        var last: std.AutoHashMapUnmanaged(u64, usize) = .empty;
        defer last.deinit(gpa);
        for (0..len - n + 1) |i| {
            const gram = std.hash.Wyhash.hash(0, std.mem.sliceAsBytes(fingerprints[i .. i + n]));
            if (last.get(gram)) |prev| {
                const region = Region{ .start = prev, .end = i };
                if (i - prev >= 2 and gramsMatch(self.current_nodes[prev .. prev + n], self.current_nodes[i .. i + n])) {
                    const entry = try seen.getOrPut(gpa, region);
                    if (!entry.found_existing) try proposals.append(gpa, region);
                }
            }
            try last.put(gpa, gram, i);
        }
    }
    std.mem.sort(Region, proposals.items, {}, reverseRegion);
    for (proposals.items) |r| {
        if (r.end > self.current_nodes.len) continue;
        var attempt: std.ArrayList(c.ChoiceNode) = .empty;
        defer attempt.deinit(gpa);
        try attempt.appendSlice(gpa, self.current_nodes[0..r.start]);
        try attempt.appendSlice(gpa, self.current_nodes[r.end..]);
        _ = try self.consider(attempt.items);
    }
}
pub fn minimizeIndividualChoices(self: *Shrinker) !void {
    const gpa = self.allocator;
    var i: usize = 0;
    while (i < self.current_nodes.len) : (i += 1) {
        var node = try self.current_nodes[i].deepClone(gpa);
        defer node.deinit(gpa);
        if (node.was_forced) continue;
        const pair = node.data.asInteger() orelse continue;
        var simplest = try pair[0].simplest(gpa);
        defer simplest.deinit();
        if (pair[1].eql(simplest)) continue;
        const epoch = self.improvements;
        var search = root.search.BinSearchDownBig.init(gpa, try simplest.clone(gpa), try pair[1].clone(gpa));
        defer search.deinit();
        while (try search.probe()) |owned| {
            var v = owned;
            defer v.deinit();
            try search.record(try self.replaceInt(i, &v));
        }
        if (self.improvements > epoch) continue;
        if (i >= self.current_nodes.len) return error.InternalError;
        const original_len = self.current_nodes.len;
        var towards = try pair[1].addInt(gpa, if (pair[1].order(simplest) == .gt) @as(i32, -1) else @as(i32, 1));
        defer towards.deinit();
        const lowered = try c.cloneNodes(gpa, self.current_nodes);
        defer c.deinitNodes(gpa, lowered);
        const changed = try lowered[i].withValue(gpa, &.{ .integer = towards }) orelse return error.InternalError;
        lowered[i].deinit(gpa);
        lowered[i] = changed;
        var out = try self.runTestFn(.{ .full = lowered });
        defer out.run.deinit(gpa);
        var handled = false;
        for (@min(i+1,@min(lowered.len,out.run.nodes.len))..@min(lowered.len, out.run.nodes.len)) |k| {
            const cand = &lowered[k];
            const actual = &out.run.nodes[k];
            var retry: ?c.ChoiceNode = null;
            if (cand.data == .string and actual.data == .string and cand.data.string.value.len > actual.data.string.value.len) {
                retry = c.ChoiceNode.string(cand.data.string.constraint, try gpa.dupe(u32, cand.data.string.value[0..actual.data.string.value.len]), cand.was_forced);
            } else if (cand.data == .bytes and actual.data == .bytes and cand.data.bytes.value.len > actual.data.bytes.value.len) {
                retry = c.ChoiceNode.bytes(cand.data.bytes.constraint, try gpa.dupe(u8, cand.data.bytes.value[0..actual.data.bytes.value.len]), cand.was_forced);
            }
            if (retry) |owned| {
                var rd = owned;
                defer rd.deinit(gpa);
                const candidate = try gpa.dupe(c.ChoiceNode, lowered);
                defer gpa.free(candidate);
                candidate[k] = rd;
                if (try self.consider(candidate) and self.improvements > epoch) {
                    handled = true;
                    break;
                }
            }
        }
        if (handled or out.run.nodes.len >= original_len or out.run.nodes.len <= i + 1) continue;
        var shrank = false;
        for (out.run.spans) |span| {
            if (span.start <= i or span.end > out.run.nodes.len or span.end <= span.start) continue;
            var candidate: std.ArrayList(c.ChoiceNode) = .empty;
            defer candidate.deinit(gpa);
            try candidate.appendSlice(gpa, out.run.nodes[0..span.start]);
            try candidate.appendSlice(gpa, out.run.nodes[span.end..]);
            if (try self.consider(candidate.items) and self.improvements > epoch) {
                shrank = true;
                break;
            }
        }
        if (!shrank) {
            for (i + 1..out.run.nodes.len) |j| {
                var candidate: std.ArrayList(c.ChoiceNode) = .empty;
                defer candidate.deinit(gpa);
                try candidate.appendSlice(gpa, out.run.nodes[0..j]);
                try candidate.appendSlice(gpa, out.run.nodes[j + 1 ..]);
                if (try self.consider(candidate.items) and self.improvements > epoch) break;
            }
        }
    }
}

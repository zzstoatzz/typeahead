// SPDX-License-Identifier: MIT
const std = @import("std");

pub const Mutex = struct {
    state: std.atomic.Mutex = .unlocked,

    pub fn lock(self: *Mutex) void {
        while (!self.tryLock()) {
            std.Thread.yield() catch {};
        }
    }

    pub fn tryLock(self: *Mutex) bool {
        return self.state.tryLock();
    }

    pub fn unlock(self: *Mutex) void {
        self.state.unlock();
    }
};

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const Allocator = std.mem.Allocator;
pub const BigInt = @import("bignum.zig").BigInt;
pub const BigUint = @import("bignum.zig").BigUint;
pub const IntervalSet = @import("intervalsets.zig").IntervalSet;
const float_index = @import("float_index.zig");
const signAwareLte = @import("floats.zig").signAwareLte;
pub const Error = Allocator.Error || error{ InternalError, NegativeUnsigned, DivisionByZero };

pub const IntegerChoice = struct {
    min_value: BigInt,
    max_value: BigInt,
    shrink_towards: BigInt,

    pub fn deepClone(self: IntegerChoice, gpa: Allocator) Error!IntegerChoice {
        var min = try self.min_value.clone(gpa);
        errdefer min.deinit();
        var max = try self.max_value.clone(gpa);
        errdefer max.deinit();
        return .{ .min_value = min, .max_value = max, .shrink_towards = try self.shrink_towards.clone(gpa) };
    }

    pub fn deinit(self: *IntegerChoice) void {
        self.min_value.deinit();
        self.max_value.deinit();
        self.shrink_towards.deinit();
        self.* = undefined;
    }

    pub fn eql(self: IntegerChoice, other: IntegerChoice) bool {
        return self.min_value.eql(other.min_value) and self.max_value.eql(other.max_value) and self.shrink_towards.eql(other.shrink_towards);
    }

    pub fn simplest(self: IntegerChoice, gpa: Allocator) Error!BigInt {
        return (if (self.shrink_towards.order(self.min_value) == .lt) self.min_value else if (self.shrink_towards.order(self.max_value) == .gt) self.max_value else self.shrink_towards).clone(gpa);
    }

    pub fn unit(self: IntegerChoice, gpa: Allocator) Error!BigInt {
        var s = try self.simplest(gpa);
        defer s.deinit();
        var successor = try s.addInt(gpa, @as(i32, 1));
        if (self.validate(successor)) return successor;
        successor.deinit();
        var predecessor = try s.subInt(gpa, @as(i32, 1));
        if (self.validate(predecessor)) return predecessor;
        predecessor.deinit();
        return s.clone(gpa);
    }

    pub fn validate(self: IntegerChoice, value: BigInt) bool {
        return self.min_value.order(value) != .gt and value.order(self.max_value) != .gt;
    }

    pub fn sortKey(self: IntegerChoice, gpa: Allocator, value: BigInt) Error!struct { BigUint, bool } {
        var target = try self.simplest(gpa);
        defer target.deinit();
        var distance = try value.sub(gpa, target);
        defer distance.deinit();
        return .{ try distance.magnitude(gpa), value.order(target) == .lt };
    }

    pub fn maxIndex(self: IntegerChoice, gpa: Allocator) Error!BigUint {
        var difference = try self.max_value.sub(gpa, self.min_value);
        defer difference.deinit();
        return difference.magnitude(gpa);
    }

    pub fn toIndex(self: IntegerChoice, gpa: Allocator, value: BigInt) Error!BigUint {
        var s = try self.simplest(gpa);
        defer s.deinit();
        if (value.eql(s)) return BigUint.zero(gpa);
        var above_difference = try self.max_value.sub(gpa, s);
        defer above_difference.deinit();
        var below_difference = try s.sub(gpa, self.min_value);
        defer below_difference.deinit();
        var distance_difference = try value.sub(gpa, s);
        defer distance_difference.deinit();
        var above = try above_difference.magnitude(gpa);
        defer above.deinit();
        var below = try below_difference.magnitude(gpa);
        defer below.deinit();
        var distance = try distance_difference.magnitude(gpa);
        defer distance.deinit();
        var less = try distance.subInt(gpa, @as(u8, 1));
        defer less.deinit();
        var count = try minBig(less, above).add(gpa, minBig(less, below));
        defer count.deinit();
        return count.addInt(gpa, @as(u8, if (value.order(s) == .gt or distance.order(above) == .gt) 1 else 2));
    }

    pub fn fromIndex(self: IntegerChoice, gpa: Allocator, index: BigUint) Error!?BigInt {
        var s = try self.simplest(gpa);
        defer s.deinit();
        if (index.isZero()) return try s.clone(gpa);
        var a_difference = try self.max_value.sub(gpa, s);
        defer a_difference.deinit();
        var b_difference = try s.sub(gpa, self.min_value);
        defer b_difference.deinit();
        var above = try a_difference.magnitude(gpa);
        defer above.deinit();
        var below = try b_difference.magnitude(gpa);
        defer below.deinit();
        var maximum = try above.add(gpa, below);
        defer maximum.deinit();
        if (index.order(maximum) == .gt) return null;
        var twice = try minBig(above, below).shl(gpa, 1);
        defer twice.deinit();
        var distance: BigUint = undefined;
        var up: bool = undefined;
        if (index.order(twice) != .gt) {
            var next = try index.addInt(gpa, @as(u8, 1));
            defer next.deinit();
            distance = try next.shr(gpa, 1);
            up = index.value.isOdd();
        } else {
            distance = try index.sub(gpa, minBig(above, below));
            up = above.order(below) == .gt;
        }
        defer distance.deinit();
        var signed_distance = try distance.asSigned(gpa);
        defer signed_distance.deinit();
        return if (up) try s.add(gpa, signed_distance) else try s.sub(gpa, signed_distance);
    }

    pub fn valueFromBigint(self: IntegerChoice, gpa: Allocator, value: BigInt) Error!?BigInt {
        return if (self.validate(value)) try value.clone(gpa) else null;
    }
};

fn minBig(a: BigUint, b: BigUint) BigUint {
    return if (a.order(b) == .gt) b else a;
}

pub const BooleanChoice = struct {
    p: f64,

    pub fn eql(self: BooleanChoice, other: BooleanChoice) bool {
        return @as(u64, @bitCast(self.p)) == @as(u64, @bitCast(other.p));
    }

    pub fn simplest(_: BooleanChoice) bool {
        return false;
    }

    pub fn unit(_: BooleanChoice) bool {
        return true;
    }

    pub fn maxIndex(_: BooleanChoice, gpa: Allocator) Error!BigUint {
        return BigUint.fromInt(gpa, @as(u8, 1));
    }

    pub fn toIndex(_: BooleanChoice, gpa: Allocator, value: bool) Error!BigUint {
        return BigUint.fromInt(gpa, @as(u8, @intFromBool(value)));
    }

    pub fn fromIndex(_: BooleanChoice, index: BigUint) ?bool {
        const value = index.toInt(u8) orelse return null;
        return switch (value) {
            0 => false,
            1 => true,
            else => null,
        };
    }
};

pub const BytesChoice = struct {
    min_size: usize,
    max_size: usize,

    pub fn eql(self: BytesChoice, other: BytesChoice) bool {
        return self.min_size == other.min_size and self.max_size == other.max_size;
    }

    pub fn simplest(self: BytesChoice, gpa: Allocator) Error![]u8 {
        const result = try gpa.alloc(u8, self.min_size);
        @memset(result, 0);
        return result;
    }

    pub fn unit(self: BytesChoice, gpa: Allocator) Error![]u8 {
        const result = try gpa.alloc(u8, if (self.min_size > 0) self.min_size else if (self.max_size > 0) 1 else 0);
        @memset(result, 0);
        if (result.len > 0) result[result.len - 1] = 1;
        return result;
    }

    pub fn validate(self: BytesChoice, value: []const u8) bool {
        return value.len >= self.min_size and value.len <= self.max_size;
    }

    pub fn maxIndex(self: BytesChoice, gpa: Allocator) Error!BigUint {
        const bytes = try gpa.alloc(u8, self.max_size);
        defer gpa.free(bytes);
        @memset(bytes, 255);
        return self.toIndex(gpa, bytes);
    }

    pub fn toIndex(self: BytesChoice, gpa: Allocator, value: []const u8) Error!BigUint {
        return sequenceIndex(gpa, 256, self.min_size, value);
    }

    pub fn fromIndex(self: BytesChoice, gpa: Allocator, index: BigUint) Error!?[]u8 {
        return sequenceFromIndex(u8, gpa, 256, self.min_size, self.max_size, index);
    }
};

fn sequenceIndex(gpa: Allocator, radix: u64, min_size: usize, value: anytype) Error!BigUint {
    var base = try BigUint.fromInt(gpa, radix);
    defer base.deinit();
    var offset = try BigUint.zero(gpa);
    defer offset.deinit();
    for (min_size..value.len) |length| {
        var power = try base.pow(gpa, @intCast(length));
        defer power.deinit();
        const next = try offset.add(gpa, power);
        offset.deinit();
        offset = next;
    }
    var position = try BigUint.zero(gpa);
    defer position.deinit();
    for (value) |digit| {
        var scaled = try position.mul(gpa, base);
        defer scaled.deinit();
        const next = try scaled.addInt(gpa, digit);
        position.deinit();
        position = next;
    }
    return offset.add(gpa, position);
}

fn sequenceFromIndex(comptime T: type, gpa: Allocator, radix: u64, min_size: usize, max_size: usize, index: BigUint) Error!?[]T {
    var base = try BigUint.fromInt(gpa, radix);
    defer base.deinit();
    var remaining = try index.clone(gpa);
    defer remaining.deinit();
    var length = min_size;
    while (length <= max_size) : (length += 1) {
        var bucket = try base.pow(gpa, @intCast(length));
        defer bucket.deinit();
        if (remaining.order(bucket) == .lt) {
            const result = try gpa.alloc(T, length);
            errdefer gpa.free(result);
            var i = length;
            while (i > 0) {
                i -= 1;
                var pair = try remaining.divRem(gpa, base);
                defer pair[1].deinit();
                result[i] = pair[1].toInt(T) orelse return error.InternalError;
                remaining.deinit();
                remaining = pair[0];
            }
            return result;
        }
        const next = try remaining.sub(gpa, bucket);
        remaining.deinit();
        remaining = next;
        if (length == max_size) break;
    }
    return null;
}

pub const StringChoice = struct {
    intervals: *const IntervalSet,
    min_size: usize,
    max_size: usize,

    pub fn eql(self: StringChoice, other: StringChoice) bool {
        if (self.min_size != other.min_size or self.max_size != other.max_size or self.intervals.intervals.len != other.intervals.intervals.len) return false;
        for (self.intervals.intervals, other.intervals.intervals) |a, b| if (a.start != b.start or a.end != b.end) return false;
        return true;
    }

    pub fn codepointKey(self: StringChoice, codepoint: u32) u32 {
        return @intCast(self.intervals.indexFromCodepointInShrinkOrder(codepoint));
    }

    pub fn keyToCodepoint(self: StringChoice, key: u32) ?u32 {
        return if (key >= self.intervals.len()) null else self.intervals.charInShrinkOrder(key);
    }

    pub fn simplestCodepoint(self: StringChoice) Error!u32 {
        if (self.intervals.isEmpty()) return error.InternalError;
        return self.intervals.charInShrinkOrder(0);
    }

    pub fn simplest(self: StringChoice, gpa: Allocator) Error![]u32 {
        const cp = if (self.min_size > 0) try self.simplestCodepoint() else 0;
        const result = try gpa.alloc(u32, self.min_size);
        @memset(result, cp);
        return result;
    }

    pub fn unit(self: StringChoice, gpa: Allocator) Error![]u32 {
        if (self.intervals.isEmpty()) return self.simplest(gpa);
        const simplest_cp = try self.simplestCodepoint();
        if (self.keyToCodepoint(1)) |cp| {
            if (cp != simplest_cp) {
                if (self.min_size > 0) {
                    const result = try self.simplest(gpa);
                    result[result.len - 1] = cp;
                    return result;
                }
                if (self.max_size > 0) return gpa.dupe(u32, &.{cp});
                return self.simplest(gpa);
            }
        }
        if (self.min_size < self.max_size) {
            const result = try gpa.alloc(u32, self.min_size + 1);
            @memset(result, simplest_cp);
            return result;
        }
        return self.simplest(gpa);
    }

    pub fn validate(self: StringChoice, value: []const u32) bool {
        if (value.len < self.min_size or value.len > self.max_size) return false;
        for (value) |cp| if (!self.intervals.contains(cp)) return false;
        return true;
    }

    pub fn alphaSize(self: StringChoice) u64 {
        return self.intervals.len();
    }

    pub fn codepointRank(self: StringChoice, codepoint: u32) u64 {
        return self.codepointKey(codepoint);
    }

    pub fn codepointAtRank(self: StringChoice, rank: u64) Error!u32 {
        return self.keyToCodepoint(@truncate(rank)) orelse error.InternalError;
    }

    pub fn maxIndex(self: StringChoice, gpa: Allocator) Error!BigUint {
        var base = try BigUint.fromInt(gpa, self.alphaSize());
        defer base.deinit();
        var total = try BigUint.zero(gpa);
        defer total.deinit();
        var length = self.min_size;
        while (length <= self.max_size) : (length += 1) {
            var power = try base.pow(gpa, @intCast(length));
            defer power.deinit();
            const next = try total.add(gpa, power);
            total.deinit();
            total = next;
            if (length == self.max_size) break;
        }
        return total.subInt(gpa, @as(u8, 1));
    }

    pub fn toIndex(self: StringChoice, gpa: Allocator, value: []const u32) Error!BigUint {
        const digits = try gpa.alloc(u32, value.len);
        defer gpa.free(digits);
        for (value, digits) |cp, *digit| digit.* = self.codepointKey(cp);
        return sequenceIndex(gpa, self.alphaSize(), self.min_size, digits);
    }

    pub fn fromIndex(self: StringChoice, gpa: Allocator, index: BigUint) Error!?[]u32 {
        if (self.intervals.isEmpty() and self.max_size != 0) return error.InternalError;
        const result = try sequenceFromIndex(u32, gpa, self.alphaSize(), self.min_size, self.max_size, index) orelse return null;
        errdefer gpa.free(result);
        for (result) |*digit| digit.* = try self.codepointAtRank(digit.*);
        return result;
    }
};

pub const FloatChoice = struct {
    min_value: f64,
    max_value: f64,
    allow_nan: bool,
    allow_infinity: bool,
    smallest_nonzero_magnitude: f64,

    pub fn eql(self: FloatChoice, other: FloatChoice) bool {
        return floatBits(self.min_value) == floatBits(other.min_value) and floatBits(self.max_value) == floatBits(other.max_value) and self.allow_nan == other.allow_nan and self.allow_infinity == other.allow_infinity and floatBits(self.smallest_nonzero_magnitude) == floatBits(other.smallest_nonzero_magnitude);
    }

    pub fn validate(self: FloatChoice, value: f64) bool {
        if (std.math.isNan(value)) return self.allow_nan;
        if (std.math.isInf(value)) {
            if (!self.allow_infinity) return false;
            if (value == -std.math.inf(f64) and self.min_value > -std.math.inf(f64)) return false;
            if (value == std.math.inf(f64) and self.max_value < std.math.inf(f64)) return false;
            return true;
        }
        if (value != 0 and @abs(value) < self.smallest_nonzero_magnitude) return false;
        return signAwareLte(self.min_value, value) and signAwareLte(value, self.max_value);
    }

    pub fn simplest(self: FloatChoice) Error!f64 {
        if (self.validate(0.0)) return 0.0;
        if (self.validate(-0.0)) return -0.0;
        return self.simplestNonzero();
    }

    pub fn simplestNonzero(self: FloatChoice) Error!f64 {
        var best: ?f64 = null;
        if (self.max_value > 0) {
            const lo = @max(self.min_value, self.smallest_nonzero_magnitude);
            const hi = @min(self.max_value, std.math.floatMax(f64));
            if (lo <= hi) best = try float_index.simplestInRange(lo, hi);
        }
        if (self.min_value < 0) {
            const lo = @max(-self.max_value, self.smallest_nonzero_magnitude);
            const hi = @min(-self.min_value, std.math.floatMax(f64));
            if (lo <= hi) {
                const negative = -try float_index.simplestInRange(lo, hi);
                if (best == null or self.sortKeyOrder(negative, best.?) == .lt) best = negative;
            }
        }
        if (best) |value| return value;
        if (self.allow_infinity and self.validate(std.math.inf(f64))) return std.math.inf(f64);
        if (self.allow_infinity and self.validate(-std.math.inf(f64))) return -std.math.inf(f64);
        if (self.allow_nan) return std.math.nan(f64);
        return error.InternalError;
    }

    pub fn unit(self: FloatChoice) Error!f64 {
        const s = try self.simplest();
        if (std.math.isNan(s)) return s;
        const base = float_index.floatToIndex(@abs(s));
        for (1..4) |offset| {
            const magnitude_value = float_index.indexToFloat(base + offset);
            for ([_]f64{ magnitude_value, -magnitude_value }) |value| if (!std.math.isNan(value) and self.validate(value)) return value;
        }
        for ([_]f64{ self.min_value, self.max_value, -s }) |value| {
            if (!std.math.isNan(value) and floatBits(value) != floatBits(s) and self.validate(value)) return value;
        }
        return s;
    }

    pub fn sortKey(_: FloatChoice, value: f64) struct { u64, bool } {
        if (std.math.isNan(value)) return .{ std.math.maxInt(u64), false };
        return .{ float_index.floatToIndex(@abs(value)), floatBits(value) >> 63 == 1 };
    }

    pub fn sortKeyOrder(self: FloatChoice, a: f64, b: f64) std.math.Order {
        const ka = self.sortKey(a);
        const kb = self.sortKey(b);
        const magnitude_order = std.math.order(ka[0], kb[0]);
        return if (magnitude_order != .eq) magnitude_order else std.math.order(@intFromBool(ka[1]), @intFromBool(kb[1]));
    }

    pub fn maxIndex(_: FloatChoice, gpa: Allocator) Error!BigUint {
        return BigUint.fromInt(gpa, max_finite_global_rank + 2 + (@as(u128, 1) << 53));
    }

    pub fn toIndex(self: FloatChoice, gpa: Allocator, value: f64) Error!BigUint {
        const rank = floatGlobalRank(value);
        const base = floatGlobalRank(try self.simplest());
        if (rank < base) return error.InternalError;
        return BigUint.fromInt(gpa, rank - base);
    }

    pub fn fromIndex(self: FloatChoice, index: BigUint) Error!?f64 {
        const offset = index.toInt(u128) orelse return null;
        const raw = std.math.add(u128, floatGlobalRank(try self.simplest()), offset) catch return null;
        const value = floatFromGlobalRank(raw) orelse return null;
        return if (self.validate(value)) value else null;
    }
};

fn floatBits(value: f64) u64 {
    return @bitCast(value);
}

const max_finite_global_rank: u128 = (@as(u128, (@as(u64, 1) << 63) | (@as(u64, 2046) << 52) | ((@as(u64, 1) << 52) - 1)) * 2) + 1;

pub fn floatGlobalRank(value: f64) u128 {
    const bits = floatBits(value);
    if (std.math.isNan(value)) {
        const offset = (bits & ((@as(u64, 1) << 52) - 1)) ^ (@as(u64, 1) << 51);
        return max_finite_global_rank + 3 + @as(u128, offset) * 2 + (bits >> 63);
    }
    if (std.math.isInf(value)) return max_finite_global_rank + @as(u128, if (value > 0) 1 else 2);
    return @as(u128, float_index.floatToIndex(@abs(value))) * 2 + (bits >> 63);
}

pub fn floatFromGlobalRank(rank: u128) ?f64 {
    if (rank > max_finite_global_rank) {
        const offset = rank - max_finite_global_rank;
        if (offset == 1) return std.math.inf(f64);
        if (offset == 2) return -std.math.inf(f64);
        const relative = offset - 3;
        const mantissa_base = std.math.cast(u64, relative / 2) orelse return null;
        if (mantissa_base >> 52 != 0) return null;
        const bits = (@as(u64, @intCast(relative % 2)) << 63) | (@as(u64, 0x7ff) << 52) | (mantissa_base ^ (@as(u64, 1) << 51));
        const value: f64 = @bitCast(bits);
        return if (std.math.isNan(value)) value else null;
    }
    const index = std.math.cast(u64, rank / 2) orelse return null;
    if (index >> 63 == 0 and index >> 56 != 0) return null;
    const magnitude_value = float_index.indexToFloat(index);
    return if (rank % 2 == 1) -magnitude_value else magnitude_value;
}

pub const Span = struct {
    start: usize,
    end: usize,
    label: u64,
    depth: u32,
    parent: ?usize,
    discarded: bool,
};

pub const ChoiceValue = union(enum) {
    integer: BigInt,
    boolean: bool,
    float: f64,
    bytes: []u8,
    string: []u32,
    clone: *CloneRecord,

    pub fn valueRef(self: *const ChoiceValue) ChoiceValueRef {
        return switch (self.*) {
            .integer => |*v| .{ .integer = v },
            .boolean => |v| .{ .boolean = v },
            .float => |v| .{ .float = v },
            .bytes => |v| .{ .bytes = v },
            .string => |v| .{ .string = v },
            .clone => |v| .{ .clone = .{ .record = v } },
        };
    }

    pub fn deepClone(self: *const ChoiceValue, gpa: Allocator) Error!ChoiceValue {
        return self.valueRef().toOwned(gpa);
    }

    pub fn deinit(self: *ChoiceValue, gpa: Allocator) void {
        switch (self.*) {
            .integer => |*v| v.deinit(),
            .boolean, .float => {},
            .bytes => |v| gpa.free(v),
            .string => |v| gpa.free(v),
            .clone => |v| v.release(),
        }
        self.* = undefined;
    }

    pub fn eql(self: *const ChoiceValue, other: *const ChoiceValue) bool {
        return self.valueRef().eql(other.valueRef());
    }

    pub fn hash(self: *const ChoiceValue) u64 {
        return self.valueRef().hash();
    }
};

pub const ChoiceValueRef = union(enum) {
    integer: *const BigInt,
    boolean: bool,
    float: f64,
    bytes: []const u8,
    string: []const u32,
    clone: CloneValues,

    pub fn toOwned(self: ChoiceValueRef, gpa: Allocator) Error!ChoiceValue {
        return switch (self) {
            .integer => |v| .{ .integer = try v.clone(gpa) },
            .boolean => |v| .{ .boolean = v },
            .float => |v| .{ .float = v },
            .bytes => |v| .{ .bytes = try gpa.dupe(u8, v) },
            .string => |v| .{ .string = try gpa.dupe(u32, v) },
            .clone => |v| switch (v) {
                .record => |r| .{ .clone = r.retain() },
                .stream => |s| .{ .clone = try CloneRecord.fromStream(gpa, s) },
            },
        };
    }

    pub fn eql(self: ChoiceValueRef, other: ChoiceValueRef) bool {
        if (std.meta.activeTag(self) != std.meta.activeTag(other)) return false;
        return switch (self) {
            .integer => |v| v.eql(other.integer.*),
            .boolean => |v| v == other.boolean,
            .float => |v| floatBits(v) == floatBits(other.float),
            .bytes => |v| std.mem.eql(u8, v, other.bytes),
            .string => |v| std.mem.eql(u32, v, other.string),
            .clone => |v| v.eql(other.clone),
        };
    }

    pub fn hash(self: ChoiceValueRef) u64 {
        var state = std.hash.Wyhash.init(0);
        self.hashInto(&state);
        return state.final();
    }

    fn hashInto(self: ChoiceValueRef, state: *std.hash.Wyhash) void {
        hashInteger(state, @as(u8, @backingInt(std.meta.activeTag(self))));
        switch (self) {
            .integer => |v| {
                hashInteger(state, @as(u8, @backingInt(v.sign())));
                const magnitude = v.value.toConst();
                hashInteger(state, @as(u64, magnitude.limbs.len));
                for (magnitude.limbs) |limb| hashInteger(state, limb);
            },
            .boolean => |v| hashInteger(state, @as(u8, @intFromBool(v))),
            .float => |v| hashInteger(state, floatBits(v)),
            .bytes => |v| {
                hashInteger(state, @as(u64, v.len));
                state.update(v);
            },
            .string => |v| {
                hashInteger(state, @as(u64, v.len));
                for (v) |cp| hashInteger(state, cp);
            },
            .clone => |v| {
                hashInteger(state, @as(u64, v.len()));
                for (0..v.len()) |i| v.valueAt(i).hashInto(state);
            },
        }
    }
};

fn hashInteger(state: *std.hash.Wyhash, value: anytype) void {
    var bytes: [@sizeOf(@TypeOf(value))]u8 = undefined;
    std.mem.writeInt(@TypeOf(value), &bytes, value, .little);
    state.update(&bytes);
}

pub const RealizedStream = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize),
    nodes: []ChoiceNode,
    spans: []Span,
    flat_len: usize,

    pub fn create(gpa: Allocator, nodes: []const ChoiceNode, spans: []const Span) Error!*RealizedStream {
        const result = try gpa.create(RealizedStream);
        errdefer gpa.destroy(result);
        const owned_nodes = try cloneNodes(gpa, nodes);
        errdefer deinitNodes(gpa, owned_nodes);
        const owned_spans = try gpa.dupe(Span, spans);
        result.* = .{ .allocator = gpa, .references = .init(1), .nodes = owned_nodes, .spans = owned_spans, .flat_len = flattenedLen(nodes) };
        return result;
    }

    pub fn empty(gpa: Allocator) Error!*RealizedStream {
        return create(gpa, &.{}, &.{});
    }

    pub fn retain(self: *RealizedStream) *RealizedStream {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }

    pub fn release(self: *RealizedStream) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            deinitNodes(self.allocator, self.nodes);
            self.allocator.free(self.spans);
            self.allocator.destroy(self);
        }
    }

    pub fn len(self: *const RealizedStream) usize {
        return self.nodes.len;
    }

    pub fn isEmpty(self: *const RealizedStream) bool {
        return self.nodes.len == 0;
    }

    pub fn flatLen(self: *const RealizedStream) usize {
        return self.flat_len;
    }
};

pub const CloneRecord = struct {
    allocator: Allocator,
    references: std.atomic.Value(usize),
    children: union(enum) {
        values: struct { values: []ChoiceValue, flat_len: usize },
        realized: *RealizedStream,
    },

    pub fn fromValues(gpa: Allocator, values: []ChoiceValue) Error!*CloneRecord {
        const record = try gpa.create(CloneRecord);
        record.* = .{ .allocator = gpa, .references = .init(1), .children = .{ .values = .{ .values = values, .flat_len = flattenedValuesLen(values) } } };
        return record;
    }

    pub fn fromValuesCopy(gpa: Allocator, values: []const ChoiceValue) Error!*CloneRecord {
        const owned = try cloneValues(gpa, values);
        errdefer deinitValues(gpa, owned);
        return fromValues(gpa, owned);
    }

    pub fn fromStream(gpa: Allocator, stream: *RealizedStream) Error!*CloneRecord {
        const record = try gpa.create(CloneRecord);
        record.* = .{ .allocator = gpa, .references = .init(1), .children = .{ .realized = stream.retain() } };
        return record;
    }

    pub fn fromRun(gpa: Allocator, nodes: []const ChoiceNode, spans: []const Span) Error!*CloneRecord {
        const stream = try RealizedStream.create(gpa, nodes, spans);
        defer stream.release();
        return fromStream(gpa, stream);
    }

    pub fn empty(gpa: Allocator) Error!*CloneRecord {
        return fromRun(gpa, &.{}, &.{});
    }

    pub fn retain(self: *const CloneRecord) *CloneRecord {
        const mutable = @constCast(self);
        _ = mutable.references.fetchAdd(1, .monotonic);
        return mutable;
    }

    pub fn release(self: *CloneRecord) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            switch (self.children) {
                .values => |v| deinitValues(self.allocator, v.values),
                .realized => |stream| stream.release(),
            }
            self.allocator.destroy(self);
        }
    }

    pub fn len(self: *const CloneRecord) usize {
        return switch (self.children) {
            .values => |v| v.values.len,
            .realized => |s| s.len(),
        };
    }

    pub fn isEmpty(self: *const CloneRecord) bool {
        return self.len() == 0;
    }

    pub fn flatLen(self: *const CloneRecord) usize {
        return switch (self.children) {
            .values => |v| v.flat_len,
            .realized => |s| s.flat_len,
        };
    }

    pub fn valueAt(self: *const CloneRecord, index: usize) ChoiceValueRef {
        return switch (self.children) {
            .values => |v| v.values[index].valueRef(),
            .realized => |s| s.nodes[index].data.valueRef(),
        };
    }

    pub fn valueRefAt(self: *const CloneRecord, index: usize) ChoiceValueRef {
        return self.valueAt(index);
    }

    pub fn ownedValueAt(self: *const CloneRecord, gpa: Allocator, index: usize) Error!ChoiceValue {
        return self.valueAt(index).toOwned(gpa);
    }

    pub fn ownedValues(self: *const CloneRecord, gpa: Allocator) Error![]ChoiceValue {
        const values = try gpa.alloc(ChoiceValue, self.len());
        var filled: usize = 0;
        errdefer {
            for (values[0..filled]) |*value| value.deinit(gpa);
            gpa.free(values);
        }
        for (values, 0..) |*value, i| {
            value.* = try self.valueAt(i).toOwned(gpa);
            filled += 1;
        }
        return values;
    }

    pub fn realized(self: *const CloneRecord) ?*RealizedStream {
        return switch (self.children) {
            .values => null,
            .realized => |s| s,
        };
    }

    pub fn realizedNodes(self: *const CloneRecord) ?[]const ChoiceNode {
        return if (self.realized()) |s| s.nodes else null;
    }

    pub fn eql(self: *const CloneRecord, other: *const CloneRecord) bool {
        return (CloneValues{ .record = self }).eql(.{ .record = other });
    }
};

pub const CloneValues = union(enum) {
    record: *const CloneRecord,
    stream: *RealizedStream,

    pub fn len(self: CloneValues) usize {
        return switch (self) {
            .record => |r| r.len(),
            .stream => |s| s.len(),
        };
    }

    pub fn isEmpty(self: CloneValues) bool {
        return self.len() == 0;
    }

    pub fn flatLen(self: CloneValues) usize {
        return switch (self) {
            .record => |r| r.flatLen(),
            .stream => |s| s.flat_len,
        };
    }

    pub fn valueAt(self: CloneValues, index: usize) ChoiceValueRef {
        return switch (self) {
            .record => |r| r.valueAt(index),
            .stream => |s| s.nodes[index].data.valueRef(),
        };
    }

    pub fn eql(self: CloneValues, other: CloneValues) bool {
        if (self.flatLen() != other.flatLen() or self.len() != other.len()) return false;
        for (0..self.len()) |i| if (!self.valueAt(i).eql(other.valueAt(i))) return false;
        return true;
    }
};

pub fn flattenedLen(nodes: []const ChoiceNode) usize {
    var total: usize = 0;
    for (nodes) |node| total += if (node.data == .clone) 1 + node.data.clone.flat_len else 1;
    return total;
}

pub fn flattenedValuesLen(values: []const ChoiceValue) usize {
    var total: usize = 0;
    for (values) |value| total += if (value == .clone) 1 + value.clone.flatLen() else 1;
    return total;
}

pub fn cloneValues(gpa: Allocator, values: []const ChoiceValue) Error![]ChoiceValue {
    const result = try gpa.alloc(ChoiceValue, values.len);
    var filled: usize = 0;
    errdefer {
        for (result[0..filled]) |*value| value.deinit(gpa);
        gpa.free(result);
    }
    for (values, result) |*value, *out| {
        out.* = try value.deepClone(gpa);
        filled += 1;
    }
    return result;
}

pub fn deinitValues(gpa: Allocator, values: []ChoiceValue) void {
    for (values) |*value| value.deinit(gpa);
    gpa.free(values);
}

pub fn cloneNodes(gpa: Allocator, nodes: []const ChoiceNode) Error![]ChoiceNode {
    const result = try gpa.alloc(ChoiceNode, nodes.len);
    var filled: usize = 0;
    errdefer {
        for (result[0..filled]) |*node| node.deinit(gpa);
        gpa.free(result);
    }
    for (nodes, result) |node, *out| {
        out.* = try node.deepClone(gpa);
        filled += 1;
    }
    return result;
}

pub fn deinitNodes(gpa: Allocator, nodes: []ChoiceNode) void {
    for (nodes) |*node| node.deinit(gpa);
    gpa.free(nodes);
}

pub const ChoiceKind = union(enum) {
    integer: *const IntegerChoice,
    boolean: BooleanChoice,
    float: FloatChoice,
    bytes: BytesChoice,
    string: StringChoice,
    clone,

    pub fn deepClone(self: ChoiceKind, gpa: Allocator) Error!ChoiceKind {
        return switch (self) {
            .integer => |constraint| blk: {
                const result = try gpa.create(IntegerChoice);
                errdefer gpa.destroy(result);
                result.* = try constraint.deepClone(gpa);
                break :blk .{ .integer = result };
            },
            .string => |constraint| blk: {
                const intervals = try gpa.create(IntervalSet);
                errdefer gpa.destroy(intervals);
                intervals.* = try IntervalSet.init(gpa, constraint.intervals.intervals);
                break :blk .{ .string = .{ .intervals = intervals, .min_size = constraint.min_size, .max_size = constraint.max_size } };
            },
            else => self,
        };
    }

    pub fn deinit(self: *ChoiceKind, gpa: Allocator) void {
        switch (self.*) {
            .integer => |constraint| {
                const mutable = @constCast(constraint);
                mutable.deinit();
                gpa.destroy(mutable);
            },
            .string => |constraint| {
                const intervals = @constCast(constraint.intervals);
                intervals.deinit();
                gpa.destroy(intervals);
            },
            else => {},
        }
        self.* = undefined;
    }

    pub fn eql(self: ChoiceKind, other: ChoiceKind) bool {
        if (std.meta.activeTag(self) != std.meta.activeTag(other)) return false;
        return switch (self) {
            .integer => |v| v.eql(other.integer.*),
            .boolean => |v| v.eql(other.boolean),
            .float => |v| v.eql(other.float),
            .bytes => |v| v.eql(other.bytes),
            .string => |v| v.eql(other.string),
            .clone => true,
        };
    }

    pub fn simplest(self: ChoiceKind, gpa: Allocator) Error!ChoiceValue {
        return switch (self) {
            .integer => |v| .{ .integer = try v.simplest(gpa) },
            .boolean => |v| .{ .boolean = v.simplest() },
            .float => |v| .{ .float = try v.simplest() },
            .bytes => |v| .{ .bytes = try v.simplest(gpa) },
            .string => |v| .{ .string = try v.simplest(gpa) },
            .clone => .{ .clone = try CloneRecord.empty(gpa) },
        };
    }

    pub fn unit(self: ChoiceKind, gpa: Allocator) Error!ChoiceValue {
        return switch (self) {
            .integer => |v| .{ .integer = try v.unit(gpa) },
            .boolean => |v| .{ .boolean = v.unit() },
            .float => |v| .{ .float = try v.unit() },
            .bytes => |v| .{ .bytes = try v.unit(gpa) },
            .string => |v| .{ .string = try v.unit(gpa) },
            .clone => .{ .clone = try CloneRecord.empty(gpa) },
        };
    }

    pub fn maxIndex(self: ChoiceKind, gpa: Allocator) Error!?BigUint {
        return switch (self) {
            .integer => |v| try v.maxIndex(gpa),
            .boolean => |v| try v.maxIndex(gpa),
            .float => |v| try v.maxIndex(gpa),
            .bytes => |v| try v.maxIndex(gpa),
            .string => |v| try v.maxIndex(gpa),
            .clone => null,
        };
    }

    pub fn fromIndex(self: ChoiceKind, gpa: Allocator, index: BigUint) Error!?ChoiceValue {
        return switch (self) {
            .integer => |v| if (try v.fromIndex(gpa, index)) |value| .{ .integer = value } else null,
            .boolean => |v| if (v.fromIndex(index)) |value| .{ .boolean = value } else null,
            .float => |v| if (try v.fromIndex(index)) |value| .{ .float = value } else null,
            .bytes => |v| if (try v.fromIndex(gpa, index)) |value| .{ .bytes = value } else null,
            .string => |v| if (try v.fromIndex(gpa, index)) |value| .{ .string = value } else null,
            .clone => null,
        };
    }

    pub fn resolve(self: ChoiceKind, gpa: Allocator, value: *const ChoiceValue) Error!?ChoiceData {
        return self.resolveRef(gpa, value.valueRef());
    }

    pub fn resolveRef(self: ChoiceKind, gpa: Allocator, value: ChoiceValueRef) Error!?ChoiceData {
        return switch (self) {
            .integer => |constraint| if (value == .integer and constraint.validate(value.integer.*)) .{ .integer = .{ .constraint = constraint, .value = try value.integer.clone(gpa) } } else null,
            .boolean => |constraint| if (value == .boolean) .{ .boolean = .{ .constraint = constraint, .value = value.boolean } } else null,
            .float => |constraint| if (value == .float and constraint.validate(value.float)) .{ .float = .{ .constraint = constraint, .value = value.float } } else null,
            .bytes => |constraint| if (value == .bytes and constraint.validate(value.bytes)) .{ .bytes = .{ .constraint = constraint, .value = try gpa.dupe(u8, value.bytes) } } else null,
            .string => |constraint| if (value == .string and constraint.validate(value.string)) .{ .string = .{ .constraint = constraint, .value = try gpa.dupe(u32, value.string) } } else null,
            .clone => null,
        };
    }
};

pub const ChoiceData = union(enum) {
    integer: struct { constraint: *const IntegerChoice, value: BigInt, owns_constraint: bool = false },
    boolean: struct { constraint: BooleanChoice, value: bool },
    float: struct { constraint: FloatChoice, value: f64 },
    bytes: struct { constraint: BytesChoice, value: []u8 },
    string: struct { constraint: StringChoice, value: []u32, owns_intervals: bool = false },
    clone: *RealizedStream,

    pub fn kind(self: *const ChoiceData) ChoiceKind {
        return switch (self.*) {
            .integer => |v| .{ .integer = v.constraint },
            .boolean => |v| .{ .boolean = v.constraint },
            .float => |v| .{ .float = v.constraint },
            .bytes => |v| .{ .bytes = v.constraint },
            .string => |v| .{ .string = v.constraint },
            .clone => .clone,
        };
    }

    pub fn valueRef(self: *const ChoiceData) ChoiceValueRef {
        return switch (self.*) {
            .integer => |*v| .{ .integer = &v.value },
            .boolean => |v| .{ .boolean = v.value },
            .float => |v| .{ .float = v.value },
            .bytes => |v| .{ .bytes = v.value },
            .string => |v| .{ .string = v.value },
            .clone => |v| .{ .clone = .{ .stream = v } },
        };
    }

    pub fn value(self: *const ChoiceData, gpa: Allocator) Error!ChoiceValue {
        return self.valueRef().toOwned(gpa);
    }

    pub fn deepClone(self: *const ChoiceData, gpa: Allocator) Error!ChoiceData {
        var result: ChoiceData = switch (self.*) {
            .integer => |v| .{ .integer = .{ .constraint = v.constraint, .value = try v.value.clone(gpa) } },
            .boolean => |v| .{ .boolean = v },
            .float => |v| .{ .float = v },
            .bytes => |v| .{ .bytes = .{ .constraint = v.constraint, .value = try gpa.dupe(u8, v.value) } },
            .string => |v| .{ .string = .{ .constraint = v.constraint, .value = try gpa.dupe(u32, v.value) } },
            .clone => |v| .{ .clone = v.retain() },
        };
        errdefer result.deinit(gpa);
        try result.ownMetadata(gpa);
        return result;
    }

    fn ownMetadata(self: *ChoiceData, gpa: Allocator) Error!void {
        switch (self.*) {
            .integer => |*v| {
                if (v.owns_constraint) return;
                const constraint = try gpa.create(IntegerChoice);
                errdefer gpa.destroy(constraint);
                constraint.* = try v.constraint.deepClone(gpa);
                v.constraint = constraint;
                v.owns_constraint = true;
            },
            .string => |*v| {
                if (v.owns_intervals) return;
                const intervals = try gpa.create(IntervalSet);
                errdefer gpa.destroy(intervals);
                intervals.* = try IntervalSet.init(gpa, v.constraint.intervals.intervals);
                v.constraint.intervals = intervals;
                v.owns_intervals = true;
            },
            else => {},
        }
    }

    pub fn deinit(self: *ChoiceData, gpa: Allocator) void {
        switch (self.*) {
            .integer => |*v| {
                v.value.deinit();
                if (v.owns_constraint) {
                    const constraint = @constCast(v.constraint);
                    constraint.deinit();
                    gpa.destroy(constraint);
                }
            },
            .bytes => |v| gpa.free(v.value),
            .string => |v| {
                gpa.free(v.value);
                if (v.owns_intervals) {
                    const intervals = @constCast(v.constraint.intervals);
                    intervals.deinit();
                    gpa.destroy(intervals);
                }
            },
            .clone => |v| v.release(),
            .boolean, .float => {},
        }
        self.* = undefined;
    }

    pub fn eql(self: *const ChoiceData, other: *const ChoiceData) bool {
        return self.kind().eql(other.kind()) and self.valueRef().eql(other.valueRef());
    }

    pub fn simplestValue(self: *const ChoiceData, gpa: Allocator) Error!ChoiceValue {
        return self.kind().simplest(gpa);
    }

    pub fn isSimplest(self: *const ChoiceData, gpa: Allocator) Error!bool {
        if (self.* == .clone) return self.clone.isEmpty();
        var simplest_value = try self.simplestValue(gpa);
        defer simplest_value.deinit(gpa);
        return self.valueRef().eql(simplest_value.valueRef());
    }

    pub fn withSimplest(self: *const ChoiceData, gpa: Allocator) Error!ChoiceData {
        if (self.* == .clone) return .{ .clone = try RealizedStream.empty(gpa) };
        var simplest_value = try self.simplestValue(gpa);
        defer simplest_value.deinit(gpa);
        return (try self.withValue(gpa, &simplest_value)) orelse error.InternalError;
    }

    pub fn withValue(self: *const ChoiceData, gpa: Allocator, value_to_use: *const ChoiceValue) Error!?ChoiceData {
        if (self.* == .clone and value_to_use.* == .clone) {
            return if (value_to_use.clone.realized()) |stream| .{ .clone = stream.retain() } else null;
        }
        var result = (try self.kind().resolve(gpa, value_to_use)) orelse return null;
        errdefer result.deinit(gpa);
        try result.ownMetadata(gpa);
        return result;
    }

    pub fn toIndex(self: *const ChoiceData, gpa: Allocator) Error!?BigUint {
        return switch (self.*) {
            .integer => |v| try v.constraint.toIndex(gpa, v.value),
            .boolean => |v| try v.constraint.toIndex(gpa, v.value),
            .float => |v| try v.constraint.toIndex(gpa, v.value),
            .bytes => |v| try v.constraint.toIndex(gpa, v.value),
            .string => |v| try v.constraint.toIndex(gpa, v.value),
            .clone => null,
        };
    }

    pub fn fromIndex(self: *const ChoiceData, gpa: Allocator, index: BigUint) Error!?ChoiceValue {
        return self.kind().fromIndex(gpa, index);
    }

    pub fn maxIndex(self: *const ChoiceData, gpa: Allocator) Error!?BigUint {
        return self.kind().maxIndex(gpa);
    }

    pub fn asInteger(self: *const ChoiceData) ?struct { *const IntegerChoice, *const BigInt } {
        return switch (self.*) {
            .integer => |*v| .{ v.constraint, &v.value },
            else => null,
        };
    }

    pub fn asFloat(self: *const ChoiceData) ?struct { *const FloatChoice, f64 } {
        return switch (self.*) {
            .float => |*v| .{ &v.constraint, v.value },
            else => null,
        };
    }

    pub fn asBytes(self: *const ChoiceData) ?struct { *const BytesChoice, []const u8 } {
        return switch (self.*) {
            .bytes => |*v| .{ &v.constraint, v.value },
            else => null,
        };
    }

    pub fn asString(self: *const ChoiceData) ?struct { *const StringChoice, []const u32 } {
        return switch (self.*) {
            .string => |*v| .{ &v.constraint, v.value },
            else => null,
        };
    }

    pub fn asClone(self: *const ChoiceData) ?*RealizedStream {
        return switch (self.*) {
            .clone => |v| v,
            else => null,
        };
    }
};

pub const ChoiceNode = struct {
    data: ChoiceData,
    was_forced: bool,

    pub fn init(data: ChoiceData, was_forced: bool) ChoiceNode {
        return .{ .data = data, .was_forced = was_forced };
    }

    pub fn integer(constraint: *const IntegerChoice, value_to_use: BigInt, was_forced: bool) ChoiceNode {
        return init(.{ .integer = .{ .constraint = constraint, .value = value_to_use } }, was_forced);
    }

    pub fn boolean(constraint: BooleanChoice, value_to_use: bool, was_forced: bool) ChoiceNode {
        return init(.{ .boolean = .{ .constraint = constraint, .value = value_to_use } }, was_forced);
    }

    pub fn float(constraint: FloatChoice, value_to_use: f64, was_forced: bool) ChoiceNode {
        return init(.{ .float = .{ .constraint = constraint, .value = value_to_use } }, was_forced);
    }

    pub fn bytes(constraint: BytesChoice, value_to_use: []u8, was_forced: bool) ChoiceNode {
        return init(.{ .bytes = .{ .constraint = constraint, .value = value_to_use } }, was_forced);
    }

    pub fn string(constraint: StringChoice, value_to_use: []u32, was_forced: bool) ChoiceNode {
        return init(.{ .string = .{ .constraint = constraint, .value = value_to_use } }, was_forced);
    }

    pub fn cloneStream(stream: *RealizedStream, was_forced: bool) ChoiceNode {
        return init(.{ .clone = stream.retain() }, was_forced);
    }

    pub fn deepClone(self: ChoiceNode, gpa: Allocator) Error!ChoiceNode {
        return init(try self.data.deepClone(gpa), self.was_forced);
    }

    pub fn deinit(self: *ChoiceNode, gpa: Allocator) void {
        self.data.deinit(gpa);
        self.* = undefined;
    }

    pub fn kind(self: *const ChoiceNode) ChoiceKind {
        return self.data.kind();
    }

    pub fn value(self: *const ChoiceNode, gpa: Allocator) Error!ChoiceValue {
        return self.data.value(gpa);
    }

    pub fn eql(self: *const ChoiceNode, other: *const ChoiceNode) bool {
        return self.was_forced == other.was_forced and self.data.eql(&other.data);
    }

    pub fn withValue(self: *const ChoiceNode, gpa: Allocator, value_to_use: *const ChoiceValue) Error!?ChoiceNode {
        return if (try self.data.withValue(gpa, value_to_use)) |data| init(data, self.was_forced) else null;
    }

    pub fn withSimplest(self: *const ChoiceNode, gpa: Allocator) Error!ChoiceNode {
        return init(try self.data.withSimplest(gpa), self.was_forced);
    }

    pub fn sortKeyRef(self: *const ChoiceNode, gpa: Allocator) Error!NodeSortKeyRef {
        return switch (self.data) {
            .integer => |v| blk: {
                const key = try v.constraint.sortKey(gpa, v.value);
                break :blk .{ .scalar = .{ .magnitude = key[0], .negative = key[1] } };
            },
            .boolean => |v| .{ .scalar = .{ .magnitude = try BigUint.fromInt(gpa, @as(u8, @intFromBool(v.value))), .negative = false } },
            .float => |v| blk: {
                const key = v.constraint.sortKey(v.value);
                break :blk .{ .scalar = .{ .magnitude = try BigUint.fromInt(gpa, key[0]), .negative = key[1] } };
            },
            .bytes => |v| .{ .seq = .{ .bytes = v.value } },
            .string => |v| .{ .seq = .{ .string = .{ .constraint = v.constraint, .value = v.value } } },
            .clone => |v| .{ .clone = v },
        };
    }
};

pub const SeqKeys = union(enum) {
    bytes: []const u8,
    string: struct { constraint: StringChoice, value: []const u32 },

    pub fn len(self: SeqKeys) usize {
        return switch (self) {
            .bytes => |v| v.len,
            .string => |v| v.value.len,
        };
    }

    pub fn keyAt(self: SeqKeys, index: usize) u32 {
        return switch (self) {
            .bytes => |v| v[index],
            .string => |v| v.constraint.codepointKey(v.value[index]),
        };
    }
};

pub const NodeSortKeyRef = union(enum) {
    scalar: struct { magnitude: BigUint, negative: bool },
    seq: SeqKeys,
    clone: *const RealizedStream,

    pub fn deinit(self: *NodeSortKeyRef) void {
        if (self.* == .scalar) self.scalar.magnitude.deinit();
        self.* = undefined;
    }

    pub fn order(self: NodeSortKeyRef, gpa: Allocator, other: NodeSortKeyRef) Error!std.math.Order {
        const category_order = std.math.order(@backingInt(std.meta.activeTag(self)), @backingInt(std.meta.activeTag(other)));
        if (category_order != .eq) return category_order;
        return switch (self) {
            .scalar => |a| blk: {
                const magnitude_order = a.magnitude.order(other.scalar.magnitude);
                break :blk if (magnitude_order == .eq) std.math.order(@intFromBool(a.negative), @intFromBool(other.scalar.negative)) else magnitude_order;
            },
            .seq => |a| blk: {
                const b = other.seq;
                const length_order = std.math.order(a.len(), b.len());
                if (length_order != .eq) break :blk length_order;
                for (0..a.len()) |i| {
                    const element_order = std.math.order(a.keyAt(i), b.keyAt(i));
                    if (element_order != .eq) break :blk element_order;
                }
                break :blk .eq;
            },
            .clone => |a| blk: {
                const b = other.clone;
                const flat_order = std.math.order(a.flat_len, b.flat_len);
                if (flat_order != .eq) break :blk flat_order;
                const length_order = std.math.order(a.len(), b.len());
                if (length_order != .eq) break :blk length_order;
                break :blk try elementwiseNodesOrder(gpa, a.nodes, b.nodes);
            },
        };
    }
};

pub const NodesSortKey = struct {
    nodes: []const ChoiceNode,

    pub fn order(self: NodesSortKey, gpa: Allocator, other: NodesSortKey) Error!std.math.Order {
        return nodesOrder(gpa, self.nodes, other.nodes);
    }
};

pub fn sortKey(nodes: []const ChoiceNode) NodesSortKey {
    return .{ .nodes = nodes };
}

pub fn nodesOrder(gpa: Allocator, a: []const ChoiceNode, b: []const ChoiceNode) Error!std.math.Order {
    const flat_order = std.math.order(flattenedLen(a), flattenedLen(b));
    if (flat_order != .eq) return flat_order;
    const length_order = std.math.order(a.len, b.len);
    if (length_order != .eq) return length_order;
    return elementwiseNodesOrder(gpa, a, b);
}

fn elementwiseNodesOrder(gpa: Allocator, a: []const ChoiceNode, b: []const ChoiceNode) Error!std.math.Order {
    for (a, b) |left, right| {
        var left_key = try left.sortKeyRef(gpa);
        defer left_key.deinit();
        var right_key = try right.sortKeyRef(gpa);
        defer right_key.deinit();
        const result = try left_key.order(gpa, right_key);
        if (result != .eq) return result;
    }
    return .eq;
}

pub const ChoiceTemplateKind = enum { simplest };
pub const ChoiceTemplate = struct {
    kind: ChoiceTemplateKind,
    count: ?usize,

    pub fn simplest(count: ?usize) Error!ChoiceTemplate {
        if (count == 0) return error.InternalError;
        return .{ .kind = .simplest, .count = count };
    }
};

pub const Status = enum(u8) { early_stop = 0, invalid = 1, valid = 2, interesting = 3 };
pub const EngineError = error{ Overrun, InvalidTestCase, AssumeViolation, InvalidArgument, InternalError };
pub const InterestingOrigin = []const u8;

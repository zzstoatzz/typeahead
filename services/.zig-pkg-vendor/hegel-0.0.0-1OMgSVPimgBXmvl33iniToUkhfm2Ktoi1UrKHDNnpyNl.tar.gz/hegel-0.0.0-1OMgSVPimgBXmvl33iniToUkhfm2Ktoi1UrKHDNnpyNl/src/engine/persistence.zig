// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs: Persister and reconciliation.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const db = @import("database.zig");
const blob = @import("blob.zig");
const cache = @import("exec_cache.zig");
const policy = @import("runner_policy.zig");
const Allocator = std.mem.Allocator;
const Saved = struct { origin: []u8, nodes: []c.ChoiceNode, bytes: []u8 };
pub const Persister = struct {
    allocator: Allocator,
    database: ?*const db.DirectoryDatabase,
    database_key: ?[]const u8,
    last_saved: std.ArrayList(Saved) = .empty,
    saved_this_run: std.ArrayList([]u8) = .empty,
    preexisting: [][]u8,
    pub fn init(gpa: Allocator, database: ?*const db.DirectoryDatabase, key: ?[]const u8) !Persister {
        return .{ .allocator = gpa, .database = database, .database_key = key, .preexisting = if (database != null and key != null) try database.?.fetch(gpa, key.?) else try gpa.alloc([]u8, 0) };
    }
    pub fn deinit(self: *Persister) void {
        const gpa = self.allocator;
        for (self.last_saved.items) |saved| {
            gpa.free(saved.origin);
            c.deinitNodes(gpa, saved.nodes);
            gpa.free(saved.bytes);
        }
        self.last_saved.deinit(gpa);
        for (self.saved_this_run.items) |bytes| gpa.free(bytes);
        self.saved_this_run.deinit(gpa);
        for (self.preexisting) |bytes| gpa.free(bytes);
        gpa.free(self.preexisting);
        self.* = undefined;
    }
    pub fn record(self: *Persister, origin: []const u8, nodes: []const c.ChoiceNode) !void {
        const bytes = (try db.serializeNodes(self.allocator, nodes)) orelse return error.InternalError;
        defer self.allocator.free(bytes);
        try self.recordBytes(origin, nodes, bytes, false);
    }
    pub fn recordNd(self: *Persister, origin: []const u8, nodes: []const c.ChoiceNode, state: *const blob.NdReproState, force: bool) !void {
        const bytes = (try blob.encodeNdState(self.allocator, state)) orelse return error.InternalError;
        defer self.allocator.free(bytes);
        try self.recordBytes(origin, nodes, bytes, force);
    }
    pub fn recordBytes(self: *Persister, origin: []const u8, nodes: []const c.ChoiceNode, bytes: []const u8, force: bool) !void {
        const database = self.database orelse return;
        const key = self.database_key orelse return;
        const gpa = self.allocator;
        var previous: ?usize = null;
        for (self.last_saved.items, 0..) |saved, index| if (std.mem.eql(u8, saved.origin, origin)) {
            previous = index;
            break;
        };
        if (!force and previous != null) {
            const saved = self.last_saved.items[previous.?];
            const order = try c.nodesOrder(gpa, nodes, saved.nodes);
            if (order == .gt or (order == .eq and std.mem.eql(u8, saved.bytes, bytes))) return;
        }
        var snapshot = try cache.CachedRun.init(gpa, .interesting, origin, nodes, &.{});
        errdefer snapshot.deinit(gpa);
        const owned_bytes = try gpa.dupe(u8, bytes);
        errdefer gpa.free(owned_bytes);
        const saved_copy = try gpa.dupe(u8, bytes);
        errdefer gpa.free(saved_copy);
        try self.saved_this_run.ensureUnusedCapacity(gpa, 1);
        if (previous == null) try self.last_saved.ensureUnusedCapacity(gpa, 1);
        const secondary = try db.subKey(gpa, key, "secondary");
        defer gpa.free(secondary);
        database.save(key, bytes);
        if (previous) |index| {
            const old = self.last_saved.items[index];
            if (!std.mem.eql(u8, old.bytes, bytes)) {
                var shared = false;
                for (self.last_saved.items, 0..) |saved, other| if (other != index and std.mem.eql(u8, saved.bytes, old.bytes)) {
                    shared = true;
                    break;
                };
                if (!shared) {
                    if (contains(self.preexisting, old.bytes)) database.moveValue(key, secondary, old.bytes) else database.delete(key, old.bytes);
                }
            }
            gpa.free(old.origin);
            c.deinitNodes(gpa, old.nodes);
            gpa.free(old.bytes);
        }
        gpa.free(snapshot.spans);
        const saved: Saved = .{ .origin = snapshot.origin.?, .nodes = snapshot.nodes, .bytes = owned_bytes };
        if (previous) |index| self.last_saved.items[index] = saved else self.last_saved.appendAssumeCapacity(saved);
        self.saved_this_run.appendAssumeCapacity(saved_copy);
    }
    pub fn reconcile(self: *const Persister, new_entries: []const []const u8) !void {
        const database = self.database orelse return;
        const key = self.database_key orelse return;
        const gpa = self.allocator;
        const secondary = try db.subKey(gpa, key, "secondary");
        defer gpa.free(secondary);
        const primary_now = try database.fetch(gpa, key);
        defer freeEntries(gpa, primary_now);
        for (new_entries) |bytes| database.save(key, bytes);
        for (primary_now) |old| {
            if (contains(new_entries, old)) continue;
            if (contains(self.saved_this_run.items, old) and !contains(self.preexisting, old)) database.delete(key, old) else database.moveValue(key, secondary, old);
        }
        const secondary_now = try database.fetch(gpa, secondary);
        defer freeEntries(gpa, secondary_now);
        if (secondary_now.len > 50) {
            std.mem.sort([]u8, secondary_now, {}, struct {
                fn less(_: void, a: []const u8, b: []const u8) bool {
                    return policy.shortlex(a, b) == .lt;
                }
            }.less);
            for (secondary_now[50..]) |evicted| database.delete(secondary, evicted);
        }
    }
};
fn contains(entries: []const []const u8, bytes: []const u8) bool {
    for (entries) |entry| if (std.mem.eql(u8, entry, bytes)) return true;
    return false;
}
pub fn freeEntries(gpa: Allocator, entries: [][]u8) void {
    for (entries) |entry| gpa.free(entry);
    gpa.free(entries);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from pinned hegel-c/src/lib.rs; see docs/native-provenance/state.json.
const std = @import("std");
pub const blob_mod = @import("blob.zig");
pub const types = @import("c_api/types.zig");
pub const gpa = std.heap.c_allocator;
pub const Mutex = @import("sync.zig").Mutex;
pub const state = @import("state.zig");
pub const data_source = @import("data_source.zig");
pub const settings_mod = @import("settings.zig");
pub const printer = @import("printer.zig");
pub const hegel_result_t = c_int;
pub const HegelContext = struct { last_error: [:0]u8 };
pub const TestLocation = struct {
    file: []u8,
    begin_line: u32,
    class_name: []u8,
    function: []u8,
    pub fn deepClone(self: TestLocation) !TestLocation {
        const file = try gpa.dupe(u8, self.file);
        errdefer gpa.free(file);
        const class = try gpa.dupe(u8, self.class_name);
        errdefer gpa.free(class);
        return .{ .file = file, .begin_line = self.begin_line, .class_name = class, .function = try gpa.dupe(u8, self.function) };
    }
    pub fn view(self: TestLocation) @import("antithesis.zig").TestLocation {
        return .{ .file = self.file, .class = self.class_name, .function = self.function, .begin_line = self.begin_line };
    }
    pub fn deinit(self: *TestLocation) void {
        gpa.free(self.file);
        gpa.free(self.class_name);
        gpa.free(self.function);
    }
};
pub const HegelSettings = struct {
    inner: settings_mod.Settings,
    database_key: ?[]u8 = null,
    database_c: ?[:0]u8 = null,
    test_location: ?TestLocation = null,
    pub fn create(inner: settings_mod.Settings) !*HegelSettings {
        var settings = try inner.deepClone(gpa);
        errdefer settings.deinitOwned(gpa);
        const db: ?[:0]u8 = switch (settings.database) {
            .unset => null,
            .disabled => try gpa.dupeSentinel(u8, "", 0),
            .path => |path| try cstringStripped(path),
        };
        errdefer if (db) |d| gpa.free(d);
        const self = try gpa.create(HegelSettings);
        self.* = .{ .inner = settings, .database_c = db };
        return self;
    }
    pub fn destroy(self: *HegelSettings) void {
        self.inner.deinitOwned(gpa);
        if (self.database_key) |key| gpa.free(key);
        if (self.database_c) |db| gpa.free(db);
        if (self.test_location) |*loc| loc.deinit();
        gpa.destroy(self);
    }
};
pub const SourceShared = struct {
    references: std.atomic.Value(usize) = .init(1),
    value: data_source.NativeDataSource,
    pub fn create(value: data_source.NativeDataSource) !*SourceShared {
        const self = try gpa.create(SourceShared);
        self.* = .{ .value = value };
        return self;
    }
    pub fn retain(self: *SourceShared) *SourceShared {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *SourceShared) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            self.value.deinit();
            gpa.destroy(self);
        }
    }
};
pub const WorkerCell = struct {
    references: std.atomic.Value(usize) = .init(1),
    value: std.atomic.Value(i64),
    pub fn create(value: i64) !*WorkerCell {
        const self = try gpa.create(WorkerCell);
        self.* = .{ .value = .init(value) };
        return self;
    }
    pub fn retain(self: *WorkerCell) *WorkerCell {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *WorkerCell) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) gpa.destroy(self);
    }
};
pub const Reporter = struct {
    location: TestLocation,
    callback: types.hegel_output_callback_t,
    user_data: ?*anyopaque,
    fn emit(ctx: ?*anyopaque, line: []const u8) void {
        const self: *Reporter = @ptrCast(@alignCast(ctx.?));
        if (self.callback) |callback| {
            const text = cstringLossy(line) catch return;
            defer gpa.free(text);
            callback(self.user_data, text.ptr, text.len);
        } else (settings_mod.Output{}).line(io(), line);
    }
};
pub const FamilyShared = struct {
    references: std.atomic.Value(usize) = .init(1),
    ds: *SourceShared,
    completed: std.atomic.Value(bool) = .init(false),
    printer: *printer.PrinterShared,
    started: ?i128,
    reporter: ?Reporter = null,
    pub fn create(ds: *SourceShared) !*FamilyShared {
        const document = try printer.PrinterShared.create(gpa, 79);
        errdefer document.release();
        const self = try gpa.create(FamilyShared);
        self.* = .{ .ds = ds.retain(), .printer = document, .started = @intCast(std.Io.Clock.awake.now(io()).nanoseconds) };
        return self;
    }
    pub fn retain(self: *FamilyShared) *FamilyShared {
        _ = self.references.fetchAdd(1, .monotonic);
        return self;
    }
    pub fn release(self: *FamilyShared) void {
        if (self.references.fetchSub(1, .acq_rel) == 1) {
            self.ds.release();
            self.printer.release();
            if (self.reporter) |*reporter| reporter.location.deinit();
            gpa.destroy(self);
        }
    }
    pub fn complete(self: *FamilyShared, status: state.Status, origin: ?[]const u8) !void {
        if (self.completed.cmpxchgStrong(false, true, .acq_rel, .acquire) == null) {
            try self.ds.value.markComplete(status, origin);
            if (self.reporter) |*reporter| @import("antithesis.zig").report(gpa, io(), settings_api.environment, reporter.location.view(), status != .interesting, .{ .context = reporter, .callback = Reporter.emit }) catch {};
        }
    }
};
pub const HegelTestCase = struct {
    family: *FamilyShared,
    stream: *SourceShared,
    print_target: printer.Target,
    worker: *WorkerCell,
    local: Mutex = .{},
    completed: bool = false,
    pub fn create(family: *FamilyShared, stream: *SourceShared, target: printer.Target, worker: i64) !*HegelTestCase {
        const attribution = try WorkerCell.create(worker);
        errdefer attribution.release();
        const self = try gpa.create(HegelTestCase);
        self.* = .{ .family = family.retain(), .stream = stream.retain(), .print_target = target, .worker = attribution };
        return self;
    }
    pub fn destroy(self: *HegelTestCase) void {
        self.family.release();
        self.stream.release();
        self.worker.release();
        gpa.destroy(self);
    }
};
var io_mutex: Mutex = .{};
var io_initialized: bool = false;
var threaded_io: std.Io.Threaded = undefined;
pub fn io() std.Io {
    io_mutex.lock();
    defer io_mutex.unlock();
    if (!io_initialized) {
        threaded_io = .init(gpa, .{});
        io_initialized = true;
    }
    return threaded_io.io();
}
fn cstringStripped(text: []const u8) ![:0]u8 {
    var bytes: std.ArrayList(u8) = .empty;
    defer bytes.deinit(gpa);
    for (text) |byte| if (byte != 0) try bytes.append(gpa, byte);
    return gpa.dupeSentinel(u8, bytes.items, 0);
}
pub fn cstringLossy(text: []const u8) ![:0]u8 {
    var bytes: std.ArrayList(u8) = .empty;
    defer bytes.deinit(gpa);
    for (text) |byte| if (byte == 0) {
        try bytes.appendSlice(gpa, "\xef\xbf\xbd");
    } else try bytes.append(gpa, byte);
    return gpa.dupeSentinel(u8, bytes.items, 0);
}
pub fn setLastError(ctx: ?*HegelContext, message: []const u8) void {
    const self = ctx orelse return;
    const text = if (std.mem.indexOfScalar(u8, message, 0) != null) "error message contained NUL" else message;
    const owned = gpa.dupeSentinel(u8, text, 0) catch return;
    gpa.free(self.last_error);
    self.last_error = owned;
}
pub fn clearLastError(ctx: ?*HegelContext) void {
    const self = ctx orelse return;
    if (self.last_error.len == 0) return;
    const empty = gpa.dupeSentinel(u8, "", 0) catch return;
    gpa.free(self.last_error);
    self.last_error = empty;
}
pub fn fail(ctx: ?*HegelContext, code: c_int, comptime fmt: []const u8, args: anytype) c_int {
    const text = std.fmt.allocPrint(gpa, fmt, args) catch {
        setLastError(ctx, "out of memory");
        return types.HEGEL_E_INTERNAL;
    };
    defer gpa.free(text);
    setLastError(ctx, text);
    return code;
}
pub fn internal(ctx: ?*HegelContext, err: anyerror) c_int {
    return fail(ctx, types.HEGEL_E_INTERNAL, "{s}", .{@errorName(err)});
}
pub fn translateError(ctx: ?*HegelContext, source: ?*data_source.NativeDataSource, err: anyerror) c_int {
    return switch (err) {
        error.StopTest, error.Overrun => types.HEGEL_E_STOP_TEST,
        error.Assume, error.AssumeViolation, error.InvalidTestCase => types.HEGEL_E_ASSUME,
        error.InvalidArgument => blk: {
            if (source) |s| if (s.diagnostic) |d| {
                setLastError(ctx, d);
                break :blk types.HEGEL_E_INVALID_ARG;
            };
            break :blk fail(ctx, types.HEGEL_E_INVALID_ARG, "invalid argument", .{});
        },
        else => internal(ctx, err),
    };
}
threadlocal var last_guard_failure: c_int = types.HEGEL_E_INVALID_HANDLE;
pub fn tcGuard(ctx: ?*HegelContext, comptime name: []const u8, tc: ?*const HegelTestCase) ?*HegelTestCase {
    const self = @constCast(tc orelse {
        last_guard_failure = fail(ctx, types.HEGEL_E_INVALID_HANDLE, name ++ ": test case pointer is null", .{});
        return null;
    });
    if (self.family.completed.load(.acquire)) {
        last_guard_failure = fail(ctx, types.HEGEL_E_ALREADY_COMPLETE, name ++ ": test case is already complete", .{});
        return null;
    }
    if (!self.local.tryLock()) {
        last_guard_failure = fail(ctx, types.HEGEL_E_CONCURRENT_USE, name ++ ": test case handle is in use on another thread", .{});
        return null;
    }
    return self;
}
pub fn guardError(ctx: ?*HegelContext, tc: ?*const HegelTestCase) c_int {
    _ = ctx;
    _ = tc;
    return last_guard_failure;
}
pub fn utf8(ptr: [*c]const u8) ?[]const u8 {
    if (ptr == null) return null;
    const text = std.mem.span(@as([*:0]const u8, @ptrCast(ptr)));
    return if (std.unicode.utf8ValidateSlice(text)) text else null;
}
pub fn optionalUtf8Buffer(ctx: ?*HegelContext, comptime name: []const u8, comptime arg: []const u8, ptr: [*c]const u8, len: usize) ?[]const u8 {
    if (ptr == null) {
        if (len == 0) return "";
        _ = fail(ctx, types.HEGEL_E_INVALID_ARG, name ++ ": " ++ arg ++ " is null", .{});
        return null;
    }
    const text = ptr[0..len];
    if (!std.unicode.utf8ValidateSlice(text)) {
        _ = fail(ctx, types.HEGEL_E_INVALID_ARG, name ++ ": " ++ arg ++ " is not valid UTF-8", .{});
        return null;
    }
    return text;
}
pub fn sizeArg(n: u64) usize {
    return std.math.cast(usize, n) orelse std.math.maxInt(usize);
}
pub export fn hegel_context_new() ?*HegelContext {
    const self = gpa.create(HegelContext) catch return null;
    self.* = .{ .last_error = gpa.dupeSentinel(u8, "", 0) catch {
        gpa.destroy(self);
        return null;
    } };
    return self;
}
pub export fn hegel_context_free(ctx: ?*HegelContext) c_int {
    if (ctx) |self| {
        gpa.free(self.last_error);
        gpa.destroy(self);
    }
    return types.HEGEL_OK;
}
pub export fn hegel_context_last_error(ctx: ?*const HegelContext) [*c]const u8 {
    return if (ctx) |self| self.last_error.ptr else null;
}
pub export fn hegel_version(ctx: ?*HegelContext, out_version: [*c][*c]const u8) c_int {
    clearLastError(ctx);
    if (out_version == null) return fail(ctx, types.HEGEL_E_INVALID_ARG, "hegel_version: out parameter is null", .{});
    out_version.* = "0.45.1";
    return types.HEGEL_OK;
}

pub const printer_api = @import("printer_c_api.zig");
pub const settings_api = @import("c_api/settings.zig");
pub const runs = @import("c_api/run.zig");
pub const test_cases = @import("c_api/test_case.zig");
pub const draw_api = @import("c_api/draws.zig");
pub const stateful = @import("c_api/stateful.zig");
pub const strings = @import("c_api/strings.zig");
comptime {
    _ = printer_api;
    _ = settings_api;
    _ = runs;
    _ = test_cases;
    _ = draw_api;
    _ = stateful;
    _ = strings;
}

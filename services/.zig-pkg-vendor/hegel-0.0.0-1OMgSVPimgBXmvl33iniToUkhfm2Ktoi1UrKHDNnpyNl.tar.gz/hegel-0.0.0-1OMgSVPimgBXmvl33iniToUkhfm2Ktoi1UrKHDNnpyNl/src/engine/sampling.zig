// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and LICENSES/ for retained upstream notices.

const std = @import("std");
pub const choices = @import("choices.zig");
const statistics = @import("statistics.zig");
const math = @import("math_compat.zig");
const floats = @import("floats.zig");
pub const IntervalSet = @import("intervalsets.zig").IntervalSet;
pub const EngineRng = @import("rng.zig").EngineRng;
const BigInt = choices.BigInt;
const BigUint = choices.BigUint;
const Allocator = std.mem.Allocator;
pub const Error = choices.Error;

pub const ManyState = struct {
    min_size: usize,
    max_size: f64,
    p_continue: f64,
    count: usize = 0,
    rejections: usize = 0,
    force_stop: bool = false,

    pub fn init(min_size: usize, max_size: ?usize) ManyState {
        return .{ .min_size = min_size, .max_size = if (max_size) |n| @floatFromInt(n) else std.math.inf(f64), .p_continue = lengthPContinue(min_size, max_size) };
    }
};

pub const RecursionState = struct {
    allocator: Allocator,
    max_depth: u64,
    max_leaves: u64,
    attempt: u64 = 0,
    leaves: u64 = 0,
    base_span_depth: usize,
    target: u64,
    branch_probability: f64,
    closed_children: u64 = 0,
    closed_branches: u64 = 0,
    open_branches: std.ArrayList(Branch) = .empty,
    reprices: u64 = 0,

    pub const Branch = struct { depth: u64, children: u64 };

    pub fn deinit(self: *RecursionState) void {
        self.open_branches.deinit(self.allocator);
        self.* = undefined;
    }

    pub fn countLeaf(self: *RecursionState) bool {
        if (self.leaves >= self.max_leaves) return false;
        self.leaves += 1;
        return true;
    }

    pub fn observeDecision(self: *RecursionState, depth: u64) void {
        while (self.open_branches.items.len > 0 and self.open_branches.items[self.open_branches.items.len - 1].depth >= depth) {
            const branch = self.open_branches.pop().?;
            self.closed_children += branch.children;
            self.closed_branches += 1;
        }
        if (depth > 0 and self.open_branches.items.len > 0) self.open_branches.items[self.open_branches.items.len - 1].children += 1;
    }

    pub fn observeBranch(self: *RecursionState, depth: u64) Allocator.Error!void {
        try self.open_branches.append(self.allocator, .{ .depth = depth, .children = 0 });
    }

    pub fn closeRemainingBranches(self: *RecursionState) void {
        while (self.open_branches.pop()) |branch| {
            self.closed_children += branch.children;
            self.closed_branches += 1;
        }
    }

    pub fn discardOpenBranches(self: *RecursionState) void {
        self.open_branches.clearRetainingCapacity();
    }
};

pub fn lengthPContinue(min_size: usize, max_size: ?usize) f64 {
    const max_f: f64 = if (max_size) |n| @floatFromInt(n) else std.math.inf(f64);
    const min_f: f64 = @floatFromInt(min_size);
    const average = @min(@max(min_f * 2, min_f + 5), 0.5 * (min_f + max_f));
    const desired_extra = average - min_f;
    const max_extra = max_f - min_f;
    if (desired_extra >= max_extra) return 0.99;
    if (std.math.isInf(max_f)) return 1 - 1 / (1 + desired_extra);
    return 1 - 1 / (2 + desired_extra);
}

pub fn manyDrawLength(random: *EngineRng, min_size: usize, max_size: usize) Error!usize {
    if (min_size == max_size) return min_size;
    const extra = @floor(math.log(random.random(f64)) / math.log(lengthPContinue(min_size, max_size)));
    if (!(extra >= 0)) return error.InternalError;
    return @min(min_size +| floatToIntSaturating(usize, extra), max_size);
}

fn floatToIntSaturating(comptime T: type, value: f64) T {
    if (std.math.isNan(value)) return 0;
    if (value >= @as(f64, @floatFromInt(std.math.maxInt(T)))) return std.math.maxInt(T);
    if (value <= @as(f64, @floatFromInt(std.math.minInt(T)))) return std.math.minInt(T);
    return @intFromFloat(value);
}

pub fn standardNormal(random: *EngineRng) f64 {
    const uniform1 = 1 - random.random(f64);
    const uniform2 = random.random(f64);
    return math.sqrt(-2 * math.log(uniform1)) * math.cos(@as(f64, std.math.tau) * uniform2);
}

pub fn sampleGamma(shape: f64, random: *EngineRng) Error!f64 {
    if (!(shape > 0)) return error.InternalError;
    if (shape < 1) {
        const g = try sampleGamma(shape + 1, random);
        const u = @max(random.random(f64), std.math.floatMin(f64));
        return g * math.pow(u, 1 / shape);
    }
    const d = shape - 1.0 / 3.0;
    const c = 1 / math.sqrt(9 * d);
    while (true) {
        const x = standardNormal(random);
        const t = 1 + c * x;
        const v = t * t * t;
        if (v <= 0) continue;
        const u = random.random(f64);
        const x2 = x * x;
        if (u < 1 - 0.0331 * x2 * x2) return d * v;
        if (math.log(u) < 0.5 * x2 + d * (1 - v + math.log(v))) return d * v;
    }
}

pub fn normalizeToSimplex(comptime N: usize, input: [N]f64) [N]f64 {
    var sum: f64 = 0;
    for (input) |value| sum += value;
    if (sum <= 0) return @splat(1 / @as(f64, @floatFromInt(N)));
    var result = input;
    for (&result) |*value| value.* /= sum;
    return result;
}

pub fn sampleDirichlet(comptime N: usize, alphas: [N]f64, random: *EngineRng) Error![N]f64 {
    var g: [N]f64 = undefined;
    for (&g, alphas) |*value, alpha| value.* = try sampleGamma(alpha, random);
    return normalizeToSimplex(N, g);
}

pub fn dirichletMean(comptime N: usize, alphas: [N]f64) [N]f64 {
    var total: f64 = 0;
    for (alphas) |alpha| total += alpha;
    var result: [N]f64 = undefined;
    for (&result, alphas) |*value, alpha| value.* = alpha / total;
    return result;
}

pub const IntegerGenerationParameters = struct {
    endpoint_probability: f64,
    interesting_probability: f64,
    diffuse_probability: f64,

    pub const alphas = [4]f64{ 0.08, 0.8, 0.12, 2.2 };

    fn fromWeights(weights: [4]f64) IntegerGenerationParameters {
        return .{ .endpoint_probability = weights[0], .interesting_probability = weights[1], .diffuse_probability = weights[2] };
    }

    pub fn draw(random: *EngineRng) Error!IntegerGenerationParameters {
        return fromWeights(try sampleDirichlet(4, alphas, random));
    }

    pub fn defaults() IntegerGenerationParameters {
        return fromWeights(dirichletMean(4, alphas));
    }
};

pub const FloatGenerationParameters = struct {
    endpoint_probability: f64,
    near_zero_probability: f64,
    subnormal_probability: f64,
    near_one_probability: f64,
    integer_probability: f64,
    half_integer_probability: f64,
    near_max_for_add_probability: f64,
    near_max_for_mul_probability: f64,
    near_sqrt_min_positive_probability: f64,
    nan_probability: f64,
    infinity_probability: f64,
    max_magnitude_probability: f64,
    max_exact_integer_probability: f64,
    signed_zero_probability: f64,
    binade_edge_probability: f64,
    non_dyadic_probability: f64,
    default_probability: f64,

    pub const alphas = [17]f64{ 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.25, 0.125, 0.125, 0.125, 0.125, 0.125, 0.25, 0.25, 4 };

    pub fn fromWeights(weights: [17]f64) FloatGenerationParameters {
        var result: FloatGenerationParameters = undefined;
        inline for (@typeInfo(FloatGenerationParameters).@"struct".field_names, 0..) |field, i| @field(result, field) = weights[i];
        return result;
    }

    pub fn draw(random: *EngineRng) Error!FloatGenerationParameters {
        return fromWeights(try sampleDirichlet(17, alphas, random));
    }

    pub fn defaults() FloatGenerationParameters {
        return fromWeights(dirichletMean(17, alphas));
    }
};

pub const GenerationParameters = struct {
    integer: IntegerGenerationParameters = .defaults(),
    float: FloatGenerationParameters = .defaults(),

    pub fn draw(random: *EngineRng) Error!GenerationParameters {
        const integer = try IntegerGenerationParameters.draw(random);
        return .{ .integer = integer, .float = try FloatGenerationParameters.draw(random) };
    }
};

fn integerDistribution() Error!statistics.PiecewiseDistribution(statistics.UniformDistribution, statistics.LogStudentTDistribution) {
    return .init(.init(256), .init(13, 2), 256);
}

pub fn integerSampleFromDistribution(min_value: i128, max_value: i128, random: *EngineRng) Error!i128 {
    const distribution = try integerDistribution();
    const lo = try distribution.cdf(@as(f64, @floatFromInt(min_value)) - 0.5);
    const hi = try distribution.cdf(@as(f64, @floatFromInt(max_value)) + 0.5);
    if (hi - lo < 1e-13) return random.rangeInclusive(i128, min_value, max_value);
    const p = @max(lo + random.random(f64) * (hi - lo), std.math.floatMin(f64));
    return std.math.clamp(floatToIntSaturating(i128, @round(try distribution.inverseCdf(p))), min_value, max_value);
}

fn inRange(pool: []const i128, min_value: i128, max_value: i128) []const i128 {
    var lo: usize = 0;
    while (lo < pool.len and pool[lo] < min_value) : (lo += 1) {}
    var hi = lo;
    while (hi < pool.len and pool[hi] <= max_value) : (hi += 1) {}
    return pool[lo..hi];
}

pub fn narrowNastySample(min_value: i128, max_value: i128, random: *EngineRng) Error!i128 {
    const slice = inRange(&nasty_integers, min_value, max_value);
    const need_min = slice.len == 0 or slice[0] != min_value;
    const need_max = slice.len == 0 or slice[slice.len - 1] != max_value;
    const count = slice.len + @intFromBool(need_min) + @intFromBool(need_max);
    const threshold = @min(@as(f64, @floatFromInt(count)) * 0.01, 0.5);
    if (random.random(f64) < threshold) {
        const index = random.range(usize, 0, count);
        if (need_min and index == 0) return min_value;
        if (need_max and index == count - 1) return max_value;
        return slice[index - @intFromBool(need_min)];
    }
    return integerSampleFromDistribution(min_value, max_value, random);
}

pub fn biasedI128Sample(min_value: i128, max_value: i128, random: *EngineRng, params: IntegerGenerationParameters) Error!i128 {
    if (min_value == max_value) return min_value;
    const width = @subWithOverflow(max_value, min_value);
    if (width[1] == 0 and @as(u128, @intCast(width[0])) < 256) return narrowNastySample(min_value, max_value, random);
    var endpoints: [4]i128 = undefined;
    var n_end: usize = 0;
    for ([_]i128{ min_value, max_value, min_value +| 1, max_value -| 1 }) |value| {
        if (value >= min_value and value <= max_value and std.mem.indexOfScalar(i128, endpoints[0..n_end], value) == null) {
            endpoints[n_end] = value;
            n_end += 1;
        }
    }
    const interesting = inRange(&interesting_integers, min_value, max_value);
    const diffuse = inRange(&global_integers, min_value, max_value);
    const u = random.random(f64);
    var acc = params.endpoint_probability;
    if (u < acc and n_end > 0) return endpoints[random.range(usize, 0, n_end)];
    acc += params.interesting_probability;
    if (u < acc and interesting.len > 0) return interesting[random.range(usize, 0, interesting.len)];
    acc += params.diffuse_probability;
    if (u < acc and diffuse.len > 0) return diffuse[random.range(usize, 0, diffuse.len)];
    return integerSampleFromDistribution(min_value, max_value, random);
}

fn appendClone(allocator: Allocator, list: *std.ArrayList(BigInt), value: BigInt) Error!void {
    var owned = try value.clone(allocator);
    errdefer owned.deinit();
    try list.append(allocator, owned);
}

fn appendInRange(allocator: Allocator, list: *std.ArrayList(BigInt), value: BigInt, min_value: BigInt, max_value: BigInt) Error!void {
    if (value.order(min_value) != .lt and value.order(max_value) != .gt) try appendClone(allocator, list, value);
}

pub fn sampleBiguintAtMost(allocator: Allocator, span: BigUint, random: *EngineRng) Error!BigUint {
    const bits = span.bits();
    if (bits == 0) return error.InternalError;
    const n_bytes = (bits + 7) / 8;
    const top_bits: u3 = @intCast(bits % 8);
    while (true) {
        const bytes = try allocator.alloc(u8, n_bytes);
        defer allocator.free(bytes);
        for (bytes) |*byte| byte.* = random.random(u8);
        if (top_bits != 0) bytes[bytes.len - 1] &= (@as(u8, 1) << top_bits) - 1;
        var candidate = try BigUint.fromBytesLe(allocator, bytes);
        if (candidate.order(span) != .gt) return candidate;
        candidate.deinit();
    }
}

pub fn biguintSampleInRange(allocator: Allocator, min_value: BigInt, max_value: BigInt, random: *EngineRng, params: IntegerGenerationParameters) Error!BigInt {
    if (min_value.eql(max_value)) return min_value.clone(allocator);
    var difference = try max_value.sub(allocator, min_value);
    defer difference.deinit();
    var span = try difference.magnitude(allocator);
    defer span.deinit();
    var endpoints: std.ArrayList(BigInt) = .empty;
    defer {
        for (endpoints.items) |*value| value.deinit();
        endpoints.deinit(allocator);
    }
    for (0..4) |i| {
        var value = switch (i) {
            0 => try min_value.clone(allocator),
            1 => try max_value.clone(allocator),
            2 => try min_value.addInt(allocator, @as(u8, 1)),
            else => try max_value.subInt(allocator, @as(u8, 1)),
        };
        defer value.deinit();
        if (value.order(min_value) == .lt or value.order(max_value) == .gt) continue;
        const found = for (endpoints.items) |existing| {
            if (existing.eql(value)) break true;
        } else false;
        if (!found) try appendClone(allocator, &endpoints, value);
    }
    var diffuse: std.ArrayList(BigInt) = .empty;
    defer {
        for (diffuse.items) |*value| value.deinit();
        diffuse.deinit(allocator);
    }
    var one = try BigUint.fromInt(allocator, @as(u8, 1));
    defer one.deinit();
    for (1..@min(span.bits(), 128) + 1) |k| {
        var magnitude = try one.shl(allocator, k);
        defer magnitude.deinit();
        var value = try magnitude.asSigned(allocator);
        defer value.deinit();
        var negative = try value.negate(allocator);
        defer negative.deinit();
        try appendInRange(allocator, &diffuse, negative, min_value, max_value);
        try appendInRange(allocator, &diffuse, value, min_value, max_value);
    }
    std.mem.sort(BigInt, diffuse.items, {}, struct {
        fn less(_: void, a: BigInt, b: BigInt) bool {
            return a.order(b) == .lt;
        }
    }.less);
    const u = random.random(f64);
    var acc = params.endpoint_probability;
    if (u < acc and endpoints.items.len > 0) return endpoints.items[random.range(usize, 0, endpoints.items.len)].clone(allocator);
    acc += params.interesting_probability;
    if (u < acc) {
        var interesting: std.ArrayList(BigInt) = .empty;
        defer {
            for (interesting.items) |*value| value.deinit();
            interesting.deinit(allocator);
        }
        for (interesting_integers) |integer| {
            var value = try BigInt.fromInt(allocator, integer);
            defer value.deinit();
            try appendInRange(allocator, &interesting, value, min_value, max_value);
        }
        if (interesting.items.len > 0) return interesting.items[random.range(usize, 0, interesting.items.len)].clone(allocator);
    }
    acc += params.diffuse_probability;
    if (u < acc and diffuse.items.len > 0) return diffuse.items[random.range(usize, 0, diffuse.items.len)].clone(allocator);
    var offset = try sampleBiguintAtMost(allocator, span, random);
    defer offset.deinit();
    var signed_offset = try offset.asSigned(allocator);
    defer signed_offset.deinit();
    return min_value.add(allocator, signed_offset);
}

pub fn biasedIntegerSample(allocator: Allocator, constraint: choices.IntegerChoice, random: *EngineRng, params: IntegerGenerationParameters) Error!BigInt {
    if (constraint.min_value.toInt(i128)) |min_value| if (constraint.max_value.toInt(i128)) |max_value| {
        return BigInt.fromInt(allocator, try biasedI128Sample(min_value, max_value, random, params));
    };
    return biguintSampleInRange(allocator, constraint.min_value, constraint.max_value, random, params);
}

pub fn biasedBytesSample(allocator: Allocator, constraint: choices.BytesChoice, random: *EngineRng) Error![]u8 {
    const want_zero = constraint.min_size == 0 and constraint.max_size > 0;
    const want_ff = constraint.min_size <= 1 and constraint.max_size >= 1;
    const count = 1 + @as(usize, @intFromBool(want_zero)) + @intFromBool(want_ff);
    if (random.random(f64) < @as(f64, @floatFromInt(count)) * 0.01) {
        var slot = random.range(usize, 0, count);
        if (slot == 0) return constraint.simplest(allocator);
        slot -= 1;
        if (want_zero) {
            if (slot == 0) return allocator.dupe(u8, &.{0});
            slot -= 1;
        }
        if (!(want_ff and slot == 0)) return error.InternalError;
        return allocator.dupe(u8, &.{255});
    }
    const len = try manyDrawLength(random, constraint.min_size, constraint.max_size);
    const bytes = try allocator.alloc(u8, len);
    for (bytes) |*byte| byte.* = random.random(u8);
    return bytes;
}

pub fn weightedBooleanSample(probability: f64, random: *EngineRng) bool {
    const falsey = @min(floatToIntSaturating(u32, @max(@floor(256 * (1 - probability)), 1)), 255);
    var byte: [1]u8 = undefined;
    random.fillBytes(&byte);
    return @as(u32, byte[0]) >= falsey;
}

pub fn weightedBooleanSamplePrecise(probability: f64, random: *EngineRng) bool {
    return random.randomBool(probability);
}

pub fn weightedIndexSample(weights: []const f64, random: *EngineRng) usize {
    var total: f64 = 0;
    for (weights) |weight| total += weight;
    var target = random.random(f64) * total;
    var chosen: usize = 0;
    for (weights, 0..) |weight, i| {
        if (weight <= 0) continue;
        chosen = i;
        if (target < weight) break;
        target -= weight;
    }
    return chosen;
}

fn constantsInAlphabet(intervals: *const IntervalSet) Error![]const bool {
    if (intervals.getStringConstantsMask()) |mask| return mask;
    const mask = try intervals.allocator.alloc(bool, global_strings.len);
    for (mask, global_strings) |*allowed, points| {
        allowed.* = for (points) |cp| {
            if (!intervals.contains(cp)) break false;
        } else true;
    }
    return intervals.cacheStringConstantsMaskOwned(mask);
}

fn sizeOk(constraint: choices.StringChoice, points: []const u32) bool {
    return constraint.min_size <= points.len and points.len <= constraint.max_size;
}

pub fn biasedStringSample(allocator: Allocator, constraint: choices.StringChoice, random: *EngineRng) Error![]u32 {
    if (constraint.intervals.isEmpty()) return allocator.alloc(u32, 0);
    const want_empty = constraint.min_size == 0 and constraint.max_size > 0;
    const want_one = constraint.min_size <= 1 and constraint.max_size >= 1;
    const want_two = constraint.min_size <= 2 and constraint.max_size >= 2;
    const small_count = 1 + @as(usize, @intFromBool(want_empty)) + @intFromBool(want_one) + @intFromBool(want_two);
    const contained = try constantsInAlphabet(constraint.intervals);
    var valid_global_count: usize = 0;
    for (global_strings, contained) |points, allowed| if (allowed and sizeOk(constraint, points)) {
        valid_global_count += 1;
    };
    const count = small_count + valid_global_count;
    const threshold = @min(@as(f64, @floatFromInt(count)) * 0.01, 0.5);
    if (random.random(f64) < threshold) {
        const index = random.range(usize, 0, count);
        if (index < small_count) {
            const simplest = try constraint.simplestCodepoint();
            var slot = index;
            if (slot == 0) return constraint.simplest(allocator);
            slot -= 1;
            if (want_empty) {
                if (slot == 0) return allocator.alloc(u32, 0);
                slot -= 1;
            }
            if (want_one) {
                if (slot == 0) return allocator.dupe(u32, &.{simplest});
                slot -= 1;
            }
            if (!(want_two and slot == 0)) return error.InternalError;
            return allocator.dupe(u32, &.{ simplest, simplest });
        }
        var remaining = index - small_count;
        for (global_strings, contained) |points, allowed| {
            if (!allowed or !sizeOk(constraint, points)) continue;
            if (remaining == 0) return allocator.dupe(u32, points);
            remaining -= 1;
        }
        return error.InternalError;
    }
    const alpha = constraint.intervals.len();
    const alpha_size = random.rangeInclusive(usize, 1, @min(10, alpha));
    var sub_alphabet: [10]u32 = undefined;
    for (sub_alphabet[0..alpha_size]) |*cp| {
        const position = if (alpha > 256) blk: {
            if (random.random(f64) < 0.2) break :blk random.range(usize, 256, alpha);
            break :blk random.range(usize, 0, 256);
        } else random.range(usize, 0, alpha);
        cp.* = constraint.intervals.charInShrinkOrder(position);
    }
    const len = try manyDrawLength(random, constraint.min_size, constraint.max_size);
    const points = try allocator.alloc(u32, len);
    for (points) |*cp| cp.* = sub_alphabet[random.range(usize, 0, alpha_size)];
    return points;
}

pub fn codepointsToString(allocator: Allocator, points: []const u32) Allocator.Error![]u8 {
    var string: std.ArrayList(u8) = .empty;
    defer string.deinit(allocator);
    for (points) |cp| {
        if (cp > 0x10ffff or (cp >= 0xd800 and cp <= 0xdfff)) continue;
        var buffer: [4]u8 = undefined;
        const len = std.unicode.utf8Encode(@intCast(cp), &buffer) catch unreachable;
        try string.appendSlice(allocator, buffer[0..len]);
    }
    return string.toOwnedSlice(allocator);
}

pub const FloatWidth = enum {
    F64,
    F32,

    pub fn layout(self: FloatWidth) struct { exponent: i32, mantissa: i32 } {
        return if (self == .F64) .{ .exponent = 1023, .mantissa = 52 } else .{ .exponent = 127, .mantissa = 23 };
    }

    pub fn max(self: FloatWidth) f64 {
        return if (self == .F64) std.math.floatMax(f64) else std.math.floatMax(f32);
    }

    pub fn bitRange(self: FloatWidth, lo: f64, hi: f64) struct { lo: u64, hi: u64 } {
        if (self == .F64) return .{ .lo = @bitCast(lo), .hi = @bitCast(hi) };
        var l: f32 = @floatCast(lo);
        var h: f32 = @floatCast(hi);
        if (@as(f64, l) < lo) l = nextUp32(l);
        if (@as(f64, h) > hi) h = -nextUp32(-h);
        return .{ .lo = @as(u32, @bitCast(l)), .hi = @as(u32, @bitCast(h)) };
    }

    pub fn toFloat(self: FloatWidth, bits: u64) f64 {
        return if (self == .F64) @bitCast(bits) else @as(f32, @bitCast(@as(u32, @truncate(bits))));
    }
};

fn nextUp32(value: f32) f32 {
    if (std.math.isNan(value) or value == std.math.inf(f32)) return value;
    if (value == 0) return @bitCast(@as(u32, 1));
    const bits: u32 = @bitCast(value);
    return @bitCast(if (value < 0) bits - 1 else bits + 1);
}

pub const float_mantissa_mask: u64 = (@as(u64, 1) << 52) - 1;

pub fn floatPow2(exponent: i32) f64 {
    return if (exponent < -1022) @bitCast(@as(u64, 1) << @as(u6, @intCast(exponent + 1074))) else @bitCast(@as(u64, @intCast(exponent + 1023)) << 52);
}

pub fn floatBelow(value: f64) f64 {
    return @bitCast(@as(u64, @bitCast(value)) - 1);
}

pub fn logUniformMagnitude(lo: f64, hi: f64, random: *EngineRng) f64 {
    const lo_bits: u64 = @bitCast(lo);
    const hi_bits: u64 = @bitCast(hi);
    const e_lo = lo_bits >> 52;
    const e_hi = hi_bits >> 52;
    const e = random.rangeInclusive(u64, e_lo, e_hi);
    const m_lo = if (e == e_lo) lo_bits & float_mantissa_mask else 0;
    const m_hi = if (e == e_hi) hi_bits & float_mantissa_mask else float_mantissa_mask;
    return @bitCast((e << 52) | random.rangeInclusive(u64, m_lo, m_hi));
}

pub fn logUniformInteger(lo: u64, hi: u64, random: *EngineRng) u64 {
    const b = random.rangeInclusive(u32, 64 - @as(u32, @clz(lo)), 64 - @as(u32, @clz(hi)));
    const first = if (b == 0) 0 else @as(u64, 1) << @as(u6, @intCast(b - 1));
    const last = if (b == 0) 0 else if (b == 64) std.math.maxInt(u64) else (@as(u64, 1) << @as(u6, @intCast(b))) - 1;
    return random.rangeInclusive(u64, @max(first, lo), @min(last, hi));
}

const Magnitude = union(enum) {
    uniform,
    band: struct { lo: f64, hi: f64 },
    near_one: FloatWidth,
    integer: FloatWidth,
    half_integer: FloatWidth,
    binade_edge: FloatWidth,
};

fn sampleMagnitude(kind: Magnitude, lo: f64, hi: f64, random: *EngineRng) ?f64 {
    return switch (kind) {
        .uniform => logUniformMagnitude(lo, hi, random),
        .band => |band| if (@max(lo, band.lo) <= @min(hi, band.hi)) logUniformMagnitude(@max(lo, band.lo), @min(hi, band.hi), random) else null,
        .near_one => |width| blk: {
            const shape = width.layout();
            const m: u6 = @intCast(shape.mantissa);
            const one = @as(u64, @intCast(shape.exponent)) << m;
            const range = width.bitRange(lo, hi);
            const l = random.rangeInclusive(i32, 1, shape.mantissa);
            const span = @as(u64, 1) << @as(u6, @intCast(shape.mantissa - l));
            const sides = [_]struct { lo: u64, hi: u64 }{
                .{ .lo = @max(one, range.lo), .hi = @min(one + span - 1, range.hi) },
                .{ .lo = @max(one - (2 * span - 1), range.lo), .hi = @min(one - 1, range.hi) },
            };
            const first: usize = @intFromBool(random.random(bool));
            for ([_]usize{ first, 1 - first }) |side| {
                const bounds = sides[side];
                if (bounds.lo <= bounds.hi) break :blk width.toFloat(random.rangeInclusive(u64, bounds.lo, bounds.hi));
            }
            break :blk null;
        },
        .integer => |width| blk: {
            const low = @max(@ceil(lo), 1);
            const high = @min(@floor(hi), floatPow2(width.layout().mantissa + 1));
            if (low > high) break :blk null;
            break :blk @floatFromInt(logUniformInteger(@intFromFloat(low), @intFromFloat(high), random));
        },
        .half_integer => |width| blk: {
            const low = @max(@ceil(lo - 0.5), 0);
            const high = @min(@floor(hi - 0.5), floatPow2(width.layout().mantissa) - 1);
            if (low > high) break :blk null;
            break :blk @as(f64, @floatFromInt(logUniformInteger(@intFromFloat(low), @intFromFloat(high), random))) + 0.5;
        },
        .binade_edge => |width| blk: {
            const range = width.bitRange(lo, hi);
            if (range.lo > range.hi) break :blk null;
            const m: u6 = @intCast(width.layout().mantissa);
            const e_lo = range.lo >> m;
            const k_lo = if (e_lo == 0 or range.lo & ((@as(u64, 1) << m) - 1) != 0) e_lo + 1 else e_lo;
            const k_hi = range.hi >> m;
            if (k_lo > k_hi) break :blk null;
            const power = random.rangeInclusive(u64, k_lo, k_hi) << m;
            const predecessor = power - 1;
            break :blk width.toFloat(if (random.random(bool) and predecessor >= range.lo) predecessor else power);
        },
    };
}

fn signedMagnitudeSample(constraint: choices.FloatChoice, kind: Magnitude, random: *EngineRng) ?f64 {
    const first = random.random(bool);
    for ([_]bool{ first, !first }) |negative| {
        const min = if (negative) -constraint.max_value else constraint.min_value;
        const max = if (negative) -constraint.min_value else constraint.max_value;
        const lo = @max(min, constraint.smallest_nonzero_magnitude);
        const hi = @min(max, std.math.floatMax(f64));
        if (lo > hi) continue;
        if (sampleMagnitude(kind, lo, hi, random)) |magnitude| return if (negative) -magnitude else magnitude;
    }
    return null;
}

pub fn pickValid(constraint: choices.FloatChoice, candidates: anytype, random: *EngineRng) ?f64 {
    var valid: [candidates.len]f64 = undefined;
    var n: usize = 0;
    for (candidates) |value| {
        if (!constraint.validate(value)) continue;
        const bits: u64 = @bitCast(value);
        const seen = for (valid[0..n]) |existing| {
            if (@as(u64, @bitCast(existing)) == bits) break true;
        } else false;
        if (seen) continue;
        valid[n] = value;
        n += 1;
    }
    if (n == 0) return null;
    return valid[random.range(usize, 0, n)];
}

pub fn floatEndpointSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    const above: f64 = if (width == .F64) floats.nextUp(constraint.min_value) else nextUp32(@floatCast(constraint.min_value));
    const below: f64 = if (width == .F64) floats.nextDown(constraint.max_value) else -nextUp32(-@as(f32, @floatCast(constraint.max_value)));
    return pickValid(constraint, [_]f64{ constraint.min_value, constraint.max_value, above, constraint.min_value + 1, constraint.max_value - 1, below }, random);
}

pub fn floatNearZeroSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .band = .{ .lo = floatPow2(1 - width.layout().exponent), .hi = floatBelow(0.1) } }, random);
}

pub fn floatSubnormalSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    const shape = width.layout();
    const smallest = floatPow2(1 - shape.exponent - shape.mantissa);
    return signedMagnitudeSample(constraint, .{ .band = .{ .lo = smallest, .hi = floatPow2(1 - shape.exponent) - smallest } }, random);
}

pub fn floatNearOneSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .near_one = width }, random);
}

pub fn floatIntegerSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .integer = width }, random);
}

pub fn floatHalfIntegerSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .half_integer = width }, random);
}

pub fn floatNearMaxForAddSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .band = .{ .lo = floatPow2(width.layout().exponent), .hi = width.max() } }, random);
}

pub fn floatNearMaxForMulSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    const half = @divTrunc(width.layout().exponent + 1, 2);
    return signedMagnitudeSample(constraint, .{ .band = .{ .lo = floatPow2(half - 1), .hi = floatBelow(floatPow2(half + 1)) } }, random);
}

pub fn floatNearSqrtMinPositiveSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    const half = @divTrunc(1 - width.layout().exponent, 2);
    return signedMagnitudeSample(constraint, .{ .band = .{ .lo = floatPow2(half - 2), .hi = floatBelow(floatPow2(half + 1)) } }, random);
}

pub fn floatNanSample(constraint: choices.FloatChoice, _: FloatWidth, random: *EngineRng) ?f64 {
    if (!constraint.allow_nan) return null;
    const sign = @as(u64, @intFromBool(random.random(bool))) << 63;
    const payload = if (random.random(bool)) @as(u64, 1) << 51 else random.rangeInclusive(u64, 1, float_mantissa_mask);
    return @bitCast(sign | (@as(u64, 0x7ff) << 52) | payload);
}

pub fn floatInfinitySample(constraint: choices.FloatChoice, _: FloatWidth, random: *EngineRng) ?f64 {
    return pickValid(constraint, [_]f64{ std.math.inf(f64), -std.math.inf(f64) }, random);
}

pub fn floatMaxMagnitudeSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return pickValid(constraint, [_]f64{ width.max(), -width.max() }, random);
}

pub fn floatMaxExactIntegerSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    const limit = floatPow2(width.layout().mantissa + 1);
    return pickValid(constraint, [_]f64{ limit, -limit }, random);
}

pub fn floatSignedZeroSample(constraint: choices.FloatChoice, _: FloatWidth, random: *EngineRng) ?f64 {
    return pickValid(constraint, [_]f64{ 0, -0.0 }, random);
}

pub fn floatBinadeEdgeSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng) ?f64 {
    return signedMagnitudeSample(constraint, .{ .binade_edge = width }, random);
}

fn odd(random: *EngineRng) u64 {
    return 2 * random.rangeInclusive(u64, 1, 500) + 1;
}

pub fn floatNonDyadicSample(constraint: choices.FloatChoice, _: FloatWidth, random: *EngineRng) ?f64 {
    const magnitude = if (random.random(bool)) blk: {
        const scale = std.math.powi(u64, 10, random.rangeInclusive(u32, 1, 8)) catch unreachable;
        var n = random.rangeInclusive(u64, 1, scale * 100);
        if (n % 5 == 0) n += 1;
        break :blk @as(f64, @floatFromInt(n)) / @as(f64, @floatFromInt(scale));
    } else blk: {
        const q = odd(random);
        var p = random.rangeInclusive(u64, 1, 300);
        if (p % q == 0) p += 1;
        break :blk @as(f64, @floatFromInt(p)) / @as(f64, @floatFromInt(q));
    };
    const candidates = [_]f64{ magnitude, -magnitude };
    const first: usize = @intFromBool(random.random(bool));
    for ([_]usize{ first, 1 - first }) |i| if (constraint.validate(candidates[i])) return candidates[i];
    const size = constraint.max_value - constraint.min_value;
    if (!std.math.isFinite(size)) return null;
    const q = odd(random);
    return constraint.min_value + size * (@as(f64, @floatFromInt(random.range(u64, 1, q))) / @as(f64, @floatFromInt(q)));
}

pub fn floatDefaultSample(constraint: choices.FloatChoice, random: *EngineRng) Error!f64 {
    if (random.random(bool)) if (signedMagnitudeSample(constraint, .uniform, random)) |value| return value;
    const min = @max(constraint.min_value, -std.math.floatMax(f64));
    const max = @min(constraint.max_value, std.math.floatMax(f64));
    const u = random.random(f64);
    const value = min * (1 - u) + max * u;
    return if (constraint.validate(value)) value else constraint.simplest();
}

pub fn biasedFloatSample(constraint: choices.FloatChoice, width: FloatWidth, random: *EngineRng, params: FloatGenerationParameters) Error!f64 {
    const Category = struct { weight: f64, sample: *const fn (choices.FloatChoice, FloatWidth, *EngineRng) ?f64 };
    const categories = [_]Category{
        .{ .weight = params.endpoint_probability, .sample = floatEndpointSample },
        .{ .weight = params.near_zero_probability, .sample = floatNearZeroSample },
        .{ .weight = params.subnormal_probability, .sample = floatSubnormalSample },
        .{ .weight = params.near_one_probability, .sample = floatNearOneSample },
        .{ .weight = params.integer_probability, .sample = floatIntegerSample },
        .{ .weight = params.half_integer_probability, .sample = floatHalfIntegerSample },
        .{ .weight = params.near_max_for_add_probability, .sample = floatNearMaxForAddSample },
        .{ .weight = params.near_max_for_mul_probability, .sample = floatNearMaxForMulSample },
        .{ .weight = params.near_sqrt_min_positive_probability, .sample = floatNearSqrtMinPositiveSample },
        .{ .weight = params.nan_probability, .sample = floatNanSample },
        .{ .weight = params.infinity_probability, .sample = floatInfinitySample },
        .{ .weight = params.max_magnitude_probability, .sample = floatMaxMagnitudeSample },
        .{ .weight = params.max_exact_integer_probability, .sample = floatMaxExactIntegerSample },
        .{ .weight = params.signed_zero_probability, .sample = floatSignedZeroSample },
        .{ .weight = params.binade_edge_probability, .sample = floatBinadeEdgeSample },
        .{ .weight = params.non_dyadic_probability, .sample = floatNonDyadicSample },
    };
    const u = random.random(f64);
    var acc: f64 = 0;
    for (categories) |category| {
        acc += category.weight;
        if (u < acc) {
            if (category.sample(constraint, width, random)) |value| if (constraint.validate(value)) return value;
            break;
        }
    }
    return floatDefaultSample(constraint, random);
}

pub fn floatRestrictAndRedraw(constraint: choices.FloatChoice, raw: f64) f64 {
    const min = @max(constraint.min_value, -std.math.floatMax(f64));
    const max = @min(constraint.max_value, std.math.floatMax(f64));
    const range_size = @min(max - min, std.math.floatMax(f64));
    const mantissa = @as(u64, @bitCast(@abs(raw))) & float_mantissa_mask;
    var value = min + range_size * (@as(f64, @floatFromInt(mantissa)) / @as(f64, @floatFromInt(float_mantissa_mask)));
    if (value != 0 and @abs(value) < constraint.smallest_nonzero_magnitude) {
        value = constraint.smallest_nonzero_magnitude;
        if (constraint.smallest_nonzero_magnitude > max) value = -value;
    }
    return @min(@max(value, min), max);
}

const interesting_integers = [_]i128{ -9223372036854775808, -2147483648, -32768, -8192, -8191, -4096, -4095, -2048, -2047, -1024, -1023, -512, -511, -256, -255, -128, -127, -64, -63, -32, -31, -16, -15, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 16, 31, 32, 63, 64, 127, 128, 255, 256, 511, 512, 1023, 1024, 2047, 2048, 4095, 4096, 8191, 8192, 32767, 2147483647, 9223372036854775807 };

const global_integers = [_]i128{ -36893488147419103233, -36893488147419103232, -36893488147419103231, -32589158477190044731, -32589158477190044730, -32589158477190044729, -18446744073709551617, -18446744073709551616, -18446744073709551615, -10000000000000000001, -10000000000000000000, -9999999999999999999, -9223372036854775809, -9223372036854775808, -9223372036854775807, -4611686018427387905, -4611686018427387904, -4611686018427387903, -2432902008176640001, -2432902008176640000, -2432902008176639999, -2305843009213693953, -2305843009213693952, -2305843009213693951, -1152921504606846977, -1152921504606846976, -1152921504606846975, -1000000000000000001, -1000000000000000000, -999999999999999999, -576460752303423489, -576460752303423488, -576460752303423487, -288230376151711745, -288230376151711744, -288230376151711743, -144115188075855873, -144115188075855872, -144115188075855871, -121645100408832001, -121645100408832000, -121645100408831999, -100000000000000001, -100000000000000000, -99999999999999999, -72057594037927937, -72057594037927936, -72057594037927935, -36028797018963969, -36028797018963968, -36028797018963967, -18014398509481985, -18014398509481984, -18014398509481983, -10000000000000001, -10000000000000000, -9999999999999999, -9007199254740993, -9007199254740992, -9007199254740991, -6402373705728001, -6402373705728000, -6402373705727999, -4503599627370497, -4503599627370496, -4503599627370495, -2251799813685249, -2251799813685248, -2251799813685247, -1125899906842625, -1125899906842624, -1125899906842623, -1000000000000001, -1000000000000000, -999999999999999, -562949953421313, -562949953421312, -562949953421311, -355687428096001, -355687428096000, -355687428095999, -304250263527211, -304250263527210, -304250263527209, -281474976710657, -281474976710656, -281474976710655, -140737488355329, -140737488355328, -140737488355327, -100000000000001, -100000000000000, -99999999999999, -70368744177665, -70368744177664, -70368744177663, -35184372088833, -35184372088832, -35184372088831, -20922789888001, -20922789888000, -20922789887999, -17592186044417, -17592186044416, -17592186044415, -10000000000001, -10000000000000, -9999999999999, -8796093022209, -8796093022208, -8796093022207, -4398046511105, -4398046511104, -4398046511103, -2199023255553, -2199023255552, -2199023255551, -1307674368001, -1307674368000, -1307674367999, -1099511627777, -1099511627776, -1099511627775, -1000000000001, -1000000000000, -999999999999, -549755813889, -549755813888, -549755813887, -274877906945, -274877906944, -274877906943, -137438953473, -137438953472, -137438953471, -100000000001, -100000000000, -99999999999, -87178291201, -87178291200, -87178291199, -68719476737, -68719476736, -68719476735, -34359738369, -34359738368, -34359738367, -17179869185, -17179869184, -17179869183, -10000000001, -10000000000, -9999999999, -8589934593, -8589934592, -8589934591, -6469693231, -6469693230, -6469693229, -6227020801, -6227020800, -6227020799, -4294967297, -4294967296, -4294967295, -2147483649, -2147483648, -2147483647, -1073741825, -1073741824, -1073741823, -1000000001, -1000000000, -999999999, -536870913, -536870912, -536870911, -479001601, -479001600, -479001599, -268435457, -268435456, -268435455, -134217729, -134217728, -134217727, -100000001, -100000000, -99999999, -67108865, -67108864, -67108863, -39916801, -39916800, -39916799, -33554433, -33554432, -33554431, -16777217, -16777216, -16777215, -10000001, -10000000, -9999999, -8388609, -8388608, -8388607, -4194305, -4194304, -4194303, -3628801, -3628800, -3628799, -2097153, -2097152, -2097151, -1048577, -1048576, -1048575, -1000001, -1000000, -999999, -524289, -524288, -524287, -510511, -510510, -510509, -362881, -362880, -362879, -262145, -262144, -262143, -131073, -131072, -131071, -100001, -100000, -99999, -65537, -65536, -65535, 65535, 65536, 65537, 99999, 100000, 100001, 131071, 131072, 131073, 262143, 262144, 262145, 362879, 362880, 362881, 510509, 510510, 510511, 524287, 524288, 524289, 999999, 1000000, 1000001, 1048575, 1048576, 1048577, 2097151, 2097152, 2097153, 3628799, 3628800, 3628801, 4194303, 4194304, 4194305, 8388607, 8388608, 8388609, 9999999, 10000000, 10000001, 16777215, 16777216, 16777217, 33554431, 33554432, 33554433, 39916799, 39916800, 39916801, 67108863, 67108864, 67108865, 99999999, 100000000, 100000001, 134217727, 134217728, 134217729, 268435455, 268435456, 268435457, 479001599, 479001600, 479001601, 536870911, 536870912, 536870913, 999999999, 1000000000, 1000000001, 1073741823, 1073741824, 1073741825, 2147483647, 2147483648, 2147483649, 4294967295, 4294967296, 4294967297, 6227020799, 6227020800, 6227020801, 6469693229, 6469693230, 6469693231, 8589934591, 8589934592, 8589934593, 9999999999, 10000000000, 10000000001, 17179869183, 17179869184, 17179869185, 34359738367, 34359738368, 34359738369, 68719476735, 68719476736, 68719476737, 87178291199, 87178291200, 87178291201, 99999999999, 100000000000, 100000000001, 137438953471, 137438953472, 137438953473, 274877906943, 274877906944, 274877906945, 549755813887, 549755813888, 549755813889, 999999999999, 1000000000000, 1000000000001, 1099511627775, 1099511627776, 1099511627777, 1307674367999, 1307674368000, 1307674368001, 2199023255551, 2199023255552, 2199023255553, 4398046511103, 4398046511104, 4398046511105, 8796093022207, 8796093022208, 8796093022209, 9999999999999, 10000000000000, 10000000000001, 17592186044415, 17592186044416, 17592186044417, 20922789887999, 20922789888000, 20922789888001, 35184372088831, 35184372088832, 35184372088833, 70368744177663, 70368744177664, 70368744177665, 99999999999999, 100000000000000, 100000000000001, 140737488355327, 140737488355328, 140737488355329, 281474976710655, 281474976710656, 281474976710657, 304250263527209, 304250263527210, 304250263527211, 355687428095999, 355687428096000, 355687428096001, 562949953421311, 562949953421312, 562949953421313, 999999999999999, 1000000000000000, 1000000000000001, 1125899906842623, 1125899906842624, 1125899906842625, 2251799813685247, 2251799813685248, 2251799813685249, 4503599627370495, 4503599627370496, 4503599627370497, 6402373705727999, 6402373705728000, 6402373705728001, 9007199254740991, 9007199254740992, 9007199254740993, 9999999999999999, 10000000000000000, 10000000000000001, 18014398509481983, 18014398509481984, 18014398509481985, 36028797018963967, 36028797018963968, 36028797018963969, 72057594037927935, 72057594037927936, 72057594037927937, 99999999999999999, 100000000000000000, 100000000000000001, 121645100408831999, 121645100408832000, 121645100408832001, 144115188075855871, 144115188075855872, 144115188075855873, 288230376151711743, 288230376151711744, 288230376151711745, 576460752303423487, 576460752303423488, 576460752303423489, 999999999999999999, 1000000000000000000, 1000000000000000001, 1152921504606846975, 1152921504606846976, 1152921504606846977, 2305843009213693951, 2305843009213693952, 2305843009213693953, 2432902008176639999, 2432902008176640000, 2432902008176640001, 4611686018427387903, 4611686018427387904, 4611686018427387905, 9223372036854775807, 9223372036854775808, 9223372036854775809, 9999999999999999999, 10000000000000000000, 10000000000000000001, 18446744073709551615, 18446744073709551616, 18446744073709551617, 32589158477190044729, 32589158477190044730, 32589158477190044731, 36893488147419103231, 36893488147419103232, 36893488147419103233 };

const nasty_integers = [_]i128{ -36893488147419103233, -36893488147419103232, -36893488147419103231, -32589158477190044731, -32589158477190044730, -32589158477190044729, -18446744073709551617, -18446744073709551616, -18446744073709551615, -10000000000000000001, -10000000000000000000, -9999999999999999999, -9223372036854775809, -9223372036854775808, -9223372036854775807, -4611686018427387905, -4611686018427387904, -4611686018427387903, -2432902008176640001, -2432902008176640000, -2432902008176639999, -2305843009213693953, -2305843009213693952, -2305843009213693951, -1152921504606846977, -1152921504606846976, -1152921504606846975, -1000000000000000001, -1000000000000000000, -999999999999999999, -576460752303423489, -576460752303423488, -576460752303423487, -288230376151711745, -288230376151711744, -288230376151711743, -144115188075855873, -144115188075855872, -144115188075855871, -121645100408832001, -121645100408832000, -121645100408831999, -100000000000000001, -100000000000000000, -99999999999999999, -72057594037927937, -72057594037927936, -72057594037927935, -36028797018963969, -36028797018963968, -36028797018963967, -18014398509481985, -18014398509481984, -18014398509481983, -10000000000000001, -10000000000000000, -9999999999999999, -9007199254740993, -9007199254740992, -9007199254740991, -6402373705728001, -6402373705728000, -6402373705727999, -4503599627370497, -4503599627370496, -4503599627370495, -2251799813685249, -2251799813685248, -2251799813685247, -1125899906842625, -1125899906842624, -1125899906842623, -1000000000000001, -1000000000000000, -999999999999999, -562949953421313, -562949953421312, -562949953421311, -355687428096001, -355687428096000, -355687428095999, -304250263527211, -304250263527210, -304250263527209, -281474976710657, -281474976710656, -281474976710655, -140737488355329, -140737488355328, -140737488355327, -100000000000001, -100000000000000, -99999999999999, -70368744177665, -70368744177664, -70368744177663, -35184372088833, -35184372088832, -35184372088831, -20922789888001, -20922789888000, -20922789887999, -17592186044417, -17592186044416, -17592186044415, -10000000000001, -10000000000000, -9999999999999, -8796093022209, -8796093022208, -8796093022207, -4398046511105, -4398046511104, -4398046511103, -2199023255553, -2199023255552, -2199023255551, -1307674368001, -1307674368000, -1307674367999, -1099511627777, -1099511627776, -1099511627775, -1000000000001, -1000000000000, -999999999999, -549755813889, -549755813888, -549755813887, -274877906945, -274877906944, -274877906943, -137438953473, -137438953472, -137438953471, -100000000001, -100000000000, -99999999999, -87178291201, -87178291200, -87178291199, -68719476737, -68719476736, -68719476735, -34359738369, -34359738368, -34359738367, -17179869185, -17179869184, -17179869183, -10000000001, -10000000000, -9999999999, -8589934593, -8589934592, -8589934591, -6469693231, -6469693230, -6469693229, -6227020801, -6227020800, -6227020799, -4294967297, -4294967296, -4294967295, -2147483649, -2147483648, -2147483647, -1073741825, -1073741824, -1073741823, -1000000001, -1000000000, -999999999, -536870913, -536870912, -536870911, -479001601, -479001600, -479001599, -268435457, -268435456, -268435455, -134217729, -134217728, -134217727, -100000001, -100000000, -99999999, -67108865, -67108864, -67108863, -39916801, -39916800, -39916799, -33554433, -33554432, -33554431, -16777217, -16777216, -16777215, -10000001, -10000000, -9999999, -8388609, -8388608, -8388607, -4194305, -4194304, -4194303, -3628801, -3628800, -3628799, -2097153, -2097152, -2097151, -1048577, -1048576, -1048575, -1000001, -1000000, -999999, -524289, -524288, -524287, -510511, -510510, -510509, -362881, -362880, -362879, -262145, -262144, -262143, -131073, -131072, -131071, -100001, -100000, -99999, -65537, -65536, -65535, -32768, -8192, -8191, -4096, -4095, -2048, -2047, -1024, -1023, -512, -511, -256, -255, -128, -127, -64, -63, -32, -31, -16, -15, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 15, 16, 31, 32, 63, 64, 127, 128, 255, 256, 511, 512, 1023, 1024, 2047, 2048, 4095, 4096, 8191, 8192, 32767, 65535, 65536, 65537, 99999, 100000, 100001, 131071, 131072, 131073, 262143, 262144, 262145, 362879, 362880, 362881, 510509, 510510, 510511, 524287, 524288, 524289, 999999, 1000000, 1000001, 1048575, 1048576, 1048577, 2097151, 2097152, 2097153, 3628799, 3628800, 3628801, 4194303, 4194304, 4194305, 8388607, 8388608, 8388609, 9999999, 10000000, 10000001, 16777215, 16777216, 16777217, 33554431, 33554432, 33554433, 39916799, 39916800, 39916801, 67108863, 67108864, 67108865, 99999999, 100000000, 100000001, 134217727, 134217728, 134217729, 268435455, 268435456, 268435457, 479001599, 479001600, 479001601, 536870911, 536870912, 536870913, 999999999, 1000000000, 1000000001, 1073741823, 1073741824, 1073741825, 2147483647, 2147483648, 2147483649, 4294967295, 4294967296, 4294967297, 6227020799, 6227020800, 6227020801, 6469693229, 6469693230, 6469693231, 8589934591, 8589934592, 8589934593, 9999999999, 10000000000, 10000000001, 17179869183, 17179869184, 17179869185, 34359738367, 34359738368, 34359738369, 68719476735, 68719476736, 68719476737, 87178291199, 87178291200, 87178291201, 99999999999, 100000000000, 100000000001, 137438953471, 137438953472, 137438953473, 274877906943, 274877906944, 274877906945, 549755813887, 549755813888, 549755813889, 999999999999, 1000000000000, 1000000000001, 1099511627775, 1099511627776, 1099511627777, 1307674367999, 1307674368000, 1307674368001, 2199023255551, 2199023255552, 2199023255553, 4398046511103, 4398046511104, 4398046511105, 8796093022207, 8796093022208, 8796093022209, 9999999999999, 10000000000000, 10000000000001, 17592186044415, 17592186044416, 17592186044417, 20922789887999, 20922789888000, 20922789888001, 35184372088831, 35184372088832, 35184372088833, 70368744177663, 70368744177664, 70368744177665, 99999999999999, 100000000000000, 100000000000001, 140737488355327, 140737488355328, 140737488355329, 281474976710655, 281474976710656, 281474976710657, 304250263527209, 304250263527210, 304250263527211, 355687428095999, 355687428096000, 355687428096001, 562949953421311, 562949953421312, 562949953421313, 999999999999999, 1000000000000000, 1000000000000001, 1125899906842623, 1125899906842624, 1125899906842625, 2251799813685247, 2251799813685248, 2251799813685249, 4503599627370495, 4503599627370496, 4503599627370497, 6402373705727999, 6402373705728000, 6402373705728001, 9007199254740991, 9007199254740992, 9007199254740993, 9999999999999999, 10000000000000000, 10000000000000001, 18014398509481983, 18014398509481984, 18014398509481985, 36028797018963967, 36028797018963968, 36028797018963969, 72057594037927935, 72057594037927936, 72057594037927937, 99999999999999999, 100000000000000000, 100000000000000001, 121645100408831999, 121645100408832000, 121645100408832001, 144115188075855871, 144115188075855872, 144115188075855873, 288230376151711743, 288230376151711744, 288230376151711745, 576460752303423487, 576460752303423488, 576460752303423489, 999999999999999999, 1000000000000000000, 1000000000000000001, 1152921504606846975, 1152921504606846976, 1152921504606846977, 2305843009213693951, 2305843009213693952, 2305843009213693953, 2432902008176639999, 2432902008176640000, 2432902008176640001, 4611686018427387903, 4611686018427387904, 4611686018427387905, 9223372036854775807, 9223372036854775808, 9223372036854775809, 9999999999999999999, 10000000000000000000, 10000000000000000001, 18446744073709551615, 18446744073709551616, 18446744073709551617, 32589158477190044729, 32589158477190044730, 32589158477190044731, 36893488147419103231, 36893488147419103232, 36893488147419103233 };

const global_strings = [_][]const u32{
    &.{ 117, 110, 100, 101, 102, 105, 110, 101, 100 },
    &.{ 110, 117, 108, 108 },
    &.{ 78, 85, 76, 76 },
    &.{ 110, 105, 108 },
    &.{ 78, 73, 76 },
    &.{ 116, 114, 117, 101 },
    &.{ 102, 97, 108, 115, 101 },
    &.{ 84, 114, 117, 101 },
    &.{ 70, 97, 108, 115, 101 },
    &.{ 84, 82, 85, 69 },
    &.{ 70, 65, 76, 83, 69 },
    &.{ 78, 111, 110, 101 },
    &.{ 110, 111, 110, 101 },
    &.{ 105, 102 },
    &.{ 116, 104, 101, 110 },
    &.{ 101, 108, 115, 101 },
    &.{ 95, 95, 100, 105, 99, 116, 95, 95 },
    &.{ 95, 95, 112, 114, 111, 116, 111, 95, 95 },
    &.{48},
    &.{ 49, 101, 49, 48, 48 },
    &.{ 48, 46, 46, 48 },
    &.{ 48, 47, 48 },
    &.{ 49, 47, 48 },
    &.{ 43, 48, 46, 48 },
    &.{ 73, 110, 102, 105, 110, 105, 116, 121 },
    &.{ 45, 73, 110, 102, 105, 110, 105, 116, 121 },
    &.{ 73, 110, 102 },
    &.{ 73, 78, 70 },
    &.{ 78, 97, 78 },
    &.{ 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57, 57 },
    &.{ 44, 46, 47, 59, 39, 91, 93, 92, 45, 61, 60, 62, 63, 58, 34, 123, 125, 124, 95, 43, 33, 64, 35, 36, 37, 94, 38, 42, 40, 41, 96, 126 },
    &.{ 937, 8776, 231, 8730, 8747, 732, 181, 8804, 8805, 247, 229, 223, 8706, 402, 169, 729, 8710, 730, 172, 8230, 230, 339, 8721, 180, 174, 8224, 165, 168, 710, 248, 960, 8220, 8216, 161, 8482, 163, 162, 8734, 167, 182, 8226, 170, 186, 8211, 8800, 184, 731, 199, 9674, 305, 732, 194, 175, 728, 191, 197, 205, 206, 207, 733, 211, 212, 210, 218, 198, 9731, 338, 8222, 180, 8240, 711, 193, 168, 710, 216, 8719, 8221, 8217, 96, 8260, 8364, 8249, 8250, 64257, 64258, 8225, 176, 183, 8218, 8212, 177 },
    &.{570},
    &.{574},
    &.{ 230, 339, 198, 338, 64256, 676, 680, 223 },
    &.{ 40, 9583, 176, 9633, 176, 65289, 9583, 65077, 32, 9531, 9473, 9531, 41 },
    &.{128525},
    &.{ 127482, 127480 },
    &.{127995},
    &.{ 128077, 127995 },
    &.{ 1575, 1604, 1603, 1604, 32, 1601, 1610, 32, 1575, 1604, 1605, 1580, 1605, 1608, 32, 1593, 1577 },
    &.{ 5787, 5764, 5779, 5776, 5771, 5778, 5764, 32, 5777, 5764, 5762, 5777, 5775, 5765, 5788 },
    &.{ 3585, 3634 },
    &.{ 3585, 32, 3635, 3585, 3635 },
    &.{ 119827, 119841, 119838, 32, 119850, 119854, 119842, 119836, 119844, 32, 119835, 119851, 119848, 119856, 119847, 32, 119839, 119848, 119857, 32, 119843, 119854, 119846, 119849, 119852, 32, 119848, 119855, 119838, 119851, 32, 119853, 119841, 119838, 32, 119845, 119834, 119859, 119858, 32, 119837, 119848, 119840 },
    &.{ 120191, 120205, 120202, 32, 120214, 120218, 120206, 120200, 120208, 32, 120199, 120215, 120212, 120220, 120211, 32, 120203, 120212, 120221, 32, 120207, 120218, 120210, 120213, 120216, 32, 120212, 120219, 120202, 120215, 32, 120217, 120205, 120202, 32, 120209, 120198, 120223, 120222, 32, 120201, 120212, 120204 },
    &.{ 119931, 119945, 119942, 32, 119954, 119958, 119946, 119940, 119948, 32, 119939, 119955, 119952, 119960, 119951, 32, 119943, 119952, 119961, 32, 119947, 119958, 119950, 119953, 119956, 32, 119952, 119959, 119942, 119955, 32, 119957, 119945, 119942, 32, 119949, 119938, 119963, 119962, 32, 119941, 119952, 119944 },
    &.{ 120035, 120049, 120046, 32, 120058, 120062, 120050, 120044, 120052, 32, 120043, 120059, 120056, 120064, 120055, 32, 120047, 120056, 120065, 32, 120051, 120062, 120054, 120057, 120060, 32, 120056, 120063, 120046, 120059, 32, 120061, 120049, 120046, 32, 120053, 120042, 120067, 120066, 32, 120045, 120056, 120048 },
    &.{ 120139, 120153, 120150, 32, 120162, 120166, 120154, 120148, 120156, 32, 120147, 120163, 120160, 120168, 120159, 32, 120151, 120160, 120169, 32, 120155, 120166, 120158, 120161, 120164, 32, 120160, 120167, 120150, 120163, 32, 120165, 120153, 120150, 32, 120157, 120146, 120171, 120170, 32, 120149, 120160, 120152 },
    &.{ 647, 477, 623, 592, 32, 647, 7433, 115, 32, 633, 111, 108, 111, 112, 32, 623, 110, 115, 100, 7433, 32, 623, 477, 633, 111, 741 },
    &.{ 78, 85, 76 },
    &.{ 67, 79, 77, 49 },
    &.{ 76, 80, 84, 49 },
    &.{ 83, 99, 117, 110, 116, 104, 111, 114, 112, 101 },
    &.{ 7792, 826, 826, 789, 111, 862, 32, 823, 105, 818, 812, 839, 810, 857, 110, 797, 791, 853, 118, 799, 796, 792, 806, 863, 111, 822, 793, 816, 800, 107, 232, 858, 814, 826, 810, 825, 817, 804, 32, 790, 116, 797, 853, 819, 803, 827, 810, 862, 104, 828, 851, 818, 806, 819, 792, 818, 101, 839, 803, 816, 806, 812, 846, 32, 802, 828, 827, 817, 792, 104, 858, 846, 857, 796, 803, 818, 837, 105, 806, 818, 803, 816, 804, 118, 827, 845, 101, 826, 813, 819, 810, 816, 45, 109, 802, 105, 837, 110, 790, 826, 798, 818, 815, 816, 100, 821, 828, 799, 857, 809, 828, 792, 819, 32, 798, 805, 817, 819, 813, 114, 795, 791, 792, 101, 857, 112, 864, 114, 828, 798, 827, 813, 791, 101, 826, 800, 803, 863, 115, 792, 839, 819, 845, 797, 841, 101, 841, 805, 815, 798, 818, 858, 812, 860, 505, 812, 846, 846, 799, 790, 839, 804, 116, 845, 812, 804, 851, 828, 813, 856, 837, 105, 810, 817, 110, 864, 103, 820, 841, 32, 847, 841, 837, 99, 812, 799, 104, 865, 97, 811, 827, 815, 856, 111, 811, 799, 790, 845, 793, 797, 841, 115, 791, 806, 818, 46, 808, 825, 840, 803 },
    &.{ 2350, 2344, 2368, 2359, 32, 1605, 1606, 1588 },
    &.{ 2346, 2344, 2381, 2361, 32, 2346, 2344, 2381, 2361, 32, 2340, 2381, 2352, 32, 2352, 2381, 2330, 32, 2325, 2371, 2325, 2371, 32, 2337, 2381, 2337, 32, 2344, 2381, 2361, 2371, 2375, 32, 1573, 1604, 1575, 32, 1576, 1587, 1605, 32, 1575, 1604, 1604, 1607 },
    &.{ 108, 111, 114, 101, 109, 32, 1604, 1575, 32, 1576, 1587, 1605, 32, 1575, 1604, 1604, 1607, 32, 105, 112, 115, 117, 109, 32, 20320, 22909, 49, 50, 51, 52, 20320, 22909 },
    &.{ 97, 10, 98, 13, 99, 133, 100, 11, 101, 12, 102, 8232, 103, 8233, 104, 13, 10, 105 },
};

// SPDX-License-Identifier: MIT AND MPL-2.0
// Translated from hegel-rust 33d94c659e441127ce7b5a0f046ec4aa9315d794, hegel-c/src/native/test_runner.rs.
// Copyright 2026 Antithesis. See LICENSES and docs/native-port-licensing.md.
const std = @import("std");
const c = @import("choices.zig");
const state = @import("state.zig");
const nd = @import("nd.zig");
const graph = @import("graph.zig");
const execution = @import("execution.zig");
const types = @import("runner_types.zig");
const counters = @import("counterexample.zig");
const RunResult = execution.RunResult;
pub const Reproduction = types.Reproduction;
fn reproduces(run: *const RunResult, origin: ?[]const u8) bool {
    return run.status == .interesting and if (origin) |expected| if (run.origin) |actual| std.mem.eql(u8, actual, expected) else false else true;
}
pub fn ndReplayOnce(engine: anytype, timeline: []const c.ChoiceValue, origin: ?[]const u8) anyerror!types.NdReplay {
    const budget = nd.continuationBudget(c.flattenedValuesLen(timeline));
    const tc = try state.NativeTestCase.forProbe(engine.allocator, timeline, engine.rngSpawn(), budget);
    return ndMeasure(engine, tc, origin);
}
pub fn ndReplayGraph(engine: anytype, source: *const graph.Graph, max_size: usize, origin: ?[]const u8) anyerror!types.NdReplay {
    const tc = try state.NativeTestCase.forGraph(engine.allocator, source, engine.rngSpawn(), max_size);
    return ndMeasure(engine, tc, origin);
}
pub fn ndMeasure(engine: anytype, tc: state.NativeTestCase, origin: ?[]const u8) anyerror!types.NdReplay {
    var run = try engine.measure(tc);
    errdefer run.deinit(engine.allocator);
    if (run.divergence) |divergence| if (engine.settings.verbosity == .debug) try engine.log("replay left its counterexample at position {} of stream {any}", .{ divergence.position, divergence.stream });
    return .{ .failed = reproduces(&run, origin), .run = run };
}
pub fn ndReproduce(engine: anytype, origin: ?[]const u8, source: types.ReproSource, attempts: u64, fresh: u64) anyerror!Reproduction {
    var evidence: nd.Evidence = .{};
    var i: u64 = 0;
    while (i < attempts) : (i += 1) {
        var replay = try switch (source) {
            .graph => |value| ndReplayGraph(engine, value.source, nd.continuationBudget(value.longest), origin),
            .sequence => |timeline| ndReplayOnce(engine, timeline, origin),
        };
        evidence.record(replay.failed);
        if (replay.failed) return .{ .witness = replay.run, .evidence = evidence };
        replay.deinit(engine.allocator);
    }
    i = 0;
    while (i < fresh) : (i += 1) {
        const tc = try state.NativeTestCase.newRandom(engine.allocator, engine.rngSpawn());
        var run = try engine.measure(tc);
        if (reproduces(&run, origin)) {
            evidence.record(true);
            return .{ .witness = run, .evidence = evidence };
        }
        run.deinit(engine.allocator);
    }
    return .{ .witness = null, .evidence = evidence };
}

pub fn graftRun(gpa: std.mem.Allocator, source: *graph.Graph, longest: *usize, nodes: []const c.ChoiceNode, spans: []const c.Span) anyerror!bool {
    var run = try graph.Run.fromNodes(gpa, nodes, spans);
    defer run.deinit();
    const grafted = try source.graft(&run);
    if (grafted) longest.* = @max(longest.*, c.flattenedLen(nodes));
    return grafted;
}
pub fn ndEvidenceBatch(engine: anytype, origin: []const u8, source: *const graph.Graph, longest: usize, deadline: ?i128) anyerror!types.NdBatch {
    var evidence = (try engine.origins.entry(origin)).takeSeed() orelse nd.Evidence{};
    var witness: ?RunResult = null;
    errdefer if (witness) |*value| value.deinit(engine.allocator);
    var grafted = try source.deepClone();
    errdefer grafted.deinit();
    var grafted_longest = longest;
    const capture = engine.capture_replays;
    engine.capture_replays = true;
    defer engine.capture_replays = capture;
    var accepted = false;
    const bar_accepted = while (true) {
        if (accepted and evidence.runs() >= nd.ANCHOR_SEED_RUNS) break true;
        if (!accepted and if (deadline) |d| engine.now() >= d else false) break false;
        var replay = try ndReplayGraph(engine, &grafted, nd.continuationBudget(grafted_longest), origin);
        var keep = false;
        defer if (!keep) replay.deinit(engine.allocator);
        evidence.record(replay.failed);
        if (replay.failed) {
            _ = try graftRun(engine.allocator, &grafted, &grafted_longest, replay.run.nodes, replay.run.spans);
            if (witness == null) {
                witness = replay.run;
                keep = true;
            }
        }
        if (accepted) continue;
        switch (nd.discoveryBar(evidence)) {
            .accept => {
                if (witness != null) accepted = true else if (evidence.runs() >= nd.CONFIRM_CAP) break false;
            },
            .reject => break false,
            .continue_replaying => {},
        }
    };
    return .{ .bar_accepted = bar_accepted, .evidence = evidence, .witness = witness, .graph = grafted, .longest = grafted_longest };
}
pub fn ndDiscoverySweep(engine: anytype) anyerror!void {
    if (!engine.nd_active) return;
    while (true) {
        const borrowed = for (engine.origins.iter()) |entry| {
            if (entry.record.incumbent() != null and entry.record.needsConfirmation()) break entry.origin;
        } else return;
        const origin = try engine.allocator.dupe(u8, borrowed);
        defer engine.allocator.free(origin);
        if (!(try engine.origins.entry(origin)).spendBarAttempt()) {
            if (engine.settings.verbosity == .debug) try engine.log("nd discovery confirm: origin={s} out of bar attempts", .{origin});
            try engine.rejectOrigin(origin, .{ .fails = 0, .replays = 0 });
            continue;
        }
        var source = try engine.replaySource(origin);
        defer source.deinit();
        var batch = try ndEvidenceBatch(engine, origin, &source.graph, source.longest, null);
        defer batch.deinit(engine.allocator);
        if (engine.settings.verbosity == .debug) try engine.log("nd discovery confirm: origin={s} fails={}/{} accepted={}", .{ origin, batch.evidence.fails(), batch.evidence.runs(), batch.bar_accepted });
        const evidence: counters.Counterexample.EvidenceCounts = .{ .fails = batch.evidence.fails(), .replays = batch.evidence.runs() };
        if (batch.bar_accepted) {
            try (try engine.origins.entry(origin)).confirm(batch.evidence.lowerBound(), if (batch.witness) |*run| run else null, &batch.graph, batch.longest, evidence);
            try engine.recordNdIncumbent(origin);
        } else try engine.rejectOrigin(origin, evidence);
    }
}
pub fn backtrack(engine: anytype, origin: []const u8) anyerror!types.Backtrack {
    const gpa = engine.allocator;
    const Entry = struct { source: graph.Graph, budget: usize, accept: bool, key: []u8, flat_len: usize };
    var entries: std.ArrayList(Entry) = .empty;
    defer {
        for (entries.items) |*entry| {
            entry.source.deinit();
            gpa.free(entry.key);
        }
        entries.deinit(gpa);
    }
    if (engine.origins.get(origin)) |record| for (record.history().entries()) |entry| {
        var run = try entry.run(gpa);
        defer run.deinit();
        var source = try graph.Graph.fromRun(gpa, &run);
        errdefer source.deinit();
        const key = (try @import("database.zig").serializeNodes(gpa, entry.nodes)) orelse return error.InternalError;
        errdefer gpa.free(key);
        const flat_len = c.flattenedLen(entry.nodes);
        try entries.append(gpa, .{ .source = source, .budget = nd.continuationBudget(flat_len), .accept = entry.accept, .key = key, .flat_len = flat_len });
    };
    const attempts_left = if (engine.origins.get(origin)) |record| record.backtrackAttemptsLeft() else false;
    if (entries.items.len == 0 or !attempts_left) return .{ .exhausted = .{ .fails = 0, .replays = 0 } };
    var accepts: std.ArrayList(usize) = .empty;
    defer accepts.deinit(gpa);
    var raws: std.ArrayList(usize) = .empty;
    defer raws.deinit(gpa);
    for (entries.items, 0..) |entry, i| {
        if (entry.accept) try accepts.append(gpa, i) else try raws.append(gpa, i);
    }
    var replays_left = nd.CONFIRM_CAP;
    var fails: u64 = 0;
    var runs: u64 = 0;
    const status = try gpa.alloc(?bool, entries.items.len);
    defer gpa.free(status);
    @memset(status, null);
    var probe_order: std.ArrayList(usize) = .empty;
    defer probe_order.deinit(gpa);
    if (accepts.items.len > 0) {
        const top = accepts.items.len - 1;
        var offset: usize = 1;
        while (offset <= top) {
            try probe_order.append(gpa, accepts.items[top - offset]);
            offset *= 2;
        }
        if (top > 0 and std.mem.indexOfScalar(usize, probe_order.items, accepts.items[0]) == null) try probe_order.append(gpa, accepts.items[0]);
        if (accepts.items.len == 1) try probe_order.append(gpa, accepts.items[top]);
    }
    try probe_order.appendSlice(gpa, raws.items);
    for (probe_order.items) |index| {
        if (replays_left == 0) break;
        replays_left -= 1;
        var replay = try ndReplayGraph(engine, &entries.items[index].source, entries.items[index].budget, origin);
        defer replay.deinit(gpa);
        runs += 1;
        fails += @intFromBool(replay.failed);
        status[index] = replay.failed;
    }
    var second_pass_done = false;
    while (true) {
        var boundary: ?usize = null;
        var i = accepts.items.len;
        while (i > 0) {
            i -= 1;
            if (status[accepts.items[i]] == true) {
                boundary = i;
                break;
            }
        }
        const candidate: ?usize = if (boundary) |position| blk: {
            var low = position;
            var high = accepts.items.len;
            for (position + 1..accepts.items.len) |p| if (status[accepts.items[p]] == false) {
                high = p;
                break;
            };
            while (high - low > 1 and replays_left > 0) {
                const middle = low + (high - low) / 2;
                const index = accepts.items[middle];
                replays_left -= 1;
                var replay = try ndReplayGraph(engine, &entries.items[index].source, entries.items[index].budget, origin);
                defer replay.deinit(gpa);
                runs += 1;
                fails += @intFromBool(replay.failed);
                status[index] = replay.failed;
                if (replay.failed) low = middle else high = middle;
            }
            break :blk accepts.items[low];
        } else blk: {
            var best: ?usize = null;
            for (raws.items) |index| if (status[index] == true) {
                if (best == null or shortlex(entries.items[index].key, entries.items[best.?].key) == .lt) best = index;
            };
            break :blk best;
        };
        const index = candidate orelse {
            if (second_pass_done or replays_left == 0) return .{ .exhausted = .{ .fails = fails, .replays = runs } };
            second_pass_done = true;
            i = entries.items.len;
            while (i > 0) {
                i -= 1;
                if (status[i] == true or replays_left == 0) continue;
                replays_left -= 1;
                var replay = try ndReplayGraph(engine, &entries.items[i].source, entries.items[i].budget, origin);
                defer replay.deinit(gpa);
                runs += 1;
                fails += @intFromBool(replay.failed);
                status[i] = replay.failed;
                if (replay.failed) break;
            }
            continue;
        };
        if (!(try engine.origins.entry(origin)).spendBacktrackAttempt()) return .{ .exhausted = .{ .fails = fails, .replays = runs } };
        var batch = try ndEvidenceBatch(engine, origin, &entries.items[index].source, entries.items[index].flat_len, null);
        defer batch.deinit(gpa);
        runs += batch.evidence.runs();
        fails += batch.evidence.fails();
        if (!batch.bar_accepted) {
            status[index] = false;
            continue;
        }
        const witness = if (batch.witness) |*run| run else return error.InternalError;
        var nodes: []c.ChoiceNode = &.{};
        var spans: []c.Span = &.{};
        if (engine.origins.get(origin)) |record| {
            const history = record.history().entries();
            if (index < history.len) {
                nodes = try c.cloneNodes(gpa, history[index].nodes);
                errdefer c.deinitNodes(gpa, nodes);
                spans = try gpa.dupe(c.Span, history[index].spans);
            }
        }
        errdefer {
            c.deinitNodes(gpa, nodes);
            gpa.free(spans);
        }
        if (engine.origins.get(origin)) |record| for (record.history().entries(), 0..) |entry, j| {
            if (j != index and status[j] == true) _ = try graftRun(gpa, &batch.graph, &batch.longest, entry.nodes, entry.spans);
        };
        const restored = try engine.origins.entry(origin);
        try restored.confirm(batch.evidence.lowerBound(), witness, &batch.graph, batch.longest, .{ .fails = batch.evidence.fails(), .replays = batch.evidence.runs() });
        try restored.replace(nodes, spans);
        var repro = try restored.reproState();
        defer repro.deinit();
        try engine.persister.recordNd(origin, nodes, &repro, true);
        return .{ .restored = .{ .nodes = nodes, .spans = spans } };
    }
}
fn shortlex(a: []const u8, b: []const u8) std.math.Order {
    return if (a.len < b.len) .lt else if (a.len > b.len) .gt else std.mem.order(u8, a, b);
}

fn valuesEql(a: []const c.ChoiceValue, b: []const c.ChoiceValue) bool {
    if (a.len != b.len) return false;
    for (a, b) |aa, bb| if (!aa.eql(&bb)) return false;
    return true;
}
fn poolContains(pool: []const []c.ChoiceValue, values: []const c.ChoiceValue) bool {
    for (pool) |old| if (valuesEql(old, values)) return true;
    return false;
}
pub const Boost = struct { witness: RunResult, anchor: f64 };
pub fn ndBoost(engine: anytype, origin: []const u8, incumbent_run: *const RunResult, anchor: f64) anyerror!?Boost {
    const gpa = engine.allocator;
    if (engine.settings.verbosity == .debug) try engine.log("nd boost: origin={s} racing from anchor {d:.3}", .{ origin, anchor });
    const incumbent = try incumbent_run.realizedValues(gpa);
    defer c.deinitValues(gpa, incumbent);
    var candidates: std.ArrayList([]c.ChoiceValue) = .empty;
    defer {
        for (candidates.items) |values| c.deinitValues(gpa, values);
        candidates.deinit(gpa);
    }
    const initial = try c.cloneValues(gpa, incumbent);
    candidates.append(gpa, initial) catch |err| {
        c.deinitValues(gpa, initial);
        return err;
    };
    var attempts: usize = 0;
    while (candidates.items.len < nd.BOOST_POOL and attempts < nd.BOOST_POOL * 3) {
        attempts += 1;
        const cut = engine.rng.rangeInclusive(usize, 0, incumbent.len);
        const budget = c.flattenedValuesLen(incumbent) + 8;
        const tc = try state.NativeTestCase.forProbe(gpa, incumbent[0..cut], engine.rngSpawn(), budget);
        var run = try engine.measure(tc);
        defer run.deinit(gpa);
        const realized = try run.realizedValues(gpa);
        if (poolContains(candidates.items, realized)) c.deinitValues(gpa, realized) else candidates.append(gpa, realized) catch |err| {
            c.deinitValues(gpa, realized);
            return err;
        };
    }
    const Score = struct { index: usize, fails: u64 = 0, runs: u64 = 0 };
    const scores = try gpa.alloc(Score, candidates.items.len);
    defer gpa.free(scores);
    for (scores, 0..) |*score, i| score.* = .{ .index = i };
    var count = scores.len;
    var per_round: u64 = 2;
    while (count > 1) {
        for (scores[0..count]) |*score| {
            const candidate = candidates.items[score.index];
            const budget = nd.continuationBudget(c.flattenedValuesLen(candidate));
            var i: u64 = 0;
            while (i < per_round) : (i += 1) {
                const tc = try state.NativeTestCase.forProbe(gpa, candidate, engine.rngSpawn(), budget);
                var run = try engine.measure(tc);
                defer run.deinit(gpa);
                score.runs += 1;
                if (reproduces(&run, origin)) score.fails += 1;
            }
        }
        std.mem.sort(Score, scores[0..count], {}, struct {
            fn less(_: void, a: Score, b: Score) bool {
                return @as(f64, @floatFromInt(a.fails)) / @as(f64, @floatFromInt(@max(a.runs, 1))) > @as(f64, @floatFromInt(b.fails)) / @as(f64, @floatFromInt(@max(b.runs, 1)));
            }
        }.less);
        count = nd.boostKeep(count);
        per_round *= 2;
    }
    const winner = candidates.items[scores[0].index];
    var holdout: nd.Evidence = .{};
    var witness: ?RunResult = null;
    defer if (witness) |*run| run.deinit(gpa);
    for (0..nd.BOOST_HOLDOUT) |_| {
        var replay = try ndReplayOnce(engine, winner, origin);
        holdout.record(replay.failed);
        if (replay.failed and witness == null) witness = replay.run else replay.deinit(gpa);
    }
    const lcb = holdout.lowerBound();
    if (witness != null and lcb > anchor) {
        if (engine.settings.verbosity == .debug) try engine.log("nd boost: origin={s} anchor {d:.3} -> {d:.3}", .{ origin, anchor, lcb });
        if (valuesEql(winner, incumbent)) (try engine.origins.entry(origin)).raiseAnchor(lcb) else {
            var run = try graph.Run.fromNodes(gpa, witness.?.nodes, witness.?.spans);
            defer run.deinit();
            var stored = try engine.replaySource(origin);
            defer stored.deinit();
            const witness_len = c.flattenedLen(witness.?.nodes);
            const longest = if (stored.graph.walkVerdict(&run) == .foreign) witness_len else @max(stored.longest, witness_len);
            var augmented = try stored.graph.withRun(&run);
            defer augmented.deinit();
            try (try engine.origins.entry(origin)).install(&augmented, witness.?.nodes, witness.?.spans, lcb, longest);
            try engine.recordNdIncumbent(origin);
        }
        const result = witness.?;
        witness = null;
        return .{ .witness = result, .anchor = lcb };
    }
    return null;
}
const TargetScores = struct {
    scores: []f64,
    nodes: ?[]c.ChoiceNode,
    fn deinit(self: *TargetScores, gpa: std.mem.Allocator) void {
        gpa.free(self.scores);
        if (self.nodes) |nodes| c.deinitNodes(gpa, nodes);
    }
};
pub fn ndTargetRun(engine: anytype, timeline: []const c.ChoiceValue) anyerror!?RunResult {
    if (engine.origins.anyLive()) return null;
    const budget = nd.continuationBudget(c.flattenedValuesLen(timeline));
    const tc = try state.NativeTestCase.forProbe(engine.allocator, timeline, engine.rngSpawn(), budget);
    return try engine.measure(tc);
}
pub fn ndTargetScores(engine: anytype, timeline: []const c.ChoiceValue, label: []const u8, n: u64) anyerror!TargetScores {
    const gpa = engine.allocator;
    var scores: std.ArrayList(f64) = .empty;
    errdefer scores.deinit(gpa);
    var nodes: ?[]c.ChoiceNode = null;
    errdefer if (nodes) |value| c.deinitNodes(gpa, value);
    var i: u64 = 0;
    while (i < n) : (i += 1) {
        var run = (try ndTargetRun(engine, timeline)) orelse break;
        defer run.deinit(gpa);
        if (@backingInt(run.status) < @backingInt(c.Status.valid)) continue;
        if (run.target_observations.get(label)) |score| try scores.append(gpa, score);
        if (nodes == null) nodes = try c.cloneNodes(gpa, run.nodes);
    }
    return .{ .scores = try scores.toOwnedSlice(gpa), .nodes = nodes };
}
pub fn ndTargetReference(engine: anytype, label: []const u8, seed: []const c.ChoiceValue) anyerror!void {
    const gpa = engine.allocator;
    var batch = try ndTargetScores(engine, seed, label, nd.TARGET_ND_HOLDOUT);
    defer batch.deinit(gpa);
    const median = try nd.targetMedian(gpa, batch.scores);
    if (median != null and batch.nodes != null) {
        try engine.targeting.setNdTarget(label, .{ .nodes = batch.nodes.?, .reference = median.?, .dead = false });
        batch.nodes = null;
    } else {
        if (engine.origins.anyLive()) return;
        const nodes = try gpa.alloc(c.ChoiceNode, 0);
        errdefer gpa.free(nodes);
        try engine.targeting.setNdTarget(label, .{ .nodes = nodes, .reference = -std.math.inf(f64), .dead = true });
    }
}
pub fn ndTargetAdopt(engine: anytype, label: []const u8, winner: []const c.ChoiceValue, reference: f64) anyerror!bool {
    var fresh = try ndTargetScores(engine, winner, label, nd.TARGET_ND_HOLDOUT);
    defer fresh.deinit(engine.allocator);
    const median = (try nd.targetMedian(engine.allocator, fresh.scores)) orelse return false;
    const nodes = fresh.nodes orelse return false;
    try engine.targeting.adoptNd(label, nodes, median);
    if (engine.settings.verbosity == .debug) try engine.log("nd targeting: label={s} reference {d:.3} -> {d:.3}", .{ label, reference, median });
    return true;
}
pub fn ndTargetPerturb(engine: anytype, nodes: []const c.ChoiceNode, timeline: []const c.ChoiceValue) anyerror!?[]c.ChoiceValue {
    const gpa = engine.allocator;
    var climbable: std.ArrayList(usize) = .empty;
    defer climbable.deinit(gpa);
    for (nodes, 0..) |*node, i| if (!node.was_forced and @import("targeting.zig").isClimbable(&node.data)) try climbable.append(gpa, i);
    if (climbable.items.len > 0 and engine.rng.range(i32, 0, 2) == 0) {
        const index = climbable.items[engine.rng.range(usize, 0, climbable.items.len)];
        const magnitude = @as(i128, 1) << @as(u7, @intCast(engine.rng.range(i32, 0, 7)));
        const delta = if (engine.rng.range(i32, 0, 2) == 0) magnitude else -magnitude;
        var value = (try @import("targeting.zig").stepChoice(gpa, &nodes[index], delta)) orelse return null;
        errdefer value.deinit(gpa);
        const candidate = try c.cloneValues(gpa, timeline);
        candidate[index].deinit(gpa);
        candidate[index] = value;
        return candidate;
    }
    if (engine.origins.anyLive()) return null;
    const cut = engine.rng.rangeInclusive(usize, 0, timeline.len);
    const budget = c.flattenedValuesLen(timeline) + 8;
    const tc = try state.NativeTestCase.forProbe(gpa, timeline[0..cut], engine.rngSpawn(), budget);
    var run = try engine.measure(tc);
    defer run.deinit(gpa);
    return try run.realizedValues(gpa);
}
fn totalFloatOrder(a: f64, b: f64) std.math.Order {
    const ab: i64 = @bitCast(a);
    const bb: i64 = @bitCast(b);
    const ak = ab ^ @as(i64, @bitCast(@as(u64, @bitCast(ab >> 63)) >> 1));
    const bk = bb ^ @as(i64, @bitCast(@as(u64, @bitCast(bb >> 63)) >> 1));
    return std.math.order(ak, bk);
}
pub fn ndTargetRace(engine: anytype, label: []const u8, reference: f64, nodes: []const c.ChoiceNode, timeline: []const c.ChoiceValue, best_score: f64, best_choices: []const c.ChoiceValue) anyerror!bool {
    const gpa = engine.allocator;
    var candidates: std.ArrayList([]c.ChoiceValue) = .empty;
    defer {
        for (candidates.items) |candidate| c.deinitValues(gpa, candidate);
        candidates.deinit(gpa);
    }
    if (best_score > reference and !valuesEql(best_choices, timeline)) {
        const copy = try c.cloneValues(gpa, best_choices);
        candidates.append(gpa, copy) catch |err| {
            c.deinitValues(gpa, copy);
            return err;
        };
    }
    var attempts: usize = 0;
    while (candidates.items.len < nd.TARGET_ND_POOL and attempts < nd.TARGET_ND_POOL * 3) {
        attempts += 1;
        const candidate = (try ndTargetPerturb(engine, nodes, timeline)) orelse continue;
        if (valuesEql(candidate, timeline) or poolContains(candidates.items, candidate)) c.deinitValues(gpa, candidate) else candidates.append(gpa, candidate) catch |err| {
            c.deinitValues(gpa, candidate);
            return err;
        };
    }
    if (candidates.items.len == 0) return false;
    const Score = struct {
        index: usize,
        sum: f64 = 0,
        runs: u64 = 0,
        fn mean(self: @This()) f64 {
            return if (self.runs == 0) -std.math.inf(f64) else self.sum / @as(f64, @floatFromInt(self.runs));
        }
    };
    const scores = try gpa.alloc(Score, candidates.items.len);
    defer gpa.free(scores);
    for (scores, 0..) |*score, i| score.* = .{ .index = i };
    var count = scores.len;
    var per_round: u64 = 2;
    while (count > 1) {
        for (scores[0..count]) |*score| {
            var i: u64 = 0;
            while (i < per_round) : (i += 1) {
                var run = (try ndTargetRun(engine, candidates.items[score.index])) orelse break;
                defer run.deinit(gpa);
                if (@backingInt(run.status) < @backingInt(c.Status.valid)) continue;
                if (run.target_observations.get(label)) |value| {
                    score.sum += value;
                    score.runs += 1;
                }
            }
        }
        std.mem.sort(Score, scores[0..count], {}, struct {
            fn less(_: void, a: Score, b: Score) bool {
                return totalFloatOrder(b.mean(), a.mean()) == .lt;
            }
        }.less);
        count = nd.boostKeep(count);
        per_round *= 2;
    }
    if (scores[0].runs == 0) return false;
    const winner = candidates.items[scores[0].index];
    var holdout = try ndTargetScores(engine, winner, label, nd.TARGET_ND_HOLDOUT);
    defer holdout.deinit(gpa);
    var beats: u64 = 0;
    for (holdout.scores) |score| if (score > reference) {
        beats += 1;
    };
    if (!nd.targetAdopt(beats, nd.TARGET_ND_HOLDOUT)) return false;
    return ndTargetAdopt(engine, label, winner, reference);
}
pub fn optimiseTargetsNd(engine: anytype) anyerror!void {
    const gpa = engine.allocator;
    const seeds = try engine.targeting.seeds(gpa);
    defer {
        for (seeds) |seed| {
            gpa.free(seed.label);
            c.deinitValues(gpa, seed.choices);
        }
        gpa.free(seeds);
    }
    var races: u64 = 0;
    while (true) {
        var adopted = false;
        for (seeds) |seed| {
            if (races >= nd.TARGET_ND_RACES or engine.origins.anyLive()) return;
            if (engine.targeting.ndTarget(seed.label) == null) try ndTargetReference(engine, seed.label, seed.choices);
            const target = engine.targeting.ndTarget(seed.label) orelse continue;
            if (target.dead) continue;
            const reference = target.reference;
            const nodes = try c.cloneNodes(gpa, target.nodes);
            defer c.deinitNodes(gpa, nodes);
            const timeline = try target.timeline(gpa);
            defer c.deinitValues(gpa, timeline);
            races += 1;
            if (try ndTargetRace(engine, seed.label, reference, nodes, timeline, seed.score, seed.choices)) adopted = true;
        }
        if (!adopted) return;
    }
}

fn valuesOfNodes(gpa: std.mem.Allocator, nodes: []const c.ChoiceNode) ![]c.ChoiceValue {
    const values = try gpa.alloc(c.ChoiceValue, nodes.len);
    var count: usize = 0;
    errdefer {
        for (values[0..count]) |*value| value.deinit(gpa);
        gpa.free(values);
    }
    for (nodes, values) |node, *value| {
        value.* = try node.value(gpa);
        count += 1;
    }
    return values;
}
fn flaky(engine: anytype, origin: []const u8) anyerror {
    return engine.fail(error.Flaky, "Flaky test detected: Your test produced different outcomes when run with the same generated data — it failed when it previously succeeded, or succeeded when it previously failed. This usually means your test depends on external state such as global variables, system time, or external random number generators.\nThe failure that did not reproduce was: {s}", .{origin});
}
fn shrinkWitness(engine: anytype, origin: []const u8, initial: []const c.ChoiceNode, shrunk: *std.StringHashMapUnmanaged(void)) anyerror!?Boost {
    const gpa = engine.allocator;
    const values = try valuesOfNodes(gpa, initial);
    defer c.deinitValues(gpa, values);
    if (!engine.nd_active) {
        const tc = try state.NativeTestCase.forChoices(gpa, values, initial, null);
        var verify = try engine.testFunction(tc);
        if (reproduces(&verify, origin)) {
            if (!engine.nd_active) return .{ .witness = verify, .anchor = 0 };
        } else if (engine.settings.nondeterminism_strictness == .@"error") {
            verify.deinit(gpa);
            return flaky(engine, origin);
        } else engine.ndFlip();
        verify.deinit(gpa);
    }
    if (engine.origins.getMut(origin)) |record| if (record.takeWitness()) |witness| return .{ .witness = witness.run, .anchor = witness.anchor };
    if (!engine.origins.needsConfirmation(origin)) {
        var source = try engine.replaySource(origin);
        defer source.deinit();
        var batch = try ndEvidenceBatch(engine, origin, &source.graph, source.longest, null);
        defer batch.deinit(gpa);
        const evidence: counters.Counterexample.EvidenceCounts = .{ .fails = batch.evidence.fails(), .replays = batch.evidence.runs() };
        if (batch.witness) |witness| {
            batch.witness = null;
            errdefer {
                var cleanup = witness;
                cleanup.deinit(gpa);
            }
            try engine.confirmBatch(origin, batch.evidence.lowerBound(), &batch.graph, batch.longest, evidence);
            return .{ .witness = witness, .anchor = batch.evidence.lowerBound() };
        }
        (try engine.origins.entry(origin)).recordTrustedBatch(evidence);
        try engine.markShrunk(origin, shrunk);
        return null;
    }
    if (engine.hasHistory(origin)) {
        const result = try backtrack(engine, origin);
        switch (result) {
            .restored => |restored| {
                c.deinitNodes(gpa, restored.nodes);
                gpa.free(restored.spans);
                return null;
            },
            .exhausted => |evidence| {
                try engine.rejectOrigin(origin, .{ .fails = evidence.fails, .replays = evidence.replays });
                try engine.markShrunk(origin, shrunk);
                return null;
            },
        }
    }
    if (!(try engine.origins.entry(origin)).spendBarAttempt()) {
        try engine.rejectOrigin(origin, .{ .fails = 0, .replays = 0 });
        try engine.markShrunk(origin, shrunk);
        return null;
    }
    var source = try engine.replaySource(origin);
    defer source.deinit();
    var batch = try ndEvidenceBatch(engine, origin, &source.graph, source.longest, null);
    defer batch.deinit(gpa);
    const evidence: counters.Counterexample.EvidenceCounts = .{ .fails = batch.evidence.fails(), .replays = batch.evidence.runs() };
    if (!batch.bar_accepted) {
        try engine.rejectOrigin(origin, evidence);
        try engine.markShrunk(origin, shrunk);
        return null;
    }
    const witness = batch.witness orelse return error.InternalError;
    batch.witness = null;
    errdefer {
        var cleanup = witness;
        cleanup.deinit(gpa);
    }
    try engine.confirmBatch(origin, batch.evidence.lowerBound(), &batch.graph, batch.longest, evidence);
    return .{ .witness = witness, .anchor = batch.evidence.lowerBound() };
}
fn EngineShrinkProbe(comptime Engine: type) type {
    return struct {
        engine: *Engine,
        origin: []const u8,
        const Self = @This();
        fn call(context: *anyopaque, request: @import("shrinker.zig").Request) anyerror!@import("shrinker.zig").Outcome {
            const self: *Self = @ptrCast(@alignCast(context));
            const engine = self.engine;
            const gpa = engine.allocator;
            if (engine.nd_active) return error.ShrinkStop;
            if (engine.settings.verbosity == .verbose) try engine.log("Running test case", .{});
            var run = try switch (request) {
                .full => |nodes| blk: {
                    const values = try valuesOfNodes(gpa, nodes);
                    defer c.deinitValues(gpa, values);
                    break :blk engine.cachedTestFunction(values, nodes, 0);
                },
                .probe => |probe| engine.cachedTestFunction(probe.prefix, null, probe.max_size -| probe.prefix.len),
            };
            const matched = reproduces(&run, self.origin);
            const cached: @import("exec_cache.zig").CachedRun = .{ .status = run.status, .origin = run.origin, .nodes = run.nodes, .spans = run.spans };
            run.origin = null;
            run.nodes = &.{};
            run.spans = &.{};
            run.deinit(gpa);
            return .{ .interesting = matched, .run = cached };
        }
        fn clock(context: ?*anyopaque) ?i128 {
            const engine: *Engine = @ptrCast(@alignCast(context.?));
            return engine.now();
        }
        fn debug(context: ?*anyopaque, message: []const u8) void {
            const engine: *Engine = @ptrCast(@alignCast(context.?));
            engine.settings.output.line(engine.io, message);
        }
    };
}
fn EngineGraphProbe(comptime Engine: type) type {
    return struct {
        engine: *Engine,
        origin: []const u8,
        const Self = @This();
        fn replay(context: *anyopaque, source: *const graph.Graph, max_size: usize) anyerror!@import("graph_shrink.zig").Outcome {
            const self: *Self = @ptrCast(@alignCast(context));
            const engine = self.engine;
            const gpa = engine.allocator;
            if (engine.settings.verbosity == .verbose) try engine.log("Running test case", .{});
            var result = try ndReplayGraph(engine, source, max_size, self.origin);
            const outcome: @import("graph_shrink.zig").Outcome = .{ .failed = result.failed, .divergence = result.run.divergence != null, .ended = result.run.ended, .settled = result.run.settled, .nodes = result.run.nodes, .spans = result.run.spans };
            result.run.settled = &.{};
            result.run.nodes = &.{};
            result.run.spans = &.{};
            result.deinit(gpa);
            return outcome;
        }
        fn charge(context: *anyopaque, anchor: f64, drive: bool) u64 {
            const self: *Self = @ptrCast(@alignCast(context));
            const record = self.engine.origins.getMut(self.origin) orelse unreachable;
            return record.gauntlet_spend.charge(.{}, anchor, drive, null);
        }
        fn adopted(context: *anyopaque, source: *const graph.Graph, nodes: []const c.ChoiceNode, spans: []const c.Span, anchor: f64, longest: usize) anyerror!void {
            const self: *Self = @ptrCast(@alignCast(context));
            const engine = self.engine;
            if (engine.settings.verbosity == .debug) try engine.log("nd graph accept: origin={s} edges={} anchor={d:.3}", .{ self.origin, try source.edgeCount(), anchor });
            try (try engine.origins.entry(self.origin)).install(source, nodes, spans, anchor, longest);
            try engine.recordNdIncumbent(self.origin);
        }
    };
}
pub fn shrinkOrigin(engine: anytype, origin: []const u8, initial: []const c.ChoiceNode, initial_spans: []const c.Span, deadline: ?i128, shrunk: *std.StringHashMapUnmanaged(void)) anyerror!bool {
    const gpa = engine.allocator;
    var admitted = (try shrinkWitness(engine, origin, initial, shrunk)) orelse return false;
    defer admitted.witness.deinit(gpa);
    if (engine.nd_active and admitted.anchor < nd.BOOST_RELIABILITY_FLOOR) {
        if (try ndBoost(engine, origin, &admitted.witness, admitted.anchor)) |boost| {
            admitted.witness.deinit(gpa);
            admitted = boost;
        }
    }
    const Engine = @TypeOf(engine.*);
    if (engine.nd_active) {
        var source = try engine.replaySource(origin);
        defer source.deinit();
        var run = try graph.Run.fromNodes(gpa, admitted.witness.nodes, admitted.witness.spans);
        defer run.deinit();
        var augmented = try source.graph.withRun(&run);
        defer augmented.deinit();
        if (engine.settings.verbosity == .debug) try engine.log("nd shrink start: origin={s} edges={} anchor={d:.3}", .{ origin, try augmented.edgeCount(), admitted.anchor });
        var shrinker = try @import("graph_shrink.zig").GraphShrinker.init(gpa, &augmented, admitted.witness.nodes, admitted.witness.spans, admitted.anchor);
        defer shrinker.deinit();
        shrinker.setLongest(source.longest);
        shrinker.deadline = deadline;
        shrinker.clock_context = engine;
        shrinker.now = EngineShrinkProbe(Engine).clock;
        var probe: EngineGraphProbe(Engine) = .{ .engine = engine, .origin = origin };
        try shrinker.shrink(.{ .context = &probe, .replay = EngineGraphProbe(Engine).replay, .charge = EngineGraphProbe(Engine).charge, .adopted = EngineGraphProbe(Engine).adopted });
        if (engine.settings.verbosity == .debug) {
            const anchor = if (engine.origins.get(origin)) |record| record.anchor() orelse admitted.anchor else admitted.anchor;
            var final = try engine.replaySource(origin);
            defer final.deinit();
            try engine.log("nd shrink done: origin={s} edges={} anchor={d:.3} timed_out={}", .{ origin, try final.graph.edgeCount(), anchor, shrinker.timed_out });
        }
        try engine.markShrunk(origin, shrunk);
        return shrinker.timed_out;
    }
    var probe: EngineShrinkProbe(Engine) = .{ .engine = engine, .origin = origin };
    var shrinker = try @import("shrinker.zig").Shrinker.init(gpa, .{ .context = &probe, .call = EngineShrinkProbe(Engine).call }, admitted.witness.nodes, admitted.witness.spans);
    defer shrinker.deinit();
    shrinker.deadline = deadline;
    shrinker.clock_context = engine;
    shrinker.now = EngineShrinkProbe(Engine).clock;
    shrinker.initialCoarseReduction() catch |err| if (err != error.ShrinkStop) return err;
    if (engine.settings.verbosity == .debug) {
        shrinker.debug_context = engine;
        shrinker.debug = EngineShrinkProbe(Engine).debug;
    }
    try shrinker.shrink();
    if (engine.nd_active) try (try engine.origins.entry(origin)).replace(initial, initial_spans) else {
        try (try engine.origins.entry(origin)).replace(shrinker.current_nodes, shrinker.current_spans);
        try engine.markShrunk(origin, shrunk);
    }
    return shrinker.timed_out;
}

fn clearShrunk(gpa: std.mem.Allocator, shrunk: *std.StringHashMapUnmanaged(void)) void {
    var keys = shrunk.keyIterator();
    while (keys.next()) |key| gpa.free(key.*);
    shrunk.deinit(gpa);
}
fn reshrinkRestored(engine: anytype, origin: []const u8, restored: anytype, deadline: ?i128, enabled: bool) anyerror!void {
    const gpa = engine.allocator;
    defer c.deinitNodes(gpa, restored.nodes);
    defer gpa.free(restored.spans);
    if (enabled) {
        var shrunk: std.StringHashMapUnmanaged(void) = .empty;
        defer clearShrunk(gpa, &shrunk);
        _ = try shrinkOrigin(engine, origin, restored.nodes, restored.spans, deadline, &shrunk);
    }
}
pub fn finalReplay(engine: anytype, deadline: ?i128, reshrink: bool) anyerror!void {
    if (!engine.origins.anyLive()) return;
    const gpa = engine.allocator;
    var pending = std.ArrayList([]u8).fromOwnedSlice(try engine.origins.liveOrigins(gpa));
    defer {
        for (pending.items) |origin| gpa.free(origin);
        pending.deinit(gpa);
    }
    var replayed: std.ArrayList([]u8) = .empty;
    defer {
        for (replayed.items) |origin| gpa.free(origin);
        replayed.deinit(gpa);
    }
    while (pending.items.len > 0) {
        const origin = pending.orderedRemove(0);
        var keep_origin = false;
        defer if (!keep_origin) gpa.free(origin);
        const nodes = try c.cloneNodes(gpa, engine.origins.incumbent(origin) orelse &.{});
        defer c.deinitNodes(gpa, nodes);
        const values = try valuesOfNodes(gpa, nodes);
        defer c.deinitValues(gpa, values);
        if (!engine.nd_active) {
            var run = blk: {
                engine.capture_replays = true;
                defer engine.capture_replays = false;
                const tc = try state.NativeTestCase.forChoices(gpa, values, nodes, null);
                break :blk try engine.measure(tc);
            };
            defer run.deinit(gpa);
            const reproduced = reproduces(&run, origin);
            if (reproduced and !engine.nd_active) {
                try replayed.append(gpa, origin);
                keep_origin = true;
                continue;
            }
            try pending.appendSlice(gpa, replayed.items);
            replayed.clearRetainingCapacity();
            if (!reproduced) {
                if (engine.settings.nondeterminism_strictness == .@"error") return flaky(engine, origin);
                engine.ndFlip();
                if (engine.origins.needsConfirmation(origin) and engine.hasHistory(origin)) {
                    switch (try backtrack(engine, origin)) {
                        .restored => |restored| try reshrinkRestored(engine, origin, restored, deadline, reshrink),
                        .exhausted => |evidence| {
                            try engine.rejectOrigin(origin, .{ .fails = evidence.fails, .replays = evidence.replays });
                            continue;
                        },
                    }
                }
            }
        }
        if (engine.origins.incumbent(origin) == null) return engine.fail(error.InternalError, "final_replay: {s} lost its incumbent without continuing", .{origin});
        var source = try engine.replaySource(origin);
        defer source.deinit();
        var reproduction = blk: {
            engine.capture_replays = true;
            defer engine.capture_replays = false;
            break :blk try ndReproduce(engine, origin, .{ .graph = .{ .source = &source.graph, .longest = source.longest } }, nd.reuseReplayBudget(), nd.FINAL_REPLAY_FRESH);
        };
        defer if (reproduction.witness) |*run| run.deinit(gpa);
        const batch: counters.Counterexample.EvidenceCounts = .{ .fails = reproduction.evidence.fails(), .replays = reproduction.evidence.runs() };
        if (engine.origins.needsConfirmation(origin)) {
            var confirmed = false;
            var review_evidence: counters.Counterexample.EvidenceCounts = .{ .fails = 0, .replays = 0 };
            if (reproduction.witness) |*run| if ((try engine.origins.entry(origin)).spendBarAttempt()) {
                var realized = try graph.Run.fromNodes(gpa, run.nodes, run.spans);
                defer realized.deinit();
                var reviewed = try source.graph.withRun(&realized);
                defer reviewed.deinit();
                const longest = @max(source.longest, c.flattenedLen(run.nodes));
                var review = try ndEvidenceBatch(engine, origin, &reviewed, longest, deadline);
                defer review.deinit(gpa);
                review_evidence = .{ .fails = review.evidence.fails(), .replays = review.evidence.runs() };
                if (review.bar_accepted) {
                    const counter = try engine.origins.entry(origin);
                    try counter.confirm(review.evidence.lowerBound(), null, &review.graph, review.longest, review_evidence);
                    counter.recordFinalReplay(batch);
                    confirmed = true;
                }
            };
            if (!confirmed) {
                var rejected: counters.Counterexample.EvidenceCounts = .{ .fails = batch.fails + review_evidence.fails, .replays = batch.replays + review_evidence.replays };
                if (engine.hasHistory(origin)) {
                    switch (try backtrack(engine, origin)) {
                        .restored => |restored| {
                            try reshrinkRestored(engine, origin, restored, deadline, reshrink);
                            try pending.append(gpa, origin);
                            keep_origin = true;
                            continue;
                        },
                        .exhausted => |evidence| {
                            rejected.fails += evidence.fails;
                            rejected.replays += evidence.replays;
                        },
                    }
                }
                try engine.rejectOrigin(origin, rejected);
            }
        } else (try engine.origins.entry(origin)).recordFinalReplay(batch);
    }
}
pub fn runBlob(engine: anytype, encoded: []const u8) anyerror!@import("test_runner.zig").TestRunResult {
    const gpa = engine.allocator;
    var decoded = (try @import("blob.zig").decodeBlob(gpa, encoded)) orelse return engine.fail(error.InvalidArgument, "invalid reproduce blob", .{});
    defer decoded.deinit(gpa);
    switch (decoded) {
        .choices => |values| {
            var rng = @import("test_runner.zig").createRng(engine.io, engine.settings, null);
            const budget = nd.continuationBudget(c.flattenedValuesLen(values));
            for (0..nd.V1_BLOB_REPLAYS) |_| {
                var tc = try state.NativeTestCase.forProbe(gpa, values, rng.spawn(), budget);
                tc.setShouldCapture();
                var run = try engine.executor.execute(gpa, tc);
                defer run.deinit(gpa);
                if (run.status == .interesting) {
                    const origin = try gpa.dupe(u8, run.origin orelse return error.InternalError);
                    errdefer gpa.free(origin);
                    const failures = try gpa.alloc(@import("test_runner.zig").Failure, 1);
                    failures[0] = .{ .origin = origin, .reproduce_blob = null, .caveat = null };
                    return .{ .failures = failures };
                }
            }
            return .{ .failures = try gpa.alloc(@import("test_runner.zig").Failure, 0) };
        },
        .nd => |*stored| {
            if (engine.settings.nondeterminism_strictness != .@"error") engine.ndFlip();
            engine.capture_replays = true;
            defer engine.capture_replays = false;
            const longest = @min(@as(usize, stored.longest), engine.choiceBound());
            var reproduction = try ndReproduce(engine, null, .{ .graph = .{ .source = &stored.graph, .longest = longest } }, nd.reuseReplayBudget(), 0);
            defer if (reproduction.witness) |*run| run.deinit(gpa);
            if (reproduction.witness) |run| if (run.origin) |name| {
                const origin = try gpa.dupe(u8, name);
                errdefer gpa.free(origin);
                try (try engine.origins.entry(origin)).trust(.{ .graph = &stored.graph, .longest = longest }, .{ .fails = reproduction.evidence.fails(), .replays = reproduction.evidence.runs() });
                const caveat = try engine.origins.caveat(origin);
                errdefer if (caveat) |value| gpa.free(value);
                const failures = try gpa.alloc(@import("test_runner.zig").Failure, 1);
                failures[0] = .{ .origin = origin, .reproduce_blob = null, .caveat = caveat };
                return .{ .failures = failures };
            };
            return .{ .failures = try gpa.alloc(@import("test_runner.zig").Failure, 0) };
        },
    }
}

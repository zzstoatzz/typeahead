//! Zig API for property tests and deterministic simulations.
//!
//! The engine generates cases, shrinks failures, and replays saved examples.
//! This module runs the property callbacks and reports failures.

const std = @import("std");
pub const c = @import("c");
pub const FaultPlan = @import("fault-plan").FaultPlan;
pub const FaultTiming = @import("fault-plan").Timing;

const gpa = std.heap.smp_allocator;

pub const Settings = struct {
    /// null uses the engine settings: `HEGEL_TEST_CASES`, a `hegel.toml` profile,
    /// or its default of 100.
    test_cases: ?u64 = null,
    /// null defers to `HEGEL_SEED`, or a fresh seed per run.
    seed: ?u64 = null,
    /// directory for the engine's failure database, which replays earlier
    /// failures first. null defers to `HEGEL_DATABASE`, else disables it.
    database: ?[*:0]const u8 = null,
    /// names this property's failures in the database. null names it by the
    /// order of `run` calls in the program: `run-0`, `run-1`.
    key: ?[*:0]const u8 = null,
    /// print every note as it is made, for every case. the only way to see
    /// the history leading to a crash, since a crashed case never reports.
    /// defaults to on when `HEGEL_ZIG_ECHO` is set.
    echo: ?bool = null,
    /// a reproduce blob from an earlier failure: replay it instead of
    /// exploring. defaults to `HEGEL_ZIG_REPLAY`.
    replay: ?[*:0]const u8 = null,
    /// print the fraction of cases in which each `case.event` happened.
    /// null turns it on unless `HEGEL_STATISTICS` says otherwise.
    statistics: ?bool = null,
};

pub const TestCase = struct {
    ctx: *c.hegel_context_t,
    tc: *c.hegel_test_case_t,
    capture: bool,
    echo: bool,
    trace: std.ArrayList(u8) = .empty,
    origin: [*:0]const u8 = "property failed",

    pub fn faultPlan(self: *TestCase, comptime Point: type, max_skip: u32) error{StopTest}!FaultPlan(Point) {
        const tags = std.meta.tags(Point);
        const point = tags[try self.index(tags.len)];
        const skip = try self.int(u32, 0, max_skip);
        const timing: FaultTiming = if (try self.boolean()) .after else .before;
        var plan: FaultPlan(Point) = .{ .observer = self.faultObserver(Point) };
        plan.arm(point, skip, timing);
        self.note("arm {s} after {d} matching calls: {s}", .{ @tagName(point), skip, @tagName(timing) });
        return plan;
    }

    pub fn faultObserver(self: *TestCase, comptime Point: type) FaultPlan(Point).Observer {
        return .{ .context = self, .selected = struct {
            fn selected(context: *anyopaque, point: Point, timing: FaultTiming) void {
                const case: *TestCase = @ptrCast(@alignCast(context));
                case.note("fault {s}: {s}", .{ @tagName(point), @tagName(timing) });
                inline for (comptime std.meta.tags(Point)) |p| if (point == p) {
                    switch (timing) {
                        .before => case.event(comptime "fault " ++ @tagName(p) ++ " before"),
                        .after => case.event(comptime "fault " ++ @tagName(p) ++ " after"),
                    }
                };
            }
        }.selected };
    }

    pub fn int(self: *TestCase, comptime T: type, min: T, max: T) error{StopTest}!T {
        var out: i64 = 0;
        try self.draw(c.hegel_generate_integer(self.ctx, self.tc, @intCast(min), @intCast(max), &out));
        return @intCast(out);
    }

    /// an index into a collection of `len` alternatives. shrinks toward 0.
    pub fn index(self: *TestCase, len: usize) error{StopTest}!usize {
        return self.int(usize, 0, len - 1);
    }

    pub fn boolean(self: *TestCase) error{StopTest}!bool {
        return try self.int(u8, 0, 1) == 1;
    }

    pub fn bytes(self: *TestCase, buf: []u8, min_len: usize, max_len: usize) error{StopTest}![]u8 {
        std.debug.assert(max_len <= buf.len);
        var result: c.hegel_generate_bytes_result_t = .{ .data = null, .len = 0 };
        try self.draw(c.hegel_generate_bytes(self.ctx, self.tc, min_len, max_len, &result));
        defer check(self.ctx, c.hegel_generate_bytes_result_free(self.ctx, &result));
        @memcpy(buf[0..result.len], result.data[0..result.len]);
        return buf[0..result.len];
    }

    /// a generated sequence of steps. each step's draws sit in their own
    /// span, so the shrinker can delete or reorder whole steps.
    pub fn steps(self: *TestCase, min: u64, max: u64) error{StopTest}!Steps {
        var collection: ?*c.hegel_collection_t = null;
        try self.draw(c.hegel_new_collection(self.ctx, self.tc, min, max, &collection));
        var label: u64 = 0;
        check(self.ctx, c.hegel_label_from_name(self.ctx, "hegel-zig.step", &label));
        return .{ .case = self, .collection = collection.?, .label = label };
    }

    /// an engine-owned state machine over the tags of `Rule`. the engine picks
    /// each rule, decides when the history ends (at most `step_count` rules),
    /// and applies swarm testing: each case enables a random subset of the
    /// rules, so some histories are saturated with a few of them. `weights`
    /// biases selection among the enabled rules, in tag order.
    pub fn machine(
        self: *TestCase,
        comptime Rule: type,
        weights: ?*const [std.meta.tags(Rule).len]f64,
        step_count: u32,
    ) error{StopTest}!Machine(Rule) {
        const tags = comptime std.meta.tags(Rule);
        const names = comptime blk: {
            var out: [tags.len][*c]const u8 = undefined;
            for (tags, 0..) |tag, i| out[i] = @tagName(tag).ptr;
            break :blk out;
        };
        const groups: [tags.len]i64 = @splat(0);
        var handle: ?*c.hegel_state_machine_t = null;
        var concurrency: i64 = 0;
        try self.draw(c.hegel_new_state_machine(
            self.ctx,
            self.tc,
            &names,
            &groups,
            if (weights) |w| w else null,
            tags.len,
            null,
            null,
            0,
            1,
            1,
            step_count,
            &handle,
            &concurrency,
        ));
        return .{ .case = self, .handle = handle.? };
    }

    /// count `label` toward the fraction of cases in which it happened. name
    /// the interactions a bug needs, like an overwrite or a read of a warm
    /// cache after one: a run where they are rare has not tested them.
    pub fn event(self: *TestCase, comptime label: [*:0]const u8) void {
        check(self.ctx, c.hegel_event(self.ctx, self.tc, label));
    }

    /// a set of things the case created, for rules that act on one of them.
    /// ids stay attached to what they name while the shrinker deletes the
    /// steps around them, where an index into a list would shift.
    pub fn pool(self: *TestCase) error{StopTest}!Pool {
        var handle: ?*c.hegel_pool_t = null;
        try self.draw(c.hegel_new_pool(self.ctx, self.tc, &handle));
        return .{ .case = self, .handle = handle.? };
    }

    /// record a line of the case's history. shown only for the minimal
    /// failing case, so the format arguments must be cheap to compute.
    pub fn note(self: *TestCase, comptime fmt: []const u8, args: anytype) void {
        if (self.echo) std.debug.print(fmt ++ "\n", args);
        if (!self.capture) return;
        self.trace.print(gpa, fmt ++ "\n", args) catch @panic("out of memory");
    }

    /// fail the case. `origin` names the violated property: the engine shrinks
    /// each distinct origin as its own bug, so it must not vary with the data.
    pub fn fail(self: *TestCase, comptime origin: [*:0]const u8) error{PropertyFailed} {
        self.origin = origin;
        return error.PropertyFailed;
    }

    fn draw(self: *TestCase, rc: c.hegel_result_t) error{StopTest}!void {
        if (rc == c.HEGEL_E_STOP_TEST) return error.StopTest;
        check(self.ctx, rc);
    }
};

pub const Steps = struct {
    case: *TestCase,
    collection: *c.hegel_collection_t,
    label: u64,
    in_step: bool = false,

    pub fn next(self: *Steps) error{StopTest}!bool {
        const case = self.case;
        if (self.in_step) {
            check(case.ctx, c.hegel_stop_span(case.ctx, case.tc, false));
            self.in_step = false;
        }
        var more = false;
        try case.draw(c.hegel_collection_more(case.ctx, case.tc, self.collection, &more));
        if (!more) return false;
        check(case.ctx, c.hegel_start_span(case.ctx, case.tc, self.label));
        self.in_step = true;
        return true;
    }

    pub fn deinit(self: *Steps) void {
        check(self.case.ctx, c.hegel_collection_free(self.case.ctx, self.collection));
    }
};

pub const Pool = struct {
    case: *TestCase,
    handle: *c.hegel_pool_t,
    len: usize = 0,

    /// a fresh id for something just created. the caller maps it to the thing.
    pub fn add(self: *Pool) error{StopTest}!u64 {
        var id: i64 = 0;
        try self.case.draw(c.hegel_pool_add(self.case.ctx, self.case.tc, self.handle, &id));
        self.len += 1;
        return @bitCast(id);
    }

    /// one of the ids added so far, or null when there are none.
    pub fn pick(self: *Pool) error{StopTest}!?u64 {
        return self.generate(false);
    }

    /// like `pick`, and removes the id, for a rule that destroys the thing.
    pub fn take(self: *Pool) error{StopTest}!?u64 {
        const id = try self.generate(true) orelse return null;
        self.len -= 1;
        return id;
    }

    pub fn deinit(self: *Pool) void {
        check(self.case.ctx, c.hegel_pool_free(self.case.ctx, self.handle));
    }

    fn generate(self: *Pool, consume: bool) error{StopTest}!?u64 {
        // the engine discards the whole case when drawing from an empty pool
        if (self.len == 0) return null;
        var id: i64 = 0;
        try self.case.draw(c.hegel_pool_generate(self.case.ctx, self.case.tc, self.handle, consume, &id));
        return @bitCast(id);
    }
};

pub fn Machine(comptime Rule: type) type {
    return struct {
        case: *TestCase,
        handle: *c.hegel_state_machine_t,
        in_round: bool = false,

        /// the next rule to apply, or null when the history is over.
        pub fn next(self: *@This()) error{StopTest}!?Rule {
            const case = self.case;
            while (true) {
                if (!self.in_round) {
                    var group: i64 = 0;
                    try case.draw(c.hegel_state_machine_next_group(case.ctx, case.tc, self.handle, &group));
                    if (group == c.HEGEL_STATE_MACHINE_DONE) return null;
                    self.in_round = true;
                }
                var rule: i64 = 0;
                try case.draw(c.hegel_state_machine_next_rule(case.ctx, case.tc, self.handle, 0, &rule));
                if (rule != c.HEGEL_STATE_MACHINE_DONE) return std.meta.tags(Rule)[@intCast(rule)];
                self.in_round = false;
            }
        }

        /// the rule `next` returned cannot apply to the current state, like a
        /// delete with nothing to delete. it does not count as a step, and
        /// the engine learns to pick something else.
        pub fn reject(self: *@This()) void {
            check(self.case.ctx, c.hegel_state_machine_rule_rejected(self.case.ctx, self.case.tc, self.handle, 0));
        }

        pub fn deinit(self: *@This()) void {
            check(self.case.ctx, c.hegel_state_machine_free(self.case.ctx, self.handle));
        }
    };
}

/// what a run exercised, by rule. "no failures" over an empty state space
/// and over a real one print the same line; this is what tells them apart.
/// counts every case the engine ran, including the ones spent shrinking.
pub fn Tally(comptime Rule: type) type {
    return struct {
        cases: u64 = 0,
        finished: u64 = 0,
        steps: u64 = 0,
        rules: [std.meta.tags(Rule).len]u64 = @splat(0),
        rejected: [std.meta.tags(Rule).len]u64 = @splat(0),
        /// summed over finished cases
        final_size: u64 = 0,

        pub fn case(self: *@This()) void {
            self.cases += 1;
        }

        pub fn step(self: *@This(), rule: Rule) void {
            self.steps += 1;
            for (std.meta.tags(Rule), &self.rules) |tag, *count| count.* += @intFromBool(tag == rule);
        }

        /// the step counted by `step` was rejected: count it here instead.
        pub fn reject(self: *@This(), rule: Rule) void {
            self.steps -= 1;
            for (std.meta.tags(Rule), &self.rules, &self.rejected) |tag, *count, *rejected| {
                if (tag != rule) continue;
                count.* -= 1;
                rejected.* += 1;
            }
        }

        /// the case ran to the end of its history. `size` is whatever measures
        /// how much state it built: keys in the tree, tasks scheduled.
        pub fn finish(self: *@This(), size: u64) void {
            self.finished += 1;
            self.final_size += size;
        }

        pub fn print(self: *const @This()) void {
            const cases: f64 = @floatFromInt(@max(self.cases, 1));
            const finished: f64 = @floatFromInt(@max(self.finished, 1));
            std.debug.print("{d} cases ({d} finished), {d} steps ({d:.1} per case), mean final size {d:.1}\n ", .{
                self.cases,
                self.finished,
                self.steps,
                @as(f64, @floatFromInt(self.steps)) / cases,
                @as(f64, @floatFromInt(self.final_size)) / finished,
            });
            for (std.meta.tags(Rule), self.rules) |rule, count| std.debug.print(" {s}={d}", .{ @tagName(rule), count });
            std.debug.print("\n", .{});
            if (std.mem.indexOfNone(u64, &self.rejected, &.{0}) != null) {
                std.debug.print(" rejected:", .{});
                for (std.meta.tags(Rule), self.rejected) |rule, count| {
                    if (count > 0) std.debug.print(" {s}={d}", .{ @tagName(rule), count });
                }
                std.debug.print("\n", .{});
            }
            for (std.meta.tags(Rule), self.rules) |rule, count| {
                if (count == 0) std.debug.print("never ran: {s}\n", .{@tagName(rule)});
            }
        }
    };
}

var runs: usize = 0;

/// run `property` against generated cases. on failure, prints each distinct
/// failure's minimal history and returns `error.PropertyFailed`.
///
/// the property returns normally to pass, `case.fail(...)` to fail, and
/// `error.Reject` to discard a case that broke a precondition. any other
/// error also fails the case, with the error name as its origin.
pub fn run(
    settings: Settings,
    context: anytype,
    comptime property: fn (@TypeOf(context), *TestCase) anyerror!void,
) error{PropertyFailed}!void {
    const ctx = c.hegel_context_new() orelse @panic("hegel_context_new failed");
    defer _ = c.hegel_context_free(ctx);

    var s: ?*c.hegel_settings_t = null;
    check(ctx, c.hegel_settings_new(ctx, &s));
    defer check(ctx, c.hegel_settings_free(ctx, s));
    if (settings.test_cases) |n| check(ctx, c.hegel_settings_set_test_cases(ctx, s, n));
    if (settings.database) |dir|
        check(ctx, c.hegel_settings_set_database(ctx, s, dir))
    else if (std.c.getenv("HEGEL_DATABASE") == null)
        check(ctx, c.hegel_settings_set_database(ctx, s, ""));
    var key_buf: [32]u8 = undefined;
    const key = settings.key orelse
        (std.fmt.bufPrintSentinel(&key_buf, "run-{d}", .{runs}, 0) catch unreachable).ptr;
    runs += 1;
    check(ctx, c.hegel_settings_set_database_key(ctx, s, key));
    if (settings.seed) |seed| check(ctx, c.hegel_settings_set_seed(ctx, s, seed, true));
    if (settings.statistics orelse (std.c.getenv("HEGEL_STATISTICS") == null))
        check(ctx, c.hegel_settings_set_show_statistics(ctx, s, true));

    const replay: ?[*:0]const u8 = settings.replay orelse std.c.getenv("HEGEL_ZIG_REPLAY");
    var hegel_run: ?*c.hegel_run_t = null;
    if (replay) |blob|
        check(ctx, c.hegel_run_start_blob(ctx, s, blob, output, null, &hegel_run))
    else
        check(ctx, c.hegel_run_start(ctx, s, output, null, &hegel_run));
    defer check(ctx, c.hegel_run_free(ctx, hegel_run));

    const echo = settings.echo orelse (std.c.getenv("HEGEL_ZIG_ECHO") != null);

    var traces: std.StringArrayHashMapUnmanaged([]u8) = .empty;
    defer {
        for (traces.values()) |trace| gpa.free(trace);
        traces.deinit(gpa);
    }

    while (true) {
        var tc: ?*c.hegel_test_case_t = null;
        check(ctx, c.hegel_next_test_case(ctx, hegel_run, &tc));
        const handle = tc orelse break;
        defer check(ctx, c.hegel_test_case_free(ctx, handle));

        var case: TestCase = .{ .ctx = ctx, .tc = handle, .capture = false, .echo = echo };
        defer case.trace.deinit(gpa);
        check(ctx, c.hegel_test_case_should_capture(ctx, handle, &case.capture));
        if (case.echo) std.debug.print("--- case ---\n", .{});

        const status: u32, const origin: ?[*:0]const u8 = if (property(context, &case)) |_|
            .{ c.HEGEL_STATUS_VALID, null }
        else |err| switch (err) {
            error.StopTest => .{ c.HEGEL_STATUS_OVERRUN, null },
            error.Reject => .{ c.HEGEL_STATUS_INVALID, null },
            error.PropertyFailed => .{ c.HEGEL_STATUS_INTERESTING, case.origin },
            else => .{ c.HEGEL_STATUS_INTERESTING, @errorName(err).ptr },
        };

        if (origin) |o| {
            if (case.capture) {
                const entry = traces.getOrPut(gpa, std.mem.span(o)) catch @panic("out of memory");
                if (entry.found_existing) gpa.free(entry.value_ptr.*);
                entry.value_ptr.* = case.trace.toOwnedSlice(gpa) catch @panic("out of memory");
            }
        }
        check(ctx, c.hegel_mark_complete(ctx, handle, status, origin));
    }

    var result: ?*c.hegel_run_result_t = null;
    check(ctx, c.hegel_run_result(ctx, hegel_run, &result));
    defer check(ctx, c.hegel_run_result_free(ctx, result));

    var run_status: c.hegel_run_status_t = undefined;
    check(ctx, c.hegel_run_result_status(ctx, result, &run_status));
    if (run_status == c.HEGEL_RUN_STATUS_PASSED) {
        if (replay != null) std.debug.print("the replayed case passes: the failure it recorded is gone\n", .{});
        return;
    }

    var run_error: [*c]const u8 = null;
    check(ctx, c.hegel_run_result_error(ctx, result, &run_error));
    if (run_error != null) std.debug.print("hegel run error: {s}\n", .{run_error});

    var failure_count: usize = 0;
    check(ctx, c.hegel_run_result_failure_count(ctx, result, &failure_count));
    for (0..failure_count) |i| {
        var failure: ?*c.hegel_failure_t = null;
        check(ctx, c.hegel_run_result_failure(ctx, result, i, &failure));
        defer check(ctx, c.hegel_failure_free(ctx, failure));

        var origin: [*c]const u8 = null;
        var blob: [*c]const u8 = null;
        var caveat: [*c]const u8 = null;
        check(ctx, c.hegel_failure_origin(ctx, failure, &origin));
        check(ctx, c.hegel_failure_reproduction_blob(ctx, failure, &blob));
        check(ctx, c.hegel_failure_caveat(ctx, failure, &caveat));

        const name = std.mem.span(origin);
        std.debug.print("\nFAILED: {s}\n", .{name});
        if (traces.get(name)) |trace| std.debug.print("minimal history:\n{s}", .{trace});
        if (caveat != null) std.debug.print("caveat: {s}\n", .{caveat});
        if (blob != null) std.debug.print("reproduce: HEGEL_ZIG_REPLAY={s}\n", .{blob});
    }
    return error.PropertyFailed;
}

/// Write engine output to stderr and use Zig terminology in the event hint.
fn output(_: ?*anyopaque, line: [*c]const u8, len: usize) callconv(.c) void {
    const text = line[0..len];
    const rust_hint = "no events were recorded; record them with tc.event(..) or tc.event_value(..)";
    if (std.mem.endsWith(u8, text, rust_hint)) {
        std.debug.print("{s}no events were recorded; record them with case.event\n", .{text[0 .. len - rust_hint.len]});
        return;
    }
    std.debug.print("{s}\n", .{text});
}

fn check(ctx: *c.hegel_context_t, rc: c.hegel_result_t) void {
    if (rc == c.HEGEL_OK) return;
    std.debug.panic("Hegel engine call failed ({d}): {s}", .{ rc, c.hegel_context_last_error(ctx) });
}

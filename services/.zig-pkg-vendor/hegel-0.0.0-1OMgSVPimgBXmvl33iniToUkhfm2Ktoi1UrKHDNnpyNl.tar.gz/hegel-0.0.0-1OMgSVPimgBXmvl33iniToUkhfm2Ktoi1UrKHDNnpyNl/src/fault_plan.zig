const std = @import("std");

pub const Timing = enum { before, after };

pub fn FaultPlan(comptime Point: type) type {
    const tags = std.meta.tags(Point);
    return struct {
        const Self = @This();

        pub const Fault = struct {
            point: ?Point,
            skip: u64,
            timing: Timing,
        };

        pub const Counts = struct {
            reached: u64 = 0,
            before: u64 = 0,
            after: u64 = 0,
        };

        pub const Observer = struct {
            context: *anyopaque,
            selected: *const fn (*anyopaque, Point, Timing) void,
        };

        armed: ?Fault = null,
        counts: [tags.len]Counts = @splat(.{}),
        suspended: bool = false,
        observer: ?Observer = null,

        pub fn arm(self: *Self, point: ?Point, skip: u64, timing: Timing) void {
            self.armed = .{ .point = point, .skip = skip, .timing = timing };
        }

        pub fn disarm(self: *Self) void {
            self.armed = null;
        }

        pub fn hit(self: *Self, point: Point) ?Timing {
            if (self.suspended) return null;
            const count = &self.counts[index(point)];
            count.reached += 1;
            const fault = self.armed orelse return null;
            if (fault.point) |p| if (p != point) return null;
            if (fault.skip > 0) {
                self.armed.?.skip -= 1;
                return null;
            }
            const timing = fault.timing;
            self.armed = null;
            switch (timing) {
                .before => count.before += 1,
                .after => count.after += 1,
            }
            if (self.observer) |observer| observer.selected(observer.context, point, timing);
            return timing;
        }

        pub fn pause(self: *Self) Suspension {
            const was = self.suspended;
            self.suspended = true;
            return .{ .plan = self, .was = was };
        }

        pub const Suspension = struct {
            plan: *Self,
            was: bool,

            pub fn end(self: Suspension) void {
                self.plan.suspended = self.was;
            }
        };

        pub fn totals(self: *const Self) Counts {
            var total: Counts = .{};
            for (self.counts) |count| {
                total.reached += count.reached;
                total.before += count.before;
                total.after += count.after;
            }
            return total;
        }

        pub fn print(self: *const Self) void {
            inline for (tags, self.counts) |point, count| {
                std.debug.print("fault {s}: {d} reached, {d} before, {d} after\n", .{ @tagName(point), count.reached, count.before, count.after });
            }
            if (self.armed) |fault| std.debug.print("fault still armed: {s}, {d} matching calls left\n", .{ if (fault.point) |p| @tagName(p) else "any point", fault.skip });
        }

        fn index(point: Point) usize {
            inline for (tags, 0..) |p, i| if (point == p) return i;
            unreachable;
        }
    };
}

const TestPoint = enum(u8) { read, write = 7 };
const Plan = FaultPlan(TestPoint);

test "a one-shot fault counts only matching calls and fires once" {
    var plan: Plan = .{};
    plan.arm(.write, 1, .after);
    try std.testing.expectEqual(null, plan.hit(.read));
    try std.testing.expectEqual(null, plan.hit(.write));
    try std.testing.expectEqual(null, plan.hit(.read));
    try std.testing.expectEqual(Timing.after, plan.hit(.write).?);
    try std.testing.expectEqual(null, plan.hit(.write));
    try std.testing.expectEqual(@as(u64, 3), plan.counts[1].reached);
    try std.testing.expectEqual(@as(u64, 1), plan.counts[1].after);
}

test "nested suspension leaves the armed occurrence and counts alone" {
    var plan: Plan = .{};
    plan.arm(null, 0, .before);
    {
        const outer = plan.pause();
        defer outer.end();
        {
            const inner = plan.pause();
            defer inner.end();
            try std.testing.expectEqual(null, plan.hit(.write));
        }
        try std.testing.expectEqual(null, plan.hit(.read));
    }
    try std.testing.expectEqual(Timing.before, plan.hit(.read).?);
    try std.testing.expectEqual(@as(u64, 1), plan.counts[0].reached);
    try std.testing.expectEqual(@as(u64, 0), plan.counts[1].reached);
}

test "disarming and replacing an armed fault" {
    var plan: Plan = .{};
    plan.arm(.read, 0, .before);
    plan.arm(.write, 0, .after);
    try std.testing.expectEqual(null, plan.hit(.read));
    plan.disarm();
    try std.testing.expectEqual(null, plan.hit(.write));
}

test "totals retain reached points and both timings across rearming" {
    var plan: Plan = .{};
    plan.arm(.write, 0, .after);
    _ = plan.hit(.write);
    _ = plan.hit(.read);
    plan.arm(.read, 0, .before);
    _ = plan.hit(.read);
    try std.testing.expectEqualDeep(Plan.Counts{ .reached = 3, .before = 1, .after = 1 }, plan.totals());
}

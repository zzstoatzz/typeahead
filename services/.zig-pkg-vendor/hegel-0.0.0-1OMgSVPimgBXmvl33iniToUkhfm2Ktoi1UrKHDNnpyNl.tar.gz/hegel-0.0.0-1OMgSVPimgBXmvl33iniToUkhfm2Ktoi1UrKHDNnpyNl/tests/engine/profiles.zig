const std = @import("std");
const p = @import("profiles");
const gpa = std.testing.allocator;
fn noEnv(_: ?*anyopaque, _: []const u8) ?[]const u8 {
    return null;
}
const env: @import("profiles").Environment = .{ .context = null, .get = noEnv };
test "default alias skips profiles already in the inheritance chain" {
    const profiles = [_]p.NamedProfile{
        .{ .name = "custom", .delta = .{ .test_cases = 12 } },
        .{ .name = "ci", .delta = .{ .extends = "default", .print_blob = false } },
    };
    const config: p.Config = .{ .default = "custom", .profiles = &profiles };
    const candidates: p.Candidates = .{ .toml = "custom", .environment = "ci" };
    const result = try p.resolve(gpa, "default", config, &.{}, .{}, candidates);
    try std.testing.expectEqual(@as(u64, 12), result.test_cases);
    try std.testing.expect(result.derandomize and !result.print_blob);
    try std.testing.expect(result.database == .disabled);
}
test "registered snapshots terminate inheritance and config applies above them" {
    const registered = [_]p.NamedProfile{.{ .name = "special", .delta = p.ProfileDelta.snapshot(.{ .test_cases = 5, .seed = 7 }) }};
    const configured = [_]p.NamedProfile{.{ .name = "special", .delta = .{ .test_cases = 99 } }};
    const result = try p.resolve(gpa, "special", .{ .profiles = &configured }, &registered, .{ .derandomize = true }, .{});
    try std.testing.expectEqual(@as(u64, 99), result.test_cases);
    try std.testing.expectEqual(@as(?u64, 7), result.seed);
    try std.testing.expect(!result.derandomize);
    const extending = [_]p.NamedProfile{.{ .name = "special", .delta = .{ .extends = "base" } }};
    try std.testing.expectError(error.ExtendsOnRegistered, p.resolve(gpa, "special", .{ .profiles = &extending }, &registered, .{}, .{}));
}
test "validation rejects unused broken profiles but ignores volatile default for base" {
    const broken = [_]p.NamedProfile{.{ .name = "unused", .delta = .{ .extends = "absent" } }};
    try std.testing.expectError(error.UnknownExtends, p.validate(gpa, .{ .profiles = &broken }, &.{}, .{}));
    const cycle = [_]p.NamedProfile{ .{ .name = "a", .delta = .{ .extends = "b" } }, .{ .name = "b", .delta = .{ .extends = "a" } } };
    try std.testing.expectError(error.ExtendsCycle, p.validate(gpa, .{ .profiles = &cycle }, &.{}, .{}));
    try p.validate(gpa, .{}, &.{}, .{ .overridden = "missing" });
    _ = try p.resolve(gpa, "base", .{}, &.{}, .{}, .{ .overridden = "missing" });
    try std.testing.expectError(error.UnknownProfile, p.resolve(gpa, "default", .{}, &.{}, .{}, .{ .overridden = "missing", .toml = "ci" }));
    try std.testing.expectError(error.CircularDefault, p.resolve(gpa, "default", .{}, &.{}, .{}, .{ .overridden = "default" }));
}
fn resolveWithFailure(allocator: std.mem.Allocator) !void {
    const configured = [_]p.NamedProfile{.{ .name = "custom", .delta = .{ .test_cases = 8 } }};
    const result = try p.settingsFor(allocator, "custom", .{ .profiles = &configured }, &.{}, null, env);
    try std.testing.expectEqual(@as(u64, 8), result.test_cases);
}
test "profile walks release their allocation on every failure" {
    try std.testing.checkAllAllocationFailures(gpa, resolveWithFailure, .{});
}

const std = @import("std");
const n = @import("native");
const gpa = std.testing.allocator;
test "targeting records strict maxima and sorts seed labels" {
    var state = n.targeting.TargetingState.init(gpa);
    defer state.deinit();
    var scores: std.StringHashMapUnmanaged(f64) = .empty;
    defer scores.deinit(gpa);
    try scores.put(gpa, "z", 1);
    try scores.put(gpa, "a", 3);
    const choices = [_]n.choices.ChoiceValue{.{ .boolean = true }};
    try state.record(&choices, &scores);
    try scores.put(gpa, "a", 2);
    try state.record(&.{}, &scores);
    try std.testing.expectEqual(@as(f64, 3), state.best("a").?.score);
    try std.testing.expectEqual(@as(usize, 1), state.best("a").?.choices.len);
    const seeds = try state.seeds(gpa);
    defer {
        for (seeds) |entry| {
            gpa.free(entry.label);
            n.choices.deinitValues(gpa, entry.choices);
        }
        gpa.free(seeds);
    }
    try std.testing.expectEqualStrings("a", seeds[0].label);
}
test "byte targeting preserves width and rejects negative or oversized proposals" {
    var node = n.choices.ChoiceNode.bytes(.{ .min_size = 2, .max_size = 2 }, try gpa.dupe(u8, &.{ 0, 255 }), false);
    defer node.deinit(gpa);
    var raised = (try n.targeting.stepChoice(gpa, &node, 1)).?;
    defer raised.deinit(gpa);
    try std.testing.expectEqualSlices(u8, &.{ 1, 0 }, raised.bytes);
    try std.testing.expect(try n.targeting.stepChoice(gpa, &node, -256) == null);
    try std.testing.expect(try n.targeting.stepChoice(gpa, &node, 65536) == null);
}

const std = @import("std");
const m = @import("math");
test "pinned Rust libm exact IEEE corpus" {
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/math.tsv"), '\n');
    var checked: usize = 0;
    while (lines.next()) |line| {
        var cols = std.mem.splitScalar(u8, line, '\t');
        const name = cols.next().?;
        const a: u64 = try std.fmt.parseInt(u64, cols.next().?, 16);
        const b: u64 = try std.fmt.parseInt(u64, cols.next().?, 16);
        const expected: u64 = try std.fmt.parseInt(u64, cols.next().?, 16);
        const x: f64 = @bitCast(a);
        const y: f64 = @bitCast(b);
        const actual: f64 = blk: {
            inline for (.{ "log", "exp", "log2", "log1p", "expm1", "sqrt", "atan", "sin", "cos", "floor", "ceil", "round" }) |f| {
                if (std.mem.eql(u8, name, f)) break :blk @field(m, f)(x);
            }
            if (std.mem.eql(u8, name, "pow")) break :blk m.pow(x, y);
            if (std.mem.eql(u8, name, "copysign")) break :blk m.copysign(x, y);
            continue;
        };
        const bits: u64 = @bitCast(actual);
        if (bits != expected) {
            std.debug.print("{s}({x},{x}) expected {x} got {x}\n", .{ name, a, b, expected, bits });
            return error.MathMismatch;
        }
        checked += 1;
    }
    try std.testing.expect(checked == 86268);
}

// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const api = @import("api");
const t = api.types;
const s = api.settings_api;
const cases = api.test_cases;
const d = api.draw_api;
const r = api.runs;
fn expect(rc: c_int) !void {
    try std.testing.expectEqual(t.HEGEL_OK, rc);
}
fn base(ctx: ?*api.HegelContext) !*api.HegelSettings {
    var settings: ?*api.HegelSettings = null;
    try expect(s.hegel_settings_new_for_profile(ctx, "base", &settings));
    try expect(s.hegel_settings_set_database(ctx, settings, ""));
    return settings.?;
}
fn simplestBlob(ctx: ?*api.HegelContext, settings: *api.HegelSettings) !*api.HegelTestCase {
    var tc: ?*api.HegelTestCase = null;
    // Version2 deterministic payload: [Boolean true, Integer5, Bytes [1,2]].
    const choices = @import("api").state.sampling.choices;
    var n = try choices.BigInt.fromInt(std.testing.allocator, @as(u8, 5));
    defer n.deinit();
    var bytes = [_]u8{ 1, 2 };
    const raw = (try api.blob_mod.encodeFailure(std.testing.allocator, &.{ .{ .boolean = true }, .{ .integer = n }, .{ .bytes = &bytes } })).?;
    defer std.testing.allocator.free(raw);
    const blob = try std.testing.allocator.dupeSentinel(u8, raw, 0);
    defer std.testing.allocator.free(blob);
    try expect(cases.hegel_test_case_from_blob(ctx, settings, blob.ptr, null, null, &tc));
    return tc.?;
}
test "C settings snapshots roundtrip enum masks, seed and database ownership" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    try expect(s.hegel_settings_set_seed(ctx, settings, 99, true));
    var seed: u64 = 0;
    var has = false;
    try expect(s.hegel_settings_get_seed(ctx, settings, &seed, &has));
    try std.testing.expect(has);
    try std.testing.expectEqual(@as(u64, 99), seed);
    try expect(s.hegel_settings_set_backend(ctx, settings, t.HEGEL_BACKEND_URANDOM));
    var backend: c_uint = 0;
    try expect(s.hegel_settings_get_backend(ctx, settings, &backend));
    try std.testing.expectEqual(@as(c_uint, t.HEGEL_BACKEND_URANDOM), backend);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, s.hegel_settings_set_backend(ctx, settings, 999));
    try std.testing.expectEqualStrings("hegel_settings_set_backend: unknown backend 999", std.mem.span(api.hegel_context_last_error(ctx)));
    try expect(s.hegel_settings_set_phases(ctx, settings, t.HEGEL_PHASE_REUSE | t.HEGEL_PHASE_GENERATE));
    var phases: u32 = 0;
    try expect(s.hegel_settings_get_phases(ctx, settings, &phases));
    try std.testing.expectEqual(@as(u32, 6), phases);
    try expect(s.hegel_settings_set_database(ctx, settings, "somewhere"));
    var database: [*c]const u8 = null;
    try expect(s.hegel_settings_get_database(ctx, settings, &database));
    try std.testing.expectEqualStrings("somewhere", std.mem.span(database));
    try expect(s.hegel_settings_set_database(ctx, settings, null));
    try expect(s.hegel_settings_get_database(ctx, settings, &database));
    try std.testing.expect(database == null);
}
test "C standalone blob draws and caller-owned buffers outlive handles" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    const tc = try simplestBlob(ctx, settings);
    var b = false;
    try expect(d.hegel_generate_boolean(ctx, tc, 0.5, false, false, &b));
    try std.testing.expect(b);
    var n: i64 = 0;
    try expect(d.hegel_generate_integer(ctx, tc, 0, 10, &n));
    try std.testing.expectEqual(@as(i64, 5), n);
    var bytes: t.hegel_generate_bytes_result_t = .{};
    try expect(d.hegel_generate_bytes(ctx, tc, 0, 5, &bytes));
    try expect(cases.hegel_mark_complete(ctx, tc, t.HEGEL_STATUS_VALID, null));
    try std.testing.expectEqual(t.HEGEL_E_ALREADY_COMPLETE, cases.hegel_mark_complete(ctx, tc, t.HEGEL_STATUS_VALID, null));
    try expect(cases.hegel_test_case_free(ctx, tc));
    try std.testing.expectEqualSlices(u8, &.{ 1, 2 }, bytes.data[0..bytes.len]);
    try expect(d.hegel_generate_bytes_result_free(ctx, &bytes));
    try expect(d.hegel_generate_bytes_result_free(ctx, &bytes));
    try std.testing.expect(bytes.data == null);
}
test "C pull run refuses unconcluded advancement and snapshots survive run free" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    try expect(s.hegel_settings_set_test_cases(ctx, settings, 3));
    try expect(s.hegel_settings_set_phases(ctx, settings, t.HEGEL_PHASE_GENERATE));
    try expect(s.hegel_settings_set_seed(ctx, settings, 10, true));
    var run: ?*r.HegelRun = null;
    try expect(r.hegel_run_start(ctx, settings, null, null, &run));
    var tc: ?*api.HegelTestCase = null;
    try expect(r.hegel_next_test_case(ctx, run, &tc));
    const first = tc.?;
    var ignored: ?*api.HegelTestCase = null;
    try std.testing.expectEqual(t.HEGEL_E_NOT_COMPLETE, r.hegel_next_test_case(ctx, run, &ignored));
    try std.testing.expect(ignored == null);
    var b = false;
    try expect(d.hegel_generate_boolean(ctx, first, 0.5, false, false, &b));
    try expect(cases.hegel_mark_complete(ctx, first, t.HEGEL_STATUS_VALID, null));
    while (true) {
        try expect(r.hegel_next_test_case(ctx, run, &tc));
        if (tc == null) break;
        _ = d.hegel_generate_boolean(ctx, tc, 0.5, false, false, &b);
        try expect(cases.hegel_mark_complete(ctx, tc, t.HEGEL_STATUS_VALID, null));
        try expect(cases.hegel_test_case_free(ctx, tc));
    }
    var result: ?*r.HegelRunResult = null;
    try expect(r.hegel_run_result(ctx, run, &result));
    try expect(r.hegel_run_free(ctx, run));
    try expect(cases.hegel_test_case_free(ctx, first));
    var status: c_uint = 99;
    try expect(r.hegel_run_result_status(ctx, result, &status));
    try std.testing.expectEqual(@as(c_uint, t.HEGEL_RUN_STATUS_PASSED), status);
    try expect(r.hegel_run_result_free(ctx, result));
}
test "C run cancellation concludes in-flight family while late cloned handles survive" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    var run: ?*r.HegelRun = null;
    try expect(r.hegel_run_start(ctx, settings, null, null, &run));
    var tc: ?*api.HegelTestCase = null;
    try expect(r.hegel_next_test_case(ctx, run, &tc));
    var child: ?*api.HegelTestCase = null;
    try expect(cases.hegel_test_case_clone(ctx, tc, &child));
    try expect(r.hegel_run_free(ctx, run));
    var b = false;
    try std.testing.expectEqual(t.HEGEL_E_ALREADY_COMPLETE, d.hegel_generate_boolean(ctx, child, 0.5, false, false, &b));
    try expect(cases.hegel_test_case_free(ctx, tc));
    try expect(cases.hegel_test_case_free(ctx, child));
}
test "C typed string and stateful constructors preserve nullable defaults and constraints" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    try expect(s.hegel_settings_set_phases(ctx, settings, t.HEGEL_PHASE_GENERATE));
    var run: ?*r.HegelRun = null;
    try expect(r.hegel_run_start(ctx, settings, null, null, &run));
    defer _ = r.hegel_run_free(ctx, run);
    var tc: ?*api.HegelTestCase = null;
    try expect(r.hegel_next_test_case(ctx, run, &tc));
    defer _ = cases.hegel_test_case_free(ctx, tc);
    var text: ?*api.strings.HegelStringGenerator = null;
    try expect(api.strings.hegel_string_generator_text(ctx, 2, 4, "ascii", 0, 127, null, 0, null, 0, null, 0, null, 0, &text));
    defer _ = api.strings.hegel_string_generator_free(ctx, text);
    var value: t.hegel_generate_string_result_t = .{};
    try expect(api.strings.hegel_generate_string(ctx, tc, text, &value));
    try std.testing.expect(value.len >= 2 and value.len <= 4);
    try expect(d.hegel_generate_string_result_free(ctx, &value));
    var regex: ?*api.strings.HegelStringGenerator = null;
    const pattern = "a{2,4}[0-9]";
    try expect(api.strings.hegel_string_generator_regex(ctx, pattern.ptr, pattern.len, true, null, &regex));
    defer _ = api.strings.hegel_string_generator_free(ctx, regex);
    try expect(api.strings.hegel_generate_string(ctx, tc, regex, &value));
    try std.testing.expect(value.len >= 3 and value.len <= 5);
    for (value.data[0 .. value.len - 1]) |ch| try std.testing.expectEqual(@as(u8, 'a'), ch);
    try std.testing.expect(std.ascii.isDigit(value.data[value.len - 1]));
    try expect(d.hegel_generate_string_result_free(ctx, &value));
    var domain: ?*api.strings.HegelStringGenerator = null;
    try expect(api.strings.hegel_string_generator_domain(ctx, 64, &domain));
    defer _ = api.strings.hegel_string_generator_free(ctx, domain);
    try expect(api.strings.hegel_generate_string(ctx, tc, domain, &value));
    try std.testing.expect(value.len <= 64);
    try std.testing.expect(std.mem.indexOfScalar(u8, value.data[0..value.len], '.') != null);
    try expect(d.hegel_generate_string_result_free(ctx, &value));
    var uuid: [16]u8 = undefined;
    try expect(d.hegel_generate_uuid(ctx, tc, 4, true, &uuid));
    try std.testing.expectEqual(@as(u8, 4), uuid[6] >> 4);
    try std.testing.expectEqual(@as(u8, 0x80), uuid[8] & 0xc0);
    var machine: ?*api.stateful.HegelStateMachine = null;
    var concurrency: i64 = 0;
    var names_array = [_][*c]const u8{"rule"};
    var groups = [_]i64{7};
    try expect(api.stateful.hegel_new_state_machine(ctx, tc, &names_array, &groups, null, 1, null, null, 0, 1, 1, 1, &machine, &concurrency));
    defer _ = api.stateful.hegel_state_machine_free(ctx, machine);
    try std.testing.expectEqual(@as(i64, 1), concurrency);
    var group: i64 = 0;
    try expect(api.stateful.hegel_state_machine_next_group(ctx, tc, machine, &group));
    try std.testing.expectEqual(@as(i64, 7), group);
    var rule: i64 = 99;
    try expect(api.stateful.hegel_state_machine_next_rule(ctx, tc, machine, 0, &rule));
    try std.testing.expectEqual(@as(i64, 0), rule);
    var pool: ?*api.stateful.HegelPool = null;
    try expect(api.stateful.hegel_new_pool(ctx, tc, &pool));
    defer _ = api.stateful.hegel_pool_free(ctx, pool);
    var id: i64 = -1;
    try expect(api.stateful.hegel_pool_add(ctx, tc, pool, &id));
    try std.testing.expectEqual(@as(i64, 0), id);
    try expect(api.stateful.hegel_pool_generate(ctx, tc, pool, true, &id));
    try std.testing.expectEqual(@as(i64, 0), id);
    try std.testing.expectEqual(t.HEGEL_E_ASSUME, api.stateful.hegel_pool_generate(ctx, tc, pool, false, &id));
    try expect(cases.hegel_mark_complete(ctx, tc, t.HEGEL_STATUS_VALID, null));
}
test "C invalid inputs do not consume draw positions or lose error precedence" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    const settings = try base(ctx);
    defer _ = s.hegel_settings_free(ctx, settings);
    const tc = try simplestBlob(ctx, settings);
    defer _ = cases.hegel_test_case_free(ctx, tc);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_HANDLE, d.hegel_generate_boolean(ctx, null, 0.5, false, false, null));
    var n: i64 = 0;
    var encoding = [_]u8{0};
    var out: [16]u8 = undefined;
    var written: usize = 0;
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, d.hegel_generate_integer_big(ctx, tc, &encoding, 0, &encoding, 1, &out, out.len, &written));
    try std.testing.expectEqualStrings("hegel_generate_integer_big: bound encodings must not be empty", std.mem.span(api.hegel_context_last_error(ctx)));
    var b = false;
    try expect(d.hegel_generate_boolean(ctx, tc, 0.5, false, false, &b));
    try std.testing.expect(b);
    try expect(d.hegel_generate_integer(ctx, tc, 0, 10, &n));
    try std.testing.expectEqual(@as(i64, 5), n);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, cases.hegel_target(ctx, tc, 1, null));
    var generator: ?*api.strings.HegelStringGenerator = null;
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, api.strings.hegel_string_generator_regex(ctx, "[", 1, true, null, &generator));
    try std.testing.expect(generator == null);
    tc.local.lock();
    try std.testing.expectEqual(t.HEGEL_E_CONCURRENT_USE, d.hegel_generate_boolean(ctx, tc, 0.5, false, false, null));
    tc.local.unlock();
    try expect(cases.hegel_mark_complete(ctx, tc, t.HEGEL_STATUS_VALID, null));
    try std.testing.expectEqual(t.HEGEL_E_ALREADY_COMPLETE, d.hegel_generate_boolean(ctx, tc, 0.5, false, false, null));
}

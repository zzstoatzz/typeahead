const std = @import("std");
const s = @import("sampling");
const A = std.testing.allocator;
fn parse(comptime T: type, t: []const u8) !T {
    return std.fmt.parseInt(T, t, 10);
}
test "seeded samplers match pinned Rust" {
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/sampling.tsv"), '\n');
    var random = s.EngineRng.seeded(0);
    var params: s.FloatGenerationParameters = undefined;
    var alphabet = try s.IntervalSet.init(A, &.{ .{ .start = 0, .end = 0xd7ff }, .{ .start = 0xe000, .end = 0x10ffff } });
    defer alphabet.deinit();
    var failures: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const kind = fields.next().?[0];
        const seed = try parse(u64, fields.next().?);
        const mode = if (kind == 'F') try parse(u8, fields.next().?) else 0;
        const draw = try parse(usize, fields.next().?);
        if (draw == 0) {
            random = s.EngineRng.seeded(seed);
            if (kind == 'F') {
                if (mode >= 4) {
                    var weights: [17]f64 = undefined;
                    @memset(&weights, 0);
                    weights[(mode - 4) / 2] = 1;
                    params = .fromWeights(weights);
                } else params = if (mode >= 2) try s.FloatGenerationParameters.draw(&random) else .defaults();
            }
        }
        const expected = fields.next().?;
        switch (kind) {
            'F' => {
                const got = try s.biasedFloatSample(.{ .min_value = -std.math.inf(f64), .max_value = std.math.inf(f64), .allow_nan = true, .allow_infinity = true, .smallest_nonzero_magnitude = @bitCast(@as(u64, 1)) }, if (mode % 2 == 0) .F64 else .F32, &random, params);
                if (@as(u64, @bitCast(got)) != try parse(u64, expected)) {
                    if (failures < 20) std.debug.print("float seed={} mode={} draw={} expected={s} got={}\n", .{ seed, mode, draw, expected, @as(u64, @bitCast(got)) });
                    failures += 1;
                }
            },
            'I' => {
                const got = try s.biasedI128Sample(-1000000000000000000, 1000000000000000000, &random, .defaults());
                if (got != try parse(i128, expected)) {
                    if (failures < 20) std.debug.print("integer seed={} draw={} expected={s} got={}\n", .{ seed, draw, expected, got });
                    failures += 1;
                }
            },
            'G' => {
                var one = try s.choices.BigInt.fromInt(A, @as(u8, 1));
                defer one.deinit();
                var max = try one.shl(A, 256);
                defer max.deinit();
                var min = try max.negate(A);
                defer min.deinit();
                var got = try s.biguintSampleInRange(A, min, max, &random, .defaults());
                defer got.deinit();
                var want = try s.choices.BigInt.fromString(A, 10, expected);
                defer want.deinit();
                if (!got.eql(want)) {
                    if (failures < 20) std.debug.print("bigint seed={} draw={} expected={s}\n", .{ seed, draw, expected });
                    failures += 1;
                }
            },
            'B' => {
                const got = try s.biasedBytesSample(A, .{ .min_size = 0, .max_size = 32 }, &random);
                defer A.free(got);
                const encoded = try std.fmt.allocPrint(A, "{x}", .{got});
                defer A.free(encoded);
                if (!std.mem.eql(u8, if (got.len == 0) "_" else encoded, expected)) {
                    if (failures < 20) std.debug.print("bytes seed={} draw={} expected={s} got={s}\n", .{ seed, draw, expected, encoded });
                    failures += 1;
                }
            },
            'S' => {
                const got = try s.biasedStringSample(A, .{ .intervals = &alphabet, .min_size = 0, .max_size = 32 }, &random);
                defer A.free(got);
                var parts = std.mem.splitScalar(u8, expected, ',');
                var differs = false;
                if (std.mem.eql(u8, expected, "_")) {
                    differs = got.len != 0;
                } else {
                    for (got) |cp| {
                        const part = parts.next() orelse {
                            differs = true;
                            break;
                        };
                        if (cp != try std.fmt.parseInt(u32, part, 16)) differs = true;
                    }
                    if (parts.next() != null) differs = true;
                }
                if (differs) {
                    if (failures < 20) std.debug.print("string seed={} draw={} expected={s} got={any}\n", .{ seed, draw, expected, got });
                    failures += 1;
                }
            },
            else => return error.UnknownKind,
        }
    }
    try std.testing.expectEqual(@as(usize, 0), failures);
}

fn allocationPaths(allocator: std.mem.Allocator) !void {
    var rng = s.EngineRng.seeded(42);
    var one = try s.choices.BigInt.fromInt(allocator, @as(u8, 1));
    defer one.deinit();
    var min = try one.shl(allocator, 129);
    defer min.deinit();
    var max = try min.addInt(allocator, @as(u8, 10));
    defer max.deinit();
    var number = try s.biguintSampleInRange(allocator, min, max, &rng, .defaults());
    defer number.deinit();
    try std.testing.expect(number.order(min) != .lt and number.order(max) != .gt);
    var alphabet = try s.IntervalSet.init(allocator, &.{.{ .start = 'A', .end = 'z' }});
    defer alphabet.deinit();
    const text = try s.biasedStringSample(allocator, .{ .intervals = &alphabet, .min_size = 2, .max_size = 10 }, &rng);
    defer allocator.free(text);
    const bytes = try s.biasedBytesSample(allocator, .{ .min_size = 2, .max_size = 10 }, &rng);
    defer allocator.free(bytes);
    const encoded = try s.codepointsToString(allocator, &.{ 'A', 0x1f600, 0xd800, 0x110000 });
    defer allocator.free(encoded);
    try std.testing.expectEqualStrings("A😀", encoded);
}
test "sampler ownership survives every allocation failure" {
    try std.testing.checkAllAllocationFailures(A, allocationPaths, .{});
}
test "recursive arity bookkeeping follows completed branches" {
    var state: s.RecursionState = .{ .allocator = A, .max_depth = 10, .max_leaves = 2, .base_span_depth = 0, .target = 2, .branch_probability = 0.5 };
    defer state.deinit();
    state.observeDecision(0);
    try state.observeBranch(0);
    state.observeDecision(1);
    try state.observeBranch(1);
    state.observeDecision(2);
    try std.testing.expect(state.countLeaf());
    state.observeDecision(2);
    try std.testing.expect(state.countLeaf());
    state.observeDecision(1);
    try std.testing.expectEqual(@as(u64, 2), state.closed_children);
    try std.testing.expectEqual(@as(u64, 1), state.closed_branches);
    try std.testing.expect(!state.countLeaf());
    state.closeRemainingBranches();
    try std.testing.expectEqual(@as(u64, 4), state.closed_children);
    try std.testing.expectEqual(@as(u64, 2), state.closed_branches);
}

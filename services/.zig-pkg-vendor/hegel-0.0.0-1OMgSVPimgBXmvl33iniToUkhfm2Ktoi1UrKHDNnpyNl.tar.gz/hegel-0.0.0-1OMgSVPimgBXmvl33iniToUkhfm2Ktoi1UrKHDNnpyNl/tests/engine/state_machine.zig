// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const Ntc = native.state.NativeTestCase;
const Machine = native.state_machine.NativeStateMachine;
const gpa = std.testing.allocator;
test "simplest sequential machine runs one rule and stops at next round" {
    var tc = try Ntc.forSimplest(gpa, 100);
    defer tc.deinit();
    var machine = try Machine.init(&tc, &.{ 7, 7 }, &.{ 1, 2 }, &.{ true, false }, 1, 1, 50);
    defer machine.deinit();
    try std.testing.expectError(error.InvalidArgument, machine.nextRule(&tc, 0));
    try std.testing.expectEqual(@as(?i64, 7), try machine.nextGroup(&tc));
    try std.testing.expectEqual(@as(?i64, 0), try machine.nextRule(&tc, 0));
    try std.testing.expectEqual(@as(?i64, null), try machine.nextRule(&tc, 0));
    try std.testing.expectEqual(@as(?i64, null), try machine.nextGroup(&tc));
    const count = tc.nodes.items.len;
    try std.testing.expect(try machine.shouldCheckInvariant(&tc, 0));
    try std.testing.expectEqual(count, tc.nodes.items.len);
    try std.testing.expect(!(try machine.shouldCheckInvariant(&tc, 1)));
    try std.testing.expectError(error.InvalidArgument, machine.shouldCheckInvariant(&tc, -1));
    try std.testing.expectError(error.InvalidArgument, machine.nextRule(&tc, 1));
}
test "rejections refund sequential rounds and cannot be double reported" {
    var tc = try Ntc.newRandom(gpa, .seeded(42));
    defer tc.deinit();
    var machine = try Machine.init(&tc, &.{9}, &.{1}, &.{}, 1, 1, 1);
    defer machine.deinit();
    try std.testing.expectEqual(@as(?i64, 9), try machine.nextGroup(&tc));
    try std.testing.expectError(error.InvalidArgument, machine.ruleRejected(0));
    try std.testing.expectEqual(@as(?i64, 0), try machine.nextRule(&tc, 0));
    try machine.ruleRejected(0);
    try std.testing.expectError(error.InvalidArgument, machine.ruleRejected(0));
    try std.testing.expectEqual(@as(?i64, 9), try machine.nextGroup(&tc));
    try std.testing.expectEqual(@as(?i64, 0), try machine.nextRule(&tc, 0));
    try std.testing.expectEqual(@as(?i64, null), try machine.nextGroup(&tc));
}
test "concurrent groups never hand out a foreign rule and workers remain bounded" {
    for (0..20) |seed| {
        var tc = try Ntc.newRandom(gpa, .seeded(seed));
        defer tc.deinit();
        var machine = try Machine.init(&tc, &.{ 4, 8, 4, 8 }, &.{ 1, 2, 3, 4 }, &.{}, 2, 2, 8);
        defer machine.deinit();
        var rounds: usize = 0;
        while (try machine.nextGroup(&tc)) |group| {
            rounds += 1;
            for (0..2) |worker| {
                var count: usize = 0;
                while (try machine.nextRule(&tc, @intCast(worker))) |rule| {
                    try std.testing.expectEqual(group, ([_]i64{ 4, 8, 4, 8 })[@intCast(rule)]);
                    count += 1;
                }
                try std.testing.expect(count <= 5);
            }
        }
        try std.testing.expect(rounds >= 1 and rounds <= 8);
    }
}
fn allocationExercise(allocator: std.mem.Allocator) !void {
    var tc = try Ntc.forSimplest(allocator, 100);
    defer tc.deinit();
    var machine = try Machine.init(&tc, &.{ 4, 8, 4 }, &.{ 1, 2, 3 }, &.{false}, 2, 2, 3);
    defer machine.deinit();
    _ = try machine.nextGroup(&tc);
    _ = try machine.nextRule(&tc, 0);
    _ = try machine.shouldCheckInvariant(&tc, 0);
}
test "construction and draw OOM unwind every group and worker" {
    try std.testing.checkAllAllocationFailures(gpa, allocationExercise, .{});
}

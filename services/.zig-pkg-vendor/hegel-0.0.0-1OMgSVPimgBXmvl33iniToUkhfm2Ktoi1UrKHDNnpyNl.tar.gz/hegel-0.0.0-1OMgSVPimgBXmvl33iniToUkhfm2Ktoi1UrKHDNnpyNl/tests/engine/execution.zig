const std = @import("std");
const n = @import("native");
fn exercise(gpa: std.mem.Allocator) !void {
    var original = n.execution.RunResult.fromCached(try n.exec_cache.CachedRun.init(gpa, .interesting, "origin", &.{}, &.{}));
    defer original.deinit(gpa);
    original.events = try gpa.alloc(n.execution.Event, 2);
    original.events[0] = .{ .label = try gpa.dupe(u8, "first"), .value = 1 };
    original.events[1] = .{ .label = try gpa.dupe(u8, "second"), .value = null };
    const key = try gpa.dupe(u8, "target");
    original.target_observations.put(gpa, key, 3) catch |err| {
        gpa.free(key);
        return err;
    };
    original.divergence = .{ .stream = try gpa.dupe(usize, &.{ 0, 2 }), .position = 7 };
    var copy = try original.deepClone(gpa);
    defer copy.deinit(gpa);
    try std.testing.expectEqualStrings("origin", copy.origin.?);
    try std.testing.expectEqualStrings("second", copy.events[1].label);
    try std.testing.expectEqual(@as(f64, 3), copy.target_observations.get("target").?);
    try std.testing.expectEqualSlices(usize, &.{ 0, 2 }, copy.divergence.?.stream);
}
test "execution snapshots own their nested metadata" {
    try exercise(std.testing.allocator);
}
fn cloneWithFailure(gpa: std.mem.Allocator, source: *const n.execution.RunResult) !void {
    var copy = try source.deepClone(gpa);
    defer copy.deinit(gpa);
    try std.testing.expectEqualStrings("second", copy.events[1].label);
}
test "execution clone releases partially copied event metadata" {
    const gpa = std.testing.allocator;
    var original = n.execution.RunResult.fromCached(try n.exec_cache.CachedRun.init(gpa, .interesting, "origin", &.{}, &.{}));
    defer original.deinit(gpa);
    original.events = try gpa.alloc(n.execution.Event, 2);
    original.events[0] = .{ .label = try gpa.dupe(u8, "first"), .value = 1 };
    original.events[1] = .{ .label = try gpa.dupe(u8, "second"), .value = null };
    try std.testing.checkAllAllocationFailures(gpa, cloneWithFailure, .{&original});
}
const Driver = struct {
    complete: bool,
    fn run(context: *anyopaque, handle: *n.state.NativeTestCaseHandle) !void {
        const self: *Driver = @ptrCast(@alignCast(context));
        const tc = handle.lock();
        defer handle.unlock();
        _ = try tc.weighted(0.5, null);
        try tc.family.target("score", 12);
        try tc.family.event("visited", null);
        if (self.complete) {
            try tc.conclude(.interesting, "failure");
            try tc.freeze();
        }
    }
};
fn executeWithFailure(gpa: std.mem.Allocator) !void {
    var driver: Driver = .{ .complete = true };
    const executor: n.execution.Executor = .{ .context = &driver, .call = Driver.run };
    var result = try executor.execute(gpa, try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer result.deinit(gpa);
    try std.testing.expectEqualStrings("failure", result.origin.?);
    try std.testing.expectEqual(@as(f64, 12), result.target_observations.get("score").?);
    try std.testing.expectEqualStrings("visited", result.events[0].label);
    try std.testing.expectEqual(@as(usize, 1), result.nodes.len);
}
test "execution enforces completion and snapshots observations" {
    const gpa = std.testing.allocator;
    try executeWithFailure(gpa);
    var driver: Driver = .{ .complete = false };
    const executor: n.execution.Executor = .{ .context = &driver, .call = Driver.run };
    try std.testing.expectError(error.UnconcludedCase, executor.execute(gpa, try n.state.NativeTestCase.forSimplest(gpa, 100)));
    try std.testing.checkAllAllocationFailures(gpa, executeWithFailure, .{});
}

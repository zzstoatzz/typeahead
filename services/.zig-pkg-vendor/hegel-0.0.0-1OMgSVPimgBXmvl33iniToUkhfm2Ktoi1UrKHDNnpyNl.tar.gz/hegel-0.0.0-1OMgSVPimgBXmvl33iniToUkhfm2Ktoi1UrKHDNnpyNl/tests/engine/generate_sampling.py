import argparse
import json
import os
import pathlib
import subprocess
import tomllib

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
HERE = pathlib.Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description="Regenerate sampler fixtures through the pinned Rust __bench API.")
    parser.add_argument("--upstream", type=pathlib.Path, default=pathlib.Path.home() / ".cache/hegel-zig" / ("hegel-rust-" + PIN))
    parser.add_argument("--work", type=pathlib.Path, default=HERE.parents[1] / "work/native-sampling-oracle")
    parser.add_argument("--output", type=pathlib.Path, default=HERE / "fixtures/sampling.tsv")
    args = parser.parse_args()
    upstream = args.upstream.resolve()
    revision = subprocess.check_output(["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True).strip()
    if revision != PIN:
        raise RuntimeError(f"expected upstream {PIN}, got {revision}")
    (args.work / "src").mkdir(parents=True, exist_ok=True)
    (args.work / "Cargo.toml").write_text('[package]\nname="native-sampling-oracle"\nversion="0.0.0"\nedition="2024"\n[dependencies]\nhegel_c={package="hegeltest-c",path=' + json.dumps(str(upstream / "hegel-c")) + ',features=["__bench"]}\n')
    (args.work / "Cargo.lock").write_bytes((upstream / "Cargo.lock").read_bytes())
    (args.work / "src/main.rs").write_bytes((HERE / "sampling_oracle.rs.in").read_bytes())
    env = dict(os.environ, CARGO_TARGET_DIR=str(upstream / "target"))
    # Cargo prunes workspace-only packages while retaining existing versions.
    subprocess.run(["cargo", "metadata", "--offline", "--format-version=1", "--manifest-path", str(args.work / "Cargo.toml")], check=True, env=env, stdout=subprocess.DEVNULL)
    pinned = {(p["name"], p["version"]) for p in tomllib.loads((upstream / "Cargo.lock").read_text())["package"]}
    actual = tomllib.loads((args.work / "Cargo.lock").read_text())["package"]
    unexpected = [(p["name"], p["version"]) for p in actual if p["name"] != "native-sampling-oracle" and (p["name"], p["version"]) not in pinned]
    if unexpected:
        raise RuntimeError(f"oracle dependency versions differ from pinned lock: {unexpected}")
    generated = subprocess.check_output(["cargo", "run", "--release", "--locked", "--offline", "--manifest-path", str(args.work / "Cargo.toml")], env=env)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(generated)
    print(f"wrote {len(generated.splitlines())} records from {PIN} to {args.output}")

if __name__ == "__main__":
    main()

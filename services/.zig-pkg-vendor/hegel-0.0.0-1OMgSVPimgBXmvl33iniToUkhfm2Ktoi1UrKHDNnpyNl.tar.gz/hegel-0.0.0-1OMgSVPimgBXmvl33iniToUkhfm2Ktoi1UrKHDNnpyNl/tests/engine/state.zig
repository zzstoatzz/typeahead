// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const state = native.state;
const gpa = std.testing.allocator;
const Value = native.choices.ChoiceValue;
fn integer(n: i64) !Value {
    return .{ .integer = try state.BigInt.fromInt(gpa, n) };
}
test "replay typed draws, forced draws, spans and immutable first conclusion" {
    var five = try integer(5);
    defer five.deinit(gpa);
    var ten = try integer(10);
    defer ten.deinit(gpa);
    var zero = try integer(0);
    defer zero.deinit(gpa);
    var tc = try state.NativeTestCase.forChoices(gpa, &.{ five, .{ .boolean = false }, .{ .boolean = true } }, null, null);
    defer tc.deinit();
    _ = try tc.startSpan(42);
    var value = try tc.drawInteger(zero.integer, ten.integer);
    defer value.deinit();
    try std.testing.expectEqual(@as(?i64, 5), value.toInt(i64));
    try std.testing.expect(try tc.weighted(0.5, true));
    try std.testing.expect(try tc.weighted(0.5, null));
    tc.stopSpan(true);
    try tc.conclude(.interesting, "failure");
    try tc.freeze();
    try std.testing.expectEqual(state.Status.interesting, tc.status().?);
    try std.testing.expect(tc.has_discards);
    try std.testing.expectEqual(@as(usize, 3), tc.spans.asSlice()[0].end);
    try std.testing.expectError(error.Overrun, tc.weighted(0.5, null));
}
test "fresh IDs repair collisions and set references keep predecessor meaning" {
    var one = try integer(1);
    defer one.deinit(gpa);
    var zero = try integer(0);
    defer zero.deinit(gpa);
    var tc = try state.NativeTestCase.forChoices(gpa, &.{ one, one, one, zero }, null, null);
    defer tc.deinit();
    try std.testing.expectEqual(@as(i64, 1), try tc.drawFreshId());
    try std.testing.expectEqual(@as(i64, 0), try tc.drawFreshId());
    try std.testing.expectEqual(@as(i64, 0), try tc.drawFromSet(&.{0}));
    try std.testing.expectEqual(@as(i64, 1), try tc.drawFromSet(&.{1}));
}
test "simplest template shares clone draw budget and reassembles realized streams" {
    var tc = try state.NativeTestCase.forSimplest(gpa, 3);
    defer tc.deinit();
    const handle = try tc.cloneStream();
    defer handle.release();
    const child = handle.lock();
    try std.testing.expect(!(try child.weighted(0.5, null)));
    handle.unlock();
    try std.testing.expect(!(try tc.weighted(0.5, null)));
    try std.testing.expectError(error.Overrun, tc.weighted(0.5, null));
    try tc.freeze();
    try tc.reassemble();
    try std.testing.expectEqual(@as(usize, 1), tc.nodes.items[0].data.clone.nodes.len);
    try std.testing.expectEqual(state.Status.early_stop, tc.status().?);
}
test "draw addresses agree with graph reconstruction including empty sibling spans" {
    var tc = try state.NativeTestCase.forSimplest(gpa, 20);
    defer tc.deinit();
    _ = try tc.startSpan(1);
    _ = try tc.startSpan(2);
    tc.stopSpan(false);
    _ = try tc.startSpan(2);
    const addr = try tc.drawAddress(gpa);
    defer gpa.free(addr);
    _ = try tc.weighted(0.5, null);
    tc.stopSpan(false);
    tc.stopSpan(false);
    const addrs = try native.graph.drawAddresses(gpa, tc.spans.asSlice(), tc.nodes.items.len);
    defer native.graph.deinitAddresses(gpa, addrs);
    try std.testing.expect(native.graph.framesEql(addr, addrs[0]));
}
fn allocationExercise(allocator: std.mem.Allocator) !void {
    var tc = try state.NativeTestCase.forSimplest(allocator, 30);
    defer tc.deinit();
    _ = try tc.startSpan(42);
    _ = try tc.drawFreshId();
    _ = try tc.drawFromSet(&.{0});
    const handle = try tc.cloneStream();
    defer handle.release();
    const child = handle.lock();
    _ = child.weighted(0.5, null) catch |err| {
        handle.unlock();
        return err;
    };
    handle.unlock();
    _ = try tc.weighted(0.5, null);
    const bytes = try tc.drawBytes(2, 3);
    allocator.free(bytes);
    try tc.freeze();
    try tc.reassemble();
}
test "state allocation failures release realized nodes, spans, handles and family" {
    try std.testing.checkAllAllocationFailures(gpa, allocationExercise, .{});
}
test "all typed draw constraints own metadata independently of caller" {
    var tc = try state.NativeTestCase.forSimplest(gpa, 30);
    defer tc.deinit();
    const b = try tc.drawBytes(2, 5);
    defer gpa.free(b);
    try std.testing.expectEqualSlices(u8, &.{ 0, 0 }, b);
    const intervals = try native.intervalsets.IntervalSet.init(gpa, &.{.{ .start = 65, .end = 67 }});
    var alphabet = intervals;
    defer alphabet.deinit();
    const text = try tc.drawString(&alphabet, 1, 5);
    defer gpa.free(text);
    try std.testing.expectEqualStrings("A", text);
    try std.testing.expectEqual(@as(f64, 0), try tc.drawFloat(.F64, -1, 1, false, false, 5e-324));
    try std.testing.expectEqual(@as(u64, 3), try tc.drawIntegerUniform(3, 100));
    try std.testing.expectEqual(@as(usize, 1), try tc.drawIndexWeighted(&.{ 0, 1, 0 }));
}
fn appendValues(out: *std.ArrayList(u8), values: []const Value) !void {
    for (values, 0..) |value, i| {
        if (i > 0) try out.append(gpa, ';');
        switch (value) {
            .boolean => |b| try out.appendSlice(gpa, if (b) "b1" else "b0"),
            .integer => |n| {
                try out.append(gpa, 'i');
                const text = try n.toString(gpa, 10);
                defer gpa.free(text);
                try out.appendSlice(gpa, text);
            },
            .bytes => |bytes| {
                try out.append(gpa, 'x');
                for (bytes) |byte| {
                    var buf: [2]u8 = undefined;
                    _ = try std.fmt.bufPrint(&buf, "{x:0>2}", .{byte});
                    try out.appendSlice(gpa, &buf);
                }
            },
            .clone => |record| {
                try out.appendSlice(gpa, "c(");
                const children = try record.ownedValues(gpa);
                defer native.choices.deinitValues(gpa, children);
                try appendValues(out, children);
                try out.append(gpa, ')');
            },
            else => return error.UnexpectedValue,
        }
    }
}
fn fixtureBody(tc: *state.NativeTestCase) !void {
    _ = try tc.startSpan(55);
    _ = try tc.weightedPrecise(0.125, null);
    var lo = try state.BigInt.fromInt(gpa, @as(i64, -10));
    defer lo.deinit();
    var hi = try state.BigInt.fromInt(gpa, @as(i64, 10));
    defer hi.deinit();
    var n = try tc.drawInteger(lo, hi);
    n.deinit();
    const handle = try tc.cloneStream();
    defer handle.release();
    const child = handle.lock();
    {
        defer handle.unlock();
        _ = try child.weightedPrecise(0.9, null);
        var zero = try state.BigInt.fromInt(gpa, @as(u8, 0));
        defer zero.deinit();
        var hundred = try state.BigInt.fromInt(gpa, @as(u8, 100));
        defer hundred.deinit();
        var v = try child.drawInteger(zero, hundred);
        v.deinit();
    }
    const bytes = try tc.drawBytes(0, 4);
    gpa.free(bytes);
    var pool = state.NativeVariables.init(gpa);
    defer pool.deinit();
    try pool.add(try tc.drawFreshId());
    try pool.add(try tc.drawFreshId());
    var members = try pool.active(gpa);
    const chosen = tc.drawFromSet(members) catch |err| {
        gpa.free(members);
        return err;
    };
    gpa.free(members);
    try pool.consume(chosen);
    members = try pool.active(gpa);
    defer gpa.free(members);
    _ = try tc.drawFromSet(members);
    tc.stopSpan(false);
    try tc.freeze();
    try tc.reassemble();
}
test "300 original Rust replay_case fixtures match Fresh Sequence and Set outcomes" {
    var zero = try integer(0);
    defer zero.deinit(gpa);
    var one = try integer(1);
    defer one.deinit(gpa);
    var seven = try integer(7);
    defer seven.deinit(gpa);
    var nn = try integer(99);
    defer nn.deinit(gpa);
    var child: Value = .{ .clone = try native.choices.CloneRecord.fromValuesCopy(gpa, &.{ .{ .boolean = false }, nn }) };
    defer child.deinit(gpa);
    var ab = [_]u8{ 1, 2 };
    var bb = [_]u8{9};
    const a = [_]Value{ zero, .{ .boolean = false }, child, .{ .bytes = &ab }, one, one, one, zero };
    const b = [_]Value{ .{ .boolean = true }, seven, child, .{ .bytes = &bb }, zero, one, one, zero };
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/state.tsv"), '\n');
    var cases: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const mode = try std.fmt.parseInt(u8, fields.next().?, 10);
        const seed = try std.fmt.parseInt(u64, fields.next().?, 10);
        const expected = fields.next().?;
        const divergence = fields.next().?;
        const live = fields.next().?;
        var tc = switch (mode) {
            0 => try state.NativeTestCase.forProbe(gpa, &.{}, .seeded(seed), 30),
            1 => try state.NativeTestCase.forProbe(gpa, &a, .seeded(seed), native.choices.flattenedValuesLen(&a) + 20),
            else => try state.NativeTestCase.forCounterexample(gpa, &.{ &a, &b }, .seeded(seed), @max(native.choices.flattenedValuesLen(&a), native.choices.flattenedValuesLen(&b)) + 20),
        };
        defer tc.deinit();
        try fixtureBody(&tc);
        var values: std.ArrayList(Value) = .empty;
        defer {
            for (values.items) |*value| value.deinit(gpa);
            values.deinit(gpa);
        }
        for (tc.nodes.items) |*node| {
            var value = try node.value(gpa);
            errdefer value.deinit(gpa);
            try values.append(gpa, value);
        }
        var text: std.ArrayList(u8) = .empty;
        defer text.deinit(gpa);
        try appendValues(&text, values.items);
        if (!std.mem.eql(u8, expected, text.items)) {
            std.debug.print("mode={d} seed={d}\n", .{ mode, seed });
            try std.testing.expectEqualStrings(expected, text.items);
        }
        if (std.mem.eql(u8, divergence, "_")) try std.testing.expect(tc.divergence() == null) else {
            const d = tc.divergence().?;
            var buf: [64]u8 = undefined;
            const s = try std.fmt.bufPrint(&buf, ":{d}", .{d.position});
            try std.testing.expectEqualStrings(divergence, s);
            try std.testing.expectEqual(@as(usize, 0), d.stream.len);
        }
        const flags = try tc.liveTimelines(gpa);
        defer gpa.free(flags);
        try std.testing.expectEqual(live.len, flags.len);
        for (flags, live) |flag, digit| try std.testing.expectEqual(flag, digit == '1');
        cases += 1;
    }
    try std.testing.expectEqual(@as(usize, 300), cases);
}
const ThreadDraw = struct {
    handle: *state.NativeTestCaseHandle,
    ids: [40]i64 = undefined,
    failed: bool = false,
    fn run(self: *ThreadDraw) void {
        const tc = self.handle.lock();
        defer self.handle.unlock();
        for (&self.ids) |*id| id.* = tc.drawFreshId() catch {
            self.failed = true;
            return;
        };
    }
};
test "concurrent clone streams reserve unique family IDs and share first conclusion" {
    var tc = try state.NativeTestCase.forSimplest(gpa, 100);
    defer tc.deinit();
    const a = try tc.cloneStream();
    defer a.release();
    const b = try tc.cloneStream();
    defer b.release();
    var left: ThreadDraw = .{ .handle = a };
    var right: ThreadDraw = .{ .handle = b };
    const ta = try std.Thread.spawn(.{}, ThreadDraw.run, .{&left});
    const tb = try std.Thread.spawn(.{}, ThreadDraw.run, .{&right});
    ta.join();
    tb.join();
    try std.testing.expect(!left.failed and !right.failed);
    var seen: [80]bool = @splat(false);
    for (left.ids ++ right.ids) |id| {
        try std.testing.expect(id >= 0 and id < seen.len);
        try std.testing.expect(!seen[@intCast(id)]);
        seen[@intCast(id)] = true;
    }
    try tc.conclude(.invalid, null);
    const child = a.lock();
    defer a.unlock();
    try std.testing.expectError(error.InvalidTestCase, child.weighted(0.5, null));
}
const Observer = struct {
    draws: usize = 0,
    conclusions: usize = 0,
    final_status: ?state.Status = null,
    fn boolean(ctx: *anyopaque, _: bool, _: bool) void {
        const self: *Observer = @ptrCast(@alignCast(ctx));
        self.draws += 1;
    }
    fn conclude(ctx: *anyopaque, status: state.Status, _: ?state.InterestingOrigin) void {
        const self: *Observer = @ptrCast(@alignCast(ctx));
        self.conclusions += 1;
        self.final_status = status;
    }
    const vtable: state.DataObserver.VTable = .{ .draw_boolean = boolean, .conclude_test = conclude };
};
test "observer concludes once after implicitly closing all spans" {
    var observer: Observer = .{};
    var tc = try state.NativeTestCase.forChoices(gpa, &.{.{ .boolean = true }}, null, .{ .context = &observer, .vtable = &Observer.vtable });
    defer tc.deinit();
    _ = try tc.startSpan(9);
    _ = try tc.weighted(0.5, null);
    try tc.conclude(.invalid, null);
    try tc.freeze();
    try tc.freeze();
    try std.testing.expectEqual(@as(usize, 1), observer.draws);
    try std.testing.expectEqual(@as(usize, 1), observer.conclusions);
    try std.testing.expectEqual(state.Status.invalid, observer.final_status.?);
    try std.testing.expectEqual(@as(usize, 1), tc.spans.asSlice()[0].end);
}

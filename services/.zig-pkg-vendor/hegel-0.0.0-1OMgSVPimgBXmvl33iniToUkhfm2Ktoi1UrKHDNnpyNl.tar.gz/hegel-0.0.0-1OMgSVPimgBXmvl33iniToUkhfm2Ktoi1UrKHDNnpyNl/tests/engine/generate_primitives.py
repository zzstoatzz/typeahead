import argparse
import pathlib
import subprocess
import json

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
HERE = pathlib.Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(
        description="Regenerate primitive fixtures by compiling the exact pinned Rust source. "
        "The oracle uses assertion shims for the engine's invariant macros and tests valid inputs."
    )
    parser.add_argument("--upstream", type=pathlib.Path, default=pathlib.Path.home() / ".cache/hegel-zig" / ("hegel-rust-" + PIN))
    parser.add_argument("--rand-source", type=pathlib.Path)
    parser.add_argument("--input", type=pathlib.Path, default=HERE / "regex_patterns.tsv")
    parser.add_argument("--output", type=pathlib.Path, default=HERE / "fixtures/primitives.tsv")
    parser.add_argument("--template", type=pathlib.Path, default=HERE / "primitives_oracle.rs.in")
    parser.add_argument("--work", type=pathlib.Path, default=HERE.parents[1] / "work/primitives-oracle")
    args = parser.parse_args()
    upstream = args.upstream.resolve()
    revision = subprocess.check_output(["git", "-C", str(upstream), "rev-parse", "HEAD"], text=True).strip()
    if revision != PIN:
        raise RuntimeError(f"expected upstream {PIN}, got {revision}")
    rand_source = args.rand_source
    if rand_source is None:
        candidates = list((pathlib.Path.home() / ".cargo/registry/src").glob("*/rand-0.10.1"))
        if len(candidates) != 1:
            raise RuntimeError("pass --rand-source pointing to pinned rand 0.10.1")
        rand_source = candidates[0]
    args.work.mkdir(parents=True, exist_ok=True)
    template = args.template.read_text()
    source = template.replace("@ROOT@", str(upstream)).replace("@RAND@", str(rand_source.resolve())).replace("@INPUT@", str(args.input.resolve()))
    main_rs = args.work / "main.rs"
    main_rs.write_text(source)
    deps = upstream / "target/release/deps"
    built = subprocess.run(
        ["cargo", "build", "--manifest-path", str(upstream / "Cargo.toml"), "-p", "hegeltest-c", "--release", "--locked", "--offline", "--message-format=json"],
        check=True, capture_output=True, text=True,
    )
    artifacts = {}
    for line in built.stdout.splitlines():
        message = json.loads(line)
        if message.get("reason") != "compiler-artifact":
            continue
        for filename in message["filenames"]:
            if filename.endswith(".rlib"):
                artifacts[message["target"]["name"]] = filename
    command = ["rustc", "--edition=2024", "-Awarnings", str(main_rs), "-o", str(args.work / "oracle"), "-L", "dependency=" + str(deps)]
    for name in ("libm", "once_cell", "rand", "rand_core", "hashbrown", "rustc_hash"):
        command.extend(["--extern", name + "=" + artifacts[name]])
    subprocess.run(command, check=True)
    generated = subprocess.check_output([str(args.work / "oracle")])
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(generated)
    print(f"wrote {len(generated.splitlines())} records from {PIN} to {args.output}")


if __name__ == "__main__":
    main()

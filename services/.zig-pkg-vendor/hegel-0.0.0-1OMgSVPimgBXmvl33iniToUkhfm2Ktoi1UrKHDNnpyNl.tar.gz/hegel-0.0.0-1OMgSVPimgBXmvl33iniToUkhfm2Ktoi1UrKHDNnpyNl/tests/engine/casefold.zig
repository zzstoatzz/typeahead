const std = @import("std");
const fold = @import("re").casefold;
fn number(h: *u64, n: u32) void {
    var bytes: [4]u8 = undefined;
    std.mem.writeInt(u32, &bytes, n, .little);
    for (bytes) |b| h.* = (h.* ^ b) *% 1099511628211;
}
test "casefold compares every Unicode scalar with pinned Rust" {
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/casefold.tsv"), '\n');
    while (lines.next()) |line| {
        var fields = std.mem.splitScalar(u8, line, '\t');
        const flags = try std.fmt.parseInt(u32, fields.next().?, 10);
        const expected = try std.fmt.parseInt(u64, fields.next().?, 10);
        var h: u64 = 14695981039346656037;
        for (0..0x110000) |index| {
            if (index >= 0xd800 and index <= 0xdfff) continue;
            const cp: u32 = @intCast(index);
            number(&h, fold.lower(cp, flags));
            number(&h, @intFromBool(fold.isCased(cp, flags)));
            if (cp % 127 == 0 or cp < 2048) {
                number(&h, @intFromBool(fold.literalMatches('s', cp, flags)));
                number(&h, @intFromBool(fold.rangeMatches(65, 90, cp, flags)));
                number(&h, @intFromBool(fold.grouprefEq('s', cp, flags)));
                const values = fold.uppersOf(cp, flags);
                number(&h, @intCast(values.len));
                for (values) |v| number(&h, v);
            }
        }
        try std.testing.expectEqual(expected, h);
    }
}

const std = @import("std");
const a = @import("antithesis");
test "assertion declares then evaluates with JSON escaped location" {
    const gpa = std.testing.allocator;
    const text = try a.assertionLines(gpa, .{ .class = "suite", .function = "test\"\\\n", .file = "file\t.zig", .begin_line = 42 }, true);
    defer gpa.free(text);
    var lines = std.mem.tokenizeScalar(u8, text, '\n');
    var declaration = try std.json.parseFromSlice(std.json.Value, gpa, lines.next().?, .{});
    defer declaration.deinit();
    var evaluation = try std.json.parseFromSlice(std.json.Value, gpa, lines.next().?, .{});
    defer evaluation.deinit();
    const first = declaration.value.object.get("antithesis_assert").?.object;
    const second = evaluation.value.object.get("antithesis_assert").?.object;
    try std.testing.expect(!first.get("hit").?.bool and !first.get("condition").?.bool);
    try std.testing.expect(second.get("hit").?.bool and second.get("condition").?.bool);
    try std.testing.expectEqualStrings("suite::test\"\\\n passes properties", second.get("id").?.string);
    try std.testing.expect(lines.next() == null);
}
fn noEnv(_: ?*anyopaque, _: []const u8) ?[]const u8 {
    return null;
}
test "outside Antithesis no assertion file is written" {
    try a.report(std.testing.allocator, std.testing.io, .{ .context = null, .get = noEnv }, .{ .class = "suite", .function = "test", .file = "file", .begin_line = 1 }, true, .{});
}
test "inside Antithesis verdicts append complete declaration and evaluation pairs" {
    const gpa = std.testing.allocator;
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    const directory = try std.fmt.allocPrint(gpa, ".zig-cache/tmp/{s}", .{tmp.sub_path});
    defer gpa.free(directory);
    const Env = struct {
        fn get(context: ?*anyopaque, key: []const u8) ?[]const u8 {
            const path: *const []const u8 = @ptrCast(@alignCast(context.?));
            return if (std.mem.eql(u8, key, "ANTITHESIS_OUTPUT_DIR")) path.* else null;
        }
    };
    const path: []const u8 = directory;
    const env = @import("antithesis").Environment{ .context = @ptrCast(@constCast(&path)), .get = Env.get };
    try std.testing.expect(try a.checkEnvironment(gpa, std.testing.io, env) == null);
    const location: a.TestLocation = .{ .class = "suite", .function = "test", .file = "file.zig", .begin_line = 1 };
    try a.report(gpa, std.testing.io, env, location, true, .{});
    try a.report(gpa, std.testing.io, env, location, false, .{});
    const contents = try tmp.dir.readFileAlloc(std.testing.io, "sdk.jsonl", gpa, .unlimited);
    defer gpa.free(contents);
    try std.testing.expectEqual(@as(usize, 4), std.mem.count(u8, contents, "\n"));
    var lines = std.mem.tokenizeScalar(u8, contents, '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        var value = try std.json.parseFromSlice(std.json.Value, gpa, line, .{});
        defer value.deinit();
        try std.testing.expect(value.value.object.contains("antithesis_assert"));
        count += 1;
    }
    try std.testing.expectEqual(@as(usize, 4), count);
}

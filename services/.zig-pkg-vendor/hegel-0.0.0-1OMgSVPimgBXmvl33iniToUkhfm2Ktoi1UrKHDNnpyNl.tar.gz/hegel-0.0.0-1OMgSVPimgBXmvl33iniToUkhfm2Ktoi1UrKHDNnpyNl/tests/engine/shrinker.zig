const std = @import("std");
const sh = @import("shrinker");
const c = sh.choices;
const Context = struct {
    allocator: std.mem.Allocator,
    calls: usize = 0,
    adopted: usize = 0,
    fn call(p: *anyopaque, req: sh.Request) anyerror!sh.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        self.calls += 1;
        const nodes = switch (req) {
            .full => |n| n,
            .probe => return error.UnexpectedProbe,
        };
        return .{ .interesting = true, .run = try sh.CachedRun.init(self.allocator, .interesting, null, nodes, &.{}) };
    }
    fn accept(p: *anyopaque) anyerror!void {
        const self: *@This() = @ptrCast(@alignCast(p));
        self.adopted += 1;
    }
};
test "candidate acceptance preserves forced values and reports only adopted runs" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false)};
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call, .candidate_adopted = Context.accept }, &nodes, &.{});
    defer s.deinit();
    try std.testing.expect(try s.consider(&nodes));
    try std.testing.expectEqual(0, context.calls);
    const smaller = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false)};
    try std.testing.expect(try s.consider(&smaller));
    try std.testing.expectEqual(1, context.adopted);
    try std.testing.expectEqual(1, s.improvements);
    try std.testing.expect(s.all_changed_nodes.contains(0));
    try s.clearChangeTracking();
    try std.testing.expectEqual(0, s.all_changed_nodes.count());
    const repl = [_]sh.Replacement{.{ .index = 0, .value = .{ .boolean = true } }};
    try std.testing.expect(!try s.replace(&repl));
    try std.testing.expectEqual(1, context.calls);
}
test "sequence sorting evaluates and adopts stable smaller arrangement" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{ c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false), c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false) };
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &nodes, &.{});
    defer s.deinit();
    try s.sortValues();
    try std.testing.expectEqual(false, s.current_nodes[0].data.valueRef().boolean);
    try std.testing.expectEqual(1, s.improvements);
    try s.swapAdjacentBlocks();
    try s.zeroChoices();
    try s.swapIntegerSign();
    try s.lowerCommonNodeOffset();
}
test "scheduler fixates deterministic passes and removes discarded spans" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{ c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false), c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false) };
    const spans = [_]c.Span{.{ .start = 0, .end = 1, .label = 0, .depth = 0, .parent = null, .discarded = true }};
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &nodes, &spans);
    defer s.deinit();
    var passes = [_]sh.ShrinkPass{.{ .name = "trivial", .run = sh.Shrinker.tryTrivialSpans }};
    try s.fixateShrinkPasses(&passes);
    try std.testing.expectEqual(1, s.current_nodes.len);
}
const IntContext = struct {
    allocator: std.mem.Allocator,
    minimum: i64,
    fn call(p: *anyopaque, req: sh.Request) anyerror!sh.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        const nodes = switch (req) {
            .full => |n| n,
            .probe => return error.UnexpectedProbe,
        };
        const v = nodes[0].data.asInteger().?[1];
        return .{ .interesting = (v.toInt(i64) orelse return error.InvalidInteger) >= self.minimum, .run = try sh.CachedRun.init(self.allocator, .interesting, null, nodes, &.{}) };
    }
};
test "integer shrink reaches exact threshold" {
    const gpa = std.testing.allocator;
    var ic = c.IntegerChoice{ .min_value = try c.BigInt.fromInt(gpa, -1000), .max_value = try c.BigInt.fromInt(gpa, 1000000), .shrink_towards = try c.BigInt.fromInt(gpa, 0) };
    defer ic.deinit();
    var node = c.ChoiceNode.integer(&ic, try c.BigInt.fromInt(gpa, 765432), false);
    defer node.deinit(gpa);
    var context = IntContext{ .allocator = gpa, .minimum = 117 };
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = IntContext.call }, &.{node}, &.{});
    defer s.deinit();
    try s.binarySearchIntegerTowardsZero();
    try std.testing.expectEqual(@as(?i64, 117), s.current_nodes[0].data.asInteger().?[1].toInt(i64));
    try s.initialCoarseReduction();
    try s.bindDeletion();
    try s.redistributeIntegers();
    try s.lowerIntegersTogether();
    try s.shrinkDuplicates();
    try s.minimizeIndividualChoices();
    try s.lowerAndBump();
    try s.mutateAndShrink();
    try std.testing.expectError(error.UnexpectedProbe, s.tryShorteningViaIncrement());
}
test "same-label sibling spans reorder by value" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{ c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false), c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false) };
    const spans = [_]c.Span{ .{ .start = 0, .end = 1, .label = 1, .depth = 0, .parent = null, .discarded = false }, .{ .start = 1, .end = 2, .label = 1, .depth = 0, .parent = null, .discarded = false } };
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &nodes, &spans);
    defer s.deinit();
    try s.reorderSpans();
    try std.testing.expectEqual(false, s.current_nodes[0].data.valueRef().boolean);
    try s.passToDescendant();
    try s.deleteSpans();
}
test "deletion passes can remove all unconstrained choices" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{ c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false), c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false) };
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &nodes, &.{});
    defer s.deinit();
    try s.nodeProgram(1);
    try s.deleteBetweenRepeats();
    try s.deleteChunks();
    try std.testing.expectEqual(0, s.current_nodes.len);
}
test "bytes shrinking retains minimal length and lowers each byte" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    var node = c.ChoiceNode.bytes(.{ .min_size = 2, .max_size = 10 }, try gpa.dupe(u8, &.{ 9, 7, 5 }), false);
    defer node.deinit(gpa);
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &.{node}, &.{});
    defer s.deinit();
    try s.shrinkBytes();
    try s.redistributeBytesPairs();
    try std.testing.expectEqualSlices(u8, &.{ 0, 0 }, s.current_nodes[0].data.bytes.value);
}

test "float shrinking reaches canonical zero" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    const node = c.ChoiceNode.float(.{ .min_value = -1000, .max_value = 1000, .allow_nan = false, .allow_infinity = false, .smallest_nonzero_magnitude = 0 }, 23.75, false);
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &.{node}, &.{});
    defer s.deinit();
    try s.shrinkFloats();
    try s.redistributeNumericPairs();
    try s.scaleNumericPairs();
    try std.testing.expectEqual(@as(u64, 0), @as(u64, @bitCast(s.current_nodes[0].data.float.value)));
}

test "string shrink preserves alphabet and minimum length" {
    const gpa = std.testing.allocator;
    var context = Context{ .allocator = gpa };
    var intervals = try c.IntervalSet.init(gpa, &.{ .{ .start = 0x30, .end = 0x39 }, .{ .start = 0x41, .end = 0x7a } });
    defer intervals.deinit();
    var node = c.ChoiceNode.string(.{ .intervals = &intervals, .min_size = 2, .max_size = 10 }, try gpa.dupe(u32, &.{ 0x5a, 0x59, 0x58 }), false);
    defer node.deinit(gpa);
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = Context.call }, &.{node}, &.{});
    defer s.deinit();
    try s.shrinkStrings();
    try s.redistributeStringPairs();
    try s.lowerDuplicatedCharacters();
    try s.normalizeUnicodeChars();
    try std.testing.expectEqualSlices(u32, &.{ 0x30, 0x30 }, s.current_nodes[0].data.string.value);
}
const BoolContext = struct {
    allocator: std.mem.Allocator,
    fn call(p: *anyopaque, req: sh.Request) anyerror!sh.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        var nodes: std.ArrayList(c.ChoiceNode) = .empty;
        defer nodes.deinit(self.allocator);
        switch (req) {
            .full => |v| try nodes.appendSlice(self.allocator, v),
            .probe => |v| {
                for (v.prefix) |value| {
                    if (value != .boolean) return error.UnexpectedKind;
                    try nodes.append(self.allocator, c.ChoiceNode.boolean(.{ .p = 0.5 }, value.boolean, false));
                }
            },
        }
        const interesting = nodes.items.len >= 1 and nodes.items[0].data == .boolean and nodes.items[0].data.boolean.value;
        return .{ .interesting = interesting, .run = try sh.CachedRun.init(self.allocator, .valid, null, nodes.items, &.{}) };
    }
};
test "full scheduler converges to a single required true boolean" {
    const gpa = std.testing.allocator;
    var context = BoolContext{ .allocator = gpa };
    const nodes = [_]c.ChoiceNode{ c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false), c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false) };
    var s = try sh.Shrinker.init(gpa, .{ .context = &context, .call = BoolContext.call }, &nodes, &.{});
    defer s.deinit();
    try s.shrink();
    try std.testing.expectEqual(1, s.current_nodes.len);
    try std.testing.expect(s.current_nodes[0].data.boolean.value);
}
const CloneContext = struct {
    allocator: std.mem.Allocator,
    ic: *const c.IntegerChoice,
    fn call(p: *anyopaque, req: sh.Request) anyerror!sh.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        const a = self.allocator;
        var generated: std.ArrayList(c.ChoiceNode) = .empty;
        defer {
            for (generated.items) |*n| n.deinit(a);
            generated.deinit(a);
        }
        const nodes: []const c.ChoiceNode = switch (req) {
            .full => |n| n,
            .probe => |v| blk: {
                for (v.prefix) |*value| {
                    if (value.* != .clone) continue;
                    const record = value.clone;
                    var children: std.ArrayList(c.ChoiceNode) = .empty;
                    defer {
                        for (children.items) |*n| n.deinit(a);
                        children.deinit(a);
                    }
                    for (0..record.len()) |i| {
                        const child = record.valueAt(i);
                        if (child != .integer) continue;
                        try children.append(a, c.ChoiceNode.integer(self.ic, try child.integer.clone(a), false));
                    }
                    const stream = try c.RealizedStream.create(a, children.items, &.{});
                    defer stream.release();
                    try generated.append(a, c.ChoiceNode.cloneStream(stream, false));
                }
                break :blk generated.items;
            },
        };
        const interesting = nodes.len == 1 and nodes[0].data == .clone and nodes[0].data.clone.nodes.len == 1 and nodes[0].data.clone.nodes[0].data == .integer and (nodes[0].data.clone.nodes[0].data.integer.value.toInt(i64) orelse return error.InvalidInteger) >= 117;
        return .{ .interesting = interesting, .run = try sh.CachedRun.init(a, .valid, null, nodes, &.{}) };
    }
};
test "nested clone shrinking owns snapshots and forwards accepted candidates" {
    const a = std.testing.allocator;
    var ic = c.IntegerChoice{ .min_value = try c.BigInt.fromInt(a, 0), .max_value = try c.BigInt.fromInt(a, 1000000), .shrink_towards = try c.BigInt.fromInt(a, 0) };
    defer ic.deinit();
    var child = c.ChoiceNode.integer(&ic, try c.BigInt.fromInt(a, 765432), false);
    defer child.deinit(a);
    const stream = try c.RealizedStream.create(a, &.{child}, &.{});
    defer stream.release();
    var node = c.ChoiceNode.cloneStream(stream, false);
    defer node.deinit(a);
    var context = CloneContext{ .allocator = a, .ic = &ic };
    var s = try sh.Shrinker.init(a, .{ .context = &context, .call = CloneContext.call }, &.{node}, &.{});
    defer s.deinit();
    try s.shrinkCloneStreams();
    try std.testing.expectEqual(@as(?i64, 117), s.current_nodes[0].data.clone.nodes[0].data.integer.value.toInt(i64));
}
fn acceptanceAllocationFailures(a: std.mem.Allocator) !void {
    var context = Context{ .allocator = a };
    const nodes = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false)};
    var s = try sh.Shrinker.init(a, .{ .context = &context, .call = Context.call }, &nodes, &.{});
    defer s.deinit();
    const lower = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false)};
    _ = try s.consider(&lower);
    try s.clearChangeTracking();
}
test "shrinker snapshots release all ownership on allocation failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, acceptanceAllocationFailures, .{});
}
const ClockContext = struct {
    time: i128 = 10,
    fn now(p: ?*anyopaque) ?i128 {
        const self: *@This() = @ptrCast(@alignCast(p.?));
        return self.time;
    }
};
test "deadline stops before evaluator and latches timeout" {
    const a = std.testing.allocator;
    var context = Context{ .allocator = a };
    var clock = ClockContext{};
    var s = try sh.Shrinker.init(a, .{ .context = &context, .call = Context.call }, &.{c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false)}, &.{});
    defer s.deinit();
    s.deadline = 9;
    s.now = ClockContext.now;
    s.clock_context = &clock;
    try std.testing.expectError(error.ShrinkStop, s.consider(&.{c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false)}));
    try std.testing.expect(s.timed_out);
    try std.testing.expectEqual(0, context.calls);
}

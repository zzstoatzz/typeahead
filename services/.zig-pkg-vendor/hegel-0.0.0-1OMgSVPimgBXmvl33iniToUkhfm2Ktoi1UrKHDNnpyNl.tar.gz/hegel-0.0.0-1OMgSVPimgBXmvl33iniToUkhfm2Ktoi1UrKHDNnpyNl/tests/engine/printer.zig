const std = @import("std");
const p = @import("printer");
test "group layout and deferred slots" {
    var printer = p.Printer.init(std.testing.allocator, 8);
    defer printer.deinit();
    try printer.beginGroup(.main, 2, "[");
    try printer.text(.main, "abc");
    try printer.breakable(.main, " ");
    const slot = try printer.deferred(.main);
    try printer.text(.{ .slot = slot }, "defghi");
    try printer.endGroup(.main, "]");
    try printer.resolve();
    try std.testing.expectEqualStrings("[abc\n  defghi]", try printer.value());
    try std.testing.expectError(error.DeadSlot, printer.text(.main, "late"));
}
test "reflow compile" {
    var printer = p.Printer.init(std.testing.allocator, 8);
    defer printer.deinit();
    try p.reflow.reflow(&printer, .main, "Some(123, 456)", .{});
    try std.testing.expectEqualStrings("Some(123,\n     456)", try printer.value());
}
fn allocationFailureCase(a: std.mem.Allocator) !void {
    var printer = p.Printer.init(a, 8);
    defer printer.deinit();
    try printer.beginSpeculative(.main);
    const slot = try printer.deferred(.main);
    try printer.text(.{ .slot = slot }, "discard");
    try printer.note(.main, "held\nnote", "! ");
    try printer.abortSpeculative(.main);
    try printer.beginGroup(.main, 2, "[");
    try printer.text(.main, "alpha");
    try printer.breakable(.main, " ");
    try printer.text(.main, "beta");
    try printer.endGroup(.main, "]");
    _ = try printer.value();
}
test "printer releases ownership across allocation failures" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, allocationFailureCase, .{});
}

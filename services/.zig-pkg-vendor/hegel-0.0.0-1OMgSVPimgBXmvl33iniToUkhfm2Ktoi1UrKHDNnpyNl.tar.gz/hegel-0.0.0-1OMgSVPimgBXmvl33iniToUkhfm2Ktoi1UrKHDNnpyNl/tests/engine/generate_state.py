import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
import tomllib

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
upstream = pathlib.Path(sys.argv[1]).resolve()
root = pathlib.Path(__file__).resolve().parents[2]
revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=upstream, text=True).strip()
if revision != PIN:
    raise SystemExit(f"expected upstream {PIN}, found {revision}")
original_lock = (upstream / "Cargo.lock").read_bytes()
upstream_packages = {
    (p["name"], p["version"])
    for p in tomllib.loads(original_lock.decode())["package"]
}
with tempfile.TemporaryDirectory(prefix="hegel-choice-oracle-") as temp:
    crate = pathlib.Path(temp)
    (crate / "src").mkdir()
    (crate / "src/main.rs").write_bytes((root / "tests/engine/state_oracle.rs").read_bytes())
    (crate / "Cargo.lock").write_bytes(original_lock)
    (crate / "Cargo.toml").write_text(
        '[package]\nname="native-state-oracle"\nversion="0.0.0"\nedition="2024"\n'
        '[dependencies]\nhegel_c={package="hegeltest-c",path='
        + json.dumps(str(upstream / "hegel-c"))
        + ',features=["__bench"]}\n'
    )
    result = subprocess.run(
        ["cargo", "run", "--offline", "--release", "--manifest-path", str(crate / "Cargo.toml"), "--target-dir", str(root / "work/native-state-oracle-target")],
        check=True,
        stdout=subprocess.PIPE,
    )
    for package in tomllib.loads((crate / "Cargo.lock").read_text())["package"]:
        if package["name"] != "native-state-oracle" and (package["name"], package["version"]) not in upstream_packages:
            raise SystemExit(f"oracle dependency drift: {package['name']} {package['version']}")
    destination = root / "tests/engine/fixtures/state.tsv"
    destination.write_bytes(result.stdout)
    print(f"{destination}: {len(result.stdout.splitlines())} cases; sha256={hashlib.sha256(result.stdout).hexdigest()}")

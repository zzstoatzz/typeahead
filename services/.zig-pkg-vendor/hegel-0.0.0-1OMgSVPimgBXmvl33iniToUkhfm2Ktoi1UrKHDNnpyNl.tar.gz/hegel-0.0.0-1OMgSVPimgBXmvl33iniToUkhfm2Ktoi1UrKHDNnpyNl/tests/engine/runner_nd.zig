const std = @import("std");
const n = @import("native");
const Driver = struct {
    executions: usize = 0,
    alternating: bool = false,
    fail_after: ?usize = null,
    fail_through: ?usize = null,
    fn execute(context: *anyopaque, handle: *n.state.NativeTestCaseHandle) anyerror!void {
        const self: *Driver = @ptrCast(@alignCast(context));
        self.executions += 1;
        const tc = handle.lock();
        defer handle.unlock();
        _ = tc.weighted(0.5, null) catch |err| switch (err) {
            error.Overrun, error.InvalidTestCase => return,
            else => return err,
        };
        if (if (self.fail_after) |limit| self.executions > limit else if (self.fail_through) |limit| self.executions <= limit else !self.alternating or self.executions % 2 == 0) try tc.conclude(.interesting, "bug");
        try tc.freeze();
    }
};
test "complete runner confirms and reports both deterministic and ND failures" {
    const gpa = std.testing.allocator;
    for ([_]bool{ false, true }) |forced| {
        var driver: Driver = .{};
        const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 1, .test_cases = 10, .database = .disabled, .verbosity = .quiet, .nd_force = forced, .phases = &.{ .generate, .shrink } }, null, .{ .context = &driver, .call = Driver.execute });
        defer engine.deinit();
        var result = try engine.run();
        defer result.deinit(gpa);
        try std.testing.expectEqual(@as(usize, 1), result.failures.len);
        try std.testing.expectEqualStrings("bug", result.failures[0].origin);
        try std.testing.expect(driver.executions > 1);
        if (forced) try std.testing.expect(!engine.origins.needsConfirmation("bug"));
    }
}
test "a verdict change enters ND review and retains a reproducing witness" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{ .alternating = true };
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 2, .test_cases = 10, .database = .disabled, .verbosity = .quiet, .phases = &.{ .generate, .shrink } }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var result = try engine.run();
    defer result.deinit(gpa);
    try std.testing.expect(engine.nd_active);
    try std.testing.expectEqual(@as(usize, 1), result.failures.len);
    try std.testing.expectEqualStrings("bug", result.failures[0].origin);
}

test "fresh rescue successes do not dilute replay evidence" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{ .fail_after = 4 };
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 3, .database = .disabled, .nd_force = true }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var result = try engine.ndReproduce(null, .{ .sequence = &.{} }, 3, 2);
    defer if (result.witness) |*run| run.deinit(gpa);
    try std.testing.expect(result.witness != null);
    try std.testing.expectEqual(@as(u64, 4), result.evidence.runs());
    try std.testing.expectEqual(@as(u64, 1), result.evidence.fails());
    try std.testing.expectEqual(@as(usize, 5), driver.executions);
}
test "seeded confirmation still requires an in-batch reproducing witness" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 4, .database = .disabled, .nd_force = true }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var initial = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer initial.deinit(gpa);
    (try engine.origins.entry("bug")).seedEvidence(.{ .failures = 4, .replays = 4 });
    driver.fail_after = std.math.maxInt(usize);
    try engine.ndDiscoverySweep();
    try std.testing.expect(engine.origins.incumbent("bug") == null);
    try std.testing.expect(engine.origins.needsConfirmation("bug"));
    try std.testing.expectEqual(@as(usize, 37), driver.executions);
}

const ScoringDriver = struct {
    executions: usize = 0,
    fn execute(context: *anyopaque, handle: *n.state.NativeTestCaseHandle) anyerror!void {
        const self: *ScoringDriver = @ptrCast(@alignCast(context));
        self.executions += 1;
        const tc = handle.lock();
        defer handle.unlock();
        const gpa = tc.allocator;
        var min = try n.choices.BigInt.fromInt(gpa, @as(u8, 0));
        defer min.deinit();
        var max = try n.choices.BigInt.fromInt(gpa, @as(u16, 1000));
        defer max.deinit();
        var value = tc.drawInteger(min, max) catch |err| switch (err) {
            error.Overrun, error.InvalidTestCase => return,
            else => return err,
        };
        defer value.deinit();
        const score = @as(f64, @floatFromInt(value.toInt(u16).?)) + if (self.executions % 2 == 0) @as(f64, 0.25) else 0;
        try tc.family.target("score", score);
        try tc.freeze();
    }
};
test "ND targeting measures noisy candidates and adopts a fresh holdout winner" {
    const gpa = std.testing.allocator;
    var driver: ScoringDriver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 5, .database = .disabled, .nd_force = true, .verbosity = .quiet }, null, .{ .context = &driver, .call = ScoringDriver.execute });
    defer engine.deinit();
    var initial = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer initial.deinit(gpa);
    try engine.optimiseTargetsNd();
    const target = engine.targeting.ndTarget("score").?;
    try std.testing.expect(!target.dead);
    try std.testing.expect(target.reference > 0.25);
    try std.testing.expect(driver.executions > n.nd.TARGET_ND_HOLDOUT);
    try std.testing.expect(!engine.origins.anyLive());
}
fn reproductionAllocationPaths(gpa: std.mem.Allocator) !void {
    var driver: Driver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 6, .database = .disabled, .nd_force = true, .verbosity = .quiet }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var result = try engine.ndReproduce(null, .{ .sequence = &.{} }, 1, 0);
    defer if (result.witness) |*run| run.deinit(gpa);
    try std.testing.expect(result.witness != null);
}
test "measurement reproduction releases partial state on every allocation failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, reproductionAllocationPaths, .{});
}

test "a one-off failure survives dry confirmation as a caveat-only report" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{ .fail_through = 1 };
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 7, .test_cases = 10, .database = .disabled, .verbosity = .quiet, .phases = &.{ .generate, .shrink } }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var result = try engine.run();
    defer result.deinit(gpa);
    try std.testing.expect(engine.nd_active);
    try std.testing.expectEqual(@as(usize, 1), result.failures.len);
    try std.testing.expectEqualStrings("bug", result.failures[0].origin);
    try std.testing.expect(result.failures[0].reproduce_blob == null);
    try std.testing.expect(result.failures[0].caveat != null);
}
test "an expired final-review deadline cannot confirm from one reproduction" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 8, .database = .disabled, .nd_force = true, .verbosity = .quiet }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var initial = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer initial.deinit(gpa);
    try engine.finalReplay(engine.now() - 1, false);
    try std.testing.expect(engine.origins.incumbent("bug") == null);
    try std.testing.expect(engine.origins.needsConfirmation("bug"));
    try std.testing.expectEqual(@as(usize, 2), driver.executions);
}

const std = @import("std");
const rust = @import("rust_fmt");
test "floating point diagnostics retain Rust Display strings" {
    const A = std.testing.allocator;
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/format.tsv"), '\n');
    var differences: usize = 0;
    while (lines.next()) |line| {
        var fields = std.mem.splitScalar(u8, line, '\t');
        const bits = try std.fmt.parseInt(u64, fields.next().?, 10);
        const hex = fields.next().?;
        const expected = try A.alloc(u8, hex.len / 2);
        defer A.free(expected);
        _ = try std.fmt.hexToBytes(expected, hex);
        const actual = try std.fmt.allocPrint(A, "{f}", .{rust.floatDisplay(@bitCast(bits))});
        defer A.free(actual);
        if (!std.mem.eql(u8, expected, actual)) {
            if (differences < 10) std.debug.print("bits={} expected={s} actual={s}\n", .{ bits, expected, actual });
            differences += 1;
        }
    }
    try std.testing.expectEqual(@as(usize, 0), differences);
}

const std = @import("std");
const native = @import("native");
const blob = native.blob;

test "native decoder reads a failure blob emitted by the pinned Rust engine" {
    const allocator = std.testing.allocator;
    var decoded = (try blob.decodeBlob(allocator, "AXicdYoxCgAACAK7ta3/fzYbhAhyUNGrkJJxcPFyDuXHsJgGGGMAhA==")).?;
    defer decoded.deinit(allocator);
    const bytes = (try native.database.serializeChoices(allocator, decoded.choices)).?;
    defer allocator.free(bytes);
    try std.testing.expectEqualSlices(u8, @embedFile("fixtures/stale_cache.choices"), bytes);
}

test "native encoder emits a compatible raw or compressed choice payload" {
    const allocator = std.testing.allocator;
    const values = (try native.database.deserializeChoicesExact(allocator, @embedFile("fixtures/stale_cache.choices"))).?;
    defer native.database.deinitValues(allocator, values);
    const encoded = (try blob.encodeFailure(allocator, values)).?;
    defer allocator.free(encoded);
    var decoded = (try blob.decodeBlob(allocator, encoded)).?;
    defer decoded.deinit(allocator);
    try std.testing.expectEqual(values.len, decoded.choices.len);
    for (values, decoded.choices) |*a, *b| try std.testing.expect(a.eql(b));
}

test "blob decoding rejects malformed prefixes, compression, and nested records" {
    const allocator = std.testing.allocator;
    for ([_][]const u8{ "", "!", "BA==", "AQ==", "AXicAA==", "AA==", "Ag==", "Aw==" }) |encoded| {
        try std.testing.expectEqual(null, try blob.decodeBlob(allocator, encoded));
    }
}

fn allocationFailures(allocator: std.mem.Allocator) !void {
    var decoded = (try blob.decodeBlob(allocator, "AXicdYoxCgAACAK7ta3/fzYbhAhyUNGrkJJxcPFyDuXHsJgGGGMAhA==")).?;
    defer decoded.deinit(allocator);
    const encoded = (try blob.encodeFailure(allocator, decoded.choices)).?;
    defer allocator.free(encoded);
}

test "blob codec cleans up on every allocation failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, allocationFailures, .{});
}

// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const r = native.replay;
const Value = native.choices.ChoiceValue;
const gpa = std.testing.allocator;
var boolean_tag: std.meta.Tag(Value) = .boolean;
var integer_tag: std.meta.Tag(Value) = .integer;
fn accepts(ctx: *anyopaque, value: *const Value) bool {
    const tag: *const std.meta.Tag(Value) = @ptrCast(@alignCast(ctx));
    return std.meta.activeTag(value.*) == tag.*;
}
fn fit(tag: *std.meta.Tag(Value)) r.Fits {
    return .{ .context = tag, .call = accepts };
}
fn integer(n: i64) !Value {
    return .{ .integer = try native.bignum.BigInt.fromInt(gpa, n) };
}
fn served(replay: *r.Replay, position: usize, tag: *std.meta.Tag(Value)) !*const Value {
    const result = try replay.resolve(&.{}, position, &.{}, fit(tag));
    try std.testing.expect(result == .served);
    return result.served;
}
test "live pool prunes by compatible value and rescues newest compatible history" {
    var one = try integer(1);
    defer one.deinit(gpa);
    var two = try integer(2);
    defer two.deinit(gpa);
    var three = try integer(3);
    defer three.deinit(gpa);
    var nine = try integer(9);
    defer nine.deinit(gpa);
    var replay = try r.Replay.counterexample(gpa, &.{ &.{ .{ .boolean = true }, one, three }, &.{ .{ .boolean = true }, two, .{ .boolean = false }, nine } });
    defer replay.deinit();
    try std.testing.expect((try served(&replay, 0, &boolean_tag)).boolean);
    try std.testing.expect((try served(&replay, 1, &integer_tag)).eql(&one));
    try std.testing.expect(!((try served(&replay, 2, &boolean_tag)).boolean));
    try std.testing.expect((try served(&replay, 3, &integer_tag)).eql(&nine));
    try std.testing.expectEqual(@as(usize, 2), replay.divergence().?.position);
}
test "punning exposes mismatched value without recording divergence" {
    var replay = try r.Replay.pun(gpa, &.{.{ .boolean = true }}, null);
    defer replay.deinit();
    const result = try replay.resolve(&.{}, 0, &.{}, fit(&integer_tag));
    try std.testing.expect(result == .misfit);
    try std.testing.expect(result.misfit.value.boolean);
    try std.testing.expect(replay.divergence() == null);
    var child = try replay.cloneChild(&.{}, 0, &.{});
    defer child.deinit();
    try std.testing.expect((try child.resolve(&.{0}, 0, &.{}, fit(&boolean_tag))) == .exhausted);
    try std.testing.expect(replay.divergence() == null);
}
test "empty timelines record first divergence" {
    var replay = try r.Replay.counterexample(gpa, &.{&.{}});
    defer replay.deinit();
    try std.testing.expect((try replay.resolve(&.{2}, 4, &.{}, fit(&boolean_tag))) == .exhausted);
    try std.testing.expectEqual(@as(usize, 4), replay.divergence().?.position);
    try std.testing.expectEqualSlices(usize, &.{2}, replay.divergence().?.stream);
    try std.testing.expect((try replay.resolve(&.{}, 9, &.{}, fit(&boolean_tag))) == .exhausted);
    try std.testing.expectEqual(@as(usize, 4), replay.divergence().?.position);
}
test "child pruning selects the parent family history" {
    var number = try integer(1);
    defer number.deinit(gpa);
    var ca: Value = .{ .clone = try native.choices.CloneRecord.fromValuesCopy(gpa, &.{number}) };
    defer ca.deinit(gpa);
    var cb: Value = .{ .clone = try native.choices.CloneRecord.fromValuesCopy(gpa, &.{.{ .boolean = true }}) };
    defer cb.deinit(gpa);
    var replay = try r.Replay.counterexample(gpa, &.{ &.{ ca, .{ .boolean = false } }, &.{ cb, .{ .boolean = true } } });
    defer replay.deinit();
    var child = try replay.cloneChild(&.{}, 0, &.{});
    defer child.deinit();
    try std.testing.expect((try served(&child, 0, &boolean_tag)).boolean);
    try std.testing.expect((try served(&replay, 1, &boolean_tag)).boolean);
    try std.testing.expect(replay.divergence() == null);
}
test "graph ties settle by the next address" {
    const coin = [_]native.graph.Frame{.{ .label = 1, .ordinal = 0 }};
    const left = [_]native.graph.Frame{.{ .label = 2, .ordinal = 0 }};
    const right = [_]native.graph.Frame{.{ .label = 3, .ordinal = 0 }};
    var a = native.graph.Run.init(gpa);
    defer a.deinit();
    var b = native.graph.Run.init(gpa);
    defer b.deinit();
    try a.append(&coin, &.{ .boolean = true });
    try a.append(&left, &.{ .boolean = false });
    try b.append(&coin, &.{ .boolean = true });
    try b.append(&right, &.{ .boolean = true });
    var graph = try native.graph.Graph.fromRun(gpa, &a);
    defer graph.deinit();
    _ = try graph.graft(&b);
    var replay = try r.Replay.graph(gpa, &graph);
    defer replay.deinit();
    try std.testing.expect((try replay.resolve(&.{}, 0, &coin, fit(&boolean_tag))).served.boolean);
    try std.testing.expect((try replay.resolve(&.{}, 1, &right, fit(&boolean_tag))).served.boolean);
    try std.testing.expect(replay.endedOnEnd());
    try std.testing.expect(replay.divergence() == null);
    const settled = try replay.settled(gpa);
    defer gpa.free(settled);
    try std.testing.expectEqual(@as(usize, 2), settled.len);
}
fn allocationExercise(allocator: std.mem.Allocator) !void {
    var replay = try r.Replay.counterexample(allocator, &.{ &.{.{ .boolean = true }}, &.{.{ .boolean = false }} });
    defer replay.deinit();
    _ = try replay.resolve(&.{}, 0, &.{}, fit(&boolean_tag));
    var child = try replay.cloneChild(&.{}, 0, &.{});
    defer child.deinit();
    _ = try child.resolve(&.{0}, 0, &.{}, fit(&boolean_tag));
}
test "live family allocation failures release owned timelines" {
    try std.testing.checkAllAllocationFailures(gpa, allocationExercise, .{});
}
const ExternalContext = struct {
    destroyed: *usize,
    fn resolve(_: *anyopaque, _: std.mem.Allocator, _: []const usize, pos: usize, _: []const native.graph.Frame, _: r.Fits) anyerror!?Value {
        return if (pos == 0) Value{ .boolean = true } else null;
    }
    fn divergence(_: *anyopaque) ?r.Divergence {
        return null;
    }
    fn longest(_: *anyopaque) usize {
        return 1;
    }
    fn destroy(ctx: *anyopaque, allocator: std.mem.Allocator) void {
        const self: *ExternalContext = @ptrCast(@alignCast(ctx));
        self.destroyed.* += 1;
        allocator.destroy(self);
    }
    const vtable: r.ExternalReplay.VTable = .{ .resolve = resolve, .divergence = divergence, .longest = longest, .deinit = destroy };
};
test "external replay lifetime follows every shared child" {
    var destroyed: usize = 0;
    const ctx = try gpa.create(ExternalContext);
    ctx.* = .{ .destroyed = &destroyed };
    var replay = try r.Replay.external(gpa, .{ .context = ctx, .vtable = &ExternalContext.vtable });
    var child = try replay.cloneChild(&.{}, 0, &.{});
    try std.testing.expectEqual(@as(usize, 1), replay.longest());
    try std.testing.expect((try served(&replay, 0, &boolean_tag)).boolean);
    replay.deinit();
    try std.testing.expectEqual(@as(usize, 0), destroyed);
    try std.testing.expect((try served(&child, 0, &boolean_tag)).boolean);
    child.deinit();
    try std.testing.expectEqual(@as(usize, 1), destroyed);
}
fn graphAllocationExercise(allocator: std.mem.Allocator) !void {
    const addr = [_]native.graph.Frame{.{ .label = 4, .ordinal = 0 }};
    var ca: Value = .{ .clone = try native.choices.CloneRecord.fromValuesCopy(allocator, &.{.{ .boolean = true }}) };
    defer ca.deinit(allocator);
    var run = native.graph.Run.init(allocator);
    defer run.deinit();
    try run.append(&addr, &ca);
    var graph = try native.graph.Graph.fromRun(allocator, &run);
    defer graph.deinit();
    var replay = try r.Replay.graph(allocator, &graph);
    defer replay.deinit();
    var child = try replay.cloneChild(&.{}, 0, &addr);
    defer child.deinit();
    _ = try child.resolve(&.{0}, 0, &.{}, fit(&boolean_tag));
    const edges = try replay.settled(allocator);
    allocator.free(edges);
}
test "graph replay clone allocation failures unwind graph snapshots and family ties" {
    try std.testing.checkAllAllocationFailures(gpa, graphAllocationExercise, .{});
}

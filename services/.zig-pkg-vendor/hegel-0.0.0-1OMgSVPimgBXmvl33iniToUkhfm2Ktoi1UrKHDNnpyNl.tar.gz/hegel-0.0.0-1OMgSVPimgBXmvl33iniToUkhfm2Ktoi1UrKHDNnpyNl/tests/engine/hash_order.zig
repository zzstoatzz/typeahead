const std = @import("std");
const h = @import("hash_order");
const gpa = std.testing.allocator;
fn numbers(comptime T: type, text: []const u8, base: u8) ![]T {
    var items: std.ArrayList(T) = .empty;
    errdefer items.deinit(gpa);
    var values = std.mem.tokenizeScalar(u8, text, ',');
    while (values.next()) |value| try items.append(gpa, try std.fmt.parseInt(T, value, base));
    return items.toOwnedSlice(gpa);
}
test "span label hash and hashbrown iteration order match pinned Rust" {
    if (@sizeOf(usize) != 8) return error.SkipZigTest;
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/hash_order.tsv"), '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const keys = try numbers(u64, fields.next().?, 16);
        defer gpa.free(keys);
        const hashes = try numbers(u64, fields.next().?, 16);
        defer gpa.free(hashes);
        const expected = try numbers(usize, fields.next().?, 10);
        defer gpa.free(expected);
        for (keys, hashes) |key, hash| try std.testing.expectEqual(hash, h.hashU64(key));
        const actual = try h.u64MapOrderWithGroup(gpa, keys, 8);
        defer gpa.free(actual);
        try std.testing.expectEqualSlices(usize, expected, actual);
        count += 1;
    }
    try std.testing.expectEqual(@as(usize, 320), count);
}

import argparse
import pathlib
import subprocess

PIN = "33d94c659e441127ce7b5a0f046ec4aa9315d794"
HERE = pathlib.Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description="Compile the unmodified pinned ND decision module to generate comparison fixtures.")
    parser.add_argument("--upstream", type=pathlib.Path, default=pathlib.Path.home()/".cache/hegel-zig"/("hegel-rust-"+PIN))
    parser.add_argument("--work", type=pathlib.Path, default=HERE.parents[1]/"work/nd-oracle")
    parser.add_argument("--output", type=pathlib.Path, default=HERE/"fixtures/nd.tsv")
    args=parser.parse_args()
    revision=subprocess.check_output(["git","-C",str(args.upstream),"rev-parse","HEAD"],text=True).strip()
    if revision!=PIN: raise RuntimeError("unexpected upstream revision: "+revision)
    args.work.mkdir(parents=True,exist_ok=True)
    source=(HERE/"nd_oracle.rs.in").read_text().replace("@SOURCE@",str(args.upstream/"hegel-c/src/native/nd/mod.rs"))
    path=args.work/"main.rs";path.write_text(source)
    deps=args.upstream/"target/release/deps"
    libraries=list(deps.glob("liblibm-*.rlib"))
    if len(libraries)!=1: raise RuntimeError("expected one pinned compiled libm artifact")
    subprocess.run(["rustc","--edition=2024","-Awarnings",str(path),"-L","dependency="+str(deps),"--extern","libm="+str(libraries[0]),"-o",str(args.work/"oracle")],check=True)
    data=subprocess.check_output([str(args.work/"oracle")])
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_bytes(data)
    print("Generated",len(data.splitlines()),"rows from",PIN)

if __name__=="__main__":main()

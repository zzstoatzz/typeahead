const std = @import("std");
const statistics = @import("statistics");

fn integer(text: ?[]const u8) !u64 {
    return std.fmt.parseInt(u64, text orelse return error.MissingField, 10);
}

test "statistics match the pinned Rust numerical oracle" {
    const piecewise = try statistics.PiecewiseDistribution(statistics.UniformDistribution, statistics.LogStudentTDistribution).init(.init(256), .init(13, 2), 256);
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/statistics.tsv"), '\n');
    var differences: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const operation = fields.next().?[0];
        switch (operation) {
            'C', 'Q' => {
                const df: i32 = @intCast(try integer(fields.next()));
                const input: f64 = @bitCast(try integer(fields.next()));
                const expected = try integer(fields.next());
                const actual: u64 = @bitCast(if (operation == 'C') try statistics.stdtr(df, input) else try statistics.stdtrit(df, input));
                if (actual != expected) {
                    std.debug.print("{c} df={d} input={d}: expected {x}, got {x}\n", .{ operation, df, input, expected, actual });
                    differences += 1;
                }
            },
            'P' => {
                const input: f64 = @bitCast(try integer(fields.next()));
                const expected_cdf = try integer(fields.next());
                const expected_pdf = try integer(fields.next());
                const actual_cdf: u64 = @bitCast(try piecewise.cdf(input));
                const actual_pdf: u64 = @bitCast(piecewise.pdf(input));
                if (actual_cdf != expected_cdf or actual_pdf != expected_pdf) {
                    std.debug.print("P input={d}: cdf expected {x} got {x}; pdf expected {x} got {x}\n", .{ input, expected_cdf, actual_cdf, expected_pdf, actual_pdf });
                    differences += 1;
                }
            },
            'J' => {
                const input: f64 = @bitCast(try integer(fields.next()));
                const expected = try integer(fields.next());
                const actual: u64 = @bitCast(try piecewise.inverseCdf(input));
                if (actual != expected) {
                    std.debug.print("J input={d}: expected {x}, got {x}\n", .{ input, expected, actual });
                    differences += 1;
                }
            },
            else => return error.UnknownOperation,
        }
        try std.testing.expectEqual(null, fields.next());
    }
    try std.testing.expectEqual(@as(usize, 0), differences);
}

test "statistical parameter errors are explicit" {
    try std.testing.expectError(error.InternalError, statistics.stdtr(0, 1));
    try std.testing.expectError(error.InternalError, statistics.stdtrit(0, 0.5));
    try std.testing.expectError(error.InternalError, statistics.stdtrit(1, 0));
    try std.testing.expectError(error.InternalError, statistics.stdtrit(1, 1));
    try std.testing.expectError(error.InternalError, statistics.PiecewiseDistribution(statistics.UniformDistribution, statistics.UniformDistribution).init(.init(1), .init(2), 3));
}

const std = @import("std");
const api = @import("api");
const p = api.printer_api;
const t = api.types;
test "printer C handles validate text, preserve anchored content, and invalidate slots" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    var options: ?*p.HegelPrinterOptions = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_options_new(ctx, &options));
    defer _ = p.hegel_printer_options_free(ctx, options);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_printer_options_set_max_width(ctx, options, 0));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_options_set_max_width(ctx, options, 8));
    var root: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_new(ctx, options, &root));
    defer _ = p.hegel_printer_free(ctx, root);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_printer_text(ctx, root, "x\ny", 3));
    try std.testing.expectEqualStrings("hegel_printer_text: text must not contain newlines", std.mem.span(api.hegel_context_last_error(ctx)));
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_printer_text(ctx, root, &[_]u8{0xff}, 1));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_begin_group(ctx, root, 2, "[", 1));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "abc", 3));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_breakable(ctx, root, " ", 1));
    var child: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_deferred(ctx, root, &child));
    defer _ = p.hegel_printer_free(ctx, child);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, child, "defghi", 6));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_end_group(ctx, root, "]", 1));
    var value: t.hegel_printer_value_result_t = .{};
    defer _ = p.hegel_printer_value_result_free(ctx, &value);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_printer_value(ctx, root, &value));
    try std.testing.expectEqualStrings("hegel_printer_value: printer has unresolved deferred slots", std.mem.span(api.hegel_context_last_error(ctx)));
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_printer_resolve(ctx, child));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_resolve(ctx, root));
    var live = true;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_is_live(ctx, child, &live));
    try std.testing.expect(!live);
    try std.testing.expectEqual(t.HEGEL_E_INVALID_HANDLE, p.hegel_printer_text(ctx, child, "late", 4));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value(ctx, root, &value));
    try std.testing.expectEqualStrings("[abc\n  defghi]", value.data[0..value.len]);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value_result_free(ctx, &value));
    try std.testing.expect(value.data == null and value.len == 0);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value_result_free(ctx, &value));
}
test "empty printer buffers remain owned" {
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    var root: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_new(ctx, null, &root));
    defer _ = p.hegel_printer_free(ctx, root);
    var value: t.hegel_printer_value_result_t = .{};
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value(ctx, root, &value));
    defer _ = p.hegel_printer_value_result_free(ctx, &value);
    try std.testing.expect(value.data != null and value.len == 0);
}

const ThreadWriter = struct {
    printer: *p.HegelPrinter,
    byte: u8,
    count: usize,
    failed: std.atomic.Value(bool) = .init(false),
    fn run(self: *@This()) void {
        for (0..self.count) |_| {
            if (p.hegel_printer_text(null, self.printer, @ptrCast(&self.byte), 1) != t.HEGEL_OK) self.failed.store(true, .release);
        }
    }
};
test "concurrent region writes preserve anchors and same-handle races reject" {
    var root: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_new(null, null, &root));
    defer _ = p.hegel_printer_free(null, root);
    var left: ?*p.HegelPrinter = null;
    var right: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_deferred(null, root, &left));
    defer _ = p.hegel_printer_free(null, left);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_deferred(null, root, &right));
    defer _ = p.hegel_printer_free(null, right);
    var a = ThreadWriter{ .printer = left.?, .byte = 'a', .count = 100 };
    var b = ThreadWriter{ .printer = right.?, .byte = 'b', .count = 100 };
    const ta = try std.Thread.spawn(.{}, ThreadWriter.run, .{&a});
    const tb = std.Thread.spawn(.{}, ThreadWriter.run, .{&b}) catch |err| {
        ta.join();
        return err;
    };
    ta.join();
    tb.join();
    try std.testing.expect(!a.failed.load(.acquire) and !b.failed.load(.acquire));
    left.?.inner.mutex.lock();
    var cwriter = ThreadWriter{ .printer = left.?, .byte = 'c', .count = 1 };
    const tc = std.Thread.spawn(.{}, ThreadWriter.run, .{&cwriter}) catch |err| {
        left.?.inner.mutex.unlock();
        return err;
    };
    while (!left.?.busy.load(.acquire)) std.atomic.spinLoopHint();
    const race_result = p.hegel_printer_text(null, left, "bad", 3);
    left.?.inner.mutex.unlock();
    tc.join();
    try std.testing.expectEqual(t.HEGEL_E_CONCURRENT_USE, race_result);
    try std.testing.expect(!cwriter.failed.load(.acquire));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_resolve(null, root));
    var value: t.hegel_printer_value_result_t = .{};
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value(null, root, &value));
    defer _ = p.hegel_printer_value_result_free(null, &value);
    try std.testing.expectEqual(201, value.len);
    for (value.data[0..100]) |byte| try std.testing.expectEqual(@as(u8, 'a'), byte);
    try std.testing.expectEqual(@as(u8, 'c'), value.data[100]);
    for (value.data[101..201]) |byte| try std.testing.expectEqual(@as(u8, 'b'), byte);
}
test "family printer width is fixed by first explicit option and handles outlive cases" {
    const a = std.testing.allocator;
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    var settings: ?*api.HegelSettings = null;
    try std.testing.expectEqual(t.HEGEL_OK, api.settings_api.hegel_settings_new_for_profile(ctx, "base", &settings));
    defer _ = api.settings_api.hegel_settings_free(ctx, settings);
    const raw = (try api.blob_mod.encodeFailure(a, &.{})).?;
    defer a.free(raw);
    const blob = try a.dupeSentinel(u8, raw, 0);
    defer a.free(blob);
    var tc: ?*api.HegelTestCase = null;
    try std.testing.expectEqual(t.HEGEL_OK, api.test_cases.hegel_test_case_from_blob(ctx, settings, blob.ptr, null, null, &tc));
    defer if (tc) |case| {
        _ = api.test_cases.hegel_test_case_free(ctx, case);
    };
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_note(ctx, tc, "before", 6));
    var root: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_test_case_printer(ctx, tc, null, &root));
    defer _ = p.hegel_printer_free(ctx, root);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_begin_group(ctx, root, 2, "[", 1));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "abc", 3));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_breakable(ctx, root, " ", 1));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "defghi", 6));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_end_group(ctx, root, "]", 1));
    var options: ?*p.HegelPrinterOptions = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_options_new(ctx, &options));
    defer _ = p.hegel_printer_options_free(ctx, options);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_options_set_max_width(ctx, options, 8));
    var second: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_test_case_printer(ctx, tc, options, &second));
    defer _ = p.hegel_printer_free(ctx, second);
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_options_set_max_width(ctx, options, 10));
    var conflict: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_E_INVALID_ARG, p.hegel_test_case_printer(ctx, tc, options, &conflict));
    try std.testing.expect(conflict == null);
    try std.testing.expectEqualStrings("hegel_test_case_printer: the family's document is laid out to max_width 8 and cannot change to 10", std.mem.span(api.hegel_context_last_error(ctx)));
    try std.testing.expectEqual(t.HEGEL_OK, api.test_cases.hegel_test_case_free(ctx, tc));
    tc = null;
    var value: t.hegel_printer_value_result_t = .{};
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value(ctx, root, &value));
    defer _ = p.hegel_printer_value_result_free(ctx, &value);
    try std.testing.expectEqualStrings("before\n[abc\n  defghi]", value.data[0..value.len]);
}
test "existing printer attribution follows worker changes and held notes survive abort" {
    const a = std.testing.allocator;
    const ctx = api.hegel_context_new().?;
    defer _ = api.hegel_context_free(ctx);
    var settings: ?*api.HegelSettings = null;
    try std.testing.expectEqual(t.HEGEL_OK, api.settings_api.hegel_settings_new_for_profile(ctx, "base", &settings));
    defer _ = api.settings_api.hegel_settings_free(ctx, settings);
    const raw = (try api.blob_mod.encodeFailure(a, &.{})).?;
    defer a.free(raw);
    const blob = try a.dupeSentinel(u8, raw, 0);
    defer a.free(blob);
    var tc: ?*api.HegelTestCase = null;
    try std.testing.expectEqual(t.HEGEL_OK, api.test_cases.hegel_test_case_from_blob(ctx, settings, blob.ptr, null, null, &tc));
    defer _ = api.test_cases.hegel_test_case_free(ctx, tc);
    tc.?.family.started = null;
    var root: ?*p.HegelPrinter = null;
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_test_case_printer(ctx, tc, null, &root));
    defer _ = p.hegel_printer_free(ctx, root);
    try std.testing.expectEqual(t.HEGEL_OK, api.test_cases.hegel_test_case_set_worker(ctx, tc, 3));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "a", 1));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_hard_break(ctx, root));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_begin_speculative(ctx, root));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "lost", 4));
    try std.testing.expectEqual(t.HEGEL_OK, api.test_cases.hegel_test_case_set_worker(ctx, tc, 4));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_note(ctx, tc, "inside", 6));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_abort_speculative(ctx, root));
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_text(ctx, root, "b", 1));
    var value: t.hegel_printer_value_result_t = .{};
    try std.testing.expectEqual(t.HEGEL_OK, p.hegel_printer_value(ctx, root, &value));
    defer _ = p.hegel_printer_value_result_free(ctx, &value);
    try std.testing.expectEqualStrings("[worker 3 +0.000ms] a\n[worker 4 +0.000ms] inside\n[worker 4 +0.000ms] b", value.data[0..value.len]);
}

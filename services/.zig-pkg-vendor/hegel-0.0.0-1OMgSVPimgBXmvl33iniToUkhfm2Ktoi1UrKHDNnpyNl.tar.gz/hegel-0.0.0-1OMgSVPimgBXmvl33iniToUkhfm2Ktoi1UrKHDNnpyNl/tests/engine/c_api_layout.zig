const std = @import("std");
const types = @import("types");
const header = @import("header");

test "native C ABI enum values match the pinned original header" {
    inline for (@typeInfo(types).@"struct".decl_names) |name| {
        if (comptime std.mem.startsWith(u8, name, "HEGEL_") and !std.mem.eql(u8, name, "HEGEL_H")) {
            try std.testing.expectEqual(@as(i128, @intCast(@field(header, name))), @as(i128, @intCast(@field(types, name))));
        }
    }
    inline for (.{ "hegel_result_t", "hegel_status_t", "hegel_backend_t", "hegel_run_status_t", "hegel_verbosity_t", "hegel_nondeterminism_strictness_t", "hegel_phase_t", "hegel_health_check_t" }) |name| {
        try std.testing.expectEqual(@sizeOf(@field(header, name)), @sizeOf(@field(types, name)));
        try std.testing.expectEqual(@alignOf(@field(header, name)), @alignOf(@field(types, name)));
    }
}

test "every native C wire struct matches header field size alignment and offset" {
    inline for (.{ "hegel_generate_bytes_result_t", "hegel_generate_string_result_t", "hegel_date_t", "hegel_time_t", "hegel_datetime_t", "hegel_printer_value_result_t" }) |name| {
        const Original = @field(header, name);
        const Native = @field(types, name);
        try std.testing.expectEqual(@sizeOf(Original), @sizeOf(Native));
        try std.testing.expectEqual(@alignOf(Original), @alignOf(Native));
        try std.testing.expectEqual(@typeInfo(Original).@"struct".field_names.len, @typeInfo(Native).@"struct".field_names.len);
        inline for (@typeInfo(Native).@"struct".field_names) |field_name| {
            const Field = @FieldType(Native, field_name);
            try std.testing.expectEqual(@offsetOf(Original, field_name), @offsetOf(Native, field_name));
            try std.testing.expectEqual(@sizeOf(@FieldType(Original, field_name)), @sizeOf(Field));
            try std.testing.expectEqual(@alignOf(@FieldType(Original, field_name)), @alignOf(Field));
        }
    }
}

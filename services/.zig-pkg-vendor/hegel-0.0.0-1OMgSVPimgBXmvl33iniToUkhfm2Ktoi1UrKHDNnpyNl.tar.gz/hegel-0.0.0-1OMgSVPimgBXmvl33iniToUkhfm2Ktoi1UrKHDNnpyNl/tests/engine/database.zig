const std = @import("std");
const native = @import("native");
const db = native.database;
const Value = native.choices.ChoiceValue;
const BigInt = native.bignum.BigInt;

test "choice storage matches the pinned Rust failure blob" {
    const allocator = std.testing.allocator;
    const bytes = @embedFile("fixtures/stale_cache.choices");
    const values = (try db.deserializeChoicesExact(allocator, bytes)).?;
    defer db.deinitValues(allocator, values);
    const encoded = (try db.serializeChoices(allocator, values)).?;
    defer allocator.free(encoded);
    try std.testing.expectEqualSlices(u8, bytes, encoded);
    for (0..bytes.len) |end| {
        const partial = try db.deserializeChoicesExact(allocator, bytes[0..end]);
        if (partial) |result| {
            db.deinitValues(allocator, result);
            return error.TruncatedStorageAccepted;
        }
    }
}

test "legacy integer widths, noncanonical booleans, and trailing data retain compatibility" {
    const allocator = std.testing.allocator;
    const bytes = [_]u8{ 2, 0, 0, 0, 0, 0, 255, 1, 7, 99 };
    const values = (try db.deserializeChoices(allocator, &bytes)).?;
    defer db.deinitValues(allocator, values);
    try std.testing.expectEqual(@as(i8, -1), values[0].integer.toInt(i8).?);
    try std.testing.expect(values[1].boolean);
    try std.testing.expectEqual(null, try db.deserializeChoicesExact(allocator, &bytes));
    const unknown = [_]u8{ 1, 0, 0, 0, 255 };
    try std.testing.expectEqual(null, try db.deserializeChoices(allocator, &unknown));
}

test "choice storage preserves large integers, float bits, raw codepoints, and nested clones" {
    const allocator = std.testing.allocator;
    const children = try allocator.alloc(Value, 1);
    children[0] = .{ .bytes = try allocator.dupe(u8, "child") };
    var values = [_]Value{
        .{ .integer = try BigInt.fromString(allocator, 16, "-10000000000000000000000000000000000000000000000000000000000000001") },
        .{ .float = @bitCast(@as(u64, 0xfff8000000000042)) },
        .{ .float = -0.0 },
        .{ .string = try allocator.dupe(u32, &.{ 0, 0xd800, 0x10ffff, 0xffffffff }) },
        .{ .clone = try native.choices.CloneRecord.fromValues(allocator, children) },
    };
    defer for (&values) |*value| value.deinit(allocator);
    const encoded = (try db.serializeChoices(allocator, &values)).?;
    defer allocator.free(encoded);
    const decoded = (try db.deserializeChoicesExact(allocator, encoded)).?;
    defer db.deinitValues(allocator, decoded);
    try std.testing.expectEqual(values.len, decoded.len);
    for (&values, decoded) |*a, *b| try std.testing.expect(a.eql(b));
}

fn codecAllocationFailures(allocator: std.mem.Allocator) !void {
    const values = (try db.deserializeChoicesExact(allocator, @embedFile("fixtures/stale_cache.choices"))).?;
    defer db.deinitValues(allocator, values);
    const encoded = (try db.serializeChoices(allocator, values)).?;
    defer allocator.free(encoded);
}

test "choice codec releases partial allocations on every failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, codecAllocationFailures, .{});
}

test "directory corpus persists a set, tracks keys, moves absent entries, and tolerates IO failures" {
    const allocator = std.testing.allocator;
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    const root = try std.fmt.allocPrint(allocator, ".zig-cache/tmp/{s}/corpus", .{tmp.sub_path});
    defer allocator.free(root);
    var corpus = try db.DirectoryDatabase.init(allocator, std.testing.io, root);
    defer corpus.deinit();
    corpus.save("case/a", "first");
    corpus.save("case/a", "first");
    corpus.save("case/a", "second");
    const values = try corpus.fetch(allocator, "case/a");
    defer freeBytes(allocator, values);
    try std.testing.expectEqual(@as(usize, 2), values.len);
    const keys = try corpus.fetch(allocator, db.metakeys_name);
    defer freeBytes(allocator, keys);
    try std.testing.expectEqual(@as(usize, 1), keys.len);
    try std.testing.expectEqualStrings("case/a", keys[0]);
    corpus.moveValue("case/a", "case/b", "first");
    corpus.moveValue("missing", "case/b", "third");
    corpus.moveValue("case/b", "case/b", "third");
    const moved = try corpus.fetch(allocator, "case/b");
    defer freeBytes(allocator, moved);
    try std.testing.expectEqual(@as(usize, 2), moved.len);
    corpus.delete("case/a", "second");
    const empty = try corpus.fetch(allocator, "case/a");
    defer freeBytes(allocator, empty);
    try std.testing.expectEqual(@as(usize, 0), empty.len);
    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "not-a-directory", .data = "data" });
    const bad = try std.fmt.allocPrint(allocator, ".zig-cache/tmp/{s}/not-a-directory/corpus", .{tmp.sub_path});
    defer allocator.free(bad);
    var broken = try db.DirectoryDatabase.init(allocator, std.testing.io, bad);
    defer broken.deinit();
    broken.save("key", "value");
    broken.delete("key", "value");
    broken.moveValue("a", "b", "value");
    const missing = try broken.fetch(allocator, "key");
    defer freeBytes(allocator, missing);
    try std.testing.expectEqual(@as(usize, 0), missing.len);
}

fn freeBytes(allocator: std.mem.Allocator, values: [][]u8) void {
    for (values) |value| allocator.free(value);
    allocator.free(values);
}

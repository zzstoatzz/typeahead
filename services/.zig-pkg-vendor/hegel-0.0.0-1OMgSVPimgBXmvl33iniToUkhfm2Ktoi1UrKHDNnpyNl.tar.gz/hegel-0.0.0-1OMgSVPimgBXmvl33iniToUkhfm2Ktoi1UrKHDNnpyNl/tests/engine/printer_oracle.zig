const std = @import("std");
const p = @import("printer");
fn decode(a: std.mem.Allocator, text: []const u8) ![]u8 {
    if (std.mem.eql(u8, text, "_")) return a.alloc(u8, 0);
    const bytes = try a.alloc(u8, text.len / 2);
    errdefer a.free(bytes);
    return std.fmt.hexToBytes(bytes, text);
}
test "printer and reflow exactly match original Rust layouts" {
    const a = std.testing.allocator;
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/printer.tsv"), '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        var cols = std.mem.splitScalar(u8, line, '\t');
        const name = cols.next().?;
        const width = try std.fmt.parseInt(usize, cols.next().?, 10);
        const input = try decode(a, cols.next().?);
        defer a.free(input);
        const expected = try decode(a, cols.next().?);
        defer a.free(expected);
        const expected_error = cols.next().?;
        var printer = p.Printer.init(a, width);
        defer printer.deinit();
        if (std.mem.eql(u8, name, "reflow")) {
            try p.reflow.reflow(&printer, .main, input, .{});
        } else {
            const program = try std.fmt.parseInt(u8, name[7..], 10);
            switch (program) {
                0 => {
                    try printer.beginGroup(.main, 2, "[");
                    try printer.text(.main, "αβ");
                    try printer.breakable(.main, " ");
                    try printer.beginGroup(.main, 1, "(");
                    try printer.text(.main, "gamma");
                    try printer.breakable(.main, ", ");
                    try printer.text(.main, "δ");
                    try printer.ifBreak(.main, ",");
                    try printer.endGroup(.main, ")");
                    try printer.endGroup(.main, "]");
                },
                1 => {
                    try printer.beginGroup(.main, 2, "[");
                    try printer.text(.main, "a");
                    try printer.comment(.main, " // note");
                    try printer.breakable(.main, " ");
                    try printer.text(.main, "b");
                    try printer.endGroup(.main, "\u{2003}]");
                },
                2 => {
                    try printer.linePrefix(.main, "> ");
                    const b = try printer.block(.main, 3);
                    try printer.text(.{ .slot = b }, "hello");
                    try printer.hardBreak(.{ .slot = b });
                    const child = try printer.block(.{ .slot = b }, 2);
                    try printer.text(.{ .slot = child }, "world");
                    try printer.hardBreak(.{ .slot = child });
                    try printer.text(.main, "tail");
                    try printer.resolve();
                },
                3 => {
                    try printer.text(.main, "keep");
                    try printer.beginSpeculative(.main);
                    try printer.text(.main, "lost");
                    const slot = try printer.deferred(.main);
                    try printer.text(.{ .slot = slot }, "gone");
                    try printer.note(.main, "note\nnext", "! ");
                    try printer.abortSpeculative(.main);
                    try std.testing.expect(!printer.slotIsLive(slot));
                    try printer.beginSpeculative(.main);
                    try printer.text(.main, "commit");
                    try printer.commitSpeculative(.main);
                },
                4 => {
                    try printer.beginSpeculative(.main);
                    try printer.endGroup(.main, "bad");
                    try std.testing.expectError(error.UnbalancedGroup, printer.commitSpeculative(.main));
                    try printer.abortSpeculative(.main);
                    const slot = try printer.deferred(.main);
                    try printer.beginSpeculative(.{ .slot = slot });
                    try printer.text(.{ .slot = slot }, "discard");
                    try printer.resolve();
                },
                else => return error.InvalidFixture,
            }
        }
        const actual = try printer.value();
        if (!std.mem.eql(u8, expected, actual)) {
            std.debug.print("{s} width{d} input{s}\n", .{ name, width, input });
            try std.testing.expectEqualStrings(expected, actual);
        }
        if (!std.mem.eql(u8, expected_error, "_")) {
            try std.testing.expectError(error.DeadSlot, printer.text(.main, "late"));
            try std.testing.expectEqualStrings(expected_error, p.errorMessage(error.DeadSlot));
        }
        count += 1;
    }
    try std.testing.expectEqual(498, count);
}

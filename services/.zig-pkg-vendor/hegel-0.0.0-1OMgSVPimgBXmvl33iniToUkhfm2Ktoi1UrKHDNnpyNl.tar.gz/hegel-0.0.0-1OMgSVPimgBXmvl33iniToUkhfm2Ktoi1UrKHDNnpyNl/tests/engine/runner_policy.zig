const std = @import("std");
const p = @import("policy");
test "filtered spaces stop after the source confidence budget" {
    const budget = p.invalidThresholds(0.01, 0.99);
    try std.testing.expectEqual(@as(u64, 458), budget.base);
    try std.testing.expectEqual(@as(u64, 100), budget.per_valid);
    try std.testing.expect(p.withinInvalidBudget(458, 0, 0, budget));
    try std.testing.expect(!p.withinInvalidBudget(459, 0, 0, budget));
    try std.testing.expect(p.withinInvalidBudget(558, 0, 1, budget));
    try std.testing.expect(!p.withinInvalidBudget(558, 1, 1, budget));
}
test "health checks stop at ten valid cases and distinguish initial invalidity" {
    try std.testing.expect(p.tooSlow(9, 31, 30, false));
    try std.testing.expect(!p.tooSlow(10, 31, 30, false));
    try std.testing.expect(!p.tooSlow(9, 30, 30, false));
    try std.testing.expect(p.tooLarge(9, 20, false));
    try std.testing.expect(!p.tooLarge(9, 20, true));
    try std.testing.expect(!p.largeInitial(false, .invalid, 100, 100, false));
    try std.testing.expect(p.largeInitial(false, .valid, 51, 100, false));
    try std.testing.expect(!p.largeInitial(false, .valid, 50, 100, false));
    try std.testing.expect(p.largeInitial(true, .early_stop, 1, 100, false));
}
test "additional bug discovery honors execution and elapsed-time boundaries" {
    try std.testing.expect(p.shouldGenerateMore(true, 9999, null, null, false, false, null));
    try std.testing.expect(p.shouldGenerateMore(false, 9, 1, 1, true, true, null));
    try std.testing.expect(!p.shouldGenerateMore(false, 10, 1, 1, true, true, null));
    try std.testing.expect(p.shouldGenerateMore(false, 199, 100, null, true, true, 10_000_000_000));
    try std.testing.expect(!p.shouldGenerateMore(false, 200, 100, null, true, true, null));
    try std.testing.expect(!p.shouldGenerateMore(false, 1, 100, null, true, true, 10_000_000_001));
}
test "target schedule advances from the observed count" {
    var schedule = p.TargetingSchedule.init(100);
    try std.testing.expect(!schedule.shouldFire(49));
    try std.testing.expect(schedule.shouldFire(60));
    try std.testing.expect(!schedule.shouldFire(60));
    try std.testing.expect(!schedule.shouldFire(109));
    try std.testing.expect(schedule.shouldFire(110));
}
test "duration diagnostics use Rust debug units and precision" {
    const gpa = std.testing.allocator;
    for ([_]struct { u128, []const u8 }{ .{ 30_000_000_000, "30s" }, .{ 1_000_000_001, "1.000000001s" }, .{ 1_200, "1.2µs" }, .{ 1_050_000, "1.05ms" }, .{ 1, "1ns" } }) |fixture| {
        const formatted = try p.formatDuration(gpa, fixture[0]);
        defer gpa.free(formatted);
        try std.testing.expectEqualStrings(fixture[1], formatted);
    }
}

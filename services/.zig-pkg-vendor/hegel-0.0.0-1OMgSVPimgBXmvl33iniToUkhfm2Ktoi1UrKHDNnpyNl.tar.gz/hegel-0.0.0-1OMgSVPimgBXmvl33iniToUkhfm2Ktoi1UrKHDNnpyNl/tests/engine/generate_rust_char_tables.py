import pathlib
import subprocess

HERE=pathlib.Path(__file__).resolve().parent
EXPECTED="rustc 1.96.0 (ac68faa20 2026-05-25)"
version=subprocess.check_output(["rustc","--version"],text=True).strip()
if version!=EXPECTED:
    raise RuntimeError(f"expected oracle compiler {EXPECTED}, got {version}")
work=HERE.parents[1]/"work/rust-char-oracle"
work.mkdir(parents=True,exist_ok=True)
subprocess.run(["rustc","--crate-name","rust_char_tables",str(HERE/"rust_char_tables.rs.in"),"-o",str(work/"oracle")],check=True)
tables=subprocess.check_output([str(work/"oracle")])
if not tables.startswith(b"V 17 0 0\n"):
    raise RuntimeError("Rust standard library Unicode version changed")
lines=tables.splitlines(keepends=True)
(HERE.parents[1]/"src/engine/unicode/rust_char_data.tsv").write_bytes(b"".join(line for line in lines if line[:1] not in (b"L",b"U")))
(HERE.parents[1]/"src/engine/unicode/rust_char_expansions.tsv").write_bytes(b"".join(line for line in lines if line[:1] in (b"L",b"U")))

const std = @import("std");
const s = @import("settings");
const Entry = struct { []const u8, []const u8 };
const Env = struct {
    entries: []const Entry,
    fn get(context: ?*anyopaque, key: []const u8) ?[]const u8 {
        const self: *const Env = @ptrCast(@alignCast(context.?));
        for (self.entries) |entry| if (std.mem.eql(u8, entry[0], key)) return entry[1];
        return null;
    }
    fn view(self: *const Env) s.Environment {
        return .{ .context = @constCast(self), .get = get };
    }
};
test "settings overrides preserve unusual Rust environment semantics" {
    const env: Env = .{ .entries = &.{ .{ "HEGEL_TEST_CASES", "+42" }, .{ "HEGEL_SEED", "18446744073709551615" }, .{ "HEGEL_DATABASE", "disabled" }, .{ "HEGEL_STATISTICS", "false" }, .{ "HEGEL_PRINT_BLOB", "no" }, .{ "HEGEL_DERANDOMIZE", "yes" }, .{ "HEGEL_NONDETERMINISM_STRICTNESS", "error" } } };
    const settings = try (s.Settings{}).withEnvOverrides(env.view());
    try std.testing.expectEqual(@as(u64, 42), settings.test_cases);
    try std.testing.expectEqual(std.math.maxInt(u64), settings.seed.?);
    try std.testing.expect(settings.show_statistics and settings.derandomize and !settings.print_blob);
    try std.testing.expect(settings.database == .disabled);
    try std.testing.expectEqual(s.NondeterminismStrictness.@"error", settings.nondeterminism_strictness);
    const zero: Env = .{ .entries = &.{ .{ "HEGEL_STATISTICS", "0" }, .{ "HEGEL_SEED", "none" }, .{ "HEGEL_TEST_CASES", "" } } };
    const unchanged = try settings.withEnvOverrides(zero.view());
    try std.testing.expect(unchanged.show_statistics and unchanged.seed == null);
    try std.testing.expectEqual(@as(u64, 42), unchanged.test_cases);
    inline for (.{ "0", "-1", " 1", "1_0", "18446744073709551616" }) |bad| {
        const invalid: Env = .{ .entries = &.{.{ "HEGEL_TEST_CASES", bad }} };
        try std.testing.expectError(error.InvalidEnvironment, settings.withEnvOverrides(invalid.view()));
    }
}
test "CI presence differs from exact true and empty settings" {
    const present: Env = .{ .entries = &.{.{ "CI", "" }} };
    try std.testing.expect(s.isInCi(present.view()));
    const false_ci: Env = .{ .entries = &.{.{ "GITHUB_ACTIONS", "TRUE" }} };
    try std.testing.expect(!s.isInCi(false_ci.view()));
    const true_ci: Env = .{ .entries = &.{.{ "GITHUB_ACTIONS", "true" }} };
    try std.testing.expect(s.isInCi(true_ci.view()));
    try std.testing.expect(s.parseBool("TRUE") == null);
    var settings: s.Settings = .{};
    try std.testing.expectEqual(@as(usize, 1 << 20), settings.choiceBound());
    settings.suppress_health_check = &.{.test_cases_too_large};
    try std.testing.expectEqual(std.math.maxInt(usize), settings.choiceBound());
}
fn cloneSettings(allocator: std.mem.Allocator) !void {
    const original: s.Settings = .{ .database = .{ .path = "corpus" }, .config_path = "hegel.toml", .suppress_health_check = &.{.too_slow} };
    var owned = try original.deepClone(allocator);
    defer owned.deinitOwned(allocator);
    try std.testing.expectEqualStrings("corpus", owned.database.path);
    try std.testing.expect(owned.database.path.ptr != original.database.path.ptr);
}
test "settings snapshots own profile strings and clean up allocation failure" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, cloneSettings, .{});
}

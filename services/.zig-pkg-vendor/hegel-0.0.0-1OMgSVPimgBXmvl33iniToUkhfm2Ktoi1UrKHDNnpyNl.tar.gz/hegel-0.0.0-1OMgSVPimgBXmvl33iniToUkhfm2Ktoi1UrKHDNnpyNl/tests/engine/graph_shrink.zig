// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const gs = native.graph_shrink;
const c = native.choices;
const gpa = std.testing.allocator;
const Probe = struct {
    allocator: std.mem.Allocator,
    calls: usize = 0,
    adopts: usize = 0,
    fn replay(ctx: *anyopaque, graph: *const native.graph.Graph, max_size: usize) anyerror!gs.Outcome {
        const self: *Probe = @ptrCast(@alignCast(ctx));
        self.calls += 1;
        var tc = try native.state.NativeTestCase.forGraph(self.allocator, graph, .seeded(@intCast(self.calls)), max_size);
        defer tc.deinit();
        var lo = try c.BigInt.fromInt(self.allocator, @as(u8, 0));
        defer lo.deinit();
        var hi = try c.BigInt.fromInt(self.allocator, @as(u8, 100));
        defer hi.deinit();
        var number = try tc.drawInteger(lo, hi);
        defer number.deinit();
        const failed = number.toInt(i64).? >= 5;
        try tc.freeze();
        const nodes = try c.cloneNodes(self.allocator, tc.nodes.items);
        errdefer c.deinitNodes(self.allocator, nodes);
        const spans = try self.allocator.dupe(c.Span, tc.spans.asSlice());
        errdefer self.allocator.free(spans);
        return .{ .failed = failed, .divergence = tc.divergence() != null, .ended = tc.endedOnEnd(), .settled = try tc.settledEdges(self.allocator), .nodes = nodes, .spans = spans };
    }
    fn charge(_: *anyopaque, _: f64, _: bool) u64 {
        return 4;
    }
    fn adopted(ctx: *anyopaque, _: *const native.graph.Graph, _: []const c.ChoiceNode, _: []const c.Span, _: f64, _: usize) anyerror!void {
        const self: *Probe = @ptrCast(@alignCast(ctx));
        self.adopts += 1;
    }
    fn interface(self: *Probe) gs.GraphProbe {
        return .{ .context = self, .replay = replay, .charge = charge, .adopted = adopted };
    }
};
fn exercise(allocator: std.mem.Allocator) !void {
    var value = c.ChoiceValue{ .integer = try c.BigInt.fromInt(allocator, @as(u8, 100)) };
    defer value.deinit(allocator);
    var tc = try native.state.NativeTestCase.forChoices(allocator, &.{value}, null, null);
    defer tc.deinit();
    var lo = try c.BigInt.fromInt(allocator, @as(u8, 0));
    defer lo.deinit();
    var hi = try c.BigInt.fromInt(allocator, @as(u8, 100));
    defer hi.deinit();
    var n = try tc.drawInteger(lo, hi);
    n.deinit();
    try tc.freeze();
    var run = try native.graph.Run.fromNodes(allocator, tc.nodes.items, tc.spans.asSlice());
    defer run.deinit();
    var graph = try native.graph.Graph.fromRun(allocator, &run);
    defer graph.deinit();
    var shrinker = try gs.GraphShrinker.init(allocator, &graph, tc.nodes.items, tc.spans.asSlice(), 0.5);
    defer shrinker.deinit();
    var probe = Probe{ .allocator = allocator };
    try shrinker.shrink(probe.interface());
    try std.testing.expectEqual(@as(?i64, 5), shrinker.witness_nodes[0].data.integer.value.toInt(i64));
    try std.testing.expect(probe.adopts > 0);
    try std.testing.expect(shrinker.replays() >= native.nd.ANCHOR_SEED_RUNS);
    try std.testing.expect(shrinker.anchor() > 0.5);
}
test "real state replay and gauntlet shrink integer failure to exact threshold" {
    try exercise(gpa);
}
test "spans delete nested draws and renumber only later same-label siblings" {
    var run = native.graph.Run.init(gpa);
    defer run.deinit();
    try run.append(&.{ .{ .label = 1, .ordinal = 0 }, .{ .label = 2, .ordinal = 0 }, .{ .label = native.graph.DRAW_LABEL, .ordinal = 0 } }, &.{ .boolean = true });
    try run.append(&.{ .{ .label = 1, .ordinal = 0 }, .{ .label = 2, .ordinal = 1 }, .{ .label = native.graph.DRAW_LABEL, .ordinal = 0 } }, &.{ .boolean = false });
    const spans = try gs.spansOf(gpa, &run);
    defer {
        for (spans) |span| gpa.free(span.addr);
        gpa.free(spans);
    }
    try std.testing.expectEqual(@as(usize, 3), spans.len);
    try std.testing.expectEqual(@as(usize, 1), spans[0].start);
    var shorter = try gs.withoutSpan(gpa, &run, &.{ .{ .label = 1, .ordinal = 0 }, .{ .label = 2, .ordinal = 0 } });
    defer shorter.deinit();
    try std.testing.expectEqual(@as(usize, 1), shorter.steps.items.len);
    try std.testing.expectEqual(@as(usize, 0), shorter.steps.items[0].addr[1].ordinal);
    try std.testing.expect(!shorter.steps.items[0].value.boolean);
}
fn judgeAllocations(allocator: std.mem.Allocator) !void {
    var value = c.ChoiceValue{ .integer = try c.BigInt.fromInt(allocator, @as(u8, 100)) };
    defer value.deinit(allocator);
    var tc = try native.state.NativeTestCase.forChoices(allocator, &.{value}, null, null);
    defer tc.deinit();
    var lo = try c.BigInt.fromInt(allocator, @as(u8, 0));
    defer lo.deinit();
    var hi = try c.BigInt.fromInt(allocator, @as(u8, 100));
    defer hi.deinit();
    var n = try tc.drawInteger(lo, hi);
    n.deinit();
    try tc.freeze();
    var run = try native.graph.Run.fromNodes(allocator, tc.nodes.items, tc.spans.asSlice());
    defer run.deinit();
    var graph = try native.graph.Graph.fromRun(allocator, &run);
    defer graph.deinit();
    var shrinker = try gs.GraphShrinker.init(allocator, &graph, tc.nodes.items, tc.spans.asSlice(), 0.5);
    defer shrinker.deinit();
    var probe = Probe{ .allocator = allocator };
    var simpler = c.ChoiceValue{ .integer = try c.BigInt.fromInt(allocator, @as(u8, 50)) };
    defer simpler.deinit(allocator);
    const candidate = try graph.setValue(0, run.steps.items[0].addr, &value, &simpler);
    switch (try shrinker.judge(probe.interface(), candidate, .{ .value = .{ .node = 0, .addr = run.steps.items[0].addr, .value = &simpler } })) {
        .accepted => |a| {
            var accepted = a;
            accepted.graph.deinit();
            accepted.witness.deinit(allocator);
        },
        .rejected => return error.ExpectedAccept,
    }
    const deleted = try graph.deleteEdge(0, 0);
    try std.testing.expect((try shrinker.judge(probe.interface(), deleted, .delete)) == .rejected);
}
test "graph judgement allocation failures release accepted and rejected candidates" {
    try std.testing.checkAllAllocationFailures(gpa, judgeAllocations, .{});
}

const std = @import("std");
const native = @import("native");
const draws = native.draws;
const A = std.testing.allocator;
test "typed regex draws execute against the real native test case" {
    const Fixture = struct { pattern: []const u8, value: []const u8 };
    for ([_]Fixture{
        .{ .pattern = "^a{2,4}b$", .value = "aab" },
        .{ .pattern = "(?P<x>ab)(?P=x)", .value = "abab" },
        .{ .pattern = "a(?=b)b", .value = "ab" },
        .{ .pattern = "a(?!b)c", .value = "ac" },
        .{ .pattern = "(?>ab)c", .value = "abc" },
        .{ .pattern = "a*+b", .value = "b" },
        .{ .pattern = "(a)?(?(1)b|c)", .value = "c" },
    }) |fixture| {
        var compiled = try draws.regex.CompiledRegex.compile(A, fixture.pattern, null, null);
        defer compiled.deinit();
        var tc = try native.state.NativeTestCase.forSimplest(A, 1000);
        defer tc.deinit();
        const output = try draws.regex.generateRegex(&tc, &compiled, true);
        defer A.free(output);
        try std.testing.expectEqualStrings(fixture.value, output);
    }
}
fn allocationPaths(allocator: std.mem.Allocator) !void {
    var alphabet = try native.intervalsets.IntervalSet.init(allocator, &.{.{ .start = 'A', .end = 'z' }});
    defer alphabet.deinit();
    var compiled = try draws.regex.CompiledRegex.compile(allocator, "(?i:[a-c]+)\\1?", &alphabet, null);
    defer compiled.deinit();
}
fn regexAllocationPaths(allocator: std.mem.Allocator) !void {
    var alphabet = try native.intervalsets.IntervalSet.init(allocator, &.{.{ .start = 'A', .end = 'z' }});
    defer alphabet.deinit();
    var compiled = try draws.regex.CompiledRegex.compile(allocator, "(?P<x>(?i:[a-c]+))(?P=x)", &alphabet, null);
    defer compiled.deinit();
    var tc = try native.state.NativeTestCase.forSimplest(allocator, 1000);
    defer tc.deinit();
    const result = try draws.regex.generateRegex(&tc, &compiled, true);
    defer allocator.free(result);
    try std.testing.expectEqualStrings("aa", result);
}
test "compiled regex and generation unwind allocation failures" {
    try std.testing.checkAllAllocationFailures(A, regexAllocationPaths, .{});
}

test "all string generator kinds own their constraints and execute" {
    var domains = try draws.internet.defaultDomains(A);
    defer domains.deinit();
    const Fixture = struct { spec: draws.StringSpec, value: []const u8 };
    var cases = [_]Fixture{
        .{ .spec = try draws.StringSpec.initText(A, .{ .min_codepoint = 'A', .max_codepoint = 'Z' }, 1, 5), .value = "A" },
        .{ .spec = try draws.StringSpec.initEmail(A, domains.top_level_domains), .value = "0@a.COM" },
        .{ .spec = try draws.StringSpec.initUrl(A, domains.top_level_domains), .value = "http://a.COM/" },
        .{ .spec = try draws.StringSpec.initDomain(A, 255, domains.top_level_domains), .value = "a.COM" },
    };
    defer for (&cases) |*fixture| fixture.spec.deinit();
    for (&cases) |*fixture| {
        var tc = try native.state.NativeTestCase.forSimplest(A, 10000);
        defer tc.deinit();
        const output = try draws.generateString(&tc, &fixture.spec);
        defer A.free(output);
        try std.testing.expectEqualStrings(fixture.value, output);
    }
}
test "text constructors retain upstream diagnostics" {
    var diagnostic: ?[]u8 = null;
    defer if (diagnostic) |value| A.free(value);
    try std.testing.expectError(error.InvalidArgument, draws.StringSpec.initTextDetailed(A, .{ .codec = "ascii", .include_characters = "é" }, 0, 10, &diagnostic));
    try std.testing.expectEqualStrings("include_characters ['é'] cannot be encoded by codec \"ascii\"", diagnostic.?);
}

fn sharedRegexWorker(compiled: *const draws.regex.CompiledRegex, failed: *std.atomic.Value(bool)) void {
    for (0..16) |_| {
        var tc = native.state.NativeTestCase.forSimplest(std.heap.page_allocator, 1000) catch {
            failed.store(true, .release);
            return;
        };
        defer tc.deinit();
        const value = draws.regex.generateRegex(&tc, compiled, true) catch {
            failed.store(true, .release);
            return;
        };
        defer std.heap.page_allocator.free(value);
        if (!std.mem.eql(u8, value, "a")) failed.store(true, .release);
    }
}
test "immutable compiled generators share only synchronized caches" {
    var compiled = try draws.regex.CompiledRegex.compile(A, "(?:(?i:[a-c]+)|xy)", null, null);
    defer compiled.deinit();
    var failed: std.atomic.Value(bool) = .init(false);
    var threads: [4]std.Thread = undefined;
    var count: usize = 0;
    defer for (threads[0..count]) |thread| thread.join();
    for (&threads) |*thread| {
        thread.* = try std.Thread.spawn(.{}, sharedRegexWorker, .{ &compiled, &failed });
        count += 1;
    }
    for (threads) |thread| thread.join();
    count = 0;
    try std.testing.expect(!failed.load(.acquire));
}

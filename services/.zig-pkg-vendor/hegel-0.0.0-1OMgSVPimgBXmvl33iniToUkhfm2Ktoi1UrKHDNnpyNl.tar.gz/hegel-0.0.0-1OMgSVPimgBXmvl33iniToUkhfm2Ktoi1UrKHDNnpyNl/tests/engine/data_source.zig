// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const Source = native.data_source.NativeDataSource;
const Ntc = native.state.NativeTestCase;
const gpa = std.testing.allocator;
test "source abort latches only its own stream; family verdict remains authoritative" {
    var created = try Source.init(gpa, try Ntc.forSimplest(gpa, 2));
    defer created.source.deinit();
    defer created.handle.release();
    var child = try created.source.cloneStream();
    defer child.deinit();
    try std.testing.expect(!(try child.generateBoolean(0.5, null)));
    try std.testing.expectError(error.StopTest, child.generateBoolean(0.5, null));
    try std.testing.expect(child.aborted.load(.monotonic));
    try std.testing.expect(!created.source.aborted.load(.monotonic));
    try created.source.markComplete(.interesting, "late");
    const out = try Source.takeOutcome(created.handle, gpa);
    defer if (out.origin) |o| gpa.free(o);
    try std.testing.expectEqual(native.choices.Status.early_stop, out.status);
    try std.testing.expectError(error.StopTest, created.source.generateBoolean(0.5, null));
}
test "rejected empty pool does not permanently abort stream" {
    var created = try Source.init(gpa, try Ntc.forSimplest(gpa, 20));
    defer created.source.deinit();
    defer created.handle.release();
    var pool = try created.source.newPool();
    defer pool.deinit();
    try std.testing.expectError(error.Assume, created.source.poolGenerate(&pool, false));
    try std.testing.expect(!created.source.aborted.load(.monotonic));
    try std.testing.expectEqual(@as(i64, 0), try created.source.poolAdd(&pool));
    try std.testing.expectEqual(@as(i64, 0), try created.source.poolGenerate(&pool, true));
    try created.source.markComplete(.valid, null);
    const nodes = try Source.takeNodes(created.handle, gpa);
    defer native.choices.deinitNodes(gpa, nodes);
    try std.testing.expectEqual(@as(usize, 2), nodes.len);
}
test "target labels are family unique and events retain order across clones" {
    var created = try Source.init(gpa, try Ntc.forSimplest(gpa, 20));
    defer created.source.deinit();
    defer created.handle.release();
    var child = try created.source.cloneStream();
    defer child.deinit();
    try created.source.targetObservation(1, "score");
    try std.testing.expectError(error.InvalidArgument, child.targetObservation(2, "score"));
    try created.source.eventObservation("a", null);
    try child.eventObservation("b", 3);
    const targets = try Source.takeTargetObservations(created.handle, gpa);
    var owned = targets;
    defer {
        var keys = owned.keyIterator();
        while (keys.next()) |key| gpa.free(key.*);
        owned.deinit(gpa);
    }
    try std.testing.expectEqual(@as(f64, 1), targets.get("score").?);
    const events = try Source.takeEvents(created.handle, gpa);
    defer {
        for (events) |event| gpa.free(event.label);
        gpa.free(events);
    }
    try std.testing.expectEqualStrings("a", events[0].label);
    try std.testing.expectEqualStrings("b", events[1].label);
}
test "state machines validate all argument domains before drawing" {
    var created = try Source.init(gpa, try Ntc.forSimplest(gpa, 100));
    defer created.source.deinit();
    defer created.handle.release();
    try std.testing.expectError(error.InvalidArgument, created.source.newStateMachine(&.{}, &.{}, &.{}, &.{}, &.{}, 1, 1, 1));
    try std.testing.expectEqualStrings("cannot run a state machine with no rules", created.source.diagnostic.?);
    var machine = try created.source.newStateMachine(&.{"r"}, &.{7}, &.{1}, &.{"i"}, &.{true}, 1, 1, 1);
    defer machine.deinit();
    try std.testing.expectEqual(@as(?i64, 7), try created.source.stateMachineNextGroup(&machine));
    try std.testing.expectEqual(@as(?i64, 0), try created.source.stateMachineNextRule(&machine, 0));
    try std.testing.expect(try created.source.stateMachineShouldCheckInvariant(&machine, 0));
}
test "typed data source methods run real constrained draws" {
    var created = try Source.init(gpa, try Ntc.forSimplest(gpa, 200));
    defer created.source.deinit();
    defer created.handle.release();
    var lo = try native.choices.BigInt.fromInt(gpa, @as(u8, 2));
    defer lo.deinit();
    var hi = try native.choices.BigInt.fromInt(gpa, @as(u8, 5));
    defer hi.deinit();
    var n = try created.source.generateInteger(lo, hi);
    defer n.deinit();
    try std.testing.expectEqual(@as(?u8, 2), n.toInt(u8));
    const bytes = try created.source.generateBytes(1, 2);
    defer gpa.free(bytes);
    var collection = try created.source.newCollection(1, 2);
    try std.testing.expect(try created.source.collectionMore(&collection));
    try created.source.collectionReject(&collection);
    var recursion = try created.source.newRecursion(3, 4);
    defer recursion.deinit();
    _ = try created.source.recursionBranch(&recursion, 0);
    _ = try created.source.recursionLeaf(&recursion);
    _ = try created.source.recursionFinish(&recursion);
    _ = try created.source.generateUuid(4);
    _ = try created.source.generateIpv4();
    _ = try created.source.generateIpv6();
    _ = try created.source.generateFloat(.{ .width = 64, .min_value = 0, .max_value = 1, .allow_nan = false, .allow_infinity = false, .exclude_min = false, .exclude_max = false, .smallest_nonzero_magnitude = 5e-324 });
}

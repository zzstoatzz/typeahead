const std = @import("std");
const n = @import("native");
const Driver = struct {
    fail: bool = false,
    fn execute(context: *anyopaque, handle: *n.state.NativeTestCaseHandle) !void {
        const self: *Driver = @ptrCast(@alignCast(context));
        const tc = handle.lock();
        defer handle.unlock();
        _ = try tc.weighted(0.5, null);
        if (self.fail) try tc.conclude(.interesting, "bug");
        try tc.freeze();
    }
};
test "raw generation executes duplicates and cached replay serves exact conclusions" {
    const gpa = std.testing.allocator;
    var driver: Driver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 1, .database = .disabled, .nondeterminism_strictness = .@"error" }, null, .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    engine.collect_statistics = true;
    var first = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer first.deinit(gpa);
    var duplicate = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
    defer duplicate.deinit(gpa);
    try std.testing.expectEqual(@as(u64, 2), engine.calls);
    try std.testing.expectEqual(@as(u64, 1), engine.consecutive_duplicates);
    engine.collect_statistics = false;
    const values = try first.realizedValues(gpa);
    defer n.choices.deinitValues(gpa, values);
    var fill = try engine.cachedTestFunction(values, null, 0);
    defer fill.deinit(gpa);
    const calls = engine.calls;
    var served = try engine.cachedTestFunction(values, null, 100);
    defer served.deinit(gpa);
    try std.testing.expectEqual(calls, engine.calls);
}
test "a changed verdict errors under strictness and flips under quiet" {
    const gpa = std.testing.allocator;
    inline for (.{ n.settings.NondeterminismStrictness.@"error", n.settings.NondeterminismStrictness.quiet }) |strictness| {
        var driver: Driver = .{};
        const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 1, .database = .disabled, .nondeterminism_strictness = strictness }, null, .{ .context = &driver, .call = Driver.execute });
        defer engine.deinit();
        var first = try engine.testFunction(try n.state.NativeTestCase.forSimplest(gpa, 100));
        defer first.deinit(gpa);
        driver.fail = true;
        const tc = try n.state.NativeTestCase.forSimplest(gpa, 100);
        if (strictness == .@"error") try std.testing.expectError(error.Flaky, engine.testFunction(tc)) else {
            var changed = try engine.testFunction(tc);
            defer changed.deinit(gpa);
            try std.testing.expect(engine.nd_active);
            try std.testing.expectEqual(@as(usize, 0), engine.exec_cache.verdicts.count());
        }
    }
}
fn reuseOnce(gpa: std.mem.Allocator, root: []const u8) !void {
    var driver: Driver = .{};
    const engine = try n.test_runner.Engine.create(gpa, std.testing.io, .{ .seed = 1, .database = .{ .path = root }, .phases = &.{.reuse}, .nondeterminism_strictness = .@"error" }, "reuse", .{ .context = &driver, .call = Driver.execute });
    defer engine.deinit();
    var result = try engine.run();
    defer result.deinit(gpa);
    try std.testing.expectEqual(@as(usize, 0), result.failures.len);
}
test "database reuse releases executed snapshots on allocation failure" {
    const gpa = std.testing.allocator;
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    const root = try std.fmt.allocPrint(gpa, ".zig-cache/tmp/{s}", .{tmp.sub_path});
    defer gpa.free(root);
    var db = try n.database.DirectoryDatabase.init(gpa, std.testing.io, root);
    defer db.deinit();
    const values = [_]n.choices.ChoiceValue{.{ .boolean = false }};
    const bytes = (try n.database.serializeChoices(gpa, &values)).?;
    defer gpa.free(bytes);
    db.save("reuse", bytes);
    var baseline = std.testing.FailingAllocator.init(gpa, .{});
    try reuseOnce(baseline.allocator(), root);
    for (0..baseline.alloc_index + 8) |index| {
        db.save("reuse", bytes);
        var failing = std.testing.FailingAllocator.init(gpa, .{ .fail_index = index });
        reuseOnce(failing.allocator(), root) catch |err| if (err != error.OutOfMemory) return err;
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
    }
}

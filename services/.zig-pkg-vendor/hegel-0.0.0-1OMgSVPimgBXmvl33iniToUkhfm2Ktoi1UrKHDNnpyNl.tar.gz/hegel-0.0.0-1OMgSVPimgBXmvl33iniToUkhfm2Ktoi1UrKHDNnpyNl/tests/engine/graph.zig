// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const graph = @import("native").graph;
const gpa = std.testing.allocator;
const Value = graph.ChoiceValue;
const BigInt = @FieldType(Value, "integer");
const coin = [_]graph.Frame{ .{ .label = 1, .ordinal = 0 }, .{ .label = 10, .ordinal = 0 } };
const left = [_]graph.Frame{ .{ .label = 2, .ordinal = 0 }, .{ .label = 11, .ordinal = 0 } };
const right = [_]graph.Frame{ .{ .label = 3, .ordinal = 0 }, .{ .label = 11, .ordinal = 0 } };

fn branch(allocator: std.mem.Allocator, addr: []const graph.Frame, first: bool, number: i64) !graph.Run {
    var run = graph.Run.init(allocator);
    errdefer run.deinit();
    try run.append(&coin, &.{ .boolean = first });
    var integer: Value = .{ .integer = try BigInt.fromInt(allocator, number) };
    defer integer.deinit(allocator);
    try run.append(addr, &integer);
    return run;
}

test "draw addresses retain sibling ordinals including empty spans" {
    const addresses = try graph.drawAddresses(gpa, &.{
        .{ .start = 0, .end = 2, .label = 1, .parent = null, .depth = 0, .discarded = false },
        .{ .start = 0, .end = 1, .label = 17, .parent = 0, .depth = 0, .discarded = false },
        .{ .start = 1, .end = 1, .label = 3, .parent = 0, .depth = 0, .discarded = false },
        .{ .start = 1, .end = 2, .label = 17, .parent = 0, .depth = 0, .discarded = false },
        .{ .start = 2, .end = 3, .label = 1, .parent = null, .depth = 0, .discarded = false },
        .{ .start = 2, .end = 3, .label = 18, .parent = 4, .depth = 0, .discarded = false },
        .{ .start = 9, .end = 9, .label = 1, .parent = null, .depth = 0, .discarded = false },
    }, 3);
    defer graph.deinitAddresses(gpa, addresses);
    try std.testing.expect(graph.framesEql(addresses[0], &.{ .{ .label = 1, .ordinal = 0 }, .{ .label = 17, .ordinal = 0 }, .{ .label = graph.DRAW_LABEL, .ordinal = 0 } }));
    try std.testing.expect(graph.framesEql(addresses[1], &.{ .{ .label = 1, .ordinal = 0 }, .{ .label = 17, .ordinal = 1 }, .{ .label = graph.DRAW_LABEL, .ordinal = 0 } }));
    try std.testing.expect(graph.framesEql(addresses[2], &.{ .{ .label = 1, .ordinal = 1 }, .{ .label = 18, .ordinal = 0 }, .{ .label = graph.DRAW_LABEL, .ordinal = 0 } }));
}

test "run nodes exclude forced draws without renumbering addresses" {
    var run = try graph.Run.fromNodes(gpa, &.{
        .{ .data = .{ .boolean = .{ .constraint = .{ .p = 0.5 }, .value = false } }, .was_forced = true },
        .{ .data = .{ .boolean = .{ .constraint = .{ .p = 0.5 }, .value = true } }, .was_forced = false },
    }, &.{});
    defer run.deinit();
    try std.testing.expectEqual(@as(usize, 1), run.steps.items.len);
    try std.testing.expectEqual(@as(usize, 1), run.steps.items[0].addr[0].ordinal);
    try std.testing.expect(run.steps.items[0].value.boolean);
}

test "ties preserve both histories while foreign draws are not grafted" {
    var a = try branch(gpa, &left, true, 5);
    defer a.deinit();
    var b = try branch(gpa, &right, true, 7);
    defer b.deinit();
    var foreign = try branch(gpa, &left, false, 5);
    defer foreign.deinit();
    var g = try graph.Graph.fromRun(gpa, &a);
    defer g.deinit();
    try std.testing.expectEqual(graph.Walked.gap, g.walkVerdict(&b));
    try std.testing.expect(try g.graft(&b));
    try std.testing.expect(!(try g.insert(&b)));
    try std.testing.expectEqual(graph.Walked.whole, g.walkVerdict(&a));
    try std.testing.expectEqual(graph.Walked.whole, g.walkVerdict(&b));
    try std.testing.expectEqual(graph.Walked.foreign, g.walkVerdict(&foreign));
    try std.testing.expect(!(try g.graft(&foreign)));
    var independent = try g.withRun(&foreign);
    defer independent.deinit();
    try std.testing.expectEqual(graph.Walked.whole, independent.walkVerdict(&foreign));
    try std.testing.expectEqual(@as(usize, 2), try independent.edgeCount());
}

test "graph edits prune dead paths and update tied values together" {
    var a = try branch(gpa, &left, true, 5);
    defer a.deinit();
    var b = try branch(gpa, &right, true, 7);
    defer b.deinit();
    var g = try graph.Graph.fromRun(gpa, &a);
    defer g.deinit();
    _ = try g.insert(&b);
    var changed = try g.setValue(0, &coin, &.{ .boolean = true }, &.{ .boolean = false });
    defer changed.deinit();
    var a_false = try branch(gpa, &left, false, 5);
    defer a_false.deinit();
    var b_false = try branch(gpa, &right, false, 7);
    defer b_false.deinit();
    try std.testing.expectEqual(graph.Walked.whole, changed.walkVerdict(&a_false));
    try std.testing.expectEqual(graph.Walked.whole, changed.walkVerdict(&b_false));
    var deleted = try g.deleteEdge(0, 0);
    defer deleted.deinit();
    var pruned = try deleted.pruned();
    defer pruned.deinit();
    try std.testing.expectEqual(@as(usize, 3), pruned.nodes().len);
    try std.testing.expectEqual(graph.Walked.whole, pruned.walkVerdict(&b));
    try std.testing.expectEqual(graph.Walked.gap, pruned.walkVerdict(&a));
    try g.retainSettled(&.{.{ .node = 0, .edge = 1 }});
    try std.testing.expectEqual(@as(usize, 1), g.nodes()[0].edges.items.len);
    try std.testing.expectEqual(graph.Walked.whole, g.walkVerdict(&b));
    var before_key = try changed.key();
    defer before_key.deinit();
    var after_key = try pruned.key();
    defer after_key.deinit();
    try std.testing.expectEqual(std.math.Order.lt, after_key.order(before_key));
}

test "wire format roundtrips and rejects malformed graphs" {
    var empty = try graph.Graph.init(gpa);
    defer empty.deinit();
    const encoded_empty = (try empty.encode()).?;
    defer gpa.free(encoded_empty);
    try std.testing.expectEqualSlices(u8, &.{ 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0 }, encoded_empty);
    var a = try branch(gpa, &left, true, -999);
    defer a.deinit();
    var g = try graph.Graph.fromRun(gpa, &a);
    defer g.deinit();
    const encoded = (try g.encode()).?;
    defer gpa.free(encoded);
    var decoded = (try graph.Graph.decode(gpa, encoded)).?;
    defer decoded.deinit();
    try std.testing.expectEqual(graph.Walked.whole, decoded.walkVerdict(&a));
    const again = (try decoded.encode()).?;
    defer gpa.free(again);
    try std.testing.expectEqualSlices(u8, encoded, again);
    for (0..encoded.len) |len| try std.testing.expectEqual(null, try graph.Graph.decode(gpa, encoded[0..len]));
    const trailing = try std.mem.concat(gpa, u8, &.{ encoded, &.{0} });
    defer gpa.free(trailing);
    try std.testing.expectEqual(null, try graph.Graph.decode(gpa, trailing));
    encoded[4] = 1;
    try std.testing.expectEqual(null, try graph.Graph.decode(gpa, encoded));
}

fn allocationScenario(allocator: std.mem.Allocator) !void {
    var a = try branch(allocator, &left, true, 5);
    defer a.deinit();
    var b = try branch(allocator, &right, true, 7);
    defer b.deinit();
    var g = try graph.Graph.fromRun(allocator, &a);
    defer g.deinit();
    _ = try g.insert(&b);
    var clone = try g.pruned();
    defer clone.deinit();
    const encoded = (try clone.encode()).?;
    defer allocator.free(encoded);
    var decoded = (try graph.Graph.decode(allocator, encoded)).?;
    defer decoded.deinit();
    try decoded.retainSettled(&.{.{ .node = 0, .edge = 0 }});
}

test "graph ownership remains valid at every allocation failure" {
    try std.testing.checkAllAllocationFailures(gpa, allocationScenario, .{});
}

// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const nd = @import("native").nd;
fn number(comptime T: type, field: ?[]const u8) !T {
    return std.fmt.parseInt(T, field orelse return error.MissingField, 10);
}
fn float(field: ?[]const u8) !f64 {
    return @bitCast(try number(u64, field));
}
fn evidence(fails: u64, runs: u64) nd.Evidence {
    return .{ .failures = fails, .replays = runs };
}
fn close(expected: f64, actual: f64) !void {
    try std.testing.expectApproxEqAbs(expected, actual, @max(@abs(expected) * 1e-14, 1e-15));
}

test "nondeterministic decisions match the unmodified pinned Rust module" {
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/nd.tsv"), '\n');
    var spend: nd.GauntletSpend = .{};
    var records: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const op = fields.next().?;
        switch (op[0]) {
            'E' => {
                const fails = try number(u64, fields.next());
                const runs = try number(u64, fields.next());
                const e = evidence(fails, runs);
                try close(try float(fields.next()), e.lowerBound());
                try close(try float(fields.next()), e.upperBound());
                try std.testing.expectEqual(try number(u8, fields.next()), @backingInt(nd.discoveryBar(e)));
                try std.testing.expectEqual(try number(u8, fields.next()) != 0, nd.targetAdopt(fails, runs));
            },
            'G' => {
                const fails = try number(u64, fields.next());
                const runs = try number(u64, fields.next());
                const anchor = try float(fields.next());
                const minimum = try number(u64, fields.next());
                try std.testing.expectEqual(try number(u8, fields.next()), @backingInt(nd.gauntlet(evidence(fails, runs), anchor, minimum)));
            },
            'S' => {
                const anchor = try float(fields.next());
                const drive = try number(u8, fields.next()) != 0;
                const i = try number(usize, fields.next());
                if (i == 0) spend = .{};
                try std.testing.expectEqual(try number(u64, fields.next()), spend.charge(.{}, anchor, drive, if (i % 17 == 16) 4 else null));
            },
            'B' => {
                const rate = try float(fields.next());
                const tolerance = try float(fields.next());
                try std.testing.expectEqual(try number(u64, fields.next()), nd.replayBudget(rate, tolerance));
            },
            'K' => {
                const count = try number(usize, fields.next());
                try std.testing.expectEqual(try number(usize, fields.next()), nd.boostKeep(count));
            },
            'C' => {
                const count = try number(usize, fields.next());
                try std.testing.expectEqual(try number(usize, fields.next()), nd.continuationBudget(count));
            },
            'M' => {
                const scores = fields.next().?;
                const want = fields.next().?;
                var values: std.ArrayList(f64) = .empty;
                defer values.deinit(std.testing.allocator);
                var parts = std.mem.splitScalar(u8, scores, ',');
                while (parts.next()) |part| if (part.len > 0) try values.append(std.testing.allocator, try float(part));
                const got = try nd.targetMedian(std.testing.allocator, values.items);
                if (std.mem.eql(u8, want, "none")) try std.testing.expectEqual(null, got) else try std.testing.expectEqual(try number(u64, want), @as(u64, @bitCast(got.?)));
            },
            'A' => {
                try close(try float(fields.next()), nd.anchorCeiling());
                try std.testing.expectEqual(try number(u64, fields.next()), nd.reuseReplayBudget());
            },
            else => return error.UnknownRecord,
        }
        records += 1;
    }
    try std.testing.expect(records > 8000);
}

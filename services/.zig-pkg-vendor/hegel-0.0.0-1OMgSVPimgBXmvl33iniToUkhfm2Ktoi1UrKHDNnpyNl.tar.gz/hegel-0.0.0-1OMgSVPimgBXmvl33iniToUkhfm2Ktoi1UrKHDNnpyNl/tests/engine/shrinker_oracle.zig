const std = @import("std");
const sh = @import("shrinker");
const c = sh.choices;
const db = sh.database;
fn hex(a: std.mem.Allocator, bytes: []const u8) ![]u8 {
    const out = try a.alloc(u8, bytes.len * 2);
    const alphabet = "0123456789abcdef";
    for (bytes, 0..) |b, i| {
        out[i * 2] = alphabet[b >> 4];
        out[i * 2 + 1] = alphabet[b & 15];
    }
    return out;
}
fn decode(a: std.mem.Allocator, text: []const u8) ![]u8 {
    const out = try a.alloc(u8, text.len / 2);
    errdefer a.free(out);
    return std.fmt.hexToBytes(out, text);
}
const Eval = struct {
    allocator: std.mem.Allocator,
    name: []const u8,
    template: []const c.ChoiceNode,
    trace: std.mem.SplitIterator(u8, .scalar),
    fn interesting(self: *@This(), nodes: []const c.ChoiceNode) bool {
        if (std.mem.eql(u8, self.name, "integer_threshold") or std.mem.eql(u8, self.name, "full_integer")) return nodes.len == 1 and nodes[0].data == .integer and (nodes[0].data.integer.value.toInt(i64) orelse return false) >= 117;
        if (std.mem.eql(u8, self.name, "integer_mask")) return nodes.len == 1 and nodes[0].data == .integer and ((nodes[0].data.integer.value.toInt(i64) orelse return false) & 255) == 0x77;
        if (std.mem.eql(u8, self.name, "duplicate_integers")) return nodes.len == 2 and nodes[0].data == .integer and nodes[1].data == .integer and nodes[0].data.valueRef().eql(nodes[1].data.valueRef()) and (nodes[0].data.integer.value.toInt(i64) orelse return false) >= 117;
        if (std.mem.eql(u8, self.name, "redistribute_integers") or std.mem.eql(u8, self.name, "lower_together") or std.mem.eql(u8, self.name, "scale_integers")) {
            if (nodes.len != 2 or nodes[0].data != .integer or nodes[1].data != .integer) return false;
            const x = nodes[0].data.integer.value.toInt(i64) orelse return false;
            const y = nodes[1].data.integer.value.toInt(i64) orelse return false;
            if (std.mem.eql(u8, self.name, "redistribute_integers")) return x + y >= 1000;
            if (std.mem.eql(u8, self.name, "lower_together")) return x - y == 1;
            return x * y >= 210000;
        }
        if (std.mem.eql(u8, self.name, "float_fraction") or std.mem.eql(u8, self.name, "float_threshold")) {
            if (nodes.len != 1 or nodes[0].data != .float) return false;
            const v = nodes[0].data.float.value;
            return if (std.mem.eql(u8, self.name, "float_fraction")) v >= 1.5 and v - @trunc(v) == 0.5 else v >= 117.5;
        }
        if (std.mem.eql(u8, self.name, "bytes_sum")) {
            if (nodes.len != 1 or nodes[0].data != .bytes) return false;
            var sum: u32 = 0;
            for (nodes[0].data.bytes.value) |v| sum += v;
            return sum >= 117;
        }
        if (std.mem.eql(u8, self.name, "string_marker")) return nodes.len == 1 and nodes[0].data == .string and std.mem.indexOfScalar(u32, nodes[0].data.string.value, 90) != null;
        return false;
    }
    fn call(p: *anyopaque, req: sh.Request) anyerror!sh.Outcome {
        const self: *@This() = @ptrCast(@alignCast(p));
        const a = self.allocator;
        var actual: std.ArrayList(c.ChoiceNode) = .empty;
        defer {
            for (actual.items) |*n| n.deinit(a);
            actual.deinit(a);
        }
        var trace: []u8 = undefined;
        switch (req) {
            .full => |nodes| {
                const bytes = (try db.serializeNodes(a, nodes)).?;
                defer a.free(bytes);
                const encoded = try hex(a, bytes);
                defer a.free(encoded);
                trace = try std.fmt.allocPrint(a, "F:{s}", .{encoded});
                for (nodes) |n| try actual.append(a, try n.deepClone(a));
            },
            .probe => |v| {
                const bytes = (try db.serializeChoices(a, v.prefix)).?;
                defer a.free(bytes);
                const encoded = try hex(a, bytes);
                defer a.free(encoded);
                trace = try std.fmt.allocPrint(a, "P:{d}:{s}", .{ v.max_size, encoded });
                for (v.prefix[0..@min(v.prefix.len, self.template.len)], self.template[0..@min(v.prefix.len, self.template.len)]) |*value, *n| {
                    if (try n.kind().resolve(a, value)) |data| try actual.append(a, c.ChoiceNode.init(data, false));
                }
            },
        }
        defer a.free(trace);
        const expected = self.trace.next() orelse {
            std.debug.print("extra {s}: {s}\n", .{ self.name, trace });
            return error.ExtraProbe;
        };
        if (!std.mem.eql(u8, expected, trace)) {
            std.debug.print("{s} probe mismatch\nexpected {s}\nactual   {s}\n", .{ self.name, expected, trace });
            return error.ProbeMismatch;
        }
        return .{ .interesting = self.interesting(actual.items), .run = try sh.CachedRun.init(a, .valid, null, actual.items, &.{}) };
    }
};
test "all shrinker probes and accepted targets match pinned Rust" {
    const a = std.testing.allocator;
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/shrinker.tsv"), '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        var cols = std.mem.splitScalar(u8, line, '\t');
        const name = cols.next().?;
        const encoded = cols.next().?;
        const trace = cols.next().?;
        const expected = cols.next().?;
        const calls = try std.fmt.parseInt(usize, cols.next().?, 10);
        const improvements = try std.fmt.parseInt(usize, cols.next().?, 10);
        const bytes = try decode(a, encoded);
        defer a.free(bytes);
        const values = (try db.deserializeChoicesExact(a, bytes)).?;
        defer c.deinitValues(a, values);
        var ic = c.IntegerChoice{ .min_value = try c.BigInt.fromInt(a, -1000000), .max_value = try c.BigInt.fromInt(a, 2000000), .shrink_towards = try c.BigInt.fromInt(a, 0) };
        defer ic.deinit();
        var alphabet = try c.IntervalSet.init(a, &.{ .{ .start = 48, .end = 57 }, .{ .start = 65, .end = 122 } });
        defer alphabet.deinit();
        var initial: std.ArrayList(c.ChoiceNode) = .empty;
        defer {
            for (initial.items) |*n| n.deinit(a);
            initial.deinit(a);
        }
        for (values) |*v| {
            const kind: c.ChoiceKind = switch (v.*) {
                .integer => .{ .integer = &ic },
                .float => .{ .float = .{ .min_value = -1000, .max_value = 1000, .allow_nan = false, .allow_infinity = false, .smallest_nonzero_magnitude = 5e-324 } },
                .bytes => .{ .bytes = .{ .min_size = 1, .max_size = 20 } },
                .string => .{ .string = .{ .intervals = &alphabet, .min_size = 1, .max_size = 20 } },
                else => return error.BadFixture,
            };
            try initial.append(a, c.ChoiceNode.init((try kind.resolve(a, v)).?, false));
        }
        var ctx = Eval{ .allocator = a, .name = name, .template = initial.items, .trace = std.mem.splitScalar(u8, trace, '|') };
        var shrinker = try sh.Shrinker.init(a, .{ .context = &ctx, .call = Eval.call }, initial.items, &.{});
        defer shrinker.deinit();
        if (std.mem.startsWith(u8, name, "integer_")) try shrinker.binarySearchIntegerTowardsZero() else if (std.mem.eql(u8, name, "duplicate_integers")) try shrinker.shrinkDuplicates() else if (std.mem.eql(u8, name, "redistribute_integers")) try shrinker.redistributeIntegers() else if (std.mem.eql(u8, name, "lower_together")) try shrinker.lowerIntegersTogether() else if (std.mem.startsWith(u8, name, "float_")) try shrinker.shrinkFloats() else if (std.mem.eql(u8, name, "bytes_sum")) try shrinker.shrinkBytes() else if (std.mem.eql(u8, name, "string_marker")) try shrinker.shrinkStrings() else if (std.mem.eql(u8, name, "scale_integers")) try shrinker.scaleNumericPairs() else if (std.mem.eql(u8, name, "full_integer")) try shrinker.shrink() else return error.BadFixture;
        const final = (try db.serializeNodes(a, shrinker.current_nodes)).?;
        defer a.free(final);
        const final_hex = try hex(a, final);
        defer a.free(final_hex);
        try std.testing.expectEqualStrings(expected, final_hex);
        try std.testing.expectEqual(calls, shrinker.calls);
        try std.testing.expectEqual(improvements, shrinker.improvements);
        try std.testing.expect(ctx.trace.next() == null);
        count += 1;
    }
    try std.testing.expectEqual(11, count);
}

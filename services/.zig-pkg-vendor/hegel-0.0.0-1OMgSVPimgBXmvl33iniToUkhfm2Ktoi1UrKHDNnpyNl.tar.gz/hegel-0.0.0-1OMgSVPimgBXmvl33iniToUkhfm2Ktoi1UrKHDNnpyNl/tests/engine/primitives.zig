const std = @import("std");
const labels = @import("labels");
const base64 = @import("base64");
const floats = @import("floats");
const float_index = @import("float_index");
const intervalsets = @import("intervalsets");
const rng = @import("rng");

fn number(comptime T: type, text: ?[]const u8) !T {
    return std.fmt.parseInt(T, text orelse return error.MissingField, 10);
}

test "primitives match the pinned Rust implementations" {
    if (@bitSizeOf(usize) != 64) return error.SkipZigTest;
    const allocator = std.testing.allocator;
    var sets = [_]intervalsets.IntervalSet{
        try .init(allocator, &.{}),
        try .init(allocator, &.{.{ .start = 0, .end = 127 }}),
        try .init(allocator, &.{ .{ .start = 4, .end = 8 }, .{ .start = 14, .end = 25 }, .{ .start = 45, .end = 70 }, .{ .start = 100, .end = 110 } }),
        try .init(allocator, &.{ .{ .start = 48, .end = 48 }, .{ .start = 90, .end = 95 }, .{ .start = 1000, .end = 1001 } }),
    };
    defer for (&sets) |*set| set.deinit();
    var random: rng.SmallRng = undefined;
    var sampler: rng.EngineRng = undefined;
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/primitives.tsv"), '\n');
    var records: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const operation = fields.next().?;
        switch (operation[0]) {
            'O' => {
                const value: f64 = @bitCast(try number(u64, fields.next()));
                try std.testing.expectEqual(try number(u64, fields.next()), @as(u64, @bitCast(floats.nextUp(value))));
                try std.testing.expectEqual(try number(u64, fields.next()), @as(u64, @bitCast(floats.nextDown(value))));
            },
            'F' => {
                const value: f64 = @bitCast(try number(u64, fields.next()));
                const index = try number(u64, fields.next());
                try std.testing.expectEqual(index, float_index.floatToIndex(value));
                try std.testing.expectEqual(try number(u64, fields.next()), @as(u64, @bitCast(float_index.indexToFloat(index))));
            },
            'S' => {
                const lo: f64 = @bitCast(try number(u64, fields.next()));
                const hi: f64 = @bitCast(try number(u64, fields.next()));
                try std.testing.expectEqual(try number(u64, fields.next()), @as(u64, @bitCast(try float_index.simplestInRange(lo, hi))));
            },
            'R' => {
                random = .seeded(try number(u64, fields.next()));
                try std.testing.expectEqual(try number(u32, fields.next()), random.nextU32());
                try std.testing.expectEqual(try number(u64, fields.next()), random.nextU64());
                try std.testing.expectEqual(try number(u64, fields.next()), random.nextU64());
                try std.testing.expectEqual(try number(u32, fields.next()), random.nextU32());
            },
            'B' => {
                _ = try number(u64, fields.next());
                var bytes: [13]u8 = undefined;
                random.fillBytes(&bytes);
                const expected = (try base64.decode(allocator, fields.next().?)).?;
                defer allocator.free(expected);
                try std.testing.expectEqualSlices(u8, expected, &bytes);
            },
            'C' => {
                _ = try number(u64, fields.next());
                var child = random.spawn();
                try std.testing.expectEqual(try number(u64, fields.next()), child.nextU64());
                try std.testing.expectEqual(try number(u64, fields.next()), child.nextU64());
            },
            'T' => {
                var small = rng.Xoshiro(u32).seeded(try number(u64, fields.next()));
                try std.testing.expectEqual(try number(u32, fields.next()), small.nextU32());
                try std.testing.expectEqual(try number(u64, fields.next()), small.nextU64());
                try std.testing.expectEqual(try number(u32, fields.next()), small.nextU32());
            },
            'L' => {
                const name = (try base64.decode(allocator, fields.next().?)).?;
                defer allocator.free(name);
                try std.testing.expectEqual(try number(u64, fields.next()), labels.labelFromName(name));
            },
            'K' => try std.testing.expectEqual(try number(u64, fields.next()), labels.combineLabels(&.{ 0, 1, std.math.maxInt(u64), 0x12345678 })),
            'N' => sampler = .seeded(try number(u64, fields.next())),
            'D' => {
                try std.testing.expectEqual(try number(u8, fields.next()) != 0, sampler.random(bool));
                try std.testing.expectEqual(try number(u64, fields.next()), @as(u64, @bitCast(sampler.random(f64))));
                try std.testing.expectEqual(try number(u8, fields.next()), sampler.random(u8));
                try std.testing.expectEqual(try number(i128, fields.next()), sampler.random(i128));
            },
            'V' => {
                try std.testing.expectEqual(try number(u8, fields.next()), sampler.rangeInclusive(u8, 0, 255));
                try std.testing.expectEqual(try number(u32, fields.next()), sampler.range(u32, 10, 10000));
                try std.testing.expectEqual(try number(u64, fields.next()), sampler.rangeInclusive(u64, std.math.maxInt(u64) - 1000, std.math.maxInt(u64)));
                try std.testing.expectEqual(try number(usize, fields.next()), sampler.range(usize, 0, 4294967296));
                try std.testing.expectEqual(try number(usize, fields.next()), sampler.rangeInclusive(usize, 0, 100));
                try std.testing.expectEqual(try number(i128, fields.next()), sampler.rangeInclusive(i128, std.math.minInt(i128), std.math.maxInt(i128)));
            },
            'G' => {
                const set = &sets[try number(usize, fields.next())];
                const i = try number(isize, fields.next());
                const expected = fields.next().?;
                if (std.mem.eql(u8, expected, "-")) try std.testing.expectEqual(null, set.get(i)) else try std.testing.expectEqual(try number(u32, expected), set.get(i).?);
            },
            'I' => {
                const set = &sets[try number(usize, fields.next())];
                const i = try number(usize, fields.next());
                const cp = try number(u32, fields.next());
                try std.testing.expectEqual(cp, set.charInShrinkOrder(i));
                try std.testing.expectEqual(try number(usize, fields.next()), set.indexFromCodepointInShrinkOrder(cp));
            },
            'A' => {
                const set = &sets[try number(usize, fields.next())];
                const cp = try number(u32, fields.next());
                try std.testing.expectEqual(try number(usize, fields.next()), set.indexAbove(cp));
                const expected = fields.next().?;
                if (std.mem.eql(u8, expected, "-")) try std.testing.expectEqual(null, set.index(cp)) else try std.testing.expectEqual(try number(usize, expected), set.index(cp).?);
            },
            else => return error.UnknownOperation,
        }
        try std.testing.expectEqual(null, fields.next());
        records += 1;
    }
    try std.testing.expect(records > 7000);
}

test "base64 keeps upstream acceptance of nonzero padding bits" {
    const allocator = std.testing.allocator;
    const forms = [_][]const u8{ "Zg==", "Zh==", "Zm8=", "Zm9=" };
    for (forms, [_][]const u8{ "f", "f", "fo", "fo" }) |encoded, expected| {
        const decoded = (try base64.decode(allocator, encoded)).?;
        defer allocator.free(decoded);
        try std.testing.expectEqualSlices(u8, expected, decoded);
    }
    for ([_][]const u8{ "Zg=", "=g==", "Z=4=", "Zg=A", "Zg==AAAA", "Zg__", "Zg==\n" }) |malformed| try std.testing.expectEqual(null, try base64.decode(allocator, malformed));
    const bytes = [_]u8{ 0, 1, 254, 255, 15 };
    const encoded = try base64.encode(allocator, &bytes);
    defer allocator.free(encoded);
    try std.testing.expectEqualStrings("AAH+/w8=", encoded);
}

test "interval algebra agrees with a finite membership model" {
    const allocator = std.testing.allocator;
    for (0..256) |mask| {
        var entries: std.ArrayList(intervalsets.Interval) = .empty;
        defer entries.deinit(allocator);
        for (0..8) |i| if (mask & (@as(usize, 1) << @intCast(i)) != 0) try entries.append(allocator, .{ .start = @intCast(i), .end = @intCast(i) });
        var a = try intervalsets.IntervalSet.init(allocator, entries.items);
        defer a.deinit();
        var b = try intervalsets.IntervalSet.init(allocator, &.{ .{ .start = 1, .end = 3 }, .{ .start = 6, .end = 7 } });
        defer b.deinit();
        var joined = try a.unionWith(&b);
        defer joined.deinit();
        var diff = try a.difference(&b);
        defer diff.deinit();
        var overlap = try a.intersection(&b);
        defer overlap.deinit();
        for (0..9) |i| {
            const cp: u32 = @intCast(i);
            const in_a = mask & (@as(usize, 1) << @intCast(i)) != 0;
            const in_b = (i >= 1 and i <= 3) or (i >= 6 and i <= 7);
            try std.testing.expectEqual(in_a or in_b, joined.contains(cp));
            try std.testing.expectEqual(in_a and !in_b, diff.contains(cp));
            try std.testing.expectEqual(in_a and in_b, overlap.contains(cp));
        }
    }
    try std.testing.expectError(error.InternalError, intervalsets.IntervalSet.init(allocator, &.{.{ .start = 2, .end = 1 }}));
}

test "interval allocation failures do not leak partial sets" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, struct {
        fn exercise(allocator: std.mem.Allocator) !void {
            var a = try intervalsets.IntervalSet.init(allocator, &.{.{ .start = 0, .end = 10 }});
            defer a.deinit();
            var b = try intervalsets.IntervalSet.init(allocator, &.{.{ .start = 5, .end = 20 }});
            defer b.deinit();
            var c = try a.unionWith(&b);
            defer c.deinit();
            var d = try a.difference(&b);
            defer d.deinit();
            var e = try a.intersection(&b);
            defer e.deinit();
            _ = try a.cacheStringConstantsMaskOwned(try allocator.dupe(bool, &.{ true, false }));
            var copy = try a.clone();
            defer copy.deinit();
            try std.testing.expectEqualSlices(bool, &.{ true, false }, copy.getStringConstantsMask().?);
        }
    }.exercise, .{});
}

test "an interval memo retains its first value and frees duplicate submissions" {
    var set = try intervalsets.IntervalSet.init(std.testing.allocator, &.{ .{ .start = 'a', .end = 'a' }, .{ .start = 'b', .end = 'b' } });
    defer set.deinit();
    var empty = try intervalsets.IntervalSet.init(std.testing.allocator, &.{});
    defer empty.deinit();
    var joined = try empty.unionWith(&set);
    defer joined.deinit();
    try std.testing.expect(joined.eql(&set));
    _ = try set.cacheStringConstantsMaskOwned(try std.testing.allocator.dupe(bool, &.{ true, false }));
    const retained = try set.cacheStringConstantsMaskOwned(try std.testing.allocator.dupe(bool, &.{ false, true }));
    try std.testing.expectEqualSlices(bool, &.{ true, false }, retained);
}

test "signed zeros and adjacent float ranges retain their ordering" {
    const negative_zero: f64 = @bitCast(@as(u64, 1) << 63);
    try std.testing.expect(floats.signAwareLte(negative_zero, 0));
    try std.testing.expect(!floats.signAwareLte(0, negative_zero));
    try std.testing.expectEqual(@as(u64, 0), @as(u64, @bitCast(floats.nextUp(negative_zero))));
    for ([_]f64{ 0.1, 0.5, 1.1, 1.5, 2.1, 2.5, 1e-100, 1e100 }) |start| {
        var hi = start;
        var expected = start;
        for (0..32) |_| {
            const candidate = try float_index.simplestInRange(start, hi);
            try std.testing.expectEqual(@as(u64, @bitCast(expected)), @as(u64, @bitCast(candidate)));
            hi = floats.nextUp(hi);
            if (float_index.floatToIndex(hi) < float_index.floatToIndex(expected)) expected = hi;
        }
    }
}

test "both SmallRng word sizes match upstream reference streams" {
    var large = rng.Xoshiro(u64).seeded(42);
    for ([_]u64{ 15021278609987233951, 5881210131331364753, 18149643915985481100, 12933668939759105464 }) |expected| try std.testing.expectEqual(expected, large.nextU64());
    var small = rng.Xoshiro(u32).seeded(0);
    for ([_]u32{ 1179900579, 1938959192, 3089844957, 3657088315, 1015453891, 479942911, 3433842246, 669252886, 3985671746, 2737205563 }) |expected| try std.testing.expectEqual(expected, small.nextU32());
}

test "OS randomness fills all widths and spawning keeps the backend" {
    var threaded = std.Io.Threaded.init(std.testing.allocator, .{});
    defer threaded.deinit();
    const io = threaded.io();
    var random = rng.EngineRng.urandomSource(io);
    _ = random.nextU32();
    const first = random.nextU64();
    const second = random.nextU64();
    try std.testing.expect(first != second);
    var bytes: [31]u8 = undefined;
    random.fillBytes(&bytes);
    var child = random.spawn();
    _ = child.nextU64();
    try std.testing.expectEqual(std.meta.activeTag(random), std.meta.activeTag(child));
    const fallback = rng.EngineRng.urandomOrFallback(io, false);
    try std.testing.expectEqual(.prng, std.meta.activeTag(fallback));
    var seeded = rng.EngineRng.fromOsOrZero(42, true);
    try std.testing.expectEqual(@as(u64, 15021278609987233951), seeded.nextU64());
}

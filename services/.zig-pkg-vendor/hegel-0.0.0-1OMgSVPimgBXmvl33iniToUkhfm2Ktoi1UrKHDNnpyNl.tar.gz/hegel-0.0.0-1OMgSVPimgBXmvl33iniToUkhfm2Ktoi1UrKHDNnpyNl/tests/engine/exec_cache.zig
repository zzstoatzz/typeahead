const std = @import("std");
const n = @import("native");
const c = n.choices;
const cache = n.exec_cache;
const gpa = std.testing.allocator;
test "digest updates match concatenation and distinguish bitwise choices" {
    var digest: cache.Digest = .{};
    digest.update("abc");
    digest.update("def");
    try std.testing.expectEqual(cache.Digest.of("abcdef"), digest);
    const zero = [_]c.ChoiceValue{.{ .float = 0.0 }};
    const minus_zero = [_]c.ChoiceValue{.{ .float = -0.0 }};
    const a = (try n.database.serializeChoices(gpa, &zero)).?;
    defer gpa.free(a);
    const b = (try n.database.serializeChoices(gpa, &minus_zero)).?;
    defer gpa.free(b);
    try std.testing.expect(cache.Digest.of(a).value != cache.Digest.of(b).value);
}
fn exercise(allocator: std.mem.Allocator) !void {
    var ec = cache.ExecCache.init(allocator);
    defer ec.deinit();
    var first = try ec.record("one", .valid, null, &.{}, &.{}, true);
    defer first.deinit(allocator);
    try std.testing.expect(!first.duplicate);
    var flipped = try ec.record("one", .interesting, "bug", &.{}, &.{}, true);
    defer flipped.deinit(allocator);
    try std.testing.expect(flipped.duplicate and flipped.verdict_mismatch);
    try std.testing.expectEqualStrings("bug", flipped.mismatched_origin.?);
    var served = (try ec.serve("one")).?;
    defer served.deinit(allocator);
    try std.testing.expect(served.status == .valid);
    ec.max_full_bytes = 0;
    var second = try ec.record("two", .interesting, "other", &.{}, &.{}, true);
    defer second.deinit(allocator);
    try std.testing.expect(try ec.serve("one") == null);
    var duplicate = try ec.record("one", .valid, null, &.{}, &.{}, false);
    defer duplicate.deinit(allocator);
    try std.testing.expect(duplicate.duplicate and !duplicate.verdict_mismatch);
    ec.clear();
    var cleared = try ec.record("one", .invalid, null, &.{}, &.{}, false);
    defer cleared.deinit(allocator);
    try std.testing.expect(!cleared.duplicate);
}
test "cache keeps verdicts after serving eviction and frees every failure path" {
    try exercise(gpa);
    try std.testing.checkAllAllocationFailures(gpa, exercise, .{});
}
fn ledgerExercise(allocator: std.mem.Allocator) !void {
    var ledger = cache.KindLedger.init(allocator);
    defer ledger.deinit();
    var first = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, false, false)};
    defer first[0].deinit(allocator);
    try std.testing.expect(try ledger.observe(&first) == null);
    var changed = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.25 }, false, false)};
    defer changed[0].deinit(allocator);
    const mismatch = (try ledger.observe(&changed)).?;
    try std.testing.expectEqual(@as(usize, 0), mismatch.position);
    ledger.clear();
    try std.testing.expect(try ledger.observe(&changed) == null);
    ledger.capacity = 0;
    ledger.clear();
    try std.testing.expect(try ledger.observe(&first) == null);
    try std.testing.expect(try ledger.observe(&changed) == null);
}
test "kind ledger detects constraint drift but resets on ND flip" {
    try std.testing.checkAllAllocationFailures(gpa, ledgerExercise, .{});
}

const std = @import("std");
const s = @import("shrinker").search;
const BigInt = @import("shrinker").search.BinSearchDownBig;
test "adaptive searches preserve probe ordering and converge" {
    for (0..100) |target| {
        var f = s.FindInteger.init();
        var probes: usize = 0;
        while (f.probe()) |p| {
            f.record(p <= target);
            probes += 1;
            try std.testing.expect(probes < 100);
        }
        try std.testing.expectEqual(target, f.step().done);
    }
    var unlimited = s.FindInteger.init();
    while (unlimited.probe() != null) unlimited.record(true);
    try std.testing.expectEqual(@as(usize, 5) << 61, unlimited.step().done);
    for (0..100) |target| {
        var f = s.BinSearchDown.init(0, 100);
        while (f.probe()) |p| f.record(p >= target);
        try std.testing.expectEqual(@as(i128, @intCast(target)), f.step().done);
    }
}

test "arbitrary precision binary search" {
    const a = std.testing.allocator;
    const B = s.BigInt;
    const lo = try B.fromInt(a, 0);
    var one = try B.fromInt(a, 1);
    defer one.deinit();
    const hi = try one.shl(a, 512);
    var target = try one.shl(a, 300);
    defer target.deinit();
    var f = s.BinSearchDownBig.init(a, lo, hi);
    defer f.deinit();
    while (try f.probe()) |v| {
        var value = v;
        defer value.deinit();
        try f.record(value.order(target) != .lt);
    }
    var result = (try f.step()).done;
    defer result.deinit();
    try std.testing.expect(result.eql(target));
}
test "search probes exactly match original Rust traces" {
    const a = std.testing.allocator;
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/shrinker_search.tsv"), '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        var cols = std.mem.splitScalar(u8, line, '\t');
        const kind = cols.next().?;
        const target_text = cols.next().?;
        const trace = cols.next().?;
        var probes = std.mem.splitScalar(u8, trace, ',');
        if (std.mem.eql(u8, kind, "find")) {
            const target = try std.fmt.parseInt(usize, target_text, 10);
            var f = s.FindInteger.init();
            while (f.probe()) |p| {
                try std.testing.expectEqual(try std.fmt.parseInt(usize, probes.next().?, 10), p);
                f.record(p <= target);
            }
            try std.testing.expectEqual(try std.fmt.parseInt(usize, cols.next().?, 10), f.step().done);
        } else if (std.mem.eql(u8, kind, "binary")) {
            const target = try std.fmt.parseInt(i128, target_text, 10);
            var f = s.BinSearchDown.init(0, 100);
            while (f.probe()) |p| {
                try std.testing.expectEqual(try std.fmt.parseInt(i128, probes.next().?, 10), p);
                f.record(p >= target);
            }
        } else {
            const power = try std.fmt.parseInt(usize, target_text, 10);
            var one = try s.BigInt.fromInt(a, 1);
            defer one.deinit();
            var target = try one.shl(a, power);
            defer target.deinit();
            var f = s.BinSearchDownBig.init(a, try s.BigInt.fromInt(a, 0), try one.shl(a, 512));
            defer f.deinit();
            while (try f.probe()) |candidate| {
                var value = candidate;
                defer value.deinit();
                var expected = try s.BigInt.fromString(a, 10, probes.next().?);
                defer expected.deinit();
                try std.testing.expect(value.eql(expected));
                try f.record(value.order(target) != .lt);
            }
        }
        try std.testing.expect(probes.next() == null);
        count += 1;
    }
    try std.testing.expectEqual(22, count);
}

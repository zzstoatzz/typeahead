const std = @import("std");
const e = @import("events");
fn exercise(gpa: std.mem.Allocator) !void {
    var statistics = e.RunStatistics.init(gpa);
    defer statistics.deinit();
    try statistics.recordCase(&.{ .{ .label = "hit" }, .{ .label = "hit" }, .{ .label = "size", .value = 1 }, .{ .label = "size", .value = 9 } });
    try statistics.recordCase(&.{ .{ .label = "size", .value = 3 }, .{ .label = "size", .value = 7 } });
    statistics.recordMeasurement(true);
    statistics.recordMeasurement(false);
    const lines = try statistics.render();
    defer e.deinitLines(gpa, lines);
    try std.testing.expectEqual(@as(usize, 4), lines.len);
    try std.testing.expectEqualStrings("  * hit: 50.0% of test cases", lines[1]);
    try std.testing.expectEqualStrings("  * size: count 4, min 1, median 5, mean 5.00, p90 9, max 9", lines[2]);
    try std.testing.expectEqualStrings("  * nondeterministic handling: measurement replays 2, failing 1", lines[3]);
}
test "events deduplicate per case while numeric observations all count" {
    try exercise(std.testing.allocator);
}
test "statistics release every partial allocation" {
    try std.testing.checkAllAllocationFailures(std.testing.allocator, exercise, .{});
}

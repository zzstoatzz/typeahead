// SPDX-License-Identifier: MIT AND MPL-2.0
use hegel_c::__bench::{self as h, ChoiceValue as V, BigInt, CloneRecord, ReplayKind, DataSource, TestCaseResult};
use std::sync::Arc;
fn values(vs:&[V])->String { vs.iter().map(|v|match v {
    V::Integer(n)=>format!("i{}",n), V::Boolean(b)=>format!("b{}",*b as u8), V::Bytes(b)=>format!("x{}",b.iter().map(|v|format!("{v:02x}")).collect::<String>()),
    V::Clone(c)=>format!("c({})",values(&c.owned_values())), _=>panic!("unexpected")
}).collect::<Vec<_>>().join(";") }
fn body(ds:Box<dyn DataSource+Send+Sync>) {
    ds.start_span(55).unwrap();
    ds.generate_boolean(0.125,None).unwrap();
    ds.generate_integer(&BigInt::from(-10),&BigInt::from(10)).unwrap();
    let child=ds.clone_stream().unwrap();
    child.generate_boolean(0.9,None).unwrap();
    child.generate_integer(&BigInt::from(0),&BigInt::from(100)).unwrap();
    ds.generate_bytes(0,4).unwrap();
    let mut pool=ds.new_pool().unwrap();
    ds.pool_add(&mut pool).unwrap(); ds.pool_add(&mut pool).unwrap();
    ds.pool_generate(&mut pool,true).unwrap(); ds.pool_generate(&mut pool,false).unwrap();
    ds.stop_span(false).unwrap(); ds.mark_complete(&TestCaseResult::Valid);
}
fn main(){
    let child=V::Clone(Arc::new(CloneRecord::from_values(vec![V::Boolean(false),V::Integer(BigInt::from(99))])));
    let a=vec![V::Integer(BigInt::from(0)),V::Boolean(false),child.clone(),V::Bytes(vec![1,2]),V::Integer(BigInt::from(1)),V::Integer(BigInt::from(1)),V::Integer(BigInt::from(1)),V::Integer(BigInt::from(0))];
    let b=vec![V::Boolean(true),V::Integer(BigInt::from(7)),child,V::Bytes(vec![9]),V::Integer(BigInt::from(0)),V::Integer(BigInt::from(1)),V::Integer(BigInt::from(1)),V::Integer(BigInt::from(0))];
    let pool=vec![a.clone(),b.clone()];
    for mode in 0..3 { for seed in 0..100 {
        let kind=match mode {0=>ReplayKind::Fresh{budget:30},1=>ReplayKind::Sequence{choices:&a,extend:20},_=>ReplayKind::Set{timelines:&pool,extend:20}};
        let out=h::replay_case(kind,seed,body).unwrap();
        let divergence=out.divergence.map(|d|format!("{}:{}",d.stream.iter().map(|v|v.to_string()).collect::<Vec<_>>().join(","),d.position)).unwrap_or("_".into());
        println!("{}\t{}\t{}\t{}\t{}",mode,seed,values(&out.realized),divergence,out.live.iter().map(|b|if *b {'1'}else{'0'}).collect::<String>());
    }}
}

const std = @import("std");
const p = @import("printer");
test "debug symbols compile" {
    const text = try p.debugChoiceKind(std.testing.allocator, .clone);
    defer std.testing.allocator.free(text);
    try std.testing.expectEqualStrings("Clone", text);
}

test "debug primitive values and constraints" {
    const a = std.testing.allocator;
    var value = p.choices.ChoiceValue{ .integer = try p.choices.BigInt.fromInt(a, 117) };
    defer value.deinit(a);
    const actual = try p.debugChoiceValue(a, &value);
    defer a.free(actual);
    try std.testing.expectEqualStrings("Integer(BigInt(117))", actual);
    const kind = try p.debugChoiceKind(a, .{ .float = .{ .min_value = -0.0, .max_value = 1e16, .allow_nan = true, .allow_infinity = false, .smallest_nonzero_magnitude = 5e-324 } });
    defer a.free(kind);
    try std.testing.expectEqualStrings("Float(FloatChoice { min_value: -0.0, max_value: 1e16, allow_nan: true, allow_infinity: false, smallest_nonzero_magnitude: 5e-324 })", kind);
}
test "Rust derived Debug corpus matches all value kinds and random IEEE floats" {
    const a = std.testing.allocator;
    var lines = std.mem.tokenizeScalar(u8, @embedFile("fixtures/printer_debug.tsv"), '\n');
    var count: usize = 0;
    var ic = p.choices.IntegerChoice{ .min_value = try p.choices.BigInt.fromInt(a, -128), .max_value = try p.choices.BigInt.fromInt(a, 128), .shrink_towards = try p.choices.BigInt.fromInt(a, 0) };
    defer ic.deinit();
    var intervals = try p.choices.IntervalSet.init(a, &.{ .{ .start = 48, .end = 57 }, .{ .start = 65, .end = 122 } });
    defer intervals.deinit();
    while (lines.next()) |line| {
        var cols = std.mem.splitScalar(u8, line, '\t');
        const encoded = cols.next().?;
        const expected_value = cols.next().?;
        const expected_kind = cols.next().?;
        const bytes = try a.alloc(u8, encoded.len / 2);
        defer a.free(bytes);
        _ = try std.fmt.hexToBytes(bytes, encoded);
        const values = (try p.database.deserializeChoicesExact(a, bytes)).?;
        defer p.choices.deinitValues(a, values);
        const value = &values[0];
        const kind: p.choices.ChoiceKind = switch (value.*) {
            .integer => .{ .integer = &ic },
            .boolean => .{ .boolean = .{ .p = 0.5 } },
            .float => .{ .float = .{ .min_value = -0.0, .max_value = std.math.inf(f64), .allow_nan = true, .allow_infinity = true, .smallest_nonzero_magnitude = 5e-324 } },
            .bytes => .{ .bytes = .{ .min_size = 0, .max_size = 100 } },
            .string => .{ .string = .{ .intervals = &intervals, .min_size = 0, .max_size = 100 } },
            .clone => .clone,
        };
        const actual = try p.debugChoiceValue(a, value);
        defer a.free(actual);
        try std.testing.expectEqualStrings(expected_value, actual);
        const actual_kind = try p.debugChoiceKind(a, kind);
        defer a.free(actual_kind);
        try std.testing.expectEqualStrings(expected_kind, actual_kind);
        count += 1;
    }
    try std.testing.expectEqual(2020, count);
}

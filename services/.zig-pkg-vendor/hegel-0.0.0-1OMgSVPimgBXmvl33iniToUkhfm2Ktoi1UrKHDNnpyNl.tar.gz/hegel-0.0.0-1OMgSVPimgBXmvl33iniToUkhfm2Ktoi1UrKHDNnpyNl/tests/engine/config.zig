const std = @import("std");
const c = @import("config");
const gpa = std.testing.allocator;
const document =
    \\default = "nightly"
    \\[profiles.nightly]
    \\extends = "ci"
    \\test_cases = 10_000
    \\seed = 18446744073709551615
    \\derandomize = true
    \\report_multiple_failures = true
    \\show_statistics = true
    \\print_blob = false
    \\verbosity = "verbose"
    \\backend = "default"
    \\nondeterminism_strictness = "warn"
    \\database = 'my/db'
    \\suppress_health_check = ["too_slow", "filter_too_much"]
    \\phases = ["reuse", "generate", "shrink"]
;
fn parseWithFailure(allocator: std.mem.Allocator) !void {
    var config = try c.parse(allocator, document);
    defer config.deinit();
    try std.testing.expectEqualStrings("nightly", config.view().default.?);
    const profile = config.view().profiles[0];
    try std.testing.expectEqualStrings("ci", profile.delta.extends.?);
    try std.testing.expectEqual(@as(?u64, std.math.maxInt(u64)), profile.delta.seed.?);
    try std.testing.expectEqual(@as(?u64, 10000), profile.delta.test_cases);
}
test "config parses all profile keys with full-width unsigned seeds" {
    try parseWithFailure(gpa);
    var baseline = std.testing.FailingAllocator.init(gpa, .{});
    try parseWithFailure(baseline.allocator());
    for (0..baseline.alloc_index + 8) |index| {
        var failing = std.testing.FailingAllocator.init(gpa, .{ .fail_index = index });
        parseWithFailure(failing.allocator()) catch |err| if (err != error.OutOfMemory) return err;
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
    }
}
test "strict config errors retain source line" {
    var diagnostic: c.Diagnostic = .{};
    defer diagnostic.deinit(gpa);
    try std.testing.expectError(error.InvalidConfig, c.parseDetailed(gpa, "[profiles.a]\n\nunknown=true\n", &diagnostic));
    try std.testing.expectEqual(@as(usize, 3), diagnostic.line);
    try std.testing.expectEqualStrings("unknown key `unknown`", diagnostic.message.?);
}
test "inline profiles, quoted dotted names and multiline arrays preserve order" {
    var config = try c.parse(gpa, "profiles = { b = { test_cases = 2 }, a = { seed = 'none' } }\n");
    defer config.deinit();
    try std.testing.expectEqualStrings("b", config.view().profiles[0].name);
    try std.testing.expectEqualStrings("a", config.view().profiles[1].name);
    try std.testing.expect(config.view().profiles[1].delta.seed.? == null);
    try std.testing.expectError(error.InvalidConfig, c.parse(gpa, "[profiles.base]\n"));
    try std.testing.expectError(error.InvalidConfig, c.parse(gpa, "[profiles.a]\nphases = ['wat']\n"));
    try std.testing.expectError(error.InvalidConfig, c.parse(gpa, "[profiles.a]\nsuppress_health_check = ['all','too_slow']\n"));
}
fn noEnv(_: ?*anyopaque, _: []const u8) ?[]const u8 {
    return null;
}
test "config discovery walks ancestors and explicit config fails loudly" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    const root = try std.fmt.allocPrint(gpa, ".zig-cache/tmp/{s}", .{tmp.sub_path});
    defer gpa.free(root);
    try tmp.dir.createDirPath(std.testing.io, "a/b");
    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "hegel.toml", .data = "default='ci'\n" });
    const nested = try std.fmt.allocPrint(gpa, "{s}/a/b", .{root});
    defer gpa.free(nested);
    var config = try c.load(gpa, std.testing.io, .{ .context = null, .get = noEnv }, nested);
    defer config.deinit();
    try std.testing.expectEqualStrings("ci", config.view().default.?);
    try std.testing.expect(std.mem.endsWith(u8, config.view().path.?, "/hegel.toml"));
    const Explicit = struct {
        fn get(_: ?*anyopaque, key: []const u8) ?[]const u8 {
            return if (std.mem.eql(u8, key, "HEGEL_CONFIG")) "nonexistent/hegel.toml" else null;
        }
    };
    var diagnostic: c.Diagnostic = .{};
    defer diagnostic.deinit(gpa);
    try std.testing.expectError(error.InvalidConfig, c.loadDetailed(gpa, std.testing.io, .{ .context = null, .get = Explicit.get }, nested, &diagnostic));
    try std.testing.expectEqual(@as(usize, 0), diagnostic.line);
    try std.testing.expectEqualStrings("cannot read the file named by HEGEL_CONFIG", diagnostic.message.?);
}
test "discovery frees the candidate path when file allocation fails" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "hegel.toml", .data = "default='ci'\n" });
    const root = try std.fmt.allocPrint(gpa, ".zig-cache/tmp/{s}", .{tmp.sub_path});
    defer gpa.free(root);
    var failing = std.testing.FailingAllocator.init(gpa, .{ .fail_index = 1 });
    try std.testing.expectError(error.OutOfMemory, c.discover(failing.allocator(), std.testing.io, root));
    try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
}

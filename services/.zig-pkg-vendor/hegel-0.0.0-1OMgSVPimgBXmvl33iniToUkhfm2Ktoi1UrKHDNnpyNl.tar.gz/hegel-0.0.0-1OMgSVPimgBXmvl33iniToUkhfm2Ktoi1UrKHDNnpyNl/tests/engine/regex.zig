const std = @import("std");
const re = @import("re");
const p = re.parser;
const A = std.testing.allocator;
fn number(h: *u64, n: u64) void {
    var bytes: [8]u8 = undefined;
    std.mem.writeInt(u64, &bytes, n, .little);
    for (bytes) |b| h.* = (h.* ^ b) *% 1099511628211;
}
fn pattern(h: *u64, pat: p.SubPattern) void {
    number(h, pat.len());
    for (pat.data.items) |op| switch (op) {
        .Literal => |v| {
            number(h, 0);
            number(h, v);
        },
        .NotLiteral => |v| {
            number(h, 1);
            number(h, v);
        },
        .Any => number(h, 2),
        .At => |v| {
            number(h, 3);
            number(h, @backingInt(v));
        },
        .In => |items| {
            number(h, 4);
            number(h, items.len);
            for (items) |item| switch (item) {
                .Literal => |v| {
                    number(h, 0);
                    number(h, v);
                },
                .Negate => number(h, 1),
                .Range => |r| {
                    number(h, 2);
                    number(h, r.lo);
                    number(h, r.hi);
                },
                .Category => |v| {
                    number(h, 3);
                    number(h, @backingInt(v));
                },
            };
        },
        .Branch => |items| {
            number(h, 5);
            number(h, items.len);
            for (items) |item| pattern(h, item);
        },
        .Subpattern => |v| {
            number(h, 6);
            number(h, v.group orelse std.math.maxInt(u32));
            number(h, v.add_flags);
            number(h, v.del_flags);
            pattern(h, v.p);
        },
        .GroupRef => |v| {
            number(h, 7);
            number(h, v);
        },
        .GroupRefExists => |v| {
            number(h, 8);
            number(h, v.cond_group);
            pattern(h, v.yes);
            number(h, @intFromBool(v.no != null));
            if (v.no) |item| pattern(h, item);
        },
        .Assert => |v| {
            number(h, 9);
            number(h, @bitCast(@as(i64, v.direction)));
            pattern(h, v.p);
        },
        .AssertNot => |v| {
            number(h, 10);
            number(h, @bitCast(@as(i64, v.direction)));
            pattern(h, v.p);
        },
        .AtomicGroup => |item| {
            number(h, 11);
            pattern(h, item);
        },
        .MaxRepeat => |v| {
            number(h, 12);
            number(h, v.min);
            number(h, v.max);
            pattern(h, v.item);
        },
        .MinRepeat => |v| {
            number(h, 13);
            number(h, v.min);
            number(h, v.max);
            pattern(h, v.item);
        },
        .PossessiveRepeat => |v| {
            number(h, 14);
            number(h, v.min);
            number(h, v.max);
            pattern(h, v.item);
        },
        .Failure => number(h, 15),
    };
}
fn integer(comptime T: type, t: []const u8) !T {
    return std.fmt.parseInt(T, t, 10);
}
fn unhex(t: []const u8) ![]u8 {
    if (std.mem.eql(u8, t, "_")) return A.alloc(u8, 0);
    const bytes = try A.alloc(u8, t.len / 2);
    errdefer A.free(bytes);
    _ = try std.fmt.hexToBytes(bytes, t);
    return bytes;
}
test "full parser AST and errors match pinned Rust" {
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/regex.tsv"), '\n');
    var failures: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const kind = fields.next().?[0];
        const text = try unhex(fields.next().?);
        defer A.free(text);
        const flags = try integer(u32, fields.next().?);
        var result = try p.parsePattern(A, text, flags);
        defer result.deinit();
        if (kind == 'O') {
            const want_flags = try integer(u32, fields.next().?);
            const want_hash = try integer(u64, fields.next().?);
            if (result.parsed) |parsed| {
                var h: u64 = 14695981039346656037;
                pattern(&h, parsed.pattern);
                if (h != want_hash or parsed.flags != want_flags) {
                    if (failures < 20) std.debug.print("AST {s} flags={} expected={} got={}\n", .{ text, flags, want_hash, h });
                    failures += 1;
                }
            } else {
                if (failures < 20) std.debug.print("unexpected parse failure {s}: {s} at {}\n", .{ text, result.failure.?.msg, result.failure.?.pos });
                failures += 1;
            }
        } else {
            const pos = try integer(usize, fields.next().?);
            const msg = try unhex(fields.next().?);
            defer A.free(msg);
            if (result.failure) |failure| {
                if (failure.pos != pos or !std.mem.eql(u8, failure.msg, msg)) {
                    if (failures < 20) std.debug.print("error {s}: expected {s} at {}, got {s} at {}\n", .{ text, msg, pos, failure.msg, failure.pos });
                    failures += 1;
                }
            } else {
                if (failures < 20) std.debug.print("unexpected parser success {s}\n", .{text});
                failures += 1;
            }
        }
    }
    try std.testing.expectEqual(@as(usize, 0), failures);
}
fn allocationPaths(allocator: std.mem.Allocator) !void {
    for ([_][]const u8{ "(?P<x>a|b)+(?P=x)", "(?i:[a-z]{1,5})(?=x)", "(?P<x>", "[z-a]" }) |text| {
        var result = try p.parsePattern(allocator, text, 0);
        result.deinit();
    }
}
test "parser owns success and error trees through allocation failures" {
    try std.testing.checkAllAllocationFailures(A, allocationPaths, .{});
}

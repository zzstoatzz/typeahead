const std = @import("std");
const unicode = @import("unicode");
fn hash(current: u64, bytes: []const u8) u64 {
    var h = current;
    for (bytes) |b| h = (h ^ b) *% 1099511628211;
    return h;
}
test "every Unicode codepoint matches pinned Rust category and recursive NFD" {
    var categories: u64 = 14695981039346656037;
    var nfd = categories;
    for (0..0x110000) |cp| {
        categories = hash(categories, (try unicode.generalCategory(@intCast(cp))).asStr());
        var bytes: [4]u8 = undefined;
        std.mem.writeInt(u32, &bytes, unicode.nfdBase(@intCast(cp)) orelse std.math.maxInt(u32), .little);
        nfd = hash(nfd, &bytes);
    }
    var fields = std.mem.tokenizeAny(u8, @embedFile("fixtures/unicode.tsv"), "\t\n");
    try std.testing.expectEqual(try std.fmt.parseInt(u64, fields.next().?, 10), categories);
    try std.testing.expectEqual(try std.fmt.parseInt(u64, fields.next().?, 10), nfd);
}

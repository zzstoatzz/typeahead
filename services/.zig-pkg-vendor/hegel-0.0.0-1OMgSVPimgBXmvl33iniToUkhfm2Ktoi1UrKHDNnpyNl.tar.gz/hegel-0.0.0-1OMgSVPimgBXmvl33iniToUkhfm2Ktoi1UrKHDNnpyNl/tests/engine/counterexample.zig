// SPDX-License-Identifier: MIT AND MPL-2.0
const std = @import("std");
const native = @import("native");
const ce = native.counterexample;
const c = native.choices;
const gpa = std.testing.allocator;
const nodes = [_]c.ChoiceNode{c.ChoiceNode.boolean(.{ .p = 0.5 }, true, false)};
test "confirmation gates graph admission; rejection retains origin evidence and budgets" {
    var record = ce.Counterexample.init(gpa);
    defer record.deinit();
    try std.testing.expect(try record.adopt(&nodes, &.{}));
    try record.recordSighting(&nodes, &.{}, true);
    try record.recordSighting(&nodes, &.{}, false);
    try std.testing.expectEqual(@as(usize, 1), record.history().entries().len);
    var graph = try record.replayGraph();
    defer if (graph) |*g| g.deinit();
    try std.testing.expect(graph != null);
    try std.testing.expect(record.graph() == null);
    const evicted = record.reject(.{ .fails = 1, .replays = 10 }).?;
    defer c.deinitNodes(gpa, evicted);
    try std.testing.expect(record.incumbent() == null);
    try std.testing.expectEqual(@as(u64, 10), record.replays);
    try std.testing.expect(try record.adopt(&nodes, &.{}));
    try record.confirm(0.5, null, &graph.?, 1, .{ .fails = 5, .replays = 10 });
    try std.testing.expect(!record.needsConfirmation());
    try std.testing.expect(record.history().isEmpty());
    record.raiseAnchor(0.1);
    try std.testing.expectEqual(@as(?f64, 0.5), record.anchor());
    record.raiseAnchor(0.8);
    try std.testing.expectEqual(@as(?f64, 0.8), record.anchor());
    try std.testing.expect(record.reject(.{ .fails = 0, .replays = 40 }) == null);
    var repro = try record.reproState();
    defer repro.deinit();
    const encoded = try repro.graph.encode();
    defer gpa.free(encoded.?);
    try std.testing.expectEqual(native.database.fnv1a(encoded.?), repro.entropy);
    try std.testing.expectError(error.InternalError, record.confirm(0.9, null, &graph.?, 1, .{ .fails = 4, .replays = 4 }));
}
test "trusted evidence accumulates without demotion and budgets never reset" {
    var record = ce.Counterexample.init(gpa);
    defer record.deinit();
    try record.trust(null, .{ .fails = 1, .replays = 3 });
    record.recordTrustedBatch(.{ .fails = 0, .replays = 8 });
    try std.testing.expectEqual(@as(u64, 11), record.replays);
    try std.testing.expect(!record.needsConfirmation());
    record.seedEvidence(.{ .failures = 2, .replays = 3 });
    try std.testing.expectEqual(@as(u64, 2), record.takeSeed().?.failures);
    try std.testing.expect(record.takeSeed() == null);
    for (0..native.nd.BAR_ATTEMPTS_PER_RUN) |_| try std.testing.expect(record.spendBarAttempt());
    try std.testing.expect(!record.spendBarAttempt());
    for (0..native.nd.BACKTRACK_BAR_ATTEMPTS) |_| try std.testing.expect(record.spendBacktrackAttempt());
    try std.testing.expect(!record.backtrackAttemptsLeft());
    record.recordFinalReplay(.{ .fails = 0, .replays = 20 });
    const caveat = try record.caveat();
    defer gpa.free(caveat);
    try std.testing.expect(std.mem.indexOf(u8, caveat, "not reproduced at report time") != null);
}
fn exercise(allocator: std.mem.Allocator) !void {
    var records = ce.Counterexamples.init(allocator);
    defer records.deinit();
    var a = try records.entry("z");
    _ = try a.adopt(&nodes, &.{});
    try a.recordSighting(&nodes, &.{}, true);
    _ = try records.entry("a");
    a = records.getMut("z").?;
    var graph = (try a.replayGraph()).?;
    defer graph.deinit();
    try a.trust(.{ .graph = &graph, .longest = 1 }, .{ .fails = 1, .replays = 1 });
    try a.confirm(0.8, null, &graph, 1, .{ .fails = 4, .replays = 4 });
    try a.install(&graph, &nodes, &.{}, 0.9, 1);
    const names = try records.liveOrigins(allocator);
    defer {
        for (names) |n| allocator.free(n);
        allocator.free(names);
    }
    const caveat = try a.caveat();
    allocator.free(caveat);
}
test "origin queries remain sorted and all allocation failures unwind" {
    try std.testing.checkAllAllocationFailures(gpa, exercise, .{});
    var records = ce.Counterexamples.init(gpa);
    defer records.deinit();
    _ = try records.entry("z");
    _ = try records.entry("a");
    try std.testing.expectEqualStrings("a", records.iter()[0].origin);
    try std.testing.expect(records.needsConfirmation("missing"));
    try std.testing.expect(!records.anyLive());
}
test "confirmation witness is owned and taken exactly once" {
    var record = ce.Counterexample.init(gpa);
    defer record.deinit();
    var run = try native.graph.Run.fromNodes(gpa, &nodes, &.{});
    defer run.deinit();
    var graph = try native.graph.Graph.fromRun(gpa, &run);
    defer graph.deinit();
    var origin = [_]u8{'f'};
    const witness = ce.RunResult{ .status = .interesting, .nodes = @constCast(&nodes), .spans = &.{}, .origin = &origin };
    try record.confirm(0.75, &witness, &graph, 1, .{ .fails = 4, .replays = 4 });
    var taken = record.takeWitness().?;
    defer taken.run.deinit(gpa);
    try std.testing.expect(record.takeWitness() == null);
    try std.testing.expectEqualStrings("f", taken.run.origin.?);
    try std.testing.expectEqual(@as(f64, 0.75), taken.anchor);
}

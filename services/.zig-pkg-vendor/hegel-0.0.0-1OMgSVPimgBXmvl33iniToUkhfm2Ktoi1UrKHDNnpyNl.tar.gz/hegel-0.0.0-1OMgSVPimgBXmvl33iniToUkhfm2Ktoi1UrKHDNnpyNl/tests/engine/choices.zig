// SPDX-License-Identifier: MIT AND MPL-2.0
// See docs/native-port-licensing.md and docs/native-port-provenance.json.
const std = @import("std");
const c = @import("choices");
const gpa = std.testing.allocator;

test "choice ranks and floating-point fallbacks match the pinned Rust engine" {
    var lines = std.mem.splitScalar(u8, @embedFile("choices.tsv"), '\n');
    var cases: usize = 0;
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const kind = fields.next().?;
        if (std.mem.eql(u8, kind, "signed")) {
            var value = try c.BigInt.fromString(gpa, 10, fields.next().?);
            defer value.deinit();
            const expected = try decodeHex(fields.next().?);
            defer gpa.free(expected);
            const actual = try value.toSignedBytesLe(gpa);
            defer gpa.free(actual);
            try std.testing.expectEqualSlices(u8, expected, actual);
        } else if (std.mem.eql(u8, kind, "integer")) {
            var min = try c.BigInt.fromString(gpa, 10, fields.next().?);
            defer min.deinit();
            var max = try c.BigInt.fromString(gpa, 10, fields.next().?);
            defer max.deinit();
            var target = try c.BigInt.fromString(gpa, 10, fields.next().?);
            defer target.deinit();
            var value = try c.BigInt.fromString(gpa, 10, fields.next().?);
            defer value.deinit();
            var expected = try c.BigUint.fromString(gpa, 10, fields.next().?);
            defer expected.deinit();
            var expected_max = try c.BigUint.fromString(gpa, 10, fields.next().?);
            defer expected_max.deinit();
            const constraint: c.IntegerChoice = .{ .min_value = min, .max_value = max, .shrink_towards = target };
            var actual = try constraint.toIndex(gpa, value);
            defer actual.deinit();
            var actual_max = try constraint.maxIndex(gpa);
            defer actual_max.deinit();
            try std.testing.expect(expected.eql(actual));
            try std.testing.expect(expected_max.eql(actual_max));
            var recovered = (try constraint.fromIndex(gpa, expected)).?;
            defer recovered.deinit();
            try std.testing.expect(value.eql(recovered));
        } else if (std.mem.eql(u8, kind, "bytes")) {
            const min = try std.fmt.parseInt(usize, fields.next().?, 10);
            const max = try std.fmt.parseInt(usize, fields.next().?, 10);
            const value = try decodeHex(fields.next().?);
            defer gpa.free(value);
            var expected = try c.BigUint.fromString(gpa, 10, fields.next().?);
            defer expected.deinit();
            const constraint: c.BytesChoice = .{ .min_size = min, .max_size = max };
            var actual = try constraint.toIndex(gpa, value);
            defer actual.deinit();
            try std.testing.expect(expected.eql(actual));
            const recovered = (try constraint.fromIndex(gpa, expected)).?;
            defer gpa.free(recovered);
            try std.testing.expectEqualSlices(u8, value, recovered);
        } else if (std.mem.eql(u8, kind, "string")) {
            const min = try std.fmt.parseInt(usize, fields.next().?, 10);
            const max = try std.fmt.parseInt(usize, fields.next().?, 10);
            const value = try decodeCodepoints(fields.next().?);
            defer gpa.free(value);
            var expected = try c.BigUint.fromString(gpa, 10, fields.next().?);
            defer expected.deinit();
            var alphabet = try c.IntervalSet.init(gpa, &.{ .{ .start = 0x2f, .end = 0x32 }, .{ .start = 0x41, .end = 0x43 }, .{ .start = 0x10000, .end = 0x10001 } });
            defer alphabet.deinit();
            const constraint: c.StringChoice = .{ .intervals = &alphabet, .min_size = min, .max_size = max };
            var actual = try constraint.toIndex(gpa, value);
            defer actual.deinit();
            try std.testing.expect(expected.eql(actual));
            const recovered = (try constraint.fromIndex(gpa, expected)).?;
            defer gpa.free(recovered);
            try std.testing.expectEqualSlices(u32, value, recovered);
        } else if (std.mem.eql(u8, kind, "float")) {
            const min: f64 = @bitCast(try std.fmt.parseInt(u64, fields.next().?, 16));
            const max: f64 = @bitCast(try std.fmt.parseInt(u64, fields.next().?, 16));
            const allow_nan = try std.fmt.parseInt(u8, fields.next().?, 10) != 0;
            const allow_infinity = try std.fmt.parseInt(u8, fields.next().?, 10) != 0;
            const smallest: f64 = @bitCast(try std.fmt.parseInt(u64, fields.next().?, 16));
            const bits = try std.fmt.parseInt(u64, fields.next().?, 16);
            const value: f64 = @bitCast(bits);
            var expected = try c.BigUint.fromString(gpa, 10, fields.next().?);
            defer expected.deinit();
            const expected_simplest = try std.fmt.parseInt(u64, fields.next().?, 16);
            const expected_unit = try std.fmt.parseInt(u64, fields.next().?, 16);
            const constraint: c.FloatChoice = .{ .min_value = min, .max_value = max, .allow_nan = allow_nan, .allow_infinity = allow_infinity, .smallest_nonzero_magnitude = smallest };
            var actual = try constraint.toIndex(gpa, value);
            defer actual.deinit();
            try std.testing.expect(expected.eql(actual));
            try std.testing.expectEqual(expected_simplest, @as(u64, @bitCast(try constraint.simplest())));
            try std.testing.expectEqual(expected_unit, @as(u64, @bitCast(try constraint.unit())));
            try std.testing.expectEqual(bits, @as(u64, @bitCast((try constraint.fromIndex(expected)).?)));
        } else return error.UnknownOracleCase;
        cases += 1;
    }
    try std.testing.expectEqual(@as(usize, 87), cases);
}

fn decodeHex(text: []const u8) ![]u8 {
    if (std.mem.eql(u8, text, "_")) return gpa.alloc(u8, 0);
    const result = try gpa.alloc(u8, text.len / 2);
    errdefer gpa.free(result);
    return std.fmt.hexToBytes(result, text);
}

fn decodeCodepoints(text: []const u8) ![]u32 {
    var result: std.ArrayList(u32) = .empty;
    errdefer result.deinit(gpa);
    if (!std.mem.eql(u8, text, "_")) {
        var parts = std.mem.splitScalar(u8, text, ',');
        while (parts.next()) |part| try result.append(gpa, try std.fmt.parseInt(u32, part, 16));
    }
    return result.toOwnedSlice(gpa);
}

test "signed arbitrary integers preserve canonical two's complement at width boundaries" {
    const Case = struct { number: i128, bytes: []const u8 };
    for ([_]Case{
        .{ .number = 0, .bytes = &.{0} },
        .{ .number = 127, .bytes = &.{127} },
        .{ .number = 128, .bytes = &.{ 128, 0 } },
        .{ .number = -128, .bytes = &.{128} },
        .{ .number = -129, .bytes = &.{ 127, 255 } },
        .{ .number = -256, .bytes = &.{ 0, 255 } },
        .{ .number = std.math.minInt(i128), .bytes = &.{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 128 } },
    }) |case| {
        var integer = try c.BigInt.fromInt(gpa, case.number);
        defer integer.deinit();
        const encoded = try integer.toSignedBytesLe(gpa);
        defer gpa.free(encoded);
        try std.testing.expectEqualSlices(u8, case.bytes, encoded);
        var decoded = try c.BigInt.fromSignedBytesLe(gpa, case.bytes);
        defer decoded.deinit();
        try std.testing.expect(integer.eql(decoded));
    }
    var large_bytes: [257]u8 = @splat(0);
    large_bytes[256] = 1;
    var large = try c.BigInt.fromSignedBytesLe(gpa, &large_bytes);
    defer large.deinit();
    try std.testing.expectEqual(@as(usize, 2049), large.bits());
    try std.testing.expectEqual(null, large.toInt(u128));
    const encoded = try large.toSignedBytesLe(gpa);
    defer gpa.free(encoded);
    try std.testing.expectEqualSlices(u8, &large_bytes, encoded);
    var negative = try large.negate(gpa);
    defer negative.deinit();
    const negative_bytes = try negative.toSignedBytesLe(gpa);
    defer gpa.free(negative_bytes);
    var decoded_negative = try c.BigInt.fromSignedBytesLe(gpa, negative_bytes);
    defer decoded_negative.deinit();
    try std.testing.expect(negative.eql(decoded_negative));
}

test "integer ranks preserve asymmetric shortlex ordering beyond u128" {
    var bound_bytes: [33]u8 = @splat(0);
    bound_bytes[32] = 1;
    var high = try c.BigInt.fromSignedBytesLe(gpa, &bound_bytes);
    defer high.deinit();
    var low = try high.negate(gpa);
    defer low.deinit();
    var target = try c.BigInt.fromInt(gpa, @as(i32, 123));
    defer target.deinit();
    const constraint: c.IntegerChoice = .{ .min_value = low, .max_value = high, .shrink_towards = target };
    var maximum = try constraint.maxIndex(gpa);
    defer maximum.deinit();
    try std.testing.expectEqual(@as(usize, 258), maximum.bits());
    for ([_]i32{ 0, 123, 124, 122, -1000, 1000 }) |number| {
        var value = try c.BigInt.fromInt(gpa, number);
        defer value.deinit();
        var rank = try constraint.toIndex(gpa, value);
        defer rank.deinit();
        var recovered = (try constraint.fromIndex(gpa, rank)).?;
        defer recovered.deinit();
        try std.testing.expect(value.eql(recovered));
    }
    var edge_rank = try constraint.toIndex(gpa, high);
    defer edge_rank.deinit();
    var edge = (try constraint.fromIndex(gpa, edge_rank)).?;
    defer edge.deinit();
    try std.testing.expect(high.eql(edge));
    var outside = try maximum.addInt(gpa, @as(u8, 1));
    defer outside.deinit();
    try std.testing.expectEqual(null, try constraint.fromIndex(gpa, outside));
    const narrow: c.IntegerChoice = .{ .min_value = target, .max_value = high, .shrink_towards = low };
    var simplest = try narrow.simplest(gpa);
    defer simplest.deinit();
    try std.testing.expect(simplest.eql(target));
    var unit = try narrow.unit(gpa);
    defer unit.deinit();
    try std.testing.expectEqual(@as(?i64, 124), unit.toInt(i64));
}

test "byte ranks cross the 128-bit boundary and retain leading zeros" {
    const constraint: c.BytesChoice = .{ .min_size = 0, .max_size = 32 };
    var bytes: [32]u8 = @splat(255);
    bytes[0] = 0;
    var rank = try constraint.toIndex(gpa, &bytes);
    defer rank.deinit();
    try std.testing.expect(rank.bits() > 128);
    const recovered = (try constraint.fromIndex(gpa, rank)).?;
    defer gpa.free(recovered);
    try std.testing.expectEqualSlices(u8, &bytes, recovered);
    var maximum = try constraint.maxIndex(gpa);
    defer maximum.deinit();
    var outside = try maximum.addInt(gpa, @as(u8, 1));
    defer outside.deinit();
    try std.testing.expectEqual(null, try constraint.fromIndex(gpa, outside));
}

test "string rank uses alphabet shrink order including supplementary codepoints" {
    var alphabet = try c.IntervalSet.init(gpa, &.{ .{ .start = 0x2f, .end = 0x32 }, .{ .start = 'A', .end = 'C' }, .{ .start = 0x10000, .end = 0x10001 } });
    defer alphabet.deinit();
    const constraint: c.StringChoice = .{ .intervals = &alphabet, .min_size = 0, .max_size = 3 };
    const simplest = try constraint.simplest(gpa);
    defer gpa.free(simplest);
    try std.testing.expectEqual(@as(usize, 0), simplest.len);
    const unit = try constraint.unit(gpa);
    defer gpa.free(unit);
    try std.testing.expectEqualSlices(u32, &.{'1'}, unit);
    const value = [_]u32{ '/', '0', 0x10000 };
    var rank = try constraint.toIndex(gpa, &value);
    defer rank.deinit();
    const recovered = (try constraint.fromIndex(gpa, rank)).?;
    defer gpa.free(recovered);
    try std.testing.expectEqualSlices(u32, &value, recovered);
    try std.testing.expect(!constraint.validate(&.{ '0', 'D' }));
    var maximum = try constraint.maxIndex(gpa);
    defer maximum.deinit();
    var outside = try maximum.addInt(gpa, @as(u8, 1));
    defer outside.deinit();
    try std.testing.expectEqual(null, try constraint.fromIndex(gpa, outside));
}

test "float constraints retain signed zeros and NaN payloads" {
    const zero: c.FloatChoice = .{ .min_value = -0.0, .max_value = -0.0, .allow_nan = false, .allow_infinity = false, .smallest_nonzero_magnitude = 0x1p-1074 };
    try std.testing.expect(zero.validate(-0.0));
    try std.testing.expect(!zero.validate(0.0));
    try std.testing.expectEqual(@as(u64, 1) << 63, @as(u64, @bitCast(try zero.simplest())));
    const all: c.FloatChoice = .{ .min_value = -std.math.inf(f64), .max_value = std.math.inf(f64), .allow_nan = true, .allow_infinity = true, .smallest_nonzero_magnitude = 0x1p-1074 };
    for ([_]u64{ 0, 0x8000000000000000, 0x3ff0000000000000, 0x3ff8000000000000, 0x7ff0000000000000, 0xfff0000000000000, 0x7ff8000000000123, 0xfff8000000000321 }) |bits| {
        const value: f64 = @bitCast(bits);
        var rank = try all.toIndex(gpa, value);
        defer rank.deinit();
        const recovered = (try all.fromIndex(rank)).?;
        try std.testing.expectEqual(bits, @as(u64, @bitCast(recovered)));
    }
}

fn snapshotSurvivesOwner(allocator: std.mem.Allocator) !void {
    var lower = lowered: {
        const stream = blk: {
            var constraint: c.IntegerChoice = constraint: {
                var min = try c.BigInt.fromInt(allocator, @as(i32, -10));
                errdefer min.deinit();
                var max = try c.BigInt.fromInt(allocator, @as(i32, 10));
                errdefer max.deinit();
                break :constraint .{ .min_value = min, .max_value = max, .shrink_towards = try c.BigInt.fromInt(allocator, @as(i32, 0)) };
            };
            defer constraint.deinit();
            var source = c.ChoiceNode.integer(&constraint, try c.BigInt.fromInt(allocator, @as(i32, 7)), false);
            defer source.deinit(allocator);
            break :blk try c.RealizedStream.create(allocator, &.{source}, &.{});
        };
        defer stream.release();
        try std.testing.expectEqual(@as(?i64, 7), stream.nodes[0].data.integer.value.toInt(i64));
        break :lowered try stream.nodes[0].withSimplest(allocator);
    };
    defer lower.deinit(allocator);
    try std.testing.expectEqual(@as(?i64, 0), lower.data.integer.value.toInt(i64));
    try std.testing.expectEqual(@as(?i64, -10), lower.data.integer.constraint.min_value.toInt(i64));
}

test "realized snapshots own constraints after a testcase is freed" {
    try snapshotSurvivesOwner(gpa);
}

test "snapshot construction releases partial ownership on allocation failure" {
    try std.testing.checkAllAllocationFailures(gpa, snapshotSurvivesOwner, .{});
}

test "clone identity ignores realized metadata and hashes identically" {
    const node = c.ChoiceNode.boolean(.{ .p = 0.75 }, true, true);
    const stream = try c.RealizedStream.create(gpa, &.{node}, &.{.{ .start = 0, .end = 1, .label = 123, .depth = 0, .parent = null, .discarded = false }});
    defer stream.release();
    var realized: c.ChoiceValue = .{ .clone = try c.CloneRecord.fromStream(gpa, stream) };
    defer realized.deinit(gpa);
    var bare: c.ChoiceValue = .{ .clone = try c.CloneRecord.fromValuesCopy(gpa, &.{.{ .boolean = true }}) };
    defer bare.deinit(gpa);
    try std.testing.expect(realized.eql(&bare));
    try std.testing.expectEqual(realized.hash(), bare.hash());
    try std.testing.expectEqual(@as(usize, 2), c.flattenedValuesLen(&.{bare}));
    const plain = c.ChoiceNode.boolean(.{ .p = 0.75 }, true, false);
    const cloned = c.ChoiceNode.cloneStream(stream, false);
    defer cloned.data.clone.release();
    try std.testing.expectEqual(std.math.Order.lt, try c.nodesOrder(gpa, &.{plain}, &.{cloned}));
}

import pathlib
import re
import subprocess
from generate_primitives import PIN

HERE=pathlib.Path(__file__).resolve().parent
upstream=pathlib.Path.home()/".cache/hegel-zig"/("hegel-rust-"+PIN)
if subprocess.check_output(["git","-C",str(upstream),"rev-parse","HEAD"],text=True).strip()!=PIN:
    raise RuntimeError("upstream revision changed")
source=(upstream/"hegel-c/src/native/draws/special.rs").read_text()
def item(pattern):
    match=re.search(pattern,source)
    if not match: raise RuntimeError(pattern)
    start=source.index('{',match.start());depth=1;end=start+1
    while depth:
        depth+=(source[end]=='{')-(source[end]=='}');end+=1
    return source[match.start():end].replace('pub(crate) ','pub ')
parts=['use std::net::{Ipv4Addr,Ipv6Addr}; type InternalError=String; macro_rules! hegel_internal_assert { ($p:expr, $($t:tt)*) => {if !$p{return Err(format!($($t)*));}}; }']
for name in ['Date','Time','DateTime']:
    parts+=['#[derive(Clone,Copy,Debug)]'+item(r'pub struct '+name+r'\b')]
for name in ['V4Network','V6Network']:
    parts+=[item(r'struct '+name+r'\b')]
for name in ['days_in_month','days_from_civil','civil_from_days','time_to_ns','time_from_ns','parse_v4_cidr','parse_v6_cidr']:
    parts+=[item(r'(?:pub\(crate\) )?fn '+name+r'\b')]
for v in [4,6]:
    parts+=[re.search(r'const SPECIAL_IPV'+str(v)+r'_CIDRS:.*?= &\[.*?\];',source,re.S).group()]
parts+=[(HERE/'special_oracle.rs.in').read_text()]
work=HERE.parents[1]/'work/special-oracle';work.mkdir(parents=True,exist_ok=True)
(work/'main.rs').write_text('\n'.join(parts))
subprocess.run(['rustc','--edition=2024','-Awarnings',str(work/'main.rs'),'-o',str(work/'oracle')],check=True)
(HERE/'fixtures/special.tsv').write_bytes(subprocess.check_output([str(work/'oracle')]))

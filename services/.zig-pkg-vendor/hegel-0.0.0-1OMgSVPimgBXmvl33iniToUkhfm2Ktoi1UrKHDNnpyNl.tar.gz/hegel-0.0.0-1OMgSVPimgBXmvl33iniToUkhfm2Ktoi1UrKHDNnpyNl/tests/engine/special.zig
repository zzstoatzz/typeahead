const std = @import("std");
const special = @import("draws").special;
fn parse(comptime T: type, t: []const u8) !T {
    return std.fmt.parseInt(T, t, 10);
}
test "calendar and CIDR arithmetic matches pinned Rust" {
    var lines = std.mem.splitScalar(u8, @embedFile("fixtures/special.tsv"), '\n');
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var fields = std.mem.splitScalar(u8, line, '\t');
        const kind = fields.next().?[0];
        switch (kind) {
            'D' => {
                const date: special.Date = .{ .year = try parse(i32, fields.next().?), .month = try parse(u8, fields.next().?), .day = try parse(u8, fields.next().?) };
                const days = try parse(i64, fields.next().?);
                try std.testing.expectEqual(days, special.daysFromCivil(date));
                try std.testing.expectEqual(date, special.civilFromDays(days));
            },
            'T' => {
                const time: special.Time = .{ .hour = try parse(u8, fields.next().?), .minute = try parse(u8, fields.next().?), .second = try parse(u8, fields.next().?), .nanosecond = try parse(u32, fields.next().?) };
                const ns = try parse(i64, fields.next().?);
                try std.testing.expectEqual(ns, special.timeToNs(time));
                try std.testing.expectEqual(time, special.timeFromNs(ns));
            },
            '4' => {
                const net = try special.parseV4Cidr(fields.next().?);
                try std.testing.expectEqual(try parse(u32, fields.next().?), net.base);
                try std.testing.expectEqual(try parse(u32, fields.next().?), net.size_minus_1);
            },
            '6' => {
                const net = try special.parseV6Cidr(fields.next().?);
                try std.testing.expectEqual(try parse(u128, fields.next().?), net.base);
                try std.testing.expectEqual(try parse(u128, fields.next().?), net.size_minus_1);
            },
            else => return error.UnknownKind,
        }
    }
}

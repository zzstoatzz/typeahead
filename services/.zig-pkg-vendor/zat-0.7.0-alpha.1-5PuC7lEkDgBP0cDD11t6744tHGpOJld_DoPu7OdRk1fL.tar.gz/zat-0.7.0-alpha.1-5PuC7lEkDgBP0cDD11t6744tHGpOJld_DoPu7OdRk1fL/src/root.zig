//! zat - zig atproto primitives
//!
//! parsing and validation for AT Protocol string formats.
//! DID resolution for did:plc and did:web.

// syntax primitives
pub const Tid = @import("internal/syntax/tid.zig").Tid;
pub const Did = @import("internal/syntax/did.zig").Did;
pub const Handle = @import("internal/syntax/handle.zig").Handle;
pub const Nsid = @import("internal/syntax/nsid.zig").Nsid;
pub const Rkey = @import("internal/syntax/rkey.zig").Rkey;
pub const AtUri = @import("internal/syntax/at_uri.zig").AtUri;
pub const Datetime = @import("internal/syntax/Datetime.zig");

// identity resolution
pub const DidDocument = @import("internal/identity/did_document.zig").DidDocument;
pub const DidResolver = @import("internal/identity/did_resolver.zig").DidResolver;
pub const HandleResolver = @import("internal/identity/handle_resolver.zig").HandleResolver;

// xrpc
pub const HttpTransport = @import("zttp").Client;
pub const XrpcClient = @import("internal/xrpc/xrpc.zig").XrpcClient;

// json helpers
pub const json = @import("internal/xrpc/json.zig");

// crypto
pub const jwt = @import("internal/crypto/jwt.zig");
pub const Jwt = jwt.Jwt;
pub const multibase = @import("internal/crypto/multibase.zig");
pub const multicodec = @import("internal/crypto/multicodec.zig");
pub const Keypair = @import("internal/crypto/keypair.zig").Keypair;

// oauth
pub const oauth = @import("internal/oauth.zig");

// repo
pub const mst = @import("internal/repo/mst.zig");
pub const cbor = @import("internal/repo/cbor.zig");
pub const Cid = cbor.Cid;
pub const car = @import("internal/repo/car.zig");
pub const star = @import("internal/repo/star.zig");

// repo commit layer: build/sign, load, and verify
const repo = @import("internal/repo/repo.zig");
pub const verifyCommitSignature = repo.verifyCommitSignature;
pub const verifyCommitCar = repo.verifyCommitCar;
pub const CommitVerifyResult = repo.CommitVerifyResult;
pub const signCommit = repo.signCommit;
pub const CommitParams = repo.CommitParams;
pub const SignedCommit = repo.SignedCommit;

// sync 1.1: commit diff verification
pub const MstOperation = mst.Operation;
pub const Commit = repo.Commit;
pub const LoadedCommitCar = repo.LoadedCommitCar;
pub const loadCommitFromCAR = repo.loadCommitFromCAR;
pub const verifyCommitDiff = repo.verifyCommitDiff;
pub const CommitDiffResult = repo.CommitDiffResult;

// sync / streaming
const sync = @import("internal/streaming/sync.zig");
pub const CommitAction = sync.CommitAction;
pub const EventKind = sync.EventKind;
pub const AccountStatus = sync.AccountStatus;

// jetstream (the v1 /subscribe client). DEPRECATED HOME: the jetstream
// service SDK now lives at tangled.org/zat.dev/jetstream (ArchiveBackfill
// moved there; the subscribeEvents v2 client lands there). this v1 client
// stays functional here until its consumers migrate.
pub const jetstream = @import("internal/streaming/jetstream.zig");
pub const JetstreamClient = jetstream.JetstreamClient;
pub const JetstreamEvent = jetstream.Event;

// firehose (raw CBOR event stream)

pub const firehose = @import("internal/streaming/firehose.zig");
pub const FirehoseClient = firehose.FirehoseClient;
pub const FirehoseEvent = firehose.Event;

// labeler event stream (com.atproto.label.subscribeLabels) and the label type
pub const labels = @import("internal/streaming/labels.zig");
pub const Label = labels.Label;
pub const LabelClient = labels.LabelClient;
pub const LabelEvent = labels.Event;

// Test-only imports:
// - inline tests in implementation files stay next to private helpers/fixtures
// - *_test.zig files are supplemental black-box, stress, and compliance suites
//   that must be imported explicitly because Zig does not auto-discover tests
// - interop fixtures are resolved by build.zig's lazy dependency wiring
//
// A re-export like `pub const Foo = @import("f.zig").Foo` does NOT reach f.zig
// in a test build: nothing references the decl, so the file is never resolved
// and its tests never run — nor are its function bodies ever analyzed, so even
// outright compile errors stay hidden. Every file carrying a `test` block must
// be listed here. `zig build test` fails if one is missing; see build.zig.
comptime {
    if (@import("builtin").is_test) {
        _ = @import("internal/crypto/jwt.zig");
        _ = @import("internal/crypto/keypair.zig");
        _ = @import("internal/crypto/multibase.zig");
        _ = @import("internal/crypto/multicodec.zig");
        _ = @import("internal/identity/did_document.zig");
        _ = @import("internal/identity/did_resolver.zig");
        _ = @import("internal/identity/handle_resolver.zig");
        _ = @import("internal/identity/network_safety.zig");
        _ = @import("internal/oauth/client.zig");
        _ = @import("internal/oauth/primitives.zig");
        _ = @import("internal/repo/car.zig");
        _ = star;
        _ = @import("internal/repo/star_interop_test.zig");
        _ = @import("internal/repo/car_test.zig");
        _ = @import("internal/repo/cbor.zig");
        _ = @import("internal/repo/cbor_read_test.zig");
        _ = @import("internal/repo/cbor_rfc8949_test.zig");
        _ = @import("internal/repo/cbor_test.zig");
        _ = @import("internal/repo/cbor_write_test.zig");
        _ = @import("internal/repo/mst.zig");
        _ = @import("internal/repo/mst_test.zig");
        _ = @import("internal/repo/repo.zig");
        _ = @import("internal/streaming/firehose.zig");
        _ = @import("internal/streaming/jetstream.zig");
        _ = @import("internal/streaming/labels.zig");
        _ = @import("internal/streaming/sync.zig");
        _ = @import("internal/syntax/at_uri.zig");
        _ = Datetime;
        _ = @import("internal/syntax/did.zig");
        _ = @import("internal/syntax/handle.zig");
        _ = @import("internal/syntax/nsid.zig");
        _ = @import("internal/syntax/rkey.zig");
        _ = @import("internal/syntax/tid.zig");
        _ = @import("internal/testing/interop_tests.zig");
        _ = @import("internal/xrpc/json.zig");
        _ = @import("internal/xrpc/xrpc.zig");
    }
}

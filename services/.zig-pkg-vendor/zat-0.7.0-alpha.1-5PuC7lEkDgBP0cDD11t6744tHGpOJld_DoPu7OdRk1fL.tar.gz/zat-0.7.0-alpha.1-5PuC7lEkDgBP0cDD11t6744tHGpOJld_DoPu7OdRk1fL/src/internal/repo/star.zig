//! STAR framing (https://dasl.ing/star.html, 2026-11-03) and the public
//! ATProto repository profiles. Values stream independently of keys.
const std = @import("std");
const cbor = @import("cbor.zig");
const mst = @import("mst.zig");

pub const magic = "*l\x01\x00";
const max_metadata_bytes = 64 * 1024 * 1024;
const max_key_bytes = 64 * 1024 * 1024;
const max_value_bytes: u64 = 64 * 1024 * 1024 * 1024;
const max_varint_bytes = 9;
const control_pair: u8 = 0x01;
const control_end: u8 = 0x00;

pub const Limits = struct {
    max_metadata: usize = 64 * 1024,
    max_key: usize = 64 * 1024,
    max_value: u64 = 64 * 1024 * 1024 * 1024,
};

/// Key bytes borrow Reader until next(). Consume value_len bytes via readValue.
pub const Entry = struct { key: []const u8, value_len: u64 };
pub const Reader = struct {
    input: *std.Io.Reader,
    allocator: std.mem.Allocator,
    arena: std.heap.ArenaAllocator,
    metadata: cbor.Value,
    key_buffer: std.ArrayList(u8) = .empty,
    remaining: u64 = 0,
    limits: Limits,
    finished: bool = false,
    failed: bool = false,

    pub fn init(allocator: std.mem.Allocator, input: *std.Io.Reader, limits: Limits) !Reader {
        if (!std.mem.eql(u8, try input.takeArray(4), magic)) return error.InvalidMagic;
        const length = try lengthPrefix(input);
        if (length > max_metadata_bytes or length > limits.max_metadata) return error.MetadataTooLarge;
        var arena = std.heap.ArenaAllocator.init(allocator);
        errdefer arena.deinit();
        const a = arena.allocator();
        const bytes = try a.alloc(u8, @intCast(length));
        try input.readSliceAll(bytes);
        const metadata = try cbor.decodeAll(a, bytes);
        try validateMetadata(metadata);
        const canonical = try cbor.encodeAlloc(a, metadata);
        if (!std.mem.eql(u8, bytes, canonical)) return error.NonCanonicalMetadata;
        return .{ .input = input, .allocator = allocator, .arena = arena, .metadata = metadata, .limits = limits };
    }

    pub fn deinit(self: *Reader) void {
        self.key_buffer.deinit(self.allocator);
        self.arena.deinit();
        self.* = undefined;
    }

    pub fn next(self: *Reader) !?Entry {
        if (self.failed) return error.ReaderFailed;
        if (self.remaining != 0) return error.ValueNotConsumed;
        if (self.finished) return null;
        errdefer self.failed = true;
        switch (try self.input.takeByte()) {
            control_end => {
                if (self.input.takeByte()) |_| return error.BytesAfterEnd else |err| switch (err) {
                    error.EndOfStream => {},
                    else => return err,
                }
                self.finished = true;
                return null;
            },
            control_pair => {},
            else => return error.InvalidControlByte,
        }
        const length = try lengthPrefix(self.input);
        if (length > max_key_bytes or length > self.limits.max_key) return error.KeyTooLarge;
        try self.key_buffer.resize(self.allocator, @intCast(length));
        try self.input.readSliceAll(self.key_buffer.items);
        const value_len = try lengthPrefix(self.input);
        if (value_len > max_value_bytes or value_len > self.limits.max_value) return error.ValueTooLarge;
        self.remaining = value_len;
        return .{ .key = self.key_buffer.items, .value_len = value_len };
    }

    /// Fills up to buffer.len bytes, never consuming the following pair.
    pub fn readValue(self: *Reader, buffer: []u8) !usize {
        if (self.failed) return error.ReaderFailed;
        if (buffer.len == 0 and self.remaining != 0) return error.EmptyBuffer;
        errdefer self.failed = true;
        const count: usize = @intCast(@min(self.remaining, buffer.len));
        try self.input.readSliceAll(buffer[0..count]);
        self.remaining -= count;
        return count;
    }
};

fn validateMetadata(value: cbor.Value) !void {
    if (value != .map or value.getString("$type") == null) return error.InvalidMetadata;
    try validateDrisl(value);
}

fn validateDrisl(value: cbor.Value) error{ InvalidCid, NonCanonicalMetadata }!void {
    switch (value) {
        .cid => |cid| {
            const raw = cid.raw;
            if (raw.len != 36 or raw[0] != 1 or (raw[1] != 0x55 and raw[1] != 0x71) or
                raw[2] != 0x12 or raw[3] != 0x20) return error.InvalidCid;
        },
        .float => |number| {
            if (@as(u64, @bitCast(number)) == 0x8000000000000000) return error.NonCanonicalMetadata;
        },
        .array => |items| for (items) |item| try validateDrisl(item),
        .map => |fields| for (fields) |field| try validateDrisl(field.value),
        else => {},
    }
}

fn lengthPrefix(input: *std.Io.Reader) !u64 {
    var bytes: [max_varint_bytes]u8 = undefined;
    for (0..bytes.len) |i| {
        const byte = try input.takeByte();
        bytes[i] = byte;
        if (byte & 0x80 == 0) {
            var position: usize = 0;
            return cbor.readUvarintMinimal(bytes[0 .. i + 1], &position) orelse error.InvalidVarint;
        }
    }
    return error.InvalidVarint;
}

/// Frames pairs onto output after a canonical metadata header. Values can be
/// supplied in chunks between beginPair and the next pair; finish flushes.
pub const Writer = struct {
    output: *std.Io.Writer,
    allocator: std.mem.Allocator,
    options: Options,
    previous_key: std.ArrayList(u8) = .empty,
    remaining: u64 = 0,
    started: bool = false,
    failed: bool = false,

    pub const Options = struct {
        limits: Limits = .{},
        /// Reject keys that do not strictly increase bytewise, as the atproto
        /// repository profiles require.
        ordered_keys: bool = false,
    };

    /// Writes the magic and metadata. Rejects metadata a Reader would reject.
    pub fn init(allocator: std.mem.Allocator, output: *std.Io.Writer, metadata: cbor.Value, options: Options) !Writer {
        try validateMetadata(metadata);
        const bytes = try cbor.encodeAlloc(allocator, metadata);
        defer allocator.free(bytes);
        if (bytes.len > max_metadata_bytes or bytes.len > options.limits.max_metadata) return error.MetadataTooLarge;
        var arena = std.heap.ArenaAllocator.init(allocator);
        defer arena.deinit();
        _ = try cbor.decodeAll(arena.allocator(), bytes);
        try output.writeAll(magic);
        try cbor.writeUvarint(output, bytes.len);
        try output.writeAll(bytes);
        return .{ .output = output, .allocator = allocator, .options = options };
    }

    pub fn deinit(self: *Writer) void {
        self.previous_key.deinit(self.allocator);
        self.* = undefined;
    }

    pub fn writePair(self: *Writer, key: []const u8, value: []const u8) !void {
        try self.beginPair(key, value.len);
        try self.writeValue(value);
    }

    /// Frames the key and value length; exactly value_len bytes must follow via writeValue.
    pub fn beginPair(self: *Writer, key: []const u8, value_len: u64) !void {
        if (self.failed) return error.WriterFailed;
        if (self.remaining != 0) return error.ValueNotComplete;
        if (key.len > max_key_bytes or key.len > self.options.limits.max_key) return error.KeyTooLarge;
        if (value_len > max_value_bytes or value_len > self.options.limits.max_value) return error.ValueTooLarge;
        if (self.options.ordered_keys) {
            if (self.started and !std.mem.lessThan(u8, self.previous_key.items, key)) return error.KeysNotIncreasing;
            self.previous_key.clearRetainingCapacity();
            try self.previous_key.appendSlice(self.allocator, key);
        }
        self.started = true;
        errdefer self.failed = true;
        try self.output.writeByte(control_pair);
        try cbor.writeUvarint(self.output, key.len);
        try self.output.writeAll(key);
        try cbor.writeUvarint(self.output, value_len);
        self.remaining = value_len;
    }

    pub fn writeValue(self: *Writer, bytes: []const u8) !void {
        if (self.failed) return error.WriterFailed;
        if (bytes.len > self.remaining) return error.ValueOverrun;
        errdefer self.failed = true;
        try self.output.writeAll(bytes);
        self.remaining -= bytes.len;
    }

    /// Writes the end byte and flushes. Required: an archive without it is
    /// truncated and every reader rejects it. Fails if a value begun with
    /// beginPair is incomplete.
    pub fn finish(self: *Writer) !void {
        if (self.failed) return error.WriterFailed;
        if (self.remaining != 0) return error.ValueNotComplete;
        errdefer self.failed = true;
        try self.output.writeByte(control_end);
        try self.output.flush();
    }
};

/// Record bytes borrow PublicRepoReader until next(). Results remain provisional
/// until next() returns null, after verifying the reconstructed root.
pub const Record = struct { key: []const u8, record: []const u8 };
pub const PublicRepoReader = struct {
    reader: Reader,
    verifier: RootVerifier,
    root: [36]u8,
    subtree: bool,
    record_buffer: std.ArrayList(u8) = .empty,
    finished: bool = false,
    failed: bool = false,

    pub fn init(allocator: std.mem.Allocator, input: *std.Io.Reader, limits: Limits) !PublicRepoReader {
        var profile_limits = limits;
        profile_limits.max_key = @min(limits.max_key, 830);
        profile_limits.max_value = @min(limits.max_value, 1024 * 1024);
        var reader = try Reader.init(allocator, input, profile_limits);
        errdefer reader.deinit();
        const kind = reader.metadata.getString("$type").?;
        const subtree = std.mem.eql(u8, kind, "atproto-public-repo-subtree");
        if (!subtree and !std.mem.eql(u8, kind, "atproto-public-repo")) return error.UnsupportedProfile;
        const data = reader.metadata.get("data") orelse return error.InvalidCommit;
        if (data != .cid or !validCid(data.cid.raw)) return error.InvalidCommit;
        if (!subtree) try validateCommit(reader.metadata);
        return .{ .reader = reader, .verifier = RootVerifier.init(allocator), .root = data.cid.raw[0..36].*, .subtree = subtree };
    }

    pub fn deinit(self: *PublicRepoReader) void {
        self.record_buffer.deinit(self.reader.allocator);
        self.verifier.deinit();
        self.reader.deinit();
        self.* = undefined;
    }

    /// Verifies the commit with a caller-resolved account key. Root verification
    /// still requires consuming the entire archive; neither establishes freshness.
    pub fn verifyCommit(self: *const PublicRepoReader, key: @import("../crypto/multicodec.zig").PublicKey, expected_did: []const u8) !void {
        if (self.subtree) return error.UnsignedSubtree;
        var arena = std.heap.ArenaAllocator.init(self.reader.allocator);
        defer arena.deinit();
        const a = arena.allocator();
        var fields: std.ArrayList(cbor.Value.MapEntry) = .empty;
        for (self.reader.metadata.map) |field| {
            if (!std.mem.eql(u8, field.key, "$type")) try fields.append(a, field);
        }
        try @import("repo.zig").verifyCommitSignature(a, .{ .map = fields.items }, key, expected_did);
    }

    pub fn next(self: *PublicRepoReader) !?Record {
        if (self.failed) return error.ReaderFailed;
        if (self.finished) return null;
        errdefer self.failed = true;
        const entry = try self.reader.next() orelse {
            try self.verifier.finish(self.root);
            self.finished = true;
            return null;
        };
        const slash = std.mem.indexOfScalar(u8, entry.key, '/') orelse return error.InvalidRecordPath;
        if (@import("../syntax/nsid.zig").Nsid.parse(entry.key[0..slash]) == null or
            @import("../syntax/rkey.zig").Rkey.parse(entry.key[slash + 1 ..]) == null) return error.InvalidRecordPath;
        try self.record_buffer.resize(self.reader.allocator, @intCast(entry.value_len));
        _ = try self.reader.readValue(self.record_buffer.items);
        const record: Record = .{ .key = entry.key, .record = self.record_buffer.items };
        try self.verifier.add(record);
        return record;
    }
};

fn validCid(raw: []const u8) bool {
    return raw.len == 36 and std.mem.eql(u8, raw[0..4], &.{ 1, 0x71, 0x12, 0x20 });
}

fn validateCommit(value: cbor.Value) !void {
    const did = value.getString("did") orelse return error.InvalidCommit;
    const rev = value.getString("rev") orelse return error.InvalidCommit;
    const sig = value.getBytes("sig") orelse return error.InvalidCommit;
    const prev = value.get("prev") orelse return error.InvalidCommit;
    if (@import("../syntax/did.zig").Did.parse(did) == null or
        @import("../syntax/tid.zig").Tid.parse(rev) == null or
        value.getInt("version") != 3 or sig.len != 64) return error.InvalidCommit;
    if (prev != .null and (prev != .cid or !validCid(prev.cid.raw))) return error.InvalidCommit;
}
/// Verifies record integrity against an MST root, not account authenticity.
pub const RootVerifier = struct {
    builder: mst.SortedBuilder,
    closed: bool = false,

    pub fn init(allocator: std.mem.Allocator) RootVerifier {
        return .{ .builder = mst.SortedBuilder.init(allocator) };
    }
    pub fn deinit(self: *RootVerifier) void {
        self.builder.deinit();
        self.* = undefined;
    }
    pub fn add(self: *RootVerifier, entry: Record) !void {
        if (self.closed) return error.VerifierClosed;
        errdefer self.closed = true;
        var raw: [36]u8 = undefined;
        raw[0..4].* = .{ 1, 0x71, 0x12, 0x20 };
        std.crypto.hash.sha2.Sha256.hash(entry.record, raw[4..36], .{});
        try self.builder.add(entry.key, .{ .raw = &raw });
    }
    pub fn finish(self: *RootVerifier, expected: [36]u8) !void {
        if (self.closed) return error.VerifierClosed;
        self.closed = true;
        const actual = try self.builder.finish();
        if (!std.mem.eql(u8, &actual, &expected)) return error.RootMismatch;
    }
};

fn archive(a: std.mem.Allocator, metadata: cbor.Value, records: []const Record) ![]u8 {
    var out: std.Io.Writer.Allocating = .init(a);
    defer out.deinit();
    var writer = try Writer.init(a, &out.writer, metadata, .{});
    defer writer.deinit();
    for (records) |record| try writer.writePair(record.key, record.record);
    try writer.finish();
    return a.dupe(u8, out.written());
}

fn archiveRaw(a: std.mem.Allocator, bytes: []const u8, records: []const Record) ![]u8 {
    var out: std.Io.Writer.Allocating = .init(a);
    defer out.deinit();
    try out.writer.writeAll(magic);
    try cbor.writeUvarint(&out.writer, bytes.len);
    try out.writer.writeAll(bytes);
    for (records) |record| {
        try out.writer.writeByte(control_pair);
        try cbor.writeUvarint(&out.writer, record.key.len);
        try out.writer.writeAll(record.key);
        try cbor.writeUvarint(&out.writer, record.record.len);
        try out.writer.writeAll(record.record);
    }
    try out.writer.writeByte(control_end);
    return a.dupe(u8, out.written());
}

/// An archive's magic and metadata without its end byte, for appending frames.
fn headerOnly(a: std.mem.Allocator, metadata: cbor.Value) ![]u8 {
    const bytes = try archive(a, metadata, &.{});
    return a.realloc(bytes, bytes.len - 1);
}

const test_meta: cbor.Value = .{ .map = &.{.{ .key = "$type", .value = .{ .text = "test" } }} };

test "generic byte pairs allow empty, unordered, duplicate, and non UTF8 keys" {
    const a = std.testing.allocator;
    const bytes = try archive(a, test_meta, &.{
        .{ .key = &.{0xff}, .record = "abcde" },
        .{ .key = "", .record = "" },
        .{ .key = "", .record = "z" },
    });
    defer a.free(bytes);
    var input = std.Io.Reader.fixed(bytes);
    var reader = try Reader.init(a, &input, .{});
    defer reader.deinit();
    try std.testing.expectEqualStrings(&.{0xff}, (try reader.next()).?.key);
    try std.testing.expectError(error.ValueNotConsumed, reader.next());
    var buffer: [3]u8 = undefined;
    try std.testing.expectEqual(@as(usize, 3), try reader.readValue(&buffer));
    try std.testing.expectEqualStrings("abc", &buffer);
    try std.testing.expectEqual(@as(usize, 2), try reader.readValue(&buffer));
    try std.testing.expectEqualStrings("de", buffer[0..2]);
    try std.testing.expectEqual(@as(usize, 0), try reader.readValue(&buffer));
    try std.testing.expectEqual(@as(u64, 0), (try reader.next()).?.value_len);
    try std.testing.expectEqual(@as(u64, 1), (try reader.next()).?.value_len);
    _ = try reader.readValue(&buffer);
    try std.testing.expect(try reader.next() == null);
    try std.testing.expect(try reader.next() == null);
}

test "malformed metadata is rejected even without authentication" {
    const a = std.testing.allocator;
    const invalid = [_]struct { bytes: []const u8, err: anyerror }{
        .{ .bytes = &.{0xff}, .err = error.IndefiniteLength },
        .{ .bytes = &.{0xa0}, .err = error.InvalidMetadata },
        .{ .bytes = &.{0x80}, .err = error.InvalidMetadata },
        .{ .bytes = "\xa1\x65$type\x01", .err = error.InvalidMetadata },
        .{ .bytes = "\xa1\x65$type\x64test\x00", .err = error.TrailingBytes },
        .{ .bytes = "\xa2\x65$type\x64test\x61z\x00", .err = error.NonCanonicalMetadata },
        .{ .bytes = "\xa2\x65$type\x64test\x65$type\x64test", .err = error.DuplicateMapKey },
    };
    for (invalid) |case| {
        const bytes = try archiveRaw(a, case.bytes, &.{});
        defer a.free(bytes);
        var input = std.Io.Reader.fixed(bytes);
        try std.testing.expectError(case.err, Reader.init(a, &input, .{}));
    }
}

test "framing requires control bytes and enforces varints and size limits" {
    const a = std.testing.allocator;
    const header = try headerOnly(a, test_meta);
    defer a.free(header);
    const cases = [_]struct { suffix: []const u8, err: anyerror }{
        .{ .suffix = "", .err = error.EndOfStream },
        .{ .suffix = "\x02", .err = error.InvalidControlByte },
        .{ .suffix = "\x00\x00", .err = error.BytesAfterEnd },
        .{ .suffix = "\x01\x80", .err = error.EndOfStream },
        .{ .suffix = "\x01\x80\x00", .err = error.InvalidVarint },
        .{ .suffix = "\x01" ++ @as([max_varint_bytes]u8, @splat(0xff)), .err = error.InvalidVarint },
        .{ .suffix = "\x01\x80\x80\x80\x80\x80\x80\x80\x80\x80\x01", .err = error.InvalidVarint },
        .{ .suffix = "\x01\x01", .err = error.EndOfStream },
        .{ .suffix = "\x01\x00", .err = error.EndOfStream },
        .{ .suffix = "\x01\x81\x80\x80\x20", .err = error.KeyTooLarge },
        .{ .suffix = "\x01\x00\x81\x80\x80\x80\x80\x02", .err = error.ValueTooLarge },
    };
    for (cases) |case| {
        const bytes = try std.mem.concat(a, u8, &.{ header, case.suffix });
        defer a.free(bytes);
        var input = std.Io.Reader.fixed(bytes);
        var reader = try Reader.init(a, &input, .{});
        defer reader.deinit();
        try std.testing.expectError(case.err, reader.next());
        try std.testing.expectError(error.ReaderFailed, reader.next());
    }
    var old = std.Io.Reader.fixed("*l\x00\x01");
    try std.testing.expectError(error.InvalidMagic, Reader.init(a, &old, .{}));
    var oversized = std.Io.Reader.fixed("*l\x01\x00\x81\x80\x80\x20");
    try std.testing.expectError(error.MetadataTooLarge, Reader.init(a, &oversized, .{}));
    const empty = try archive(a, test_meta, &.{});
    defer a.free(empty);
    var constrained = std.Io.Reader.fixed(empty);
    try std.testing.expectError(error.MetadataTooLarge, Reader.init(a, &constrained, .{ .max_metadata = 1 }));
}

test "64 GiB value length needs no value-sized allocation and truncation is sticky" {
    const a = std.testing.allocator;
    const header = try headerOnly(a, test_meta);
    defer a.free(header);
    const bytes = try std.mem.concat(a, u8, &.{ header, "\x01\x00\x80\x80\x80\x80\x80\x02" });
    defer a.free(bytes);
    var memory: [8192]u8 = undefined;
    var fixed = std.heap.FixedBufferAllocator.init(&memory);
    var input = std.Io.Reader.fixed(bytes);
    var reader = try Reader.init(fixed.allocator(), &input, .{});
    defer reader.deinit();
    try std.testing.expectEqual(@as(u64, 64) * 1024 * 1024 * 1024, (try reader.next()).?.value_len);
    var buffer: [1]u8 = undefined;
    try std.testing.expectError(error.EndOfStream, reader.readValue(&buffer));
    try std.testing.expectError(error.ReaderFailed, reader.next());
}

fn subtreeArchive(a: std.mem.Allocator, records: []const Record) ![]u8 {
    var builder = mst.SortedBuilder.init(a);
    defer builder.deinit();
    for (records) |record| {
        const cid = try cbor.Cid.forDagCbor(a, record.record);
        defer a.free(cid.raw);
        try builder.add(record.key, cid);
    }
    const root = try builder.finish();
    return archive(a, .{ .map = &.{
        .{ .key = "$type", .value = .{ .text = "atproto-public-repo-subtree" } },
        .{ .key = "data", .value = .{ .cid = .{ .raw = &root } } },
    } }, records);
}

fn consume(a: std.mem.Allocator, bytes: []const u8) !usize {
    var input = std.Io.Reader.fixed(bytes);
    var reader = try PublicRepoReader.init(a, &input, .{});
    defer reader.deinit();
    var count: usize = 0;
    while (try reader.next()) |_| count += 1;
    return count;
}

test "profile verifies at EOF and rejects changed or omitted records" {
    const a = std.testing.allocator;
    const records = [_]Record{
        .{ .key = "app.bsky.feed.post/a", .record = &.{0xa0} },
        .{ .key = "app.bsky.feed.post/b", .record = &.{0xa0} },
    };
    const bytes = try subtreeArchive(a, &records);
    defer a.free(bytes);
    try std.testing.expectEqual(@as(usize, 2), try consume(a, bytes));
    bytes[bytes.len - 2] ^= 1;
    try std.testing.expectError(error.RootMismatch, consume(a, bytes));
    bytes[bytes.len - 2] ^= 1;
    var input = std.Io.Reader.fixed(bytes);
    var reader = try PublicRepoReader.init(a, &input, .{});
    defer reader.deinit();
    _ = try reader.next();
    try std.testing.expectError(error.EndOfStream, consume(a, bytes[0..input.seek]));
    const omitted = try archive(a, reader.reader.metadata, records[0..1]);
    defer a.free(omitted);
    try std.testing.expectError(error.RootMismatch, consume(a, omitted));
}

test "profile enforces paths and order independently of framing" {
    const a = std.testing.allocator;
    const bytes = try subtreeArchive(a, &.{.{ .key = "bad/path", .record = &.{0xa0} }});
    defer a.free(bytes);
    try std.testing.expectError(error.InvalidRecordPath, consume(a, bytes));
    const good = try subtreeArchive(a, &.{.{ .key = "app.bsky.feed.post/a", .record = &.{0xa0} }});
    defer a.free(good);
    var input = std.Io.Reader.fixed(good);
    var reader = try Reader.init(a, &input, .{});
    defer reader.deinit();
    const repeated = try archive(a, reader.metadata, &.{
        .{ .key = "app.bsky.feed.post/a", .record = &.{0xa0} },
        .{ .key = "app.bsky.feed.post/a", .record = &.{0xa0} },
    });
    defer a.free(repeated);
    try std.testing.expectError(error.KeysNotIncreasing, consume(a, repeated));
}

test "public commit authenticates both curves without signing profile type" {
    const Keypair = @import("../crypto/keypair.zig").Keypair;
    inline for (.{ .p256, .secp256k1 }) |kind| {
        var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
        defer arena.deinit();
        const a = arena.allocator();
        var builder = mst.SortedBuilder.init(a);
        defer builder.deinit();
        const root = try builder.finish();
        const keypair = try Keypair.fromSecretKey(kind, @splat(7));
        const pubkey = try keypair.publicKey();
        const public_key = @import("../crypto/multicodec.zig").PublicKey{ .key_type = kind, .raw = &pubkey };
        const did = "did:plc:ewvi7nxzyoun6zhxrhs64oiz";
        const signed = try @import("repo.zig").signCommit(a, .{ .did = did, .rev = "3jzfcijpj2z2a", .data = .{ .raw = &root } }, &keypair);
        const decoded = try cbor.decodeAll(a, signed.bytes);
        const fields = try a.alloc(cbor.Value.MapEntry, decoded.map.len + 1);
        @memcpy(fields[0..decoded.map.len], decoded.map);
        fields[decoded.map.len] = .{ .key = "$type", .value = .{ .text = "atproto-public-repo" } };
        const bytes = try archive(a, .{ .map = fields }, &.{});
        var input = std.Io.Reader.fixed(bytes);
        var reader = try PublicRepoReader.init(std.testing.allocator, &input, .{});
        defer reader.deinit();
        try reader.verifyCommit(public_key, did);
        try std.testing.expectError(error.InvalidCommit, reader.verifyCommit(public_key, "did:plc:other"));
        const wrong_pair = try Keypair.fromSecretKey(kind, @splat(8));
        const wrong = try wrong_pair.publicKey();
        try std.testing.expectError(error.SignatureVerificationFailed, reader.verifyCommit(.{ .key_type = kind, .raw = &wrong }, did));
        try std.testing.expect(try reader.next() == null);

        var out: std.Io.Writer.Allocating = .init(a);
        defer out.deinit();
        try out.writer.writeByte(0xa8);
        for ([_][]const u8{ "did", "rev", "sig", "prev", "sig", "data", "$type", "version" }, 0..) |name, i| {
            try cbor.encode(a, &out.writer, .{ .text = name });
            const value: cbor.Value = if (i == 4) .{ .bytes = &@as([64]u8, @splat(0)) } else if (i == 6) .{ .text = "atproto-public-repo" } else decoded.get(name).?;
            try cbor.encode(a, &out.writer, value);
        }
        const duplicate = try archiveRaw(a, out.written(), &.{});
        var duplicate_input = std.Io.Reader.fixed(duplicate);
        try std.testing.expectError(error.NonCanonicalMetadata, PublicRepoReader.init(std.testing.allocator, &duplicate_input, .{}));
        for (fields) |*field| {
            if (std.mem.eql(u8, field.key, "rev")) field.value = .{ .text = "not-a-tid" };
        }
        const invalid = try archive(a, .{ .map = fields }, &.{});
        var invalid_input = std.Io.Reader.fixed(invalid);
        try std.testing.expectError(error.InvalidCommit, PublicRepoReader.init(std.testing.allocator, &invalid_input, .{}));
    }
}

fn allocationExercise(a: std.mem.Allocator, bytes: []const u8) !void {
    _ = try consume(a, bytes);
}

test "profile releases allocations on every injected failure" {
    const a = std.testing.allocator;
    const bytes = try subtreeArchive(a, &.{
        .{ .key = "app.bsky.feed.post/a", .record = &.{0xa0} },
        .{ .key = "app.bsky.feed.post/b", .record = &.{0xa0} },
    });
    defer a.free(bytes);
    try std.testing.checkAllAllocationFailures(a, allocationExercise, .{bytes});
}

test "profile limits oversized values before allocating a record" {
    const a = std.testing.allocator;
    const empty = try subtreeArchive(a, &.{});
    defer a.free(empty);
    const header = empty[0 .. empty.len - 1];
    const bytes = try std.mem.concat(a, u8, &.{ header, "\x01\x14app.bsky.feed.post/a\x81\x80\x40" });
    defer a.free(bytes);
    try std.testing.expectError(error.ValueTooLarge, consume(a, bytes));
}

test "unsigned subtrees cannot authenticate and unknown profiles stay generic" {
    const a = std.testing.allocator;
    const bytes = try subtreeArchive(a, &.{});
    defer a.free(bytes);
    var input = std.Io.Reader.fixed(bytes);
    var reader = try PublicRepoReader.init(a, &input, .{});
    defer reader.deinit();
    try std.testing.expectError(error.UnsignedSubtree, reader.verifyCommit(.{ .key_type = .p256, .raw = "" }, "did:plc:other"));
    try std.testing.expect(try reader.next() == null);
    const unknown = try archive(a, test_meta, &.{});
    defer a.free(unknown);
    var unknown_input = std.Io.Reader.fixed(unknown);
    try std.testing.expectError(error.UnsupportedProfile, PublicRepoReader.init(a, &unknown_input, .{}));
}

test "v1 fixture agrees with Rust MST and releases allocations" {
    const bytes = @embedFile("testdata/star-v1.star");
    try std.testing.expectEqual(@as(usize, 300), try consume(std.testing.allocator, bytes));
}

test "metadata enforces DRISL negative zero and CID constraints recursively" {
    const a = std.testing.allocator;
    const cases = [_]struct { value: cbor.Value, err: anyerror }{
        .{ .value = .{ .array = &.{.{ .float = -0.0 }} }, .err = error.NonCanonicalMetadata },
        .{ .value = .{ .cid = .{ .raw = &.{ 1, 0x71 } } }, .err = error.InvalidCid },
    };
    for (cases) |case| {
        const metadata: cbor.Value = .{ .map = &.{
            .{ .key = "$type", .value = .{ .text = "test" } },
            .{ .key = "nested", .value = case.value },
        } };
        const encoded = try cbor.encodeAlloc(a, metadata);
        defer a.free(encoded);
        const bytes = try archiveRaw(a, encoded, &.{});
        defer a.free(bytes);
        var input = std.Io.Reader.fixed(bytes);
        try std.testing.expectError(case.err, Reader.init(a, &input, .{}));
        var out: std.Io.Writer.Allocating = .init(a);
        defer out.deinit();
        try std.testing.expectError(case.err, Writer.init(a, &out.writer, metadata, .{}));
    }
}

test "writer streams values and enforces lengths" {
    const a = std.testing.allocator;
    var out: std.Io.Writer.Allocating = .init(a);
    defer out.deinit();
    var writer = try Writer.init(a, &out.writer, test_meta, .{});
    defer writer.deinit();
    try writer.beginPair("k", 5);
    try std.testing.expectError(error.ValueNotComplete, writer.beginPair("x", 0));
    try std.testing.expectError(error.ValueNotComplete, writer.finish());
    try writer.writeValue("ab");
    try std.testing.expectError(error.ValueOverrun, writer.writeValue("cdef"));
    try writer.writeValue("cde");
    try writer.finish();

    var good: std.Io.Writer.Allocating = .init(a);
    defer good.deinit();
    var streaming = try Writer.init(a, &good.writer, test_meta, .{ .limits = .{ .max_value = 5 } });
    defer streaming.deinit();
    try streaming.beginPair("k", 5);
    try streaming.writeValue("ab");
    try streaming.writeValue("cde");
    try std.testing.expectError(error.ValueTooLarge, streaming.beginPair("x", 6));
    try streaming.finish();
    const expected = try archive(a, test_meta, &.{.{ .key = "k", .record = "abcde" }});
    defer a.free(expected);
    try std.testing.expectEqualSlices(u8, expected, good.written());
}

test "writer rejects metadata a reader would reject" {
    const a = std.testing.allocator;
    var out: std.Io.Writer.Allocating = .init(a);
    defer out.deinit();
    const invalid = [_]struct { value: cbor.Value, err: anyerror }{
        .{ .value = .{ .map = &.{} }, .err = error.InvalidMetadata },
        .{ .value = .{ .text = "test" }, .err = error.InvalidMetadata },
        .{ .value = .{ .map = &.{.{ .key = "$type", .value = .{ .unsigned = 1 } }} }, .err = error.InvalidMetadata },
        .{ .value = .{ .map = &.{ .{ .key = "$type", .value = .{ .text = "t" } }, .{ .key = "$type", .value = .{ .text = "t" } } } }, .err = error.DuplicateMapKey },
        .{ .value = .{ .map = &.{ .{ .key = "$type", .value = .{ .text = "t" } }, .{ .key = "f", .value = .{ .float = -0.0 } } } }, .err = error.NonCanonicalMetadata },
    };
    for (invalid) |case| try std.testing.expectError(case.err, Writer.init(a, &out.writer, case.value, .{}));
    try std.testing.expectError(error.MetadataTooLarge, Writer.init(a, &out.writer, test_meta, .{ .limits = .{ .max_metadata = 1 } }));
    try std.testing.expectEqual(@as(usize, 0), out.written().len);
}

test "writer orders keys on request and sorts metadata canonically" {
    const a = std.testing.allocator;
    var out: std.Io.Writer.Allocating = .init(a);
    defer out.deinit();
    const unsorted: cbor.Value = .{ .map = &.{ .{ .key = "$type", .value = .{ .text = "test" } }, .{ .key = "a", .value = .{ .unsigned = 1 } } } };
    var writer = try Writer.init(a, &out.writer, unsorted, .{ .ordered_keys = true });
    defer writer.deinit();
    try writer.writePair("a", "");
    try writer.writePair("b", "1");
    try std.testing.expectError(error.KeysNotIncreasing, writer.writePair("b", ""));
    try std.testing.expectError(error.KeysNotIncreasing, writer.writePair("", ""));
    try writer.writePair("c", "");
    try writer.finish();
    var input = std.Io.Reader.fixed(out.written());
    var reader = try Reader.init(a, &input, .{});
    defer reader.deinit();
    try std.testing.expectEqualStrings("a", reader.metadata.map[0].key);
    try std.testing.expectEqualStrings("$type", reader.metadata.map[1].key);
    try std.testing.expectEqualStrings("a", (try reader.next()).?.key);
    try std.testing.expectEqualStrings("b", (try reader.next()).?.key);
    var buffer: [1]u8 = undefined;
    _ = try reader.readValue(&buffer);
    try std.testing.expectEqualStrings("c", (try reader.next()).?.key);
    try std.testing.expect(try reader.next() == null);
}

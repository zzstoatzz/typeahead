//! supplemental MST tests ported from Atmos (Go implementation).
//!
//! mst.zig keeps inline tests near private helpers, reference fixtures, and
//! implementation-sensitive behavior. this file is the external suite for
//! black-box API behavior, stress cases, and compliance gaps.

const std = @import("std");
const mst = @import("mst.zig");
const cbor = @import("cbor.zig");
const car = @import("car.zig");
const Mst = mst.Mst;
const Cid = cbor.Cid;

// known empty tree CID from the AT Protocol reference implementations
const empty_tree_cid = "bafyreie5737gdxlw5i64vzichcalba3z2v5n6icifvx5xytvske7mr3hpm";

fn testCid(a: std.mem.Allocator, data: []const u8) !Cid {
    return Cid.forDagCbor(a, data);
}

// === edge cases ===

test "get from empty tree returns null" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    const tree = Mst.init(a);
    try std.testing.expect(tree.get("anything") == null);
    try std.testing.expect(tree.get("app.bsky.feed.post/abc123") == null);
}

test "delete nonexistent key is no-op" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    var tree = Mst.init(a);
    const cid = try testCid(a, "value");
    try tree.put("key1", cid);

    // deleting a key that doesn't exist should not error
    try tree.delete("nonexistent");

    // original key still present
    try std.testing.expect(tree.get("key1") != null);
}

test "remove all keys produces empty tree CID" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    var tree = Mst.init(a);
    const cid = try testCid(a, "value");

    try tree.put("key1", cid);
    try tree.put("key2", cid);
    try tree.put("key3", cid);

    try tree.delete("key1");
    try tree.delete("key2");
    try tree.delete("key3");

    const root = try tree.rootCid();
    const expected = try mst.parseCidString(a, empty_tree_cid);
    try std.testing.expectEqualSlices(u8, expected.raw, root.raw);
}

test "update existing key changes value" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    var tree = Mst.init(a);
    const cid1 = try testCid(a, "v1");
    const cid2 = try testCid(a, "v2");

    try tree.put("key", cid1);
    try std.testing.expectEqualSlices(u8, cid1.raw, tree.get("key").?.raw);

    try tree.put("key", cid2);
    try std.testing.expectEqualSlices(u8, cid2.raw, tree.get("key").?.raw);
}

// === order independence ===

test "order independence: 50 keys in 3 orderings produce same root CID" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    // generate 50 deterministic keys
    const n = 50;
    var keys: [n][]const u8 = undefined;
    var key_bufs: [n][64]u8 = undefined;
    for (0..n) |i| {
        const len = std.fmt.bufPrint(&key_bufs[i], "app.bsky.feed.post/{d:0>12}", .{i}) catch unreachable;
        keys[i] = len;
    }

    const val = try testCid(a, "value");

    // forward order
    var tree1 = Mst.init(a);
    for (keys) |k| try tree1.put(k, val);
    const cid1 = try tree1.rootCid();

    // reverse order
    var tree2 = Mst.init(a);
    var i: usize = n;
    while (i > 0) {
        i -= 1;
        try tree2.put(keys[i], val);
    }
    const cid2 = try tree2.rootCid();

    // interleaved order (even indices first, then odd)
    var tree3 = Mst.init(a);
    for (0..n) |j| {
        if (j % 2 == 0) try tree3.put(keys[j], val);
    }
    for (0..n) |j| {
        if (j % 2 == 1) try tree3.put(keys[j], val);
    }
    const cid3 = try tree3.rootCid();

    try std.testing.expectEqualSlices(u8, cid1.raw, cid2.raw);
    try std.testing.expectEqualSlices(u8, cid1.raw, cid3.raw);
}

// === stress tests ===

test "100 keys: all retrievable after insertion" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    const n = 100;
    var tree = Mst.init(a);
    var key_bufs: [n][64]u8 = undefined;
    var keys: [n][]const u8 = undefined;
    var cids: [n]Cid = undefined;

    for (0..n) |i| {
        keys[i] = std.fmt.bufPrint(&key_bufs[i], "app.bsky.feed.post/{d:0>12}", .{i}) catch unreachable;
        cids[i] = try testCid(a, keys[i]);
        try tree.put(keys[i], cids[i]);
    }

    // all keys retrievable with correct CIDs
    for (0..n) |i| {
        const got = tree.get(keys[i]) orelse {
            std.debug.print("FAIL: key {s} not found after insert\n", .{keys[i]});
            return error.TestExpectedEqual;
        };
        try std.testing.expectEqualSlices(u8, cids[i].raw, got.raw);
    }
}

test "insert 50 keys then remove every other" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    const n = 50;
    var tree = Mst.init(a);
    var key_bufs: [n][64]u8 = undefined;
    var keys: [n][]const u8 = undefined;
    const val = try testCid(a, "value");

    for (0..n) |i| {
        keys[i] = std.fmt.bufPrint(&key_bufs[i], "app.bsky.feed.post/{d:0>12}", .{i}) catch unreachable;
        try tree.put(keys[i], val);
    }

    // remove even-indexed keys
    for (0..n) |i| {
        if (i % 2 == 0) try tree.delete(keys[i]);
    }

    // verify: even keys gone, odd keys present
    for (0..n) |i| {
        const got = tree.get(keys[i]);
        if (i % 2 == 0) {
            try std.testing.expect(got == null);
        } else {
            try std.testing.expect(got != null);
        }
    }
}

// === height edge cases ===

test "keyHeight: empty key has height 0" {
    try std.testing.expectEqual(@as(u32, 0), mst.keyHeight(""));
}

test "keyHeight: deterministic for same input" {
    const h1 = mst.keyHeight("app.bsky.feed.post/3jqfcqzm3fo2j");
    const h2 = mst.keyHeight("app.bsky.feed.post/3jqfcqzm3fo2j");
    try std.testing.expectEqual(h1, h2);
}

test "keyHeight: different keys can have different heights" {
    // "blue" is known to have height 1 from the interop fixtures
    try std.testing.expectEqual(@as(u32, 1), mst.keyHeight("blue"));
    try std.testing.expectEqual(@as(u32, 0), mst.keyHeight("asdf"));
}

// === allocation failure safety ===

fn decodeMstNodeImpl(backing: std.mem.Allocator, data: []const u8) !void {
    var arena = std.heap.ArenaAllocator.init(backing);
    defer arena.deinit();
    _ = try mst.decodeMstNode(arena.allocator(), data);
}

test "checkAllAllocationFailures: decodeMstNode" {
    // build a valid MST node CBOR by hand:
    // map(2) { "e": [ map(4){k,p,t,v}, map(4){k,p,t,v} ], "l": null }
    var setup_arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer setup_arena.deinit();
    const sa = setup_arena.allocator();

    const val_cid = try Cid.forDagCbor(sa, "value");

    // build entry maps (the "k","p","t","v" maps inside the "e" array)
    const entry1: cbor.Value = .{ .map = &.{
        .{ .key = "k", .value = .{ .bytes = "app.bsky.feed.post/aaa" } },
        .{ .key = "p", .value = .{ .unsigned = 0 } },
        .{ .key = "t", .value = .null },
        .{ .key = "v", .value = .{ .cid = val_cid } },
    } };
    const entry2: cbor.Value = .{
        .map = &.{
            .{ .key = "k", .value = .{ .bytes = "bbb" } },
            .{ .key = "p", .value = .{ .unsigned = 22 } }, // prefix_len = shared with prev key
            .{ .key = "t", .value = .null },
            .{ .key = "v", .value = .{ .cid = val_cid } },
        },
    };

    const node: cbor.Value = .{ .map = &.{
        .{ .key = "e", .value = .{ .array = &.{ entry1, entry2 } } },
        .{ .key = "l", .value = .null },
    } };
    const encoded = try cbor.encodeAlloc(sa, node);

    try std.testing.checkAllAllocationFailures(
        std.testing.allocator,
        decodeMstNodeImpl,
        .{encoded},
    );
}

// === refused operations ===

/// a layer-3 key followed by a layer-1 key: the root holds only `top`, and
/// `below` sits two empty bridging nodes beneath it.
const refusal_top = "pbt.mst.key/0906";
const refusal_below = "pbt.mst.key/1524";

const RefusalFixture = struct {
    root: Cid,
    blocks: []const car.Block,

    fn init(a: std.mem.Allocator) !RefusalFixture {
        try std.testing.expectEqual(@as(u32, 3), mst.keyHeight(refusal_top));
        try std.testing.expectEqual(@as(u32, 1), mst.keyHeight(refusal_below));

        var tree = Mst.init(a);
        const value = try testCid(a, "value");
        try tree.put(refusal_top, value);
        try tree.put(refusal_below, value);

        var blocks: std.ArrayList(car.Block) = .empty;
        try tree.collectBlocks(&blocks);
        return .{ .root = try tree.rootCid(), .blocks = blocks.items };
    }

    fn rootBlock(self: RefusalFixture) car.Block {
        for (self.blocks) |block| {
            if (std.mem.eql(u8, block.cid_raw, self.root.raw)) return block;
        }
        unreachable;
    }
};

fn expectUnchangedAfterRefusedDelete(tree: *Mst, root: Cid) !void {
    try std.testing.expectError(error.PartialTree, tree.deleteReturn(refusal_top));

    try std.testing.expectEqualSlices(u8, root.raw, (try tree.rootCid()).raw);
    try std.testing.expectEqual(@as(?u32, 3), tree.root_layer);
    try std.testing.expectEqual(@as(usize, 1), tree.root.?.entries.items.len);
    try std.testing.expect(tree.get(refusal_top) != null);
}

test "deleteReturn refused by a partial tree leaves the tree unchanged" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    const fixture = try RefusalFixture.init(a);
    // only the root block: removing the root's one entry makes the stub
    // beneath it the next root, and nothing can resolve it
    var tree = try Mst.loadFromBlocks(a, .{ .roots = &.{}, .blocks = &.{fixture.rootBlock()} }, fixture.root.raw);

    try expectUnchangedAfterRefusedDelete(&tree, fixture.root);
}

test "deleteReturn refused by a failing block reader leaves the tree unchanged" {
    var arena = std.heap.ArenaAllocator.init(std.testing.allocator);
    defer arena.deinit();
    const a = arena.allocator();

    const fixture = try RefusalFixture.init(a);

    const RootOnly = struct {
        root: car.Block,

        fn get(ctx: *anyopaque, cid_raw: []const u8) anyerror!?[]const u8 {
            const self: *@This() = @ptrCast(@alignCast(ctx));
            return if (std.mem.eql(u8, cid_raw, self.root.cid_raw)) self.root.data else null;
        }
    };
    var reader: RootOnly = .{ .root = fixture.rootBlock() };
    var tree = try Mst.loadLazy(a, fixture.root.raw, .{ .ctx = &reader, .getFn = RootOnly.get });

    try expectUnchangedAfterRefusedDelete(&tree, fixture.root);
}

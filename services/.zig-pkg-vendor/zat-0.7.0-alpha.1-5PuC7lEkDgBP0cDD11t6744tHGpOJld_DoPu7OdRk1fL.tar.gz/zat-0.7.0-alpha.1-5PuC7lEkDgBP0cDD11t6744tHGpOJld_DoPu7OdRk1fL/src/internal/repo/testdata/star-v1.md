# STAR v1 fixture

`star-v1.star` contains 300 records in the `atproto-public-repo-subtree` profile.
Its MST root comes from Microcosm's Rust `MstStack`, independently of Zat.
The generator writes the published STAR framing (dasl.ing, 2026-11-03)
directly, with a control byte before each pair and an end byte; the archive
was converted to it from the earlier framing without changing its pairs.

Specification and MST implementation:
https://tangled.org/microcosm.blue/star/tree/512d0bee6bf49c7c4302d5917a1bb49c8da6fc0e

To regenerate, put `star-v1-generator.rs` at `src/main.rs` in a Rust 2024
binary crate and depend on `star-lite` via a local path to that revision's
`reference-impl/rust/star-lite`. Run `cargo run -- path/to/star-v1.star`.

Records are canonical CBOR maps containing `n` from 256 through 555. Metadata
is a canonical map with the computed `data` CID and the subtree `$type`.

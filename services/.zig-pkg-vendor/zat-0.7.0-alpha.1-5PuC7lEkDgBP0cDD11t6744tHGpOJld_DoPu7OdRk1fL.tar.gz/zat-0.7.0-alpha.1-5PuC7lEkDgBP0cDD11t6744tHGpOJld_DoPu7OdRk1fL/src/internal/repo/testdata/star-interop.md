# STAR v1 interop fixtures

`star-interop-valid.json`, `star-interop-invalid.json`, and
`star-interop-invalid-varint.json` are copied unchanged from bryan newbold's
Go STAR package at
https://tangled.org/bnewbold.net/cobalt/tree/a0b7ece/star/testdata
(`valid-star-fixtures.json`, `invalid-star-fixtures.json`,
`invalid-star-fixtures-varint.json`).

Each entry carries a `comment` and the archive as `star_hex`. Valid entries
also carry `decoded.pairs` as `key_hex` / `value_hex`. `star_interop_test.zig`
reads every valid archive, checks the pairs, and rewrites it through
`star.Writer` from the reader's metadata to the same bytes. Every invalid
archive must fail in `Reader.init` or while draining.

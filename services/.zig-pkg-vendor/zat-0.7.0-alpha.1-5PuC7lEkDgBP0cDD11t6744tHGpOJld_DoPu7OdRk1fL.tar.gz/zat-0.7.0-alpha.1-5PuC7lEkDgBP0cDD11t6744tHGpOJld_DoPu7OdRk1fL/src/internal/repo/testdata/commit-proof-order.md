# Ordered operation fixtures

These are original public subscribeRepos frames wrapped in diagnostic CBOR
packets with their verification public keys. They contain real record data.

- `commit-proof-delete-create.cbor`: zlay production rejected-proof capture
  from `lionsmane.us-east.host.bsky.network`, 2026-11-06; SHA-256
  `8755d96a42f9e05f6d98fac1730e84caea20f52687d8dbb317ef75e01f95a82b`.
- `commit-proof-shadow-delete-create.cbor`: zlay outgoing-stream shadow
  capture, 2026-11-06; original upstream was not captured; SHA-256
  `309e3069eaf232399723d5125e46fe40bd92f29f6588ee65030f99f3e5ddf391`.

Each frame contains delete followed by create at the same record path. Both
signatures verify, and reverse-order operation inversion reproduces `prevData`.
Create carries a `prev` field; the test maps it to a create operation, matching
zlay's existing parser. This fixture does not prescribe field-presence policy.

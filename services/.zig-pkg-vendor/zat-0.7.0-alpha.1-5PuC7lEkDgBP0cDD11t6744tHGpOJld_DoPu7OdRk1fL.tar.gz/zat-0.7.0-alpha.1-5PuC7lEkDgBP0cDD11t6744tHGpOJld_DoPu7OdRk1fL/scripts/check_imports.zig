const std = @import("std");

pub fn check(b: *std.Build) !?[]const u8 {
    const io = b.graph.io;
    const a = b.allocator;
    var root = try b.root.openDir(io, ".", .{});
    defer root.close(io);
    var files: std.ArrayList([]const u8) = .empty;
    try files.appendSlice(a, &.{ "build.zig", "build.zig.zon" });
    for ([_][]const u8{ "src", "scripts", "examples" }) |base| {
        // a dependency's copy ships only the paths build.zig.zon lists
        var dir = root.openDir(io, base, .{ .iterate = true }) catch |err| switch (err) {
            error.FileNotFound => continue,
            else => return err,
        };
        defer dir.close(io);
        b.dependOnDirectoryContents(b.path(base));
        var walker = try dir.walk(a);
        defer walker.deinit();
        while (try walker.next(io)) |entry| {
            const path = b.pathJoin(&.{ base, entry.path });
            if (entry.kind == .directory) b.dependOnDirectoryContents(b.path(path));
            if (entry.kind == .file and std.mem.endsWith(u8, path, ".zig")) {
                try files.append(a, try a.dupe(u8, path));
            }
        }
    }
    var errors: std.ArrayList(u8) = .empty;
    for (files.items) |file| {
        b.dependOnFileContents(b.path(file));
        const bytes = try root.readFileAlloc(io, file, a, .limited(4 << 20));
        const source = try a.dupeSentinel(u8, bytes, 0);
        var tokens = std.zig.Tokenizer.init(source);
        while (true) {
            const token = tokens.next();
            if (token.tag == .eof) break;
            if (token.tag != .builtin) continue;
            const name = source[token.loc.start..token.loc.end];
            if (!std.mem.eql(u8, name, "@import") and !std.mem.eql(u8, name, "@embedFile")) continue;
            if (tokens.next().tag != .l_paren) continue;
            const literal = tokens.next();
            if (literal.tag != .string_literal) continue;
            const path = try std.zig.string_literal.parseAlloc(a, source[literal.loc.start..literal.loc.end]);
            if (std.mem.indexOfAny(u8, path, "/\\.") == null) continue;
            const normalized = try std.fs.path.resolvePosix(a, &.{ "/", std.fs.path.dirname(file) orelse ".", path });
            if (try existsExact(io, root, normalized[1..])) continue;
            const line = 1 + std.mem.count(u8, source[0..token.loc.start], "\n");
            try errors.print(a, "{s}:{d}: missing or incorrectly cased {s} path: \"{s}\"\n", .{ file, line, name, path });
        }
    }
    return if (errors.items.len == 0) null else errors.items;
}

fn existsExact(io: std.Io, root: std.Io.Dir, path: []const u8) !bool {
    var dir = try root.openDir(io, ".", .{ .iterate = true });
    defer dir.close(io);
    var parts = std.mem.tokenizeScalar(u8, path, '/');
    while (parts.next()) |part| {
        var iter = dir.iterate();
        const found = while (try iter.next(io)) |entry| {
            if (std.mem.eql(u8, entry.name, part)) break true;
        } else false;
        if (!found) return false;
        if (parts.peek() == null) return true;
        const next = try dir.openDir(io, part, .{ .iterate = true });
        dir.close(io);
        dir = next;
    }
    return false;
}

test "exact paths reject wrong file and directory case" {
    const io = std.testing.io;
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.createDir(io, "Syntax", .default_dir);
    const file = try tmp.dir.createFile(io, "Syntax/Datetime.zig", .{});
    file.close(io);
    try std.testing.expect(try existsExact(io, tmp.dir, "Syntax/Datetime.zig"));
    try std.testing.expect(!try existsExact(io, tmp.dir, "Syntax/datetime.zig"));
    try std.testing.expect(!try existsExact(io, tmp.dir, "syntax/Datetime.zig"));
    try std.testing.expect(!try existsExact(io, tmp.dir, "Syntax/Missing.zig"));
}

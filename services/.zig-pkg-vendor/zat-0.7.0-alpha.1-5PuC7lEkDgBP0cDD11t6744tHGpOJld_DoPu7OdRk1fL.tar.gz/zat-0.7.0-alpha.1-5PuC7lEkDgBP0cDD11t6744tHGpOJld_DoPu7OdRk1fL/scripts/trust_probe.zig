const std = @import("std");
const zat = @import("zat");

pub fn main(init: std.process.Init) !void {
    var handles = zat.HandleResolver.init(init.io, init.gpa);
    defer handles.deinit();
    if (handles.resolve(zat.Handle.parse("emudhra.divy.zone").?)) |did| {
        init.gpa.free(did);
        return error.CompromisedHandleAccepted;
    } else |err| {
        if (err != error.NoDnsRecordsFound and err != error.NoValidDidFound) return err;
        std.debug.print("compromised handle rejected after DNS fallback: {s}\n", .{@errorName(err)});
    }
    var dids = zat.DidResolver.init(init.io, init.gpa);
    defer dids.deinit();
    if (dids.resolve(zat.Did.parse("did:web:emudhra.divy.zone").?)) |doc| {
        var unexpected = doc;
        unexpected.deinit();
        return error.CompromisedDidAccepted;
    } else |err| {
        if (err != error.TlsInitializationFailed) return err;
        std.debug.print("compromised DID rejected: {s}\n", .{@errorName(err)});
    }
    const control_did = try handles.resolve(zat.Handle.parse("atproto.com").?);
    defer init.gpa.free(control_did);
    var control = try dids.resolve(zat.Did.parse(control_did).?);
    defer control.deinit();
    if (control.pdsEndpoint() == null) return error.ControlFailed;
    std.debug.print("atproto.com control resolved handle and DID\n", .{});
}
